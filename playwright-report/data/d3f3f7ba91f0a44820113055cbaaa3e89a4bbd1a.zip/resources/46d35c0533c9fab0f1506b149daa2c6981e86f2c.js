import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/dashboard/collectors.tsx?tsr-split=component");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport14_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03f72e91";
import { Users, Plus, TrendingUp, Wallet, Edit, Eye, CirclePlus, MapPin, MoreVertical } from "/node_modules/.vite/deps/lucide-react.js?v=03f72e91";
import { DashboardLayout } from "/src/components/layout/DashboardLayout.tsx";
import { Sidebar } from "/src/components/layout/Sidebar.tsx";
import { Header } from "/src/components/layout/Header.tsx";
import { DataTable } from "/src/components/ui/DataTable.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { KPICard } from "/src/components/ui/KPICard.tsx";
import { Card, CardContent } from "/src/components/ui/Card.tsx";
import { ActiveBadge, InactiveBadge, PendingBadge } from "/src/components/ui/StatusBadge.tsx";
import { RegisterCollectorModal } from "/src/components/business/RegisterCollectorModal.tsx";
import { QuickTransferModal } from "/src/components/business/QuickTransferModal.tsx";
import { ExpandableRowContent } from "/src/components/ui/ExpandableRow.tsx";
import { cn } from "/src/lib/design-system.ts";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/collectors.tsx?tsr-split=component";
import __vite__cjsImport14_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
var _s = $RefreshSig$();
function CollectorsManagement() {
	_s();
	const [_searchTerm, _setSearchTerm] = useState("");
	const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
	const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
	const [selectedCollector, setSelectedCollector] = useState(null);
	const handleRegisterCollector = (data) => {
		console.log(...typeof window === "undefined" ? ["\x1B[35mLOG\x1B[39m \x1B[94m/src/routes/dashboard/collectors.tsx:38:5\x1B[39m\n → "] : [
			"%cLOG%c %cGo to Source: http://localhost:4000/__tsd/open-source?source=%2Fsrc%2Froutes%2Fdashboard%2Fcollectors.tsx%3A38%3A5%c \n → ",
			"color:#A0A",
			"color:#FFF",
			"color:#55F",
			"color:#FFF"
		], "Registering collector:", data);
		// TODO: Integrate with API
	};
	const sidebarItems = [
		{
			label: "Painel",
			icon: TrendingUp,
			href: "/dashboard/overview"
		},
		{
			label: "Gestão",
			icon: Users,
			href: "/dashboard/savers"
		},
		{
			label: "Cobradores",
			icon: CirclePlus,
			href: "/dashboard/collectors",
			isActive: true
		},
		{
			label: "Financeiro",
			icon: Wallet,
			href: "/dashboard/financial"
		},
		{
			label: "Relatórios",
			icon: TrendingUp,
			href: "/dashboard/reports"
		}
	];
	const mockCollectors = [
		{
			id: "1",
			name: "Arsénio Matusse",
			phone: "+258 84 123 4567",
			clients: 47,
			monthlyVolume: 125400,
			difference: 1200,
			status: "active"
		},
		{
			id: "2",
			name: "Célia Mondlane",
			phone: "+258 82 987 6543",
			clients: 32,
			monthlyVolume: 84200,
			difference: -4500,
			status: "suspended"
		},
		{
			id: "3",
			name: "Filipe Nyusi Jr.",
			phone: "+258 87 555 0192",
			clients: 58,
			monthlyVolume: 156e3,
			difference: 0,
			status: "active"
		},
		{
			id: "4",
			name: "Maria Machava",
			phone: "+258 86 444 5678",
			clients: 41,
			monthlyVolume: 105800,
			difference: 800,
			status: "active"
		},
		{
			id: "5",
			name: "João Sitoe",
			phone: "+258 85 333 4455",
			clients: 35,
			monthlyVolume: 89e3,
			difference: -1500,
			status: "suspended"
		}
	];
	const kpiData = [
		{
			title: "Total de Cobradores",
			value: String(mockCollectors.length),
			subtext: "+2 este mês",
			icon: Users,
			color: "text-emerald-600 bg-emerald-50 border-emerald-100",
			isDebt: false
		},
		{
			title: "Cobradores Ativos",
			value: String(mockCollectors.filter((c) => c.status === "active").length),
			subtext: `de ${mockCollectors.length} total`,
			icon: Users,
			color: "text-emerald-600 bg-emerald-50 border-emerald-100",
			isDebt: false
		},
		{
			title: "Arrecadado (Mês)",
			value: "450.000 MZN",
			subtext: "Total colectado",
			icon: Wallet,
			color: "text-blue-600 bg-blue-50 border-blue-100",
			isDebt: false
		},
		{
			title: "Meta de Colecta",
			value: "82%",
			subtext: "Progresso mensal",
			icon: TrendingUp,
			color: "text-amber-600 bg-amber-50 border-amber-100",
			isDebt: false
		}
	];
	const columns = [
		{
			key: "name",
			header: "COBRADOR",
			render: (value, row) => /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-3",
				"data-tsd-source": "/src/routes/dashboard/collectors.tsx:136:49",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					"data-tsd-source": "/src/routes/dashboard/collectors.tsx:137:11",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-semibold",
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:138:13",
						children: String(row.name).charAt(0)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: cn("absolute -bottom-1 -right-1 w-3 h-3 border-2 border-white rounded-full", row.status === "active" ? "bg-emerald-500" : row.status === "suspended" ? "bg-red-500" : "bg-slate-400"),
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:141:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 141,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/routes/dashboard/collectors.tsx:143:11",
					children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "font-bold text-sm text-slate-900",
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:144:13",
						children: String(value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400 font-mono",
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:145:13",
						children: row.phone
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 143,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 136,
				columnNumber: 49
			}, this)
		},
		{
			key: "clients",
			header: "CLIENTES",
			render: (value) => /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-1",
				"data-tsd-source": "/src/routes/dashboard/collectors.tsx:151:33",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "font-bold text-sm text-slate-900",
					"data-tsd-source": "/src/routes/dashboard/collectors.tsx:152:11",
					children: String(value)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 152,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs text-slate-400",
					"data-tsd-source": "/src/routes/dashboard/collectors.tsx:153:11",
					children: "Ticantes"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 153,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 151,
				columnNumber: 33
			}, this)
		},
		{
			key: "monthlyVolume",
			header: "VOLUME MENSAL",
			render: (value) => /* @__PURE__ */ _jsxDEV("span", {
				className: "font-mono text-sm font-bold text-slate-900 text-right block",
				"data-tsd-source": "/src/routes/dashboard/collectors.tsx:158:33",
				children: [Number(value).toLocaleString(), " MZN"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 158,
				columnNumber: 33
			}, this)
		},
		{
			key: "difference",
			header: "DIFERENÇA",
			render: (value) => /* @__PURE__ */ _jsxDEV("span", {
				className: cn("font-mono text-sm text-right block", Number(value) > 0 ? "text-emerald-600" : Number(value) < 0 ? "text-red-600" : "text-slate-500"),
				"data-tsd-source": "/src/routes/dashboard/collectors.tsx:164:33",
				children: [
					Number(value) > 0 ? "+" : "",
					Number(value).toLocaleString(),
					" MZN"
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 164,
				columnNumber: 33
			}, this)
		},
		{
			key: "status",
			header: "ESTADO",
			render: (_, row) => {
				if (row.status === "active") return /* @__PURE__ */ _jsxDEV(ActiveBadge, { "data-tsd-source": "/src/routes/dashboard/collectors.tsx:171:43" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 171,
					columnNumber: 43
				}, this);
				if (row.status === "suspended") return /* @__PURE__ */ _jsxDEV(PendingBadge, {
					"data-tsd-source": "/src/routes/dashboard/collectors.tsx:172:46",
					children: "Em Análise"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 172,
					columnNumber: 46
				}, this);
				return /* @__PURE__ */ _jsxDEV(InactiveBadge, { "data-tsd-source": "/src/routes/dashboard/collectors.tsx:173:14" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 173,
					columnNumber: 14
				}, this);
			}
		},
		{
			key: "actions",
			header: "ACÇÕES",
			render: (_, _row) => /* @__PURE__ */ _jsxDEV("div", {
				className: "flex justify-center gap-2",
				"data-tsd-source": "/src/routes/dashboard/collectors.tsx:178:46",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-all",
						title: "Atribuir Clientes",
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:179:11",
						children: /* @__PURE__ */ _jsxDEV(CirclePlus, {
							size: 16,
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:180:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-all",
						title: "Editar",
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:182:11",
						children: /* @__PURE__ */ _jsxDEV(Edit, {
							size: 16,
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:183:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 182,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-all",
						title: "Ver Relatório",
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:185:11",
						children: /* @__PURE__ */ _jsxDEV(Eye, {
							size: 16,
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:186:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 178,
				columnNumber: 46
			}, this)
		}
	];
	const renderExpandedRow = (row) => /* @__PURE__ */ _jsxDEV(ExpandableRowContent, {
		title: `Desempenho de ${row.name}`,
		onViewFullDetails: () => console.log(...typeof window === "undefined" ? ["\x1B[35mLOG\x1B[39m \x1B[94m/src/routes/dashboard/collectors.tsx:190:132\x1B[39m\n → "] : [
			"%cLOG%c %cGo to Source: http://localhost:4000/__tsd/open-source?source=%2Fsrc%2Froutes%2Fdashboard%2Fcollectors.tsx%3A190%3A132%c \n → ",
			"color:#A0A",
			"color:#FFF",
			"color:#55F",
			"color:#FFF"
		], "Navigate to full details:", row.id),
		"data-tsd-source": "/src/routes/dashboard/collectors.tsx:190:49",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-3 gap-4",
				"data-tsd-source": "/src/routes/dashboard/collectors.tsx:191:7",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:192:9",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-xs text-slate-500",
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:193:11",
							children: [/* @__PURE__ */ _jsxDEV(TrendingUp, {
								size: 14,
								"data-tsd-source": "/src/routes/dashboard/collectors.tsx:194:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/routes/dashboard/collectors.tsx:195:13",
								children: "Volume Mensal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-lg font-bold text-slate-900",
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:197:11",
							children: [row.monthlyVolume.toLocaleString(), " MZN"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:199:9",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-xs text-slate-500",
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:200:11",
							children: [/* @__PURE__ */ _jsxDEV(Users, {
								size: 14,
								"data-tsd-source": "/src/routes/dashboard/collectors.tsx:201:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 201,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/routes/dashboard/collectors.tsx:202:13",
								children: "Clientes Activos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-lg font-bold text-slate-900",
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:204:11",
							children: [row.clients, " Ticantes"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 199,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:206:9",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-xs text-slate-500",
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:207:11",
							children: [/* @__PURE__ */ _jsxDEV(Wallet, {
								size: 14,
								"data-tsd-source": "/src/routes/dashboard/collectors.tsx:208:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 208,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/routes/dashboard/collectors.tsx:209:13",
								children: "Diferença"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: cn("text-lg font-bold", row.difference > 0 ? "text-emerald-600" : row.difference < 0 ? "text-red-600" : "text-slate-900"),
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:211:11",
							children: [
								row.difference > 0 ? "+" : "",
								row.difference.toLocaleString(),
								" MZN"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 211,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 206,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 191,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "pt-4 border-t border-slate-200",
				"data-tsd-source": "/src/routes/dashboard/collectors.tsx:217:7",
				children: [/* @__PURE__ */ _jsxDEV("h5", {
					className: "text-xs font-semibold text-slate-500 uppercase mb-3",
					"data-tsd-source": "/src/routes/dashboard/collectors.tsx:218:9",
					children: "Acções Rápidas"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 218,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap gap-2",
					"data-tsd-source": "/src/routes/dashboard/collectors.tsx:219:9",
					children: [
						/* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							variant: "outline",
							leftIcon: /* @__PURE__ */ _jsxDEV(MapPin, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 220,
								columnNumber: 57
							}, this),
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:220:11",
							children: "Ver Localização"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 220,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							variant: "outline",
							leftIcon: /* @__PURE__ */ _jsxDEV(CirclePlus, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 223,
								columnNumber: 57
							}, this),
							onClick: (e) => {
								e.stopPropagation();
								setSelectedCollector(row);
								setIsTransferModalOpen(true);
							},
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:223:11",
							children: "Transferir Clientes"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 223,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							variant: "outline",
							leftIcon: /* @__PURE__ */ _jsxDEV(MoreVertical, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 230,
								columnNumber: 57
							}, this),
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:230:11",
							children: "Mais Opções"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 230,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 219,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 217,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "pt-4 border-t border-slate-200",
				"data-tsd-source": "/src/routes/dashboard/collectors.tsx:236:7",
				children: [/* @__PURE__ */ _jsxDEV("h5", {
					className: "text-xs font-semibold text-slate-500 uppercase mb-3",
					"data-tsd-source": "/src/routes/dashboard/collectors.tsx:237:9",
					children: "Informação de Contacto"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 237,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 gap-4 text-sm",
					"data-tsd-source": "/src/routes/dashboard/collectors.tsx:238:9",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:239:11",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-500",
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:240:13",
							children: "Telefone:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 240,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "ml-2 font-medium text-slate-900",
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:241:13",
							children: row.phone
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 241,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 239,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:243:11",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-500",
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:244:13",
							children: "Estado:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 244,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "ml-2 font-medium text-slate-900 capitalize",
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:245:13",
							children: row.status
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 245,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 243,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 238,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 236,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 190,
		columnNumber: 49
	}, this);
	return /* @__PURE__ */ _jsxDEV(DashboardLayout, {
		"data-tsd-source": "/src/routes/dashboard/collectors.tsx:250:10",
		children: [
			/* @__PURE__ */ _jsxDEV(Sidebar, {
				items: sidebarItems,
				"data-tsd-source": "/src/routes/dashboard/collectors.tsx:251:7"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 251,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col h-full overflow-hidden",
				"data-tsd-source": "/src/routes/dashboard/collectors.tsx:253:7",
				children: [/* @__PURE__ */ _jsxDEV(Header, {
					title: "Gestão de Cobradores",
					description: "Gerencie sua equipe de campo e acompanhe o desempenho",
					rightContent: /* @__PURE__ */ _jsxDEV(Button, {
						size: "sm",
						leftIcon: /* @__PURE__ */ _jsxDEV(Plus, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 254,
							columnNumber: 156
						}, this),
						onClick: () => setIsRegisterModalOpen(true),
						children: "Novo Cobrador"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 254,
						columnNumber: 128
					}, this),
					"data-tsd-source": "/src/routes/dashboard/collectors.tsx:254:9"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 254,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("main", {
					className: "flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 max-w-7xl w-full mx-auto animate-in fade-in slide-in-from-bottom-3 duration-500",
					"data-tsd-source": "/src/routes/dashboard/collectors.tsx:258:9",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4",
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:260:11",
						children: kpiData.map((kpi) => /* @__PURE__ */ _jsxDEV(KPICard, { ...kpi }, kpi.title, false, {
							fileName: _jsxFileName,
							lineNumber: 261,
							columnNumber: 33
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 260,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Card, {
						"data-tsd-source": "/src/routes/dashboard/collectors.tsx:265:11",
						children: /* @__PURE__ */ _jsxDEV(CardContent, {
							className: "p-0",
							"data-tsd-source": "/src/routes/dashboard/collectors.tsx:266:13",
							children: /* @__PURE__ */ _jsxDEV(DataTable, {
								data: mockCollectors,
								columns,
								searchable: true,
								searchPlaceholder: "Buscar por nome ou telefone...",
								onRowClick: (row) => console.log(...typeof window === "undefined" ? ["\x1B[35mLOG\x1B[39m \x1B[94m/src/routes/dashboard/collectors.tsx:267:154\x1B[39m\n → "] : [
									"%cLOG%c %cGo to Source: http://localhost:4000/__tsd/open-source?source=%2Fsrc%2Froutes%2Fdashboard%2Fcollectors.tsx%3A267%3A154%c \n → ",
									"color:#A0A",
									"color:#FFF",
									"color:#55F",
									"color:#FFF"
								], "View collector:", row),
								emptyMessage: "Nenhum cobrador encontrado",
								expandable: true,
								renderExpandedRow,
								onRowExpand: (row) => console.log(...typeof window === "undefined" ? ["\x1B[35mLOG\x1B[39m \x1B[94m/src/routes/dashboard/collectors.tsx:267:309\x1B[39m\n → "] : [
									"%cLOG%c %cGo to Source: http://localhost:4000/__tsd/open-source?source=%2Fsrc%2Froutes%2Fdashboard%2Fcollectors.tsx%3A267%3A309%c \n → ",
									"color:#A0A",
									"color:#FFF",
									"color:#55F",
									"color:#FFF"
								], "Row expanded:", row.id),
								"data-tsd-source": "/src/routes/dashboard/collectors.tsx:267:15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 267,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 266,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 265,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 258,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 253,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(RegisterCollectorModal, {
				isOpen: isRegisterModalOpen,
				onClose: () => setIsRegisterModalOpen(false),
				onSubmit: handleRegisterCollector,
				"data-tsd-source": "/src/routes/dashboard/collectors.tsx:273:7"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 273,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(QuickTransferModal, {
				isOpen: isTransferModalOpen,
				onClose: () => {
					setIsTransferModalOpen(false);
					setSelectedCollector(null);
				},
				onSubmit: (data) => console.log(...typeof window === "undefined" ? ["\x1B[35mLOG\x1B[39m \x1B[94m/src/routes/dashboard/collectors.tsx:278:26\x1B[39m\n → "] : [
					"%cLOG%c %cGo to Source: http://localhost:4000/__tsd/open-source?source=%2Fsrc%2Froutes%2Fdashboard%2Fcollectors.tsx%3A278%3A26%c \n → ",
					"color:#A0A",
					"color:#FFF",
					"color:#55F",
					"color:#FFF"
				], "Transfer:", data),
				collectorName: selectedCollector?.name,
				availableCollectors: mockCollectors.filter((c) => c.id !== selectedCollector?.id).map((c) => ({
					id: c.id,
					name: c.name,
					currentClients: c.clients
				})),
				"data-tsd-source": "/src/routes/dashboard/collectors.tsx:275:7"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 275,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 250,
		columnNumber: 10
	}, this);
}
_s(CollectorsManagement, "Q0gYSTnMsGH8Mm5J1V2OjqPy1dY=");
_c = CollectorsManagement;
export { CollectorsManagement as component };
var _c;
$RefreshReg$(_c, "CollectorsManagement");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/dashboard/collectors.tsx?tsr-split=component";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/collectors.tsx?tsr-split=component", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/collectors.tsx?tsr-split=component", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/collectors.tsx?tsr-split=component" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQ0E7QUFDQTtBQVdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7OztBQXlCQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2VBNEdBO0tBQUE7S0FBQTtlQUFBLENBQ0E7TUFBQTtNQUFBO2dCQUNBO0tBQ0E7Ozs7ZUFDQTtNQUFBO01BQUE7S0FBQTs7OzthQUtBOzs7OztjQUNBO0tBQUE7ZUFBQSxDQUNBO01BQUE7TUFBQTtnQkFBQTtLQUFBOzs7O2VBQ0E7TUFBQTtNQUFBO2dCQUFBO0tBQUE7Ozs7YUFDQTs7Ozs7WUFDQTs7Ozs7Ozs7Ozs7OztlQVFBO0tBQUE7S0FBQTtlQUFBO0lBQUE7Ozs7Y0FDQTtLQUFBO0tBQUE7ZUFBQTtJQUFBOzs7O1lBQ0E7Ozs7Ozs7Ozs7Ozs7ZUFRQSxzQ0FDQTs7Ozs7Ozs7Ozs7Ozs7S0FZQTtLQUFBO0tBQUE7SUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7S0FpQkE7TUFBQTtNQUFBO01BQUE7TUFBQTtnQkFLQTtPQUFBO09BQUE7TUFBQTs7Ozs7S0FDQTs7Ozs7S0FDQTtNQUFBO01BQUE7TUFBQTtNQUFBO2dCQUtBO09BQUE7T0FBQTtNQUFBOzs7OztLQUNBOzs7OztLQUNBO01BQUE7TUFBQTtNQUFBO01BQUE7Z0JBS0E7T0FBQTtPQUFBO01BQUE7Ozs7O0tBQ0E7Ozs7O0lBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FVQTtJQUFBO0lBQUE7Y0FBQTtLQUNBO01BQUE7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtPQUFBOzs7O2lCQUNBO1FBQUE7a0JBQUE7T0FBQTs7OztlQUNBOzs7OztnQkFDQTtPQUFBO09BQUE7aUJBQUE7Ozs7O2NBQ0E7Ozs7OztLQUNBO01BQUE7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtPQUFBOzs7O2lCQUNBO1FBQUE7a0JBQUE7T0FBQTs7OztlQUNBOzs7OztnQkFDQTtPQUFBO09BQUE7aUJBQUE7Ozs7O2NBQ0E7Ozs7OztLQUNBO01BQUE7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtPQUFBOzs7O2lCQUNBO1FBQUE7a0JBQUE7T0FBQTs7OztlQUNBOzs7OztnQkFDQTtPQUFBO09BQUE7aUJBQUE7UUFDQTtRQUFBO1FBQUE7T0FDQTs7Ozs7Y0FDQTs7Ozs7O0lBQ0E7Ozs7OztHQUVBO0lBQUE7SUFBQTtjQUFBLENBQ0E7S0FBQTtLQUFBO2VBQUE7SUFBQTs7OztjQUNBO0tBQUE7S0FBQTtlQUFBO01BQ0E7T0FBQTtPQUFBO09BQUE7Ozs7O09BQUE7aUJBQUE7TUFFQTs7Ozs7TUFDQTtPQUFBO09BQUE7T0FBQTs7Ozs7T0FBQTs7Ozs7OztNQVdBOzs7OztNQUNBO09BQUE7T0FBQTtPQUFBOzs7OztPQUFBO2lCQUFBO01BRUE7Ozs7O0tBQ0E7Ozs7O1lBQ0E7Ozs7OztHQUVBO0lBQUE7SUFBQTtjQUFBLENBQ0E7S0FBQTtLQUFBO2VBQUE7SUFBQTs7OztjQUNBO0tBQUE7S0FBQTtlQUFBLENBQ0E7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtpQkFBQTtNQUFBOzs7O2dCQUNBO09BQUE7T0FBQTtpQkFBQTtNQUFBOzs7O2NBQ0E7Ozs7O2VBQ0E7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtpQkFBQTtNQUFBOzs7O2dCQUNBO09BQUE7T0FBQTtpQkFBQTtNQUFBOzs7O2NBQ0E7Ozs7O2FBQ0E7Ozs7O1lBQ0E7Ozs7OztFQUNBOzs7Ozs7Ozs7R0FLQTtJQUFBO0lBQUE7R0FBQTs7Ozs7R0FFQTtJQUFBO0lBQUE7Y0FBQSxDQUNBO0tBQUE7S0FBQTtLQUFBO01BQUE7TUFBQTs7Ozs7TUFBQTtnQkFBQTtLQU1BOzs7OztLQUFBO0lBQUE7Ozs7Y0FJQTtLQUFBO0tBQUE7ZUFBQSxDQUVBO01BQUE7TUFBQTtnQkFDQTs7OzthQUFBO0tBR0E7Ozs7ZUFHQTtNQUFBO2dCQUNBO09BQUE7T0FBQTtpQkFDQTtRQUFBO1FBQUE7UUFBQTtRQUFBO1FBQUE7U0FBQTtTQUFBO1NBQUE7U0FBQTtTQUFBO1FBQUE7UUFBQTtRQUFBO1FBQUE7UUFBQTtTQUFBO1NBQUE7U0FBQTtTQUFBO1NBQUE7UUFBQTtRQUFBO09BQUE7Ozs7O01BV0E7Ozs7O0tBQ0E7Ozs7YUFDQTs7Ozs7WUFDQTs7Ozs7O0dBRUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtHQUFBOzs7OztHQU1BO0lBQUE7SUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFjQTs7Ozs7O0FBRUE7OztBQUFDIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJjb2xsZWN0b3JzLnRzeD90c3Itc3BsaXQ9Y29tcG9uZW50Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUZpbGVSb3V0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQge1xuICBVc2VycyxcbiAgUGx1cyxcbiAgVHJlbmRpbmdVcCxcbiAgV2FsbGV0LFxuICBFZGl0LFxuICBFeWUsXG4gIENpcmNsZVBsdXMsXG4gIE1hcFBpbixcbiAgTW9yZVZlcnRpY2FsXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBEYXNoYm9hcmRMYXlvdXQgfSBmcm9tICcjL2NvbXBvbmVudHMvbGF5b3V0L0Rhc2hib2FyZExheW91dCc7XG5pbXBvcnQgeyBTaWRlYmFyIH0gZnJvbSAnIy9jb21wb25lbnRzL2xheW91dC9TaWRlYmFyJztcbmltcG9ydCB7IEhlYWRlciB9IGZyb20gJyMvY29tcG9uZW50cy9sYXlvdXQvSGVhZGVyJztcbmltcG9ydCB7IERhdGFUYWJsZSB9IGZyb20gJyMvY29tcG9uZW50cy91aS9EYXRhVGFibGUnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnIy9jb21wb25lbnRzL3VpL0J1dHRvbic7XG5pbXBvcnQgeyBLUElDYXJkIH0gZnJvbSAnIy9jb21wb25lbnRzL3VpL0tQSUNhcmQnO1xuaW1wb3J0IHsgQ2FyZCwgQ2FyZENvbnRlbnQgfSBmcm9tICcjL2NvbXBvbmVudHMvdWkvQ2FyZCc7XG5pbXBvcnQgeyBBY3RpdmVCYWRnZSwgSW5hY3RpdmVCYWRnZSwgUGVuZGluZ0JhZGdlIH0gZnJvbSAnIy9jb21wb25lbnRzL3VpL1N0YXR1c0JhZGdlJztcbmltcG9ydCB7IFJlZ2lzdGVyQ29sbGVjdG9yTW9kYWwgfSBmcm9tICcjL2NvbXBvbmVudHMvYnVzaW5lc3MvUmVnaXN0ZXJDb2xsZWN0b3JNb2RhbCc7XG5pbXBvcnQgeyBRdWlja1RyYW5zZmVyTW9kYWwgfSBmcm9tICcjL2NvbXBvbmVudHMvYnVzaW5lc3MvUXVpY2tUcmFuc2Zlck1vZGFsJztcbmltcG9ydCB7IEV4cGFuZGFibGVSb3dDb250ZW50IH0gZnJvbSAnIy9jb21wb25lbnRzL3VpL0V4cGFuZGFibGVSb3cnO1xuaW1wb3J0IHsgY24gfSBmcm9tICcjL2xpYi9kZXNpZ24tc3lzdGVtJztcblxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKCcvZGFzaGJvYXJkL2NvbGxlY3RvcnMnKSh7XG4gIGNvbXBvbmVudDogQ29sbGVjdG9yc01hbmFnZW1lbnQsXG59KTtcblxuaW50ZXJmYWNlIENvbGxlY3RvciB7XG4gIGlkOiBzdHJpbmc7XG4gIG5hbWU6IHN0cmluZztcbiAgcGhvbmU6IHN0cmluZztcbiAgY2xpZW50czogbnVtYmVyO1xuICBtb250aGx5Vm9sdW1lOiBudW1iZXI7XG4gIGRpZmZlcmVuY2U6IG51bWJlcjtcbiAgc3RhdHVzOiAnYWN0aXZlJyB8ICdzdXNwZW5kZWQnIHwgJ2luYWN0aXZlJztcbiAgYXZhdGFyPzogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgQ29sbGVjdG9yRGF0YSB7XG4gIG5hbWU6IHN0cmluZztcbiAgcGhvbmU6IHN0cmluZztcbiAgZW1haWw/OiBzdHJpbmc7XG4gIG9ic2VydmF0aW9ucz86IHN0cmluZztcbiAgaXNBY3RpdmU6IGJvb2xlYW47XG59XG5cbmZ1bmN0aW9uIENvbGxlY3RvcnNNYW5hZ2VtZW50KCkge1xuICBjb25zdCBbX3NlYXJjaFRlcm0sIF9zZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2lzUmVnaXN0ZXJNb2RhbE9wZW4sIHNldElzUmVnaXN0ZXJNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNUcmFuc2Zlck1vZGFsT3Blbiwgc2V0SXNUcmFuc2Zlck1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzZWxlY3RlZENvbGxlY3Rvciwgc2V0U2VsZWN0ZWRDb2xsZWN0b3JdID0gdXNlU3RhdGU8Q29sbGVjdG9yIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgaGFuZGxlUmVnaXN0ZXJDb2xsZWN0b3IgPSAoZGF0YTogQ29sbGVjdG9yRGF0YSkgPT4ge1xuICAgIGNvbnNvbGUubG9nKCdSZWdpc3RlcmluZyBjb2xsZWN0b3I6JywgZGF0YSk7XG4gICAgLy8gVE9ETzogSW50ZWdyYXRlIHdpdGggQVBJXG4gIH07XG5cbiAgY29uc3Qgc2lkZWJhckl0ZW1zID0gW1xuICAgIHsgbGFiZWw6ICdQYWluZWwnLCBpY29uOiBUcmVuZGluZ1VwLCBocmVmOiAnL2Rhc2hib2FyZC9vdmVydmlldycgfSxcbiAgICB7IGxhYmVsOiAnR2VzdMOjbycsIGljb246IFVzZXJzLCBocmVmOiAnL2Rhc2hib2FyZC9zYXZlcnMnIH0sXG4gICAgeyBsYWJlbDogJ0NvYnJhZG9yZXMnLCBpY29uOiBDaXJjbGVQbHVzLCBocmVmOiAnL2Rhc2hib2FyZC9jb2xsZWN0b3JzJywgaXNBY3RpdmU6IHRydWUgfSxcbiAgICB7IGxhYmVsOiAnRmluYW5jZWlybycsIGljb246IFdhbGxldCwgaHJlZjogJy9kYXNoYm9hcmQvZmluYW5jaWFsJyB9LFxuICAgIHsgbGFiZWw6ICdSZWxhdMOzcmlvcycsIGljb246IFRyZW5kaW5nVXAsIGhyZWY6ICcvZGFzaGJvYXJkL3JlcG9ydHMnIH0sXG4gIF07XG5cbiAgY29uc3QgbW9ja0NvbGxlY3RvcnM6IENvbGxlY3RvcltdID0gW1xuICAgIHtcbiAgICAgIGlkOiAnMScsXG4gICAgICBuYW1lOiAnQXJzw6luaW8gTWF0dXNzZScsXG4gICAgICBwaG9uZTogJysyNTggODQgMTIzIDQ1NjcnLFxuICAgICAgY2xpZW50czogNDcsXG4gICAgICBtb250aGx5Vm9sdW1lOiAxMjU0MDAsXG4gICAgICBkaWZmZXJlbmNlOiAxMjAwLFxuICAgICAgc3RhdHVzOiAnYWN0aXZlJyxcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAnMicsXG4gICAgICBuYW1lOiAnQ8OpbGlhIE1vbmRsYW5lJyxcbiAgICAgIHBob25lOiAnKzI1OCA4MiA5ODcgNjU0MycsXG4gICAgICBjbGllbnRzOiAzMixcbiAgICAgIG1vbnRobHlWb2x1bWU6IDg0MjAwLFxuICAgICAgZGlmZmVyZW5jZTogLTQ1MDAsXG4gICAgICBzdGF0dXM6ICdzdXNwZW5kZWQnLFxuICAgIH0sXG4gICAge1xuICAgICAgaWQ6ICczJyxcbiAgICAgIG5hbWU6ICdGaWxpcGUgTnl1c2kgSnIuJyxcbiAgICAgIHBob25lOiAnKzI1OCA4NyA1NTUgMDE5MicsXG4gICAgICBjbGllbnRzOiA1OCxcbiAgICAgIG1vbnRobHlWb2x1bWU6IDE1NjAwMCxcbiAgICAgIGRpZmZlcmVuY2U6IDAsXG4gICAgICBzdGF0dXM6ICdhY3RpdmUnLFxuICAgIH0sXG4gICAge1xuICAgICAgaWQ6ICc0JyxcbiAgICAgIG5hbWU6ICdNYXJpYSBNYWNoYXZhJyxcbiAgICAgIHBob25lOiAnKzI1OCA4NiA0NDQgNTY3OCcsXG4gICAgICBjbGllbnRzOiA0MSxcbiAgICAgIG1vbnRobHlWb2x1bWU6IDEwNTgwMCxcbiAgICAgIGRpZmZlcmVuY2U6IDgwMCxcbiAgICAgIHN0YXR1czogJ2FjdGl2ZScsXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJzUnLFxuICAgICAgbmFtZTogJ0pvw6NvIFNpdG9lJyxcbiAgICAgIHBob25lOiAnKzI1OCA4NSAzMzMgNDQ1NScsXG4gICAgICBjbGllbnRzOiAzNSxcbiAgICAgIG1vbnRobHlWb2x1bWU6IDg5MDAwLFxuICAgICAgZGlmZmVyZW5jZTogLTE1MDAsXG4gICAgICBzdGF0dXM6ICdzdXNwZW5kZWQnLFxuICAgIH0sXG4gIF07XG5cbiAgY29uc3Qga3BpRGF0YSA9IFtcbiAgICB7XG4gICAgICB0aXRsZTogJ1RvdGFsIGRlIENvYnJhZG9yZXMnLFxuICAgICAgdmFsdWU6IFN0cmluZyhtb2NrQ29sbGVjdG9ycy5sZW5ndGgpLFxuICAgICAgc3VidGV4dDogJysyIGVzdGUgbcOqcycsXG4gICAgICBpY29uOiBVc2VycyxcbiAgICAgIGNvbG9yOiAndGV4dC1lbWVyYWxkLTYwMCBiZy1lbWVyYWxkLTUwIGJvcmRlci1lbWVyYWxkLTEwMCcsXG4gICAgICBpc0RlYnQ6IGZhbHNlLFxuICAgIH0sXG4gICAge1xuICAgICAgdGl0bGU6ICdDb2JyYWRvcmVzIEF0aXZvcycsXG4gICAgICB2YWx1ZTogU3RyaW5nKG1vY2tDb2xsZWN0b3JzLmZpbHRlcihjID0+IGMuc3RhdHVzID09PSAnYWN0aXZlJykubGVuZ3RoKSxcbiAgICAgIHN1YnRleHQ6IGBkZSAke21vY2tDb2xsZWN0b3JzLmxlbmd0aH0gdG90YWxgLFxuICAgICAgaWNvbjogVXNlcnMsXG4gICAgICBjb2xvcjogJ3RleHQtZW1lcmFsZC02MDAgYmctZW1lcmFsZC01MCBib3JkZXItZW1lcmFsZC0xMDAnLFxuICAgICAgaXNEZWJ0OiBmYWxzZSxcbiAgICB9LFxuICAgIHtcbiAgICAgIHRpdGxlOiAnQXJyZWNhZGFkbyAoTcOqcyknLFxuICAgICAgdmFsdWU6ICc0NTAuMDAwIE1aTicsXG4gICAgICBzdWJ0ZXh0OiAnVG90YWwgY29sZWN0YWRvJyxcbiAgICAgIGljb246IFdhbGxldCxcbiAgICAgIGNvbG9yOiAndGV4dC1ibHVlLTYwMCBiZy1ibHVlLTUwIGJvcmRlci1ibHVlLTEwMCcsXG4gICAgICBpc0RlYnQ6IGZhbHNlLFxuICAgIH0sXG4gICAge1xuICAgICAgdGl0bGU6ICdNZXRhIGRlIENvbGVjdGEnLFxuICAgICAgdmFsdWU6ICc4MiUnLFxuICAgICAgc3VidGV4dDogJ1Byb2dyZXNzbyBtZW5zYWwnLFxuICAgICAgaWNvbjogVHJlbmRpbmdVcCxcbiAgICAgIGNvbG9yOiAndGV4dC1hbWJlci02MDAgYmctYW1iZXItNTAgYm9yZGVyLWFtYmVyLTEwMCcsXG4gICAgICBpc0RlYnQ6IGZhbHNlLFxuICAgIH0sXG4gIF07XG5cbiAgY29uc3QgY29sdW1ucyA9IFtcbiAgICB7XG4gICAgICBrZXk6ICduYW1lJyxcbiAgICAgIGhlYWRlcjogJ0NPQlJBRE9SJyxcbiAgICAgIHJlbmRlcjogKHZhbHVlOiB1bmtub3duLCByb3c6IENvbGxlY3RvcikgPT4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXNsYXRlLTUwMCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgIHtTdHJpbmcocm93Lm5hbWUpLmNoYXJBdCgwKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgXCJhYnNvbHV0ZSAtYm90dG9tLTEgLXJpZ2h0LTEgdy0zIGgtMyBib3JkZXItMiBib3JkZXItd2hpdGUgcm91bmRlZC1mdWxsXCIsXG4gICAgICAgICAgICAgIHJvdy5zdGF0dXMgPT09ICdhY3RpdmUnID8gJ2JnLWVtZXJhbGQtNTAwJyA6XG4gICAgICAgICAgICAgICAgcm93LnN0YXR1cyA9PT0gJ3N1c3BlbmRlZCcgPyAnYmctcmVkLTUwMCcgOiAnYmctc2xhdGUtNDAwJ1xuICAgICAgICAgICAgKX0gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc20gdGV4dC1zbGF0ZS05MDBcIj57U3RyaW5nKHZhbHVlKX08L3A+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPntyb3cucGhvbmV9PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICksXG4gICAgfSxcbiAgICB7XG4gICAgICBrZXk6ICdjbGllbnRzJyxcbiAgICAgIGhlYWRlcjogJ0NMSUVOVEVTJyxcbiAgICAgIHJlbmRlcjogKHZhbHVlOiB1bmtub3duKSA9PiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTkwMFwiPntTdHJpbmcodmFsdWUpfTwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+VGljYW50ZXM8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGtleTogJ21vbnRobHlWb2x1bWUnLFxuICAgICAgaGVhZGVyOiAnVk9MVU1FIE1FTlNBTCcsXG4gICAgICByZW5kZXI6ICh2YWx1ZTogdW5rbm93bikgPT4gKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgdGV4dC1yaWdodCBibG9ja1wiPlxuICAgICAgICAgIHtOdW1iZXIodmFsdWUpLnRvTG9jYWxlU3RyaW5nKCl9IE1aTlxuICAgICAgICA8L3NwYW4+XG4gICAgICApLFxuICAgIH0sXG4gICAge1xuICAgICAga2V5OiAnZGlmZmVyZW5jZScsXG4gICAgICBoZWFkZXI6ICdESUZFUkVOw4dBJyxcbiAgICAgIHJlbmRlcjogKHZhbHVlOiB1bmtub3duKSA9PiAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJmb250LW1vbm8gdGV4dC1zbSB0ZXh0LXJpZ2h0IGJsb2NrXCIsXG4gICAgICAgICAgTnVtYmVyKHZhbHVlKSA+IDAgPyAndGV4dC1lbWVyYWxkLTYwMCcgOlxuICAgICAgICAgICAgTnVtYmVyKHZhbHVlKSA8IDAgPyAndGV4dC1yZWQtNjAwJyA6ICd0ZXh0LXNsYXRlLTUwMCdcbiAgICAgICAgKX0+XG4gICAgICAgICAge051bWJlcih2YWx1ZSkgPiAwID8gJysnIDogJyd9e051bWJlcih2YWx1ZSkudG9Mb2NhbGVTdHJpbmcoKX0gTVpOXG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICksXG4gICAgfSxcbiAgICB7XG4gICAgICBrZXk6ICdzdGF0dXMnLFxuICAgICAgaGVhZGVyOiAnRVNUQURPJyxcbiAgICAgIHJlbmRlcjogKF86IHVua25vd24sIHJvdzogQ29sbGVjdG9yKSA9PiB7XG4gICAgICAgIGlmIChyb3cuc3RhdHVzID09PSAnYWN0aXZlJykgcmV0dXJuIDxBY3RpdmVCYWRnZSAvPjtcbiAgICAgICAgaWYgKHJvdy5zdGF0dXMgPT09ICdzdXNwZW5kZWQnKSByZXR1cm4gPFBlbmRpbmdCYWRnZT5FbSBBbsOhbGlzZTwvUGVuZGluZ0JhZGdlPjtcbiAgICAgICAgcmV0dXJuIDxJbmFjdGl2ZUJhZGdlIC8+O1xuICAgICAgfSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGtleTogJ2FjdGlvbnMnLFxuICAgICAgaGVhZGVyOiAnQUPDh8OVRVMnLFxuICAgICAgcmVuZGVyOiAoXzogdW5rbm93biwgX3JvdzogQ29sbGVjdG9yKSA9PiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGhvdmVyOmJnLXNsYXRlLTEwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgIHRpdGxlPVwiQXRyaWJ1aXIgQ2xpZW50ZXNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxDaXJjbGVQbHVzIHNpemU9ezE2fSAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGhvdmVyOmJnLXNsYXRlLTEwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgIHRpdGxlPVwiRWRpdGFyXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RWRpdCBzaXplPXsxNn0gLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICB0aXRsZT1cIlZlciBSZWxhdMOzcmlvXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RXllIHNpemU9ezE2fSAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICksXG4gICAgfSxcbiAgXTtcblxuICBjb25zdCByZW5kZXJFeHBhbmRlZFJvdyA9IChyb3c6IENvbGxlY3RvcikgPT4gKFxuICAgIDxFeHBhbmRhYmxlUm93Q29udGVudFxuICAgICAgdGl0bGU9e2BEZXNlbXBlbmhvIGRlICR7cm93Lm5hbWV9YH1cbiAgICAgIG9uVmlld0Z1bGxEZXRhaWxzPXsoKSA9PiBjb25zb2xlLmxvZygnTmF2aWdhdGUgdG8gZnVsbCBkZXRhaWxzOicsIHJvdy5pZCl9XG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICA8VHJlbmRpbmdVcCBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgIDxzcGFuPlZvbHVtZSBNZW5zYWw8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj57cm93Lm1vbnRobHlWb2x1bWUudG9Mb2NhbGVTdHJpbmcoKX0gTVpOPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgIDxVc2VycyBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgIDxzcGFuPkNsaWVudGVzIEFjdGl2b3M8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj57cm93LmNsaWVudHN9IFRpY2FudGVzPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgIDxXYWxsZXQgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICA8c3Bhbj5EaWZlcmVuw6dhPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT17Y24oXCJ0ZXh0LWxnIGZvbnQtYm9sZFwiLCByb3cuZGlmZmVyZW5jZSA+IDAgPyBcInRleHQtZW1lcmFsZC02MDBcIiA6IHJvdy5kaWZmZXJlbmNlIDwgMCA/IFwidGV4dC1yZWQtNjAwXCIgOiBcInRleHQtc2xhdGUtOTAwXCIpfT5cbiAgICAgICAgICAgIHtyb3cuZGlmZmVyZW5jZSA+IDAgPyAnKycgOiAnJ317cm93LmRpZmZlcmVuY2UudG9Mb2NhbGVTdHJpbmcoKX0gTVpOXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICA8aDUgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSBtYi0zXCI+QWPDp8O1ZXMgUsOhcGlkYXM8L2g1PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIGxlZnRJY29uPXs8TWFwUGluIHNpemU9ezE0fSAvPn0+XG4gICAgICAgICAgICBWZXIgTG9jYWxpemHDp8Ojb1xuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICBsZWZ0SWNvbj17PENpcmNsZVBsdXMgc2l6ZT17MTR9IC8+fVxuICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDb2xsZWN0b3Iocm93KTtcbiAgICAgICAgICAgICAgc2V0SXNUcmFuc2Zlck1vZGFsT3Blbih0cnVlKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgVHJhbnNmZXJpciBDbGllbnRlc1xuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cIm91dGxpbmVcIiBsZWZ0SWNvbj17PE1vcmVWZXJ0aWNhbCBzaXplPXsxNH0gLz59PlxuICAgICAgICAgICAgTWFpcyBPcMOnw7Vlc1xuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICA8aDUgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSBtYi0zXCI+SW5mb3JtYcOnw6NvIGRlIENvbnRhY3RvPC9oNT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00IHRleHQtc21cIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDBcIj5UZWxlZm9uZTo8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtOTAwXCI+e3Jvdy5waG9uZX08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwXCI+RXN0YWRvOjwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS05MDAgY2FwaXRhbGl6ZVwiPntyb3cuc3RhdHVzfTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L0V4cGFuZGFibGVSb3dDb250ZW50PlxuICApO1xuXG4gIHJldHVybiAoXG4gICAgPERhc2hib2FyZExheW91dD5cbiAgICAgIDxTaWRlYmFyIGl0ZW1zPXtzaWRlYmFySXRlbXN9IC8+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2wgaC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICA8SGVhZGVyXG4gICAgICAgICAgdGl0bGU9XCJHZXN0w6NvIGRlIENvYnJhZG9yZXNcIlxuICAgICAgICAgIGRlc2NyaXB0aW9uPVwiR2VyZW5jaWUgc3VhIGVxdWlwZSBkZSBjYW1wbyBlIGFjb21wYW5oZSBvIGRlc2VtcGVuaG9cIlxuICAgICAgICAgIHJpZ2h0Q29udGVudD17XG4gICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIGxlZnRJY29uPXs8UGx1cyBzaXplPXsxNn0gLz59IG9uQ2xpY2s9eygpID0+IHNldElzUmVnaXN0ZXJNb2RhbE9wZW4odHJ1ZSl9PlxuICAgICAgICAgICAgICBOb3ZvIENvYnJhZG9yXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICB9XG4gICAgICAgIC8+XG5cbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBwLTYgc206cC04IHNwYWNlLXktNiBtYXgtdy03eGwgdy1mdWxsIG14LWF1dG8gYW5pbWF0ZS1pbiBmYWRlLWluIHNsaWRlLWluLWZyb20tYm90dG9tLTMgZHVyYXRpb24tNTAwXCI+XG4gICAgICAgICAgey8qIEtQSSBDYXJkcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cbiAgICAgICAgICAgIHtrcGlEYXRhLm1hcCgoa3BpKSA9PiAoXG4gICAgICAgICAgICAgIDxLUElDYXJkIGtleT17a3BpLnRpdGxlfSB7Li4ua3BpfSAvPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogVGFibGUgKi99XG4gICAgICAgICAgPENhcmQ+XG4gICAgICAgICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPVwicC0wXCI+XG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcbiAgICAgICAgICAgICAgICBkYXRhPXttb2NrQ29sbGVjdG9yc31cbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxuICAgICAgICAgICAgICAgIHNlYXJjaGFibGU9e3RydWV9XG4gICAgICAgICAgICAgICAgc2VhcmNoUGxhY2Vob2xkZXI9XCJCdXNjYXIgcG9yIG5vbWUgb3UgdGVsZWZvbmUuLi5cIlxuICAgICAgICAgICAgICAgIG9uUm93Q2xpY2s9eyhyb3cpID0+IGNvbnNvbGUubG9nKCdWaWV3IGNvbGxlY3RvcjonLCByb3cpfVxuICAgICAgICAgICAgICAgIGVtcHR5TWVzc2FnZT1cIk5lbmh1bSBjb2JyYWRvciBlbmNvbnRyYWRvXCJcbiAgICAgICAgICAgICAgICBleHBhbmRhYmxlPXt0cnVlfVxuICAgICAgICAgICAgICAgIHJlbmRlckV4cGFuZGVkUm93PXtyZW5kZXJFeHBhbmRlZFJvd31cbiAgICAgICAgICAgICAgICBvblJvd0V4cGFuZD17KHJvdykgPT4gY29uc29sZS5sb2coJ1JvdyBleHBhbmRlZDonLCByb3cuaWQpfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9DYXJkQ29udGVudD5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDwvbWFpbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8UmVnaXN0ZXJDb2xsZWN0b3JNb2RhbFxuICAgICAgICBpc09wZW49e2lzUmVnaXN0ZXJNb2RhbE9wZW59XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzUmVnaXN0ZXJNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICBvblN1Ym1pdD17aGFuZGxlUmVnaXN0ZXJDb2xsZWN0b3J9XG4gICAgICAvPlxuXG4gICAgICA8UXVpY2tUcmFuc2Zlck1vZGFsXG4gICAgICAgIGlzT3Blbj17aXNUcmFuc2Zlck1vZGFsT3Blbn1cbiAgICAgICAgb25DbG9zZT17KCkgPT4ge1xuICAgICAgICAgIHNldElzVHJhbnNmZXJNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgICAgIHNldFNlbGVjdGVkQ29sbGVjdG9yKG51bGwpO1xuICAgICAgICB9fVxuICAgICAgICBvblN1Ym1pdD17KGRhdGEpID0+IGNvbnNvbGUubG9nKCdUcmFuc2ZlcjonLCBkYXRhKX1cbiAgICAgICAgY29sbGVjdG9yTmFtZT17c2VsZWN0ZWRDb2xsZWN0b3I/Lm5hbWV9XG4gICAgICAgIGF2YWlsYWJsZUNvbGxlY3RvcnM9e21vY2tDb2xsZWN0b3JzLmZpbHRlcihjID0+IGMuaWQgIT09IHNlbGVjdGVkQ29sbGVjdG9yPy5pZCkubWFwKGMgPT4gKHtcbiAgICAgICAgICBpZDogYy5pZCxcbiAgICAgICAgICBuYW1lOiBjLm5hbWUsXG4gICAgICAgICAgY3VycmVudENsaWVudHM6IGMuY2xpZW50cyxcbiAgICAgICAgfSkpfVxuICAgICAgLz5cbiAgICA8L0Rhc2hib2FyZExheW91dD5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvemVsdG8vT25lRHJpdmUvRG9jdW1lbnRvcy9HaXRIdWIvWGl0aXF1ZUFwcFVJL3NyYy9yb3V0ZXMvZGFzaGJvYXJkL2NvbGxlY3RvcnMudHN4In0=