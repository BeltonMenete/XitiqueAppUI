import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/__root.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"];var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/__root.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
;
(function __tsdConsolePipe() {
	// Detect environment
	var isServer = typeof window === "undefined";
	var envKey = isServer ? "__TSD_SERVER_CONSOLE_PIPE_INITIALIZED__" : "__TSD_CONSOLE_PIPE_INITIALIZED__";
	var globalObj = isServer ? globalThis : window;
	// Only run once per environment
	if (globalObj[envKey]) return;
	globalObj[envKey] = true;
	var CONSOLE_LEVELS = [
		"log",
		"warn",
		"error",
		"info",
		"debug"
	];
	var VITE_SERVER_URL = "http://localhost:4000";
	// Store original console methods before we override them
	var originalConsole = {};
	for (var i = 0; i < CONSOLE_LEVELS.length; i++) {
		var level = CONSOLE_LEVELS[i];
		originalConsole[level] = console[level].bind(console);
	}
	// Simple inline batcher implementation
	var batchedEntries = [];
	var batchTimeout = null;
	var BATCH_WAIT = isServer ? 50 : 100;
	var BATCH_MAX_SIZE = isServer ? 20 : 50;
	function flushBatch() {
		if (batchedEntries.length === 0) return;
		var entries = batchedEntries;
		batchedEntries = [];
		batchTimeout = null;
		// Determine endpoint based on environment
		var endpoint = isServer ? VITE_SERVER_URL + "/__tsd/console-pipe/server" : "/__tsd/console-pipe";
		// Send to Vite server via fetch
		fetch(endpoint, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ entries })
		}).catch(function() {
			// Swallow errors  
		});
	}
	function addToBatch(entry) {
		batchedEntries.push(entry);
		if (batchedEntries.length >= BATCH_MAX_SIZE) {
			if (batchTimeout) {
				clearTimeout(batchTimeout);
				batchTimeout = null;
			}
			flushBatch();
		} else if (!batchTimeout) {
			batchTimeout = setTimeout(flushBatch, BATCH_WAIT);
		}
	}
	var MAX_DEPTH = 6;
	var MAX_ARRAY_LEN = 100;
	var MAX_OBJECT_KEYS = 100;
	var MAX_STRING_LENGTH = 1e4;
	function truncateString(value) {
		if (value.length <= MAX_STRING_LENGTH) return value;
		return value.slice(0, MAX_STRING_LENGTH) + "... (" + (value.length - MAX_STRING_LENGTH) + " more chars)";
	}
	function formatDomElement(element) {
		var tagName = element.tagName ? element.tagName.toLowerCase() : "element";
		var output = "<" + tagName;
		var attrs = [
			"id",
			"class",
			"name",
			"type",
			"role",
			"aria-label",
			"data-testid"
		];
		for (var attrIndex = 0; attrIndex < attrs.length; attrIndex++) {
			var attrName = attrs[attrIndex];
			var attrValue = element.getAttribute && element.getAttribute(attrName);
			if (attrValue) {
				output += " " + attrName + "=\"" + truncateString(String(attrValue)).replace(/"/g, "&quot;") + "\"";
			}
		}
		return output + ">";
	}
	function getObjectTypeName(arg) {
		return arg && arg.constructor && arg.constructor.name ? arg.constructor.name : "Object";
	}
	function formatArrayBufferView(arg) {
		var length = typeof arg.length === "number" ? arg.length : arg.byteLength;
		return "[" + getObjectTypeName(arg) + "(" + length + ")]";
	}
	function serializeConsoleArg(arg, seen, depth) {
		if (depth === undefined) depth = 0;
		if (arg === undefined) return "undefined";
		if (arg === null) return null;
		var argType = typeof arg;
		if (argType === "function") return "[Function" + (arg.name ? ": " + arg.name : "") + "]";
		if (argType === "symbol") return arg.toString();
		if (argType === "bigint") return arg.toString() + "n";
		if (argType === "string") return truncateString(arg);
		if (argType !== "object") return arg;
		if (!isServer) {
			if (arg.nodeType === 1 && typeof arg.tagName === "string" && typeof arg.getAttribute === "function") {
				return formatDomElement(arg);
			}
			if (arg.nodeType === 9) {
				return "[Document]";
			}
			if (typeof Window !== "undefined" && arg instanceof Window) {
				return "[Window]";
			}
			if (typeof Event !== "undefined" && arg instanceof Event) {
				return {
					type: arg.type,
					target: serializeConsoleArg(arg.target, seen, depth + 1),
					currentTarget: serializeConsoleArg(arg.currentTarget, seen, depth + 1),
					defaultPrevented: arg.defaultPrevented
				};
			}
			if (typeof Node !== "undefined" && arg instanceof Node) {
				return "[Node: " + arg.nodeName + "]";
			}
		}
		if (arg instanceof Error) {
			return {
				name: arg.name,
				message: truncateString(arg.message),
				stack: arg.stack ? truncateString(arg.stack) : arg.stack
			};
		}
		if (arg instanceof Date) {
			return arg.toISOString();
		}
		if (arg instanceof RegExp) {
			return arg.toString();
		}
		if (typeof ArrayBuffer !== "undefined") {
			if (ArrayBuffer.isView && ArrayBuffer.isView(arg)) {
				return formatArrayBufferView(arg);
			}
			if (arg instanceof ArrayBuffer) {
				return "[ArrayBuffer(" + arg.byteLength + ")]";
			}
		}
		if (typeof SharedArrayBuffer !== "undefined" && arg instanceof SharedArrayBuffer) {
			return "[SharedArrayBuffer(" + arg.byteLength + ")]";
		}
		if (depth >= MAX_DEPTH) {
			return "[MaxDepth]";
		}
		if (seen.indexOf(arg) !== -1) {
			return "[Circular]";
		}
		seen.push(arg);
		if (Array.isArray(arg)) {
			var arrayResult = [];
			var arrayLength = Math.min(arg.length, MAX_ARRAY_LEN);
			for (var arrayIndex = 0; arrayIndex < arrayLength; arrayIndex++) {
				arrayResult.push(serializeConsoleArg(arg[arrayIndex], seen, depth + 1));
			}
			if (arg.length > MAX_ARRAY_LEN) {
				arrayResult.push("... (" + (arg.length - MAX_ARRAY_LEN) + " more)");
			}
			seen.pop();
			return arrayResult;
		}
		var objectResult = {};
		var keys = Object.keys(arg);
		var keyLength = Math.min(keys.length, MAX_OBJECT_KEYS);
		for (var keyIndex = 0; keyIndex < keyLength; keyIndex++) {
			var key = keys[keyIndex];
			try {
				objectResult[key] = serializeConsoleArg(arg[key], seen, depth + 1);
			} catch (error) {
				objectResult[key] = "[Thrown: " + String(error) + "]";
			}
		}
		if (keys.length > MAX_OBJECT_KEYS) {
			objectResult["..."] = "(" + (keys.length - MAX_OBJECT_KEYS) + " more keys)";
		}
		seen.pop();
		return objectResult;
	}
	// Override global console methods
	for (var j = 0; j < CONSOLE_LEVELS.length; j++) {
		(function(level) {
			var original = originalConsole[level];
			console[level] = function() {
				var args = Array.prototype.slice.call(arguments);
				// Always call original first so logs appear normally
				original.apply(console, args);
				// Skip our own TSD Console Pipe logs to avoid recursion/noise
				if (args.length > 0 && typeof args[0] === "string" && (args[0].indexOf("[TSD Console Pipe]") !== -1 || args[0].indexOf("[@tanstack/devtools") !== -1)) {
					return;
				}
				var safeArgs = args.map(function(arg) {
					try {
						return serializeConsoleArg(arg, [], 0);
					} catch (e) {
						return String(arg);
					}
				});
				var entry = {
					level,
					args: safeArgs,
					source: isServer ? "server" : "client",
					timestamp: Date.now()
				};
				addToBatch(entry);
			};
		})(CONSOLE_LEVELS[j]);
	}
	// CLIENT ONLY: Listen for server console logs via SSE
	if (!isServer) {
		// Transform server log args - strip ANSI codes and convert source paths to clickable URLs
		function transformServerLogArgs(args) {
			var escChar = String.fromCharCode(27);
			var transformed = [];
			for (var k = 0; k < args.length; k++) {
				var arg = args[k];
				if (typeof arg === "string") {
					// Strip ANSI escape sequences (ESC[...m patterns)
					var cleaned = arg;
					// Remove ESC character followed by [...m] - need to build regex dynamically
					while (cleaned.indexOf(escChar) !== -1) {
						cleaned = cleaned.split(escChar).join("");
					}
					// Also remove any leftover bracket codes like [35m
					cleaned = cleaned.replace(/\[[0-9;]*m/g, "");
					// Transform source paths to clickable URLs
					// Match patterns like /src/components/Header.tsx:17:3
					var sourceRegex = /(\/[^\s]+:\d+:\d+)/g;
					cleaned = cleaned.replace(sourceRegex, function(match) {
						return window.location.origin + "/__tsd/open-source?source=" + encodeURIComponent(match);
					});
					if (cleaned.trim()) {
						transformed.push(cleaned);
					}
				} else {
					transformed.push(arg);
				}
			}
			return transformed;
		}
		var eventSource = new EventSource("/__tsd/console-pipe/sse");
		eventSource.onmessage = function(event) {
			try {
				var data = JSON.parse(event.data);
				if (data.entries) {
					for (var m = 0; m < data.entries.length; m++) {
						var entry = data.entries[m];
						var transformedArgs = transformServerLogArgs(entry.args);
						var prefix = "%c[Server]%c";
						var prefixStyle = "color: #9333ea; font-weight: bold;";
						var resetStyle = "color: inherit;";
						var logMethod = originalConsole[entry.level] || originalConsole.log;
						logMethod.apply(console, [
							prefix,
							prefixStyle,
							resetStyle
						].concat(transformedArgs));
					}
				}
			} catch (err) {}
		};
		eventSource.onerror = function() {
			// Swallow errors  
		};
		// Flush on page unload
		window.addEventListener("beforeunload", flushBatch);
	}
})();
import { TanStackDevtools } from "/node_modules/.vite/deps/@tanstack_react-devtools.js?v=03f72e91";
import { createRootRoute, Outlet } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=03f72e91";
import { TanStackRouterDevtoolsPanel } from "/node_modules/.vite/deps/@tanstack_react-router-devtools.js?v=03f72e91";
import "/src/styles.css?t=1786619632121";
import NotFound from "/src/components/NotFound.tsx";
const TSRNotFoundComponent = () => /* @__PURE__ */ _jsxDEV(NotFound, { "data-tsd-source": "/src/routes/__root.tsx:6:36" }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 318,
	columnNumber: 36
}, this);
_c = TSRNotFoundComponent;
export const Route = createRootRoute({
	component: RootComponent,
	notFoundComponent: TSRNotFoundComponent
});
// ok
function RootComponent() {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Outlet, { "data-tsd-source": "/src/routes/__root.tsx:15:4" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 327,
		columnNumber: 4
	}, this), /* @__PURE__ */ _jsxDEV(TanStackDevtools, {
		config: { position: "bottom-right" },
		plugins: [{
			name: "TanStack Router",
			render: /* @__PURE__ */ _jsxDEV(TanStackRouterDevtoolsPanel, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 332,
				columnNumber: 15
			}, this)
		}],
		"data-tsd-source": "/src/routes/__root.tsx:16:4"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 328,
		columnNumber: 4
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 326,
		columnNumber: 10
	}, this);
}
_c2 = RootComponent;
const hot = import.meta.hot;
if (hot && typeof window !== "undefined") {
	hot.data ??= {};
	const tsrReactRefresh = window.__TSR_REACT_REFRESH__ ??= (() => {
		const ignoredExportsById = new Map();
		const previousGetIgnoredExports = window.__getReactRefreshIgnoredExports;
		window.__getReactRefreshIgnoredExports = (ctx) => {
			const ignoredExports = previousGetIgnoredExports?.(ctx) ?? [];
			const moduleIgnored = ignoredExportsById.get(ctx.id) ?? [];
			return [...ignoredExports, ...moduleIgnored];
		};
		return { ignoredExportsById };
	})();
	tsrReactRefresh.ignoredExportsById.set("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/__root.tsx", ["Route"]);
}
export function TSRFastRefreshAnchor() {
	return null;
}
_c3 = TSRFastRefreshAnchor;
if (import.meta.hot) {
	const hot = import.meta.hot;
	const hotData = hot.data ??= {};
	const handleRouteUpdate = function handleRouteUpdate(routeId, newRoute) {
		const router = window.__TSR_ROUTER__;
		const oldRoute = router.routesById[routeId];
		if (!oldRoute) return;
		const generatedRouteOptionKeys = new Set([
			"id",
			"path",
			"getParentRoute"
		]);
		const generatedRouteOptions = {};
		generatedRouteOptionKeys.forEach((key) => {
			if (key in oldRoute.options) generatedRouteOptions[key] = oldRoute.options[key];
		});
		const preserveComponentIdentity = "shellComponent" in oldRoute.options === "shellComponent" in newRoute.options;
		const componentKeys = [
			"component",
			"shellComponent",
			"pendingComponent",
			"errorComponent",
			"notFoundComponent"
		];
		if (preserveComponentIdentity) componentKeys.forEach((key) => {
			if (key in oldRoute.options && key in newRoute.options) newRoute.options[key] = oldRoute.options[key];
		});
		const nextOptions = {
			...newRoute.options,
			...generatedRouteOptions
		};
		oldRoute.options = nextOptions;
		oldRoute.update(nextOptions);
		router._replaceRouteChunk(oldRoute, newRoute.lazyFn);
		router.setRoutes(router.buildRouteTree());
		syncHotRouteExport(oldRoute);
		router.resolvePathCache.clear();
		router._refreshRoute?.();
		function syncHotRouteExport(liveRoute) {
			newRoute.options = liveRoute.options;
			newRoute.parentRoute = liveRoute.parentRoute;
			newRoute._path = liveRoute._path;
			newRoute._id = liveRoute._id;
			newRoute._fullPath = liveRoute._fullPath;
			newRoute._to = liveRoute._to;
		}
	};
	const initialRouteId = "__root__" ?? hotData["tsr-route-id"];
	if (initialRouteId) {
		hotData["tsr-route-id"] = initialRouteId;
	}
	const existingRoute = typeof window !== "undefined" && initialRouteId ? window.__TSR_ROUTER__?.routesById?.[initialRouteId] : undefined;
	if (initialRouteId && existingRoute && existingRoute !== Route) {
		handleRouteUpdate(initialRouteId, Route);
		hotData["tsr-route-update-handled"] = Route;
	}
	hot.accept((newModule) => {
		if (Route && newModule && newModule.Route) {
			const routeId = hotData["tsr-route-id"] ?? "__root__";
			if (routeId) {
				hotData["tsr-route-id"] = routeId;
			}
			if (hotData["tsr-route-update-handled"] === newModule.Route) {
				delete hotData["tsr-route-update-handled"];
				return;
			}
			handleRouteUpdate(routeId, newModule.Route);
		}
	});
}
var _c, _c2, _c3;
$RefreshReg$(_c, "TSRNotFoundComponent");
$RefreshReg$(_c2, "RootComponent");
$RefreshReg$(_c3, "TSRFastRefreshAnchor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/__root.tsx?t=1786619632121";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/__root.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/__root.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/__root.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFDQTtDQUFBOztDQUdBO0NBQ0E7Q0FBNkM7OztDQUs3Qzs7Ozs7Ozs7Q0FHQTs7Q0FJQTs7Ozs7O0NBYUE7Q0FBQztDQUFBOzs7Ozs7Ozs7O0VBQUE7O0dBQUE7R0FBQSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiX19yb290LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBUYW5TdGFja0RldnRvb2xzIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1kZXZ0b29sc1wiO1xyXG5pbXBvcnQgeyBjcmVhdGVSb290Um91dGUsIE91dGxldCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtcm91dGVyXCI7XHJcbmltcG9ydCB7IFRhblN0YWNrUm91dGVyRGV2dG9vbHNQYW5lbCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtcm91dGVyLWRldnRvb2xzXCI7XHJcblxyXG5pbXBvcnQgXCIuLi9zdHlsZXMuY3NzXCI7XHJcbmltcG9ydCBOb3RGb3VuZCBmcm9tIFwiIy9jb21wb25lbnRzL05vdEZvdW5kXCI7XHJcblxyXG5leHBvcnQgY29uc3QgUm91dGUgPSBjcmVhdGVSb290Um91dGUoe1xyXG5cdGNvbXBvbmVudDogUm9vdENvbXBvbmVudCxcclxuXHRub3RGb3VuZENvbXBvbmVudDogKCkgPT4gPE5vdEZvdW5kIC8+LFxyXG59KTtcclxuLy8gb2tcclxuXHJcbmZ1bmN0aW9uIFJvb3RDb21wb25lbnQoKSB7XHJcblx0cmV0dXJuIChcclxuXHRcdDw+XHJcblx0XHRcdDxPdXRsZXQgLz5cclxuXHRcdFx0PFRhblN0YWNrRGV2dG9vbHNcclxuXHRcdFx0XHRjb25maWc9e3tcclxuXHRcdFx0XHRcdHBvc2l0aW9uOiBcImJvdHRvbS1yaWdodFwiLFxyXG5cdFx0XHRcdH19XHJcblx0XHRcdFx0cGx1Z2lucz17W1xyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRuYW1lOiBcIlRhblN0YWNrIFJvdXRlclwiLFxyXG5cdFx0XHRcdFx0XHRyZW5kZXI6IDxUYW5TdGFja1JvdXRlckRldnRvb2xzUGFuZWwgLz4sXHJcblx0XHRcdFx0XHR9LFxyXG5cdFx0XHRcdF19XHJcblx0XHRcdC8+XHJcblx0XHQ8Lz5cclxuXHQpO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvemVsdG8vT25lRHJpdmUvRG9jdW1lbnRvcy9HaXRIdWIvWGl0aXF1ZUFwcFVJL3NyYy9yb3V0ZXMvX19yb290LnRzeCJ9