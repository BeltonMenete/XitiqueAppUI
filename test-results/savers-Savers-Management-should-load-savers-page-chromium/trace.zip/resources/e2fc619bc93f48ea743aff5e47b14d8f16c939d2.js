import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/KPICard.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03f72e91";
import { ChevronDown, ChevronUp } from "/node_modules/.vite/deps/lucide-react.js?v=03f72e91";
import { Card, CardContent } from "/src/components/ui/Card.tsx";
import { cn } from "/src/lib/design-system.ts";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/KPICard.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
var _s = $RefreshSig$();
export function KPICard({ title, value, subtext, icon: Icon, color = "text-emerald-600 bg-emerald-50 border-emerald-100", isDebt = false, trend, className = "", clickable = false, expandedContent }) {
	_s();
	const [isExpanded, setIsExpanded] = useState(false);
	const handleClick = () => {
		if (clickable) {
			setIsExpanded(!isExpanded);
		}
	};
	return /* @__PURE__ */ _jsxDEV(Card, {
		className: cn("overflow-hidden", clickable && "hover:shadow-md transition-shadow cursor-pointer", className),
		onClick: handleClick,
		"data-tsd-source": "/src/components/ui/KPICard.tsx:44:5",
		children: /* @__PURE__ */ _jsxDEV(CardContent, {
			className: "p-5",
			"data-tsd-source": "/src/components/ui/KPICard.tsx:52:7",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-start justify-between",
				"data-tsd-source": "/src/components/ui/KPICard.tsx:53:9",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1",
					"data-tsd-source": "/src/components/ui/KPICard.tsx:54:11",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							"data-tsd-source": "/src/components/ui/KPICard.tsx:55:13",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1",
								"data-tsd-source": "/src/components/ui/KPICard.tsx:56:15",
								children: title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 56,
								columnNumber: 15
							}, this), clickable && /* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400",
								"data-tsd-source": "/src/components/ui/KPICard.tsx:60:17",
								children: isExpanded ? /* @__PURE__ */ _jsxDEV(ChevronUp, {
									size: 14,
									"data-tsd-source": "/src/components/ui/KPICard.tsx:61:33"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 61,
									columnNumber: 33
								}, this) : /* @__PURE__ */ _jsxDEV(ChevronDown, {
									size: 14,
									"data-tsd-source": "/src/components/ui/KPICard.tsx:61:59"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 61,
									columnNumber: 114
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 60,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 55,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-2xl font-bold text-slate-900 mb-1",
							"data-tsd-source": "/src/components/ui/KPICard.tsx:65:13",
							children: value
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 13
						}, this),
						subtext && /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							"data-tsd-source": "/src/components/ui/KPICard.tsx:67:15",
							children: subtext
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 15
						}, this),
						trend && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1 mt-2",
							"data-tsd-source": "/src/components/ui/KPICard.tsx:70:15",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: cn("text-xs font-semibold", trend.isPositive ? "text-emerald-600" : "text-red-600"),
								"data-tsd-source": "/src/components/ui/KPICard.tsx:71:17",
								children: [trend.isPositive ? "+" : "", trend.value]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-400",
								"data-tsd-source": "/src/components/ui/KPICard.tsx:79:17",
								children: "vs mês anterior"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 79,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: cn("w-12 h-12 rounded-lg flex items-center justify-center border", color, isDebt && "border-l-4 border-l-red-500"),
					"data-tsd-source": "/src/components/ui/KPICard.tsx:83:11",
					children: /* @__PURE__ */ _jsxDEV(Icon, {
						className: "w-6 h-6",
						"data-tsd-source": "/src/components/ui/KPICard.tsx:90:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 83,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 9
			}, this), isExpanded && expandedContent && /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-4 pt-4 border-t border-slate-200 animate-in fade-in slide-in-from-top-2 duration-200",
				"data-tsd-source": "/src/components/ui/KPICard.tsx:94:11",
				children: expandedContent
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 44,
		columnNumber: 5
	}, this);
}
_s(KPICard, "FPNvbbHVlWWR4LKxxNntSxiIS38=");
_c = KPICard;
var _c;
$RefreshReg$(_c, "KPICard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/KPICard.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/KPICard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/KPICard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/KPICard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFrQkEsMEJBQ0EsT0FDQSxPQUNBLFNBQ0EsWUFDQSw2REFDQSxnQkFDQSxPQUNBLGdCQUNBLG1CQUNBLG1CQUNBOztDQUNBO0NBRUE7RUFDQTtHQUNBO0VBQ0E7Q0FDQTtDQUVBLE9BQ0E7RUFDQSxjQUNBLG1CQUNBLGlFQUNBLFNBQ0E7RUFDQTtFQUNBO1lBQ0E7R0FBQTtHQUFBO2FBQUEsQ0FDQTtJQUFBO0lBQUE7Y0FBQSxDQUNBO0tBQUE7S0FBQTtlQUFBO01BQ0E7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFBQTtRQUFBO2tCQUNBO09BQ0E7Ozs7aUJBQ0EsYUFDQTtRQUFBO1FBQUE7a0JBQ0E7U0FBQTtTQUFBO1FBQXFEOzs7O21CQUFBO1NBQUE7U0FBQTtRQUE0Qjs7Ozs7T0FDakY7Ozs7ZUFFQTs7Ozs7O01BQ0E7T0FBQTtPQUFBO2lCQUFrRTtNQUFBOzs7OztNQUNsRSxXQUNBO09BQUE7T0FBQTtpQkFBbUQ7TUFBQTs7Ozs7TUFFbkQsU0FDQTtPQUFBO09BQUE7aUJBQUEsQ0FDQTtRQUNBLGNBQ0EseUJBQ0Esc0RBQ0E7UUFDQTtrQkFMQSxDQU1BLHdDQUNBOzs7OztpQkFDQTtRQUFBO1FBQUE7a0JBQXdEO09BQUE7Ozs7ZUFDeEQ7Ozs7OztLQUVBOzs7OztjQUNBO0tBQ0EsY0FDQSxnRUFDQSxPQUNBLHVDQUNBO0tBQ0E7ZUFDQTtNQUFBO01BQUE7S0FBc0M7Ozs7O0lBQ3RDOzs7O1lBQ0E7Ozs7O2FBQ0EsaUNBQ0E7SUFBQTtJQUFBO2NBQ0E7R0FDQTs7OztXQUVBOzs7Ozs7Q0FDQTs7Ozs7QUFFQSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiS1BJQ2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBMdWNpZGVJY29uIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENoZXZyb25Eb3duLCBDaGV2cm9uVXAgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCB9IGZyb20gXCIuL0NhcmRcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIiMvbGliL2Rlc2lnbi1zeXN0ZW1cIjtcblxuaW50ZXJmYWNlIEtQSUNhcmRQcm9wcyB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIHZhbHVlOiBzdHJpbmc7XG4gIHN1YnRleHQ/OiBzdHJpbmc7XG4gIGljb246IEx1Y2lkZUljb247XG4gIGNvbG9yPzogc3RyaW5nO1xuICBpc0RlYnQ/OiBib29sZWFuO1xuICB0cmVuZD86IHtcbiAgICB2YWx1ZTogc3RyaW5nO1xuICAgIGlzUG9zaXRpdmU6IGJvb2xlYW47XG4gIH07XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgY2xpY2thYmxlPzogYm9vbGVhbjtcbiAgZXhwYW5kZWRDb250ZW50PzogUmVhY3QuUmVhY3ROb2RlO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gS1BJQ2FyZCh7XG4gIHRpdGxlLFxuICB2YWx1ZSxcbiAgc3VidGV4dCxcbiAgaWNvbjogSWNvbixcbiAgY29sb3IgPSBcInRleHQtZW1lcmFsZC02MDAgYmctZW1lcmFsZC01MCBib3JkZXItZW1lcmFsZC0xMDBcIixcbiAgaXNEZWJ0ID0gZmFsc2UsXG4gIHRyZW5kLFxuICBjbGFzc05hbWUgPSBcIlwiLFxuICBjbGlja2FibGUgPSBmYWxzZSxcbiAgZXhwYW5kZWRDb250ZW50LFxufTogS1BJQ2FyZFByb3BzKSB7XG4gIGNvbnN0IFtpc0V4cGFuZGVkLCBzZXRJc0V4cGFuZGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBoYW5kbGVDbGljayA9ICgpID0+IHtcbiAgICBpZiAoY2xpY2thYmxlKSB7XG4gICAgICBzZXRJc0V4cGFuZGVkKCFpc0V4cGFuZGVkKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8Q2FyZFxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJvdmVyZmxvdy1oaWRkZW5cIixcbiAgICAgICAgY2xpY2thYmxlICYmIFwiaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tc2hhZG93IGN1cnNvci1wb2ludGVyXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsaWNrfVxuICAgID5cbiAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJwLTVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMVwiPlxuICAgICAgICAgICAgICAgIHt0aXRsZX1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICB7Y2xpY2thYmxlICYmIChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAge2lzRXhwYW5kZWQgPyA8Q2hldnJvblVwIHNpemU9ezE0fSAvPiA6IDxDaGV2cm9uRG93biBzaXplPXsxNH0gLz59XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG1iLTFcIj57dmFsdWV9PC9oMz5cbiAgICAgICAgICAgIHtzdWJ0ZXh0ICYmIChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPntzdWJ0ZXh0fTwvcD5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICB7dHJlbmQgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIG10LTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgXCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIixcbiAgICAgICAgICAgICAgICAgICAgdHJlbmQuaXNQb3NpdGl2ZSA/IFwidGV4dC1lbWVyYWxkLTYwMFwiIDogXCJ0ZXh0LXJlZC02MDBcIlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7dHJlbmQuaXNQb3NpdGl2ZSA/IFwiK1wiIDogXCJcIn17dHJlbmQudmFsdWV9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj52cyBtw6pzIGFudGVyaW9yPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgXCJ3LTEyIGgtMTIgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBib3JkZXJcIixcbiAgICAgICAgICAgICAgY29sb3IsXG4gICAgICAgICAgICAgIGlzRGVidCAmJiBcImJvcmRlci1sLTQgYm9yZGVyLWwtcmVkLTUwMFwiXG4gICAgICAgICAgICApfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge2lzRXhwYW5kZWQgJiYgZXhwYW5kZWRDb250ZW50ICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwIGFuaW1hdGUtaW4gZmFkZS1pbiBzbGlkZS1pbi1mcm9tLXRvcC0yIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAge2V4cGFuZGVkQ29udGVudH1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgPC9DYXJkPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy96ZWx0by9PbmVEcml2ZS9Eb2N1bWVudG9zL0dpdEh1Yi9YaXRpcXVlQXBwVUkvc3JjL2NvbXBvbmVudHMvdWkvS1BJQ2FyZC50c3gifQ==