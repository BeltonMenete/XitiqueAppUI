import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/ExpandableRow.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03f72e91";
import { ChevronDown, ChevronUp, ExternalLink } from "/node_modules/.vite/deps/lucide-react.js?v=03f72e91";
import { cn } from "/src/lib/design-system.ts";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/ExpandableRow.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
var _s = $RefreshSig$();
export function ExpandableRow({ children, expandedContent, isExpanded: controlledExpanded, onToggle, showExpandButton = true, className = "", expandedClassName = "" }) {
	_s();
	const [internalExpanded, setInternalExpanded] = useState(false);
	const isExpanded = controlledExpanded !== undefined ? controlledExpanded : internalExpanded;
	const handleToggle = () => {
		if (onToggle) {
			onToggle();
		} else {
			setInternalExpanded(!internalExpanded);
		}
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("tr", {
		className: cn("hover:bg-slate-50 transition-colors cursor-pointer", className),
		onClick: handleToggle,
		"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:38:7",
		children: [children, showExpandButton && /* @__PURE__ */ _jsxDEV("td", {
			className: "px-4 py-3 text-right",
			"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:47:11",
			children: /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: (e) => {
					e.stopPropagation();
					handleToggle();
				},
				className: "p-1 rounded hover:bg-slate-200 transition-colors",
				"aria-label": isExpanded ? "Collapse" : "Expand",
				"aria-expanded": isExpanded,
				"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:48:13",
				children: isExpanded ? /* @__PURE__ */ _jsxDEV(ChevronUp, {
					size: 16,
					className: "text-slate-400",
					"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:59:17"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 17
				}, this) : /* @__PURE__ */ _jsxDEV(ChevronDown, {
					size: 16,
					className: "text-slate-400",
					"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:61:17"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 11
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 7
	}, this), isExpanded && /* @__PURE__ */ _jsxDEV("tr", {
		className: cn("bg-slate-50/50", expandedClassName),
		"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:68:9",
		children: /* @__PURE__ */ _jsxDEV("td", {
			colSpan: showExpandButton ? 100 : 99,
			className: "px-4 py-4",
			"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:69:11",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "animate-in fade-in slide-in-from-top-2 duration-200",
				"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:70:13",
				children: expandedContent
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 11
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 68,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 5
	}, this);
}
_s(ExpandableRow, "q3T7s1oA4E0laLq+o9xcdONjQq0=");
_c = ExpandableRow;
export function ExpandableRowContent({ title, onViewFullDetails, children, className = "" }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn("space-y-4", className),
		"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:94:5",
		children: [title && /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between",
			"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:96:9",
			children: [/* @__PURE__ */ _jsxDEV("h4", {
				className: "text-sm font-semibold text-slate-900",
				"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:97:11",
				children: title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 97,
				columnNumber: 11
			}, this), onViewFullDetails && /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: (e) => {
					e.stopPropagation();
					onViewFullDetails();
				},
				className: "flex items-center gap-1 text-xs text-emerald-600 hover:text-emerald-700 font-medium",
				"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:99:13",
				children: ["Ver Detalhes Completos", /* @__PURE__ */ _jsxDEV(ExternalLink, {
					size: 12,
					"data-tsd-source": "/src/components/ui/ExpandableRow.tsx:108:15"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 99,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 9
		}, this), children]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 94,
		columnNumber: 5
	}, this);
}
_c2 = ExpandableRowContent;
var _c, _c2;
$RefreshReg$(_c, "ExpandableRow");
$RefreshReg$(_c2, "ExpandableRowContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/ExpandableRow.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/ExpandableRow.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/ExpandableRow.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/ExpandableRow.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBOzs7O0FBWUEsZ0NBQ0EsVUFDQSxpQkFDQSxnQ0FDQSxVQUNBLHlCQUNBLGdCQUNBLDBCQUNBOztDQUNBO0NBRUE7Q0FFQTtFQUNBO0dBQ0E7RUFDQTtHQUNBO0VBQ0E7Q0FDQTtDQUVBLE9BQ0EsZ0RBQ0E7RUFDQSxjQUNBLHNEQUNBLFNBQ0E7RUFDQTtFQUNBO1lBTkEsQ0FPQSxVQUNBLG9CQUNBO0dBQUE7R0FBQTthQUNBO0lBQ0E7SUFDQTtLQUNBO0tBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO2NBQ0EsYUFDQTtLQUFBO0tBQUE7S0FBQTtJQUFnRTs7OztlQUVoRTtLQUFBO0tBQUE7S0FBQTtJQUFrRTs7Ozs7R0FFbEU7Ozs7O0VBQ0E7Ozs7VUFFQTs7Ozs7V0FDQSxjQUNBO0VBQUE7RUFBQTtZQUNBO0dBQUE7R0FBQTtHQUFBO2FBQ0E7SUFBQTtJQUFBO2NBQ0E7R0FDQTs7Ozs7RUFDQTs7Ozs7Q0FDQTs7OztTQUVBOzs7OztBQUVBOzs7QUFTQSx1Q0FDQSxPQUNBLG1CQUNBLFVBQ0Esa0JBQ0E7Q0FDQSxPQUNBO0VBQUE7RUFBQTtZQUFBLENBQ0EsU0FDQTtHQUFBO0dBQUE7YUFBQSxDQUNBO0lBQUE7SUFBQTtjQUE4RDtHQUFBOzs7O2FBQzlELHFCQUNBO0lBQ0E7SUFDQTtLQUNBO0tBQ0E7SUFDQTtJQUNBO0lBQ0E7Y0FQQSxDQU9ZLDBCQUVaO0tBQUE7S0FBQTtJQUFzQzs7OztZQUN0Qzs7Ozs7V0FFQTs7Ozs7WUFFQSxRQUNBOzs7Ozs7QUFFQSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRXhwYW5kYWJsZVJvdy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBDaGV2cm9uRG93biwgQ2hldnJvblVwLCBFeHRlcm5hbExpbmsgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgY24gfSBmcm9tICcjL2xpYi9kZXNpZ24tc3lzdGVtJztcblxuaW50ZXJmYWNlIEV4cGFuZGFibGVSb3dQcm9wcyB7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG4gIGV4cGFuZGVkQ29udGVudDogUmVhY3QuUmVhY3ROb2RlO1xuICBpc0V4cGFuZGVkPzogYm9vbGVhbjtcbiAgb25Ub2dnbGU/OiAoKSA9PiB2b2lkO1xuICBzaG93RXhwYW5kQnV0dG9uPzogYm9vbGVhbjtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBleHBhbmRlZENsYXNzTmFtZT86IHN0cmluZztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEV4cGFuZGFibGVSb3coe1xuICBjaGlsZHJlbixcbiAgZXhwYW5kZWRDb250ZW50LFxuICBpc0V4cGFuZGVkOiBjb250cm9sbGVkRXhwYW5kZWQsXG4gIG9uVG9nZ2xlLFxuICBzaG93RXhwYW5kQnV0dG9uID0gdHJ1ZSxcbiAgY2xhc3NOYW1lID0gJycsXG4gIGV4cGFuZGVkQ2xhc3NOYW1lID0gJycsXG59OiBFeHBhbmRhYmxlUm93UHJvcHMpIHtcbiAgY29uc3QgW2ludGVybmFsRXhwYW5kZWQsIHNldEludGVybmFsRXhwYW5kZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGlzRXhwYW5kZWQgPSBjb250cm9sbGVkRXhwYW5kZWQgIT09IHVuZGVmaW5lZCA/IGNvbnRyb2xsZWRFeHBhbmRlZCA6IGludGVybmFsRXhwYW5kZWQ7XG5cbiAgY29uc3QgaGFuZGxlVG9nZ2xlID0gKCkgPT4ge1xuICAgIGlmIChvblRvZ2dsZSkge1xuICAgICAgb25Ub2dnbGUoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0SW50ZXJuYWxFeHBhbmRlZCghaW50ZXJuYWxFeHBhbmRlZCk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDx0clxuICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICdob3ZlcjpiZy1zbGF0ZS01MCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlcicsXG4gICAgICAgICAgY2xhc3NOYW1lXG4gICAgICAgICl9XG4gICAgICAgIG9uQ2xpY2s9e2hhbmRsZVRvZ2dsZX1cbiAgICAgID5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgICB7c2hvd0V4cGFuZEJ1dHRvbiAmJiAoXG4gICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgaGFuZGxlVG9nZ2xlKCk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSByb3VuZGVkIGhvdmVyOmJnLXNsYXRlLTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2lzRXhwYW5kZWQgPyAnQ29sbGFwc2UnIDogJ0V4cGFuZCd9XG4gICAgICAgICAgICAgIGFyaWEtZXhwYW5kZWQ9e2lzRXhwYW5kZWR9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtpc0V4cGFuZGVkID8gKFxuICAgICAgICAgICAgICAgIDxDaGV2cm9uVXAgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8Q2hldnJvbkRvd24gc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvdGQ+XG4gICAgICAgICl9XG4gICAgICA8L3RyPlxuICAgICAge2lzRXhwYW5kZWQgJiYgKFxuICAgICAgICA8dHIgY2xhc3NOYW1lPXtjbignYmctc2xhdGUtNTAvNTAnLCBleHBhbmRlZENsYXNzTmFtZSl9PlxuICAgICAgICAgIDx0ZCBjb2xTcGFuPXtzaG93RXhwYW5kQnV0dG9uID8gMTAwIDogOTl9IGNsYXNzTmFtZT1cInB4LTQgcHktNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLWluIGZhZGUtaW4gc2xpZGUtaW4tZnJvbS10b3AtMiBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAge2V4cGFuZGVkQ29udGVudH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvdGQ+XG4gICAgICAgIDwvdHI+XG4gICAgICApfVxuICAgIDwvPlxuICApO1xufVxuXG5pbnRlcmZhY2UgRXhwYW5kYWJsZVJvd0NvbnRlbnRQcm9wcyB7XG4gIHRpdGxlPzogc3RyaW5nO1xuICBvblZpZXdGdWxsRGV0YWlscz86ICgpID0+IHZvaWQ7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEV4cGFuZGFibGVSb3dDb250ZW50KHtcbiAgdGl0bGUsXG4gIG9uVmlld0Z1bGxEZXRhaWxzLFxuICBjaGlsZHJlbixcbiAgY2xhc3NOYW1lID0gJycsXG59OiBFeHBhbmRhYmxlUm93Q29udGVudFByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2NuKCdzcGFjZS15LTQnLCBjbGFzc05hbWUpfT5cbiAgICAgIHt0aXRsZSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPnt0aXRsZX08L2g0PlxuICAgICAgICAgIHtvblZpZXdGdWxsRGV0YWlscyAmJiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgb25WaWV3RnVsbERldGFpbHMoKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC14cyB0ZXh0LWVtZXJhbGQtNjAwIGhvdmVyOnRleHQtZW1lcmFsZC03MDAgZm9udC1tZWRpdW1cIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBWZXIgRGV0YWxoZXMgQ29tcGxldG9zXG4gICAgICAgICAgICAgIDxFeHRlcm5hbExpbmsgc2l6ZT17MTJ9IC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3plbHRvL09uZURyaXZlL0RvY3VtZW50b3MvR2l0SHViL1hpdGlxdWVBcHBVSS9zcmMvY29tcG9uZW50cy91aS9FeHBhbmRhYmxlUm93LnRzeCJ9