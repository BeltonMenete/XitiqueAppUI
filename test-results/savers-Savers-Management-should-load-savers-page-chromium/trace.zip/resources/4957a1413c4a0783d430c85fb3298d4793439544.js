import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/StatusBadge.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { cn, getStatusColor } from "/src/lib/design-system.ts";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/StatusBadge.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
export function StatusBadge({ status, children, className = "", size = "md" }) {
	const sizeClasses = {
		sm: "px-2 py-0.5 text-[10px]",
		md: "px-2.5 py-1 text-xs",
		lg: "px-3 py-1.5 text-sm"
	};
	return /* @__PURE__ */ _jsxDEV("span", {
		className: cn("inline-flex items-center rounded-full font-medium", getStatusColor(status), sizeClasses[size], className),
		"data-tsd-source": "/src/components/ui/StatusBadge.tsx:19:5",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 5
	}, this);
}
_c = StatusBadge;
// Specific status badge components for common use cases
export function PaidBadge({ children = "Pago" }) {
	return /* @__PURE__ */ _jsxDEV(StatusBadge, {
		status: "success",
		"data-tsd-source": "/src/components/ui/StatusBadge.tsx:34:10",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 34,
		columnNumber: 10
	}, this);
}
_c2 = PaidBadge;
export function PendingBadge({ children = "Pendente" }) {
	return /* @__PURE__ */ _jsxDEV(StatusBadge, {
		status: "warning",
		"data-tsd-source": "/src/components/ui/StatusBadge.tsx:38:10",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 10
	}, this);
}
_c3 = PendingBadge;
export function DebtBadge({ children = "Em Dívida" }) {
	return /* @__PURE__ */ _jsxDEV(StatusBadge, {
		status: "error",
		"data-tsd-source": "/src/components/ui/StatusBadge.tsx:42:10",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 42,
		columnNumber: 10
	}, this);
}
_c4 = DebtBadge;
export function ActiveBadge({ children = "Activo" }) {
	return /* @__PURE__ */ _jsxDEV(StatusBadge, {
		status: "active",
		"data-tsd-source": "/src/components/ui/StatusBadge.tsx:46:10",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 10
	}, this);
}
_c5 = ActiveBadge;
export function InactiveBadge({ children = "Inactivo" }) {
	return /* @__PURE__ */ _jsxDEV(StatusBadge, {
		status: "inactive",
		"data-tsd-source": "/src/components/ui/StatusBadge.tsx:50:10",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 50,
		columnNumber: 10
	}, this);
}
_c6 = InactiveBadge;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "StatusBadge");
$RefreshReg$(_c2, "PaidBadge");
$RefreshReg$(_c3, "PendingBadge");
$RefreshReg$(_c4, "DebtBadge");
$RefreshReg$(_c5, "ActiveBadge");
$RefreshReg$(_c6, "InactiveBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/StatusBadge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/StatusBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/StatusBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/StatusBadge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQ0E7OztBQVNBO0NBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDQTtDQUVBLE9BQ0E7RUFDQSxjQUNBLHFEQUNBLHdCQUNBLG1CQUNBLFNBQ0E7RUFDQTtFQUNBO0NBQ0E7Ozs7O0FBRUE7OztBQUdBO0NBQ0E7RUFBQTtFQUFBO0VBQXNDO0NBQUE7Ozs7O0FBQ3RDOztBQUVBO0NBQ0E7RUFBQTtFQUFBO0VBQXNDO0NBQUE7Ozs7O0FBQ3RDOztBQUVBO0NBQ0E7RUFBQTtFQUFBO0VBQW9DO0NBQUE7Ozs7O0FBQ3BDOztBQUVBO0NBQ0E7RUFBQTtFQUFBO0VBQXFDO0NBQUE7Ozs7O0FBQ3JDOztBQUVBO0NBQ0E7RUFBQTtFQUFBO0VBQXVDO0NBQUE7Ozs7O0FBQ3ZDIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTdGF0dXNCYWRnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNuLCBnZXRTdGF0dXNDb2xvciwgdHlwZSBTdGF0dXNUeXBlIH0gZnJvbSBcIiMvbGliL2Rlc2lnbi1zeXN0ZW1cIjtcblxuaW50ZXJmYWNlIFN0YXR1c0JhZGdlUHJvcHMge1xuICBzdGF0dXM6IFN0YXR1c1R5cGU7XG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc2l6ZT86IFwic21cIiB8IFwibWRcIiB8IFwibGdcIjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFN0YXR1c0JhZGdlKHsgc3RhdHVzLCBjaGlsZHJlbiwgY2xhc3NOYW1lID0gXCJcIiwgc2l6ZSA9IFwibWRcIiB9OiBTdGF0dXNCYWRnZVByb3BzKSB7XG4gIGNvbnN0IHNpemVDbGFzc2VzID0ge1xuICAgIHNtOiBcInB4LTIgcHktMC41IHRleHQtWzEwcHhdXCIsXG4gICAgbWQ6IFwicHgtMi41IHB5LTEgdGV4dC14c1wiLFxuICAgIGxnOiBcInB4LTMgcHktMS41IHRleHQtc21cIixcbiAgfTtcbiAgXG4gIHJldHVybiAoXG4gICAgPHNwYW5cbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHJvdW5kZWQtZnVsbCBmb250LW1lZGl1bVwiLFxuICAgICAgICBnZXRTdGF0dXNDb2xvcihzdGF0dXMpLFxuICAgICAgICBzaXplQ2xhc3Nlc1tzaXplXSxcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L3NwYW4+XG4gICk7XG59XG5cbi8vIFNwZWNpZmljIHN0YXR1cyBiYWRnZSBjb21wb25lbnRzIGZvciBjb21tb24gdXNlIGNhc2VzXG5leHBvcnQgZnVuY3Rpb24gUGFpZEJhZGdlKHsgY2hpbGRyZW4gPSBcIlBhZ29cIiB9OiB7IGNoaWxkcmVuPzogUmVhY3ROb2RlIH0pIHtcbiAgcmV0dXJuIDxTdGF0dXNCYWRnZSBzdGF0dXM9XCJzdWNjZXNzXCI+e2NoaWxkcmVufTwvU3RhdHVzQmFkZ2U+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gUGVuZGluZ0JhZGdlKHsgY2hpbGRyZW4gPSBcIlBlbmRlbnRlXCIgfTogeyBjaGlsZHJlbj86IFJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiA8U3RhdHVzQmFkZ2Ugc3RhdHVzPVwid2FybmluZ1wiPntjaGlsZHJlbn08L1N0YXR1c0JhZGdlPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIERlYnRCYWRnZSh7IGNoaWxkcmVuID0gXCJFbSBEw612aWRhXCIgfTogeyBjaGlsZHJlbj86IFJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiA8U3RhdHVzQmFkZ2Ugc3RhdHVzPVwiZXJyb3JcIj57Y2hpbGRyZW59PC9TdGF0dXNCYWRnZT47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBBY3RpdmVCYWRnZSh7IGNoaWxkcmVuID0gXCJBY3Rpdm9cIiB9OiB7IGNoaWxkcmVuPzogUmVhY3ROb2RlIH0pIHtcbiAgcmV0dXJuIDxTdGF0dXNCYWRnZSBzdGF0dXM9XCJhY3RpdmVcIj57Y2hpbGRyZW59PC9TdGF0dXNCYWRnZT47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBJbmFjdGl2ZUJhZGdlKHsgY2hpbGRyZW4gPSBcIkluYWN0aXZvXCIgfTogeyBjaGlsZHJlbj86IFJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiA8U3RhdHVzQmFkZ2Ugc3RhdHVzPVwiaW5hY3RpdmVcIj57Y2hpbGRyZW59PC9TdGF0dXNCYWRnZT47XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3plbHRvL09uZURyaXZlL0RvY3VtZW50b3MvR2l0SHViL1hpdGlxdWVBcHBVSS9zcmMvY29tcG9uZW50cy91aS9TdGF0dXNCYWRnZS50c3gifQ==