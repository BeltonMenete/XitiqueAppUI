import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Button.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];import { cn } from "/src/lib/design-system.ts";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/Button.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
export function Button({ children, className = "", variant = "primary", size = "md", isLoading = false, loadingText = "Carregando...", leftIcon, rightIcon, disabled, ...props }) {
	const baseClasses = "inline-flex items-center justify-center rounded-lg font-semibold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60";
	const sizeClasses = {
		sm: "px-3 py-1.5 text-xs",
		md: "px-4 py-2 text-sm",
		lg: "px-6 py-3 text-base"
	};
	const variantClasses = {
		primary: "bg-emerald-600 text-white hover:bg-emerald-700 focus:ring-emerald-500",
		secondary: "bg-slate-100 text-slate-700 hover:bg-slate-200 focus:ring-slate-500",
		danger: "bg-red-500 text-white hover:bg-red-600 focus:ring-red-500",
		ghost: "bg-transparent text-slate-600 hover:bg-slate-100 focus:ring-slate-500",
		outline: "border border-slate-300 text-slate-700 hover:bg-slate-50 focus:ring-slate-500"
	};
	return /* @__PURE__ */ _jsxDEV("button", {
		className: cn(baseClasses, sizeClasses[size], variantClasses[variant], className),
		disabled: disabled || isLoading,
		...props,
		children: isLoading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("svg", {
			className: "animate-spin -ml-1 mr-2 h-4 w-4",
			xmlns: "http://www.w3.org/2000/svg",
			fill: "none",
			viewBox: "0 0 24 24",
			"aria-hidden": "true",
			"data-tsd-source": "/src/components/ui/Button.tsx:55:11",
			children: [
				/* @__PURE__ */ _jsxDEV("title", {
					"data-tsd-source": "/src/components/ui/Button.tsx:62:13",
					children: "Carregando"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("circle", {
					className: "opacity-25",
					cx: "12",
					cy: "12",
					r: "10",
					stroke: "currentColor",
					strokeWidth: "4",
					"data-tsd-source": "/src/components/ui/Button.tsx:63:13"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					className: "opacity-75",
					fill: "currentColor",
					d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z",
					"data-tsd-source": "/src/components/ui/Button.tsx:71:13"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 11
		}, this), loadingText] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 54,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
			leftIcon && /* @__PURE__ */ _jsxDEV("span", {
				className: "mr-2",
				"data-tsd-source": "/src/components/ui/Button.tsx:81:24",
				children: leftIcon
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 24
			}, this),
			children,
			rightIcon && /* @__PURE__ */ _jsxDEV("span", {
				className: "ml-2",
				"data-tsd-source": "/src/components/ui/Button.tsx:83:25",
				children: rightIcon
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 25
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 5
	}, this);
}
_c = Button;
var _c;
$RefreshReg$(_c, "Button");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/Button.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/Button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/Button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/Button.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQ0E7OztBQVlBLHlCQUNBLFVBQ0EsZ0JBQ0EscUJBQ0EsYUFDQSxtQkFDQSwrQkFDQSxVQUNBLFdBQ0EsVUFDQSxZQUNBO0NBQ0E7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtDQUNBO0NBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0E7Q0FFQSxPQUNBO0VBQ0EsY0FDQSxhQUNBLG1CQUNBLHlCQUNBLFNBQ0E7RUFDQTtFQUNBO1lBRUEsWUFDQSxnREFDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTthQU5BO0lBT0E7S0FBQTtlQUFrQjtJQUFBOzs7OztJQUNsQjtLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0lBQVk7Ozs7O0lBQ1o7S0FDQTtLQUNBO0tBQ0E7S0FDQTtJQUFZOzs7OztHQUNaOzs7OztZQUNBLFdBQ0E7Ozs7YUFFQTtHQUNBO0lBQUE7SUFBQTtjQUE2QztHQUFBOzs7OztHQUM3QztHQUNBO0lBQUE7SUFBQTtjQUE4QztHQUFBOzs7OztFQUM5Qzs7Ozs7Q0FFQTs7Ozs7QUFFQSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQnV0dG9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IEJ1dHRvbkhUTUxBdHRyaWJ1dGVzLCBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNuLCB0eXBlIEJ1dHRvblZhcmlhbnQgfSBmcm9tIFwiIy9saWIvZGVzaWduLXN5c3RlbVwiO1xuXG5pbnRlcmZhY2UgQnV0dG9uUHJvcHMgZXh0ZW5kcyBCdXR0b25IVE1MQXR0cmlidXRlczxIVE1MQnV0dG9uRWxlbWVudD4ge1xuICBjaGlsZHJlbjogUmVhY3ROb2RlO1xuICB2YXJpYW50PzogQnV0dG9uVmFyaWFudDtcbiAgc2l6ZT86IFwic21cIiB8IFwibWRcIiB8IFwibGdcIjtcbiAgaXNMb2FkaW5nPzogYm9vbGVhbjtcbiAgbG9hZGluZ1RleHQ/OiBzdHJpbmc7XG4gIGxlZnRJY29uPzogUmVhY3ROb2RlO1xuICByaWdodEljb24/OiBSZWFjdE5vZGU7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBCdXR0b24oe1xuICBjaGlsZHJlbixcbiAgY2xhc3NOYW1lID0gXCJcIixcbiAgdmFyaWFudCA9IFwicHJpbWFyeVwiLFxuICBzaXplID0gXCJtZFwiLFxuICBpc0xvYWRpbmcgPSBmYWxzZSxcbiAgbG9hZGluZ1RleHQgPSBcIkNhcnJlZ2FuZG8uLi5cIixcbiAgbGVmdEljb24sXG4gIHJpZ2h0SWNvbixcbiAgZGlzYWJsZWQsXG4gIC4uLnByb3BzXG59OiBCdXR0b25Qcm9wcykge1xuICBjb25zdCBiYXNlQ2xhc3NlcyA9IFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLW9mZnNldC0yIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBkaXNhYmxlZDpvcGFjaXR5LTYwXCI7XG5cbiAgY29uc3Qgc2l6ZUNsYXNzZXMgPSB7XG4gICAgc206IFwicHgtMyBweS0xLjUgdGV4dC14c1wiLFxuICAgIG1kOiBcInB4LTQgcHktMiB0ZXh0LXNtXCIsXG4gICAgbGc6IFwicHgtNiBweS0zIHRleHQtYmFzZVwiLFxuICB9O1xuXG4gIGNvbnN0IHZhcmlhbnRDbGFzc2VzID0ge1xuICAgIHByaW1hcnk6IFwiYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1lbWVyYWxkLTcwMCBmb2N1czpyaW5nLWVtZXJhbGQtNTAwXCIsXG4gICAgc2Vjb25kYXJ5OiBcImJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZm9jdXM6cmluZy1zbGF0ZS01MDBcIixcbiAgICBkYW5nZXI6IFwiYmctcmVkLTUwMCB0ZXh0LXdoaXRlIGhvdmVyOmJnLXJlZC02MDAgZm9jdXM6cmluZy1yZWQtNTAwXCIsXG4gICAgZ2hvc3Q6IFwiYmctdHJhbnNwYXJlbnQgdGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtMTAwIGZvY3VzOnJpbmctc2xhdGUtNTAwXCIsXG4gICAgb3V0bGluZTogXCJib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCB0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS01MCBmb2N1czpyaW5nLXNsYXRlLTUwMFwiLFxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGJ1dHRvblxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgYmFzZUNsYXNzZXMsXG4gICAgICAgIHNpemVDbGFzc2VzW3NpemVdLFxuICAgICAgICB2YXJpYW50Q2xhc3Nlc1t2YXJpYW50XSxcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkIHx8IGlzTG9hZGluZ31cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICB7aXNMb2FkaW5nID8gKFxuICAgICAgICA8PlxuICAgICAgICAgIDxzdmdcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiAtbWwtMSBtci0yIGgtNCB3LTRcIlxuICAgICAgICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcbiAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHRpdGxlPkNhcnJlZ2FuZG88L3RpdGxlPlxuICAgICAgICAgICAgPGNpcmNsZVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvcGFjaXR5LTI1XCJcbiAgICAgICAgICAgICAgY3g9XCIxMlwiXG4gICAgICAgICAgICAgIGN5PVwiMTJcIlxuICAgICAgICAgICAgICByPVwiMTBcIlxuICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjRcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm9wYWNpdHktNzVcIlxuICAgICAgICAgICAgICBmaWxsPVwiY3VycmVudENvbG9yXCJcbiAgICAgICAgICAgICAgZD1cIk00IDEyYTggOCAwIDAxOC04VjBDNS4zNzMgMCAwIDUuMzczIDAgMTJoNHptMiA1LjI5MUE3Ljk2MiA3Ljk2MiAwIDAxNCAxMkgwYzAgMy4wNDIgMS4xMzUgNS44MjQgMyA3LjkzOGwzLTIuNjQ3elwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgIHtsb2FkaW5nVGV4dH1cbiAgICAgICAgPC8+XG4gICAgICApIDogKFxuICAgICAgICA8PlxuICAgICAgICAgIHtsZWZ0SWNvbiAmJiA8c3BhbiBjbGFzc05hbWU9XCJtci0yXCI+e2xlZnRJY29ufTwvc3Bhbj59XG4gICAgICAgICAge2NoaWxkcmVufVxuICAgICAgICAgIHtyaWdodEljb24gJiYgPHNwYW4gY2xhc3NOYW1lPVwibWwtMlwiPntyaWdodEljb259PC9zcGFuPn1cbiAgICAgICAgPC8+XG4gICAgICApfVxuICAgIDwvYnV0dG9uPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy96ZWx0by9PbmVEcml2ZS9Eb2N1bWVudG9zL0dpdEh1Yi9YaXRpcXVlQXBwVUkvc3JjL2NvbXBvbmVudHMvdWkvQnV0dG9uLnRzeCJ9