import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/business/QuickDepositModal.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03f72e91";
import { Modal, ModalFooter } from "/src/components/ui/Modal.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { DollarSign, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=03f72e91";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/QuickDepositModal.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
var _s = $RefreshSig$();
export function QuickDepositModal({ isOpen, onClose, onSubmit, saverName, lastAmount }) {
	_s();
	const [formData, setFormData] = useState({
		amount: lastAmount ? String(lastAmount) : "",
		date: new Date().toISOString().split("T")[0],
		notes: ""
	});
	const [showToast, setShowToast] = useState(false);
	const handleSubmit = (e) => {
		e.preventDefault();
		onSubmit(formData);
		setShowToast(true);
		setTimeout(() => {
			setShowToast(false);
			onClose();
		}, 2e3);
	};
	const handleCancel = () => {
		setFormData({
			amount: lastAmount ? String(lastAmount) : "",
			date: new Date().toISOString().split("T")[0],
			notes: ""
		});
		onClose();
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Modal, {
		isOpen,
		onClose: handleCancel,
		title: "Registar Depósito",
		size: "sm",
		"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:50:7",
		children: /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			className: "space-y-4",
			"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:51:9",
			children: [
				saverName && /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-50 p-3 rounded-lg",
					"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:53:13",
					children: /* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-slate-600",
						"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:54:15",
						children: ["Depositando para: ", /* @__PURE__ */ _jsxDEV("span", {
							className: "font-semibold text-slate-900",
							"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:54:71",
							children: saverName
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 54,
							columnNumber: 142
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:58:11",
					children: [
						/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "amount",
							className: "block text-sm font-medium text-slate-700 mb-1",
							"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:59:13",
							children: "Valor do Depósito (MZN) *"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:62:13",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",
								"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:63:15",
								children: /* @__PURE__ */ _jsxDEV(DollarSign, {
									size: 16,
									className: "text-slate-400",
									"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:64:17"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 64,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 63,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								id: "amount",
								type: "number",
								placeholder: "0.00",
								required: true,
								value: formData.amount,
								onChange: (e) => setFormData({
									...formData,
									amount: e.target.value
								}),
								className: "block w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
								min: "0",
								step: "0.01",
								"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:66:15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 13
						}, this),
						lastAmount && /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setFormData({
								...formData,
								amount: String(lastAmount)
							}),
							className: "text-xs text-emerald-600 hover:text-emerald-700 mt-1",
							"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:79:15",
							children: [
								"Usar último valor: ",
								lastAmount,
								" MZN"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:89:11",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "date",
						className: "block text-sm font-medium text-slate-700 mb-1",
						"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:90:13",
						children: "Data *"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "date",
						type: "date",
						required: true,
						value: formData.date,
						onChange: (e) => setFormData({
							...formData,
							date: e.target.value
						}),
						className: "block w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
						"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:93:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:103:11",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "notes",
						className: "block text-sm font-medium text-slate-700 mb-1",
						"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:104:13",
						children: "Notas (Opcional)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("textarea", {
						id: "notes",
						placeholder: "Observações sobre o depósito...",
						rows: 2,
						value: formData.notes,
						onChange: (e) => setFormData({
							...formData,
							notes: e.target.value
						}),
						className: "block w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 resize-none",
						"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:107:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(ModalFooter, {
					"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:117:11",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						type: "button",
						variant: "outline",
						onClick: handleCancel,
						"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:118:13",
						children: "Cancelar"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						type: "submit",
						leftIcon: /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 45
						}, this),
						"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:121:13",
						children: "Confirmar Depósito"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 117,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 50,
		columnNumber: 7
	}, this), showToast && /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed bottom-6 right-6 bg-white border-l-4 border-emerald-500 shadow-lg rounded-lg p-4 transform transition-all duration-300 z-50 flex items-start gap-4 max-w-sm",
		"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:130:9",
		children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
			className: "text-emerald-500 mt-0.5",
			size: 20,
			"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:131:11"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 131,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex-1",
			"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:132:11",
			children: [/* @__PURE__ */ _jsxDEV("h4", {
				className: "text-sm font-medium text-slate-900",
				"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:133:13",
				children: "Depósito Registado"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 133,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-slate-500 mt-1",
				"data-tsd-source": "/src/components/business/QuickDepositModal.tsx:134:13",
				children: "O depósito foi registado com sucesso."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 134,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 132,
			columnNumber: 11
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 130,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 5
	}, this);
}
_s(QuickDepositModal, "pJMEbiQA6pETw/48g6ou6+oZEuU=");
_c = QuickDepositModal;
var _c;
$RefreshReg$(_c, "QuickDepositModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/business/QuickDepositModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/QuickDepositModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/QuickDepositModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/QuickDepositModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFnQkE7O0NBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDQTtDQUVBO0NBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0dBQ0E7RUFDQTtDQUNBO0NBRUE7RUFDQTtHQUNBO0dBQ0E7R0FDQTtFQUNBO0VBQ0E7Q0FDQTtDQUVBLE9BQ0EsZ0RBQ0E7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO1lBQ0E7R0FBQTtHQUFBO0dBQUE7YUFBQTtJQUNBLGFBQ0E7S0FBQTtLQUFBO2VBQ0E7TUFBQTtNQUFBO2dCQUFBLENBQW1EO09BQUE7T0FBQTtpQkFBaUU7TUFBQTs7OztjQUFBOzs7Ozs7SUFDcEg7Ozs7O0lBR0E7S0FBQTtlQUFBO01BQ0E7T0FBQTtPQUFBO09BQUE7aUJBQTZGO01BRTdGOzs7OztNQUNBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtrQkFDQTtTQUFBO1NBQUE7U0FBQTtRQUFpRTs7Ozs7T0FDakU7Ozs7aUJBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7U0FBQTtTQUFBO1FBQUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtPQUFjOzs7O2VBQ2Q7Ozs7OztNQUNBLGNBQ0E7T0FDQTtPQUNBO1FBQUE7UUFBQTtPQUFBO09BQ0E7T0FDQTtpQkFKQTtRQUljO1FBQ2Q7UUFBQTtPQUNBOzs7Ozs7S0FFQTs7Ozs7O0lBRUE7S0FBQTtlQUFBLENBQ0E7TUFBQTtNQUFBO01BQUE7Z0JBQTJGO0tBRTNGOzs7O2VBQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO09BQUE7T0FBQTtNQUFBO01BQ0E7TUFDQTtLQUFZOzs7O2FBQ1o7Ozs7OztJQUVBO0tBQUE7ZUFBQSxDQUNBO01BQUE7TUFBQTtNQUFBO2dCQUE0RjtLQUU1Rjs7OztlQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtPQUFBO09BQUE7TUFBQTtNQUNBO01BQ0E7S0FBWTs7OzthQUNaOzs7Ozs7SUFFQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO01BQUE7TUFBQTtNQUFBO2dCQUEwRTtLQUUxRTs7OztlQUNBO01BQUE7TUFBQTs7Ozs7TUFBQTtnQkFBdUU7S0FFdkU7Ozs7YUFDQTs7Ozs7O0dBQ0E7Ozs7OztDQUNBOzs7O1dBR0EsYUFDQTtFQUFBO0VBQUE7WUFBQSxDQUNBO0dBQUE7R0FBQTtHQUFBO0VBQXNFOzs7O1lBQ3RFO0dBQUE7R0FBQTthQUFBLENBQ0E7SUFBQTtJQUFBO2NBQThEO0dBQUE7Ozs7YUFDOUQ7SUFBQTtJQUFBO2NBQXNEO0dBQUE7Ozs7V0FDdEQ7Ozs7O1VBQ0E7Ozs7O1NBRUE7Ozs7O0FBRUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlF1aWNrRGVwb3NpdE1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IE1vZGFsLCBNb2RhbEZvb3RlciB9IGZyb20gJyMvY29tcG9uZW50cy91aS9Nb2RhbCc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcjL2NvbXBvbmVudHMvdWkvQnV0dG9uJztcbmltcG9ydCB7IERvbGxhclNpZ24sIENoZWNrQ2lyY2xlMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmludGVyZmFjZSBRdWlja0RlcG9zaXRNb2RhbFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvblN1Ym1pdDogKGRhdGE6IERlcG9zaXREYXRhKSA9PiB2b2lkO1xuICBzYXZlck5hbWU/OiBzdHJpbmc7XG4gIGxhc3RBbW91bnQ/OiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBEZXBvc2l0RGF0YSB7XG4gIGFtb3VudDogc3RyaW5nO1xuICBkYXRlOiBzdHJpbmc7XG4gIG5vdGVzPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gUXVpY2tEZXBvc2l0TW9kYWwoeyBpc09wZW4sIG9uQ2xvc2UsIG9uU3VibWl0LCBzYXZlck5hbWUsIGxhc3RBbW91bnQgfTogUXVpY2tEZXBvc2l0TW9kYWxQcm9wcykge1xuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlPERlcG9zaXREYXRhPih7XG4gICAgYW1vdW50OiBsYXN0QW1vdW50ID8gU3RyaW5nKGxhc3RBbW91bnQpIDogJycsXG4gICAgZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gICAgbm90ZXM6ICcnLFxuICB9KTtcblxuICBjb25zdCBbc2hvd1RvYXN0LCBzZXRTaG93VG9hc3RdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgb25TdWJtaXQoZm9ybURhdGEpO1xuICAgIHNldFNob3dUb2FzdCh0cnVlKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHNldFNob3dUb2FzdChmYWxzZSk7XG4gICAgICBvbkNsb3NlKCk7XG4gICAgfSwgMjAwMCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2FuY2VsID0gKCkgPT4ge1xuICAgIHNldEZvcm1EYXRhKHtcbiAgICAgIGFtb3VudDogbGFzdEFtb3VudCA/IFN0cmluZyhsYXN0QW1vdW50KSA6ICcnLFxuICAgICAgZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gICAgICBub3RlczogJycsXG4gICAgfSk7XG4gICAgb25DbG9zZSgpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxNb2RhbCBpc09wZW49e2lzT3Blbn0gb25DbG9zZT17aGFuZGxlQ2FuY2VsfSB0aXRsZT1cIlJlZ2lzdGFyIERlcMOzc2l0b1wiIHNpemU9XCJzbVwiPlxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICB7c2F2ZXJOYW1lICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgcC0zIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTYwMFwiPkRlcG9zaXRhbmRvIHBhcmE6IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj57c2F2ZXJOYW1lfTwvc3Bhbj48L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiYW1vdW50XCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgICAgICAgIFZhbG9yIGRvIERlcMOzc2l0byAoTVpOKSAqXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcGwtMyBmbGV4IGl0ZW1zLWNlbnRlciBwb2ludGVyLWV2ZW50cy1ub25lXCI+XG4gICAgICAgICAgICAgICAgPERvbGxhclNpZ24gc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIGlkPVwiYW1vdW50XCJcbiAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIlxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFtb3VudH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIGFtb3VudDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHBsLTEwIHByLTMgcHktMiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge2xhc3RBbW91bnQgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgYW1vdW50OiBTdHJpbmcobGFzdEFtb3VudCkgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWVtZXJhbGQtNjAwIGhvdmVyOnRleHQtZW1lcmFsZC03MDAgbXQtMVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBVc2FyIMO6bHRpbW8gdmFsb3I6IHtsYXN0QW1vdW50fSBNWk5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZGF0ZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICBEYXRhICpcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgaWQ9XCJkYXRlXCJcbiAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZGF0ZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBkYXRlOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm5vdGVzXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgICAgICAgIE5vdGFzIChPcGNpb25hbClcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgaWQ9XCJub3Rlc1wiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiT2JzZXJ2YcOnw7VlcyBzb2JyZSBvIGRlcMOzc2l0by4uLlwiXG4gICAgICAgICAgICAgIHJvd3M9ezJ9XG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ub3Rlc31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBub3RlczogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAvMjAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIHJlc2l6ZS1ub25lXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8TW9kYWxGb290ZXI+XG4gICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e2hhbmRsZUNhbmNlbH0+XG4gICAgICAgICAgICAgIENhbmNlbGFyXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIGxlZnRJY29uPXs8Q2hlY2tDaXJjbGUyIHNpemU9ezE2fSAvPn0+XG4gICAgICAgICAgICAgIENvbmZpcm1hciBEZXDDs3NpdG9cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvTW9kYWxGb290ZXI+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvTW9kYWw+XG5cbiAgICAgIHsvKiBUb2FzdCBOb3RpZmljYXRpb24gKi99XG4gICAgICB7c2hvd1RvYXN0ICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBib3R0b20tNiByaWdodC02IGJnLXdoaXRlIGJvcmRlci1sLTQgYm9yZGVyLWVtZXJhbGQtNTAwIHNoYWRvdy1sZyByb3VuZGVkLWxnIHAtNCB0cmFuc2Zvcm0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHotNTAgZmxleCBpdGVtcy1zdGFydCBnYXAtNCBtYXgtdy1zbVwiPlxuICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTUwMCBtdC0wLjVcIiBzaXplPXsyMH0gLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS05MDBcIj5EZXDDs3NpdG8gUmVnaXN0YWRvPC9oND5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbXQtMVwiPk8gZGVww7NzaXRvIGZvaSByZWdpc3RhZG8gY29tIHN1Y2Vzc28uPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC8+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3plbHRvL09uZURyaXZlL0RvY3VtZW50b3MvR2l0SHViL1hpdGlxdWVBcHBVSS9zcmMvY29tcG9uZW50cy9idXNpbmVzcy9RdWlja0RlcG9zaXRNb2RhbC50c3gifQ==