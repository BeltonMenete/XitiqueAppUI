import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/DataTable.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03f72e91";
import { ChevronUp, ChevronDown, MoreHorizontal } from "/node_modules/.vite/deps/lucide-react.js?v=03f72e91";
import { cn } from "/src/lib/design-system.ts";
import { ExpandableRow } from "/src/components/ui/ExpandableRow.tsx";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/DataTable.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
var _s = $RefreshSig$();
export function DataTable({ data, columns, isLoading = false, searchable = false, searchPlaceholder = "Pesquisar...", onRowClick, emptyMessage = "Nenhum dado encontrado", className = "", rowKey = "id", expandable = false, renderExpandedRow, onRowExpand }) {
	_s();
	const [sortColumn, setSortColumn] = useState(null);
	const [sortDirection, setSortDirection] = useState("asc");
	const [searchTerm, setSearchTerm] = useState("");
	const [expandedRows, setExpandedRows] = useState(new Set());
	const handleSort = (key) => {
		if (sortColumn === key) {
			setSortDirection(sortDirection === "asc" ? "desc" : "asc");
		} else {
			setSortColumn(key);
			setSortDirection("asc");
		}
	};
	const handleRowExpand = (row) => {
		const rowId = String(row[rowKey]);
		const newExpandedRows = new Set(expandedRows);
		if (newExpandedRows.has(rowId)) {
			newExpandedRows.delete(rowId);
		} else {
			newExpandedRows.add(rowId);
		}
		setExpandedRows(newExpandedRows);
		onRowExpand?.(row);
	};
	const isRowExpanded = (row) => {
		return expandedRows.has(String(row[rowKey]));
	};
	const filteredData = data.filter((row) => {
		if (!searchTerm) return true;
		const searchLower = searchTerm.toLowerCase();
		return columns.some((col) => {
			const value = row[col.key];
			return String(value).toLowerCase().includes(searchLower);
		});
	});
	const sortedData = [...filteredData].sort((a, b) => {
		if (!sortColumn) return 0;
		const aValue = a[sortColumn];
		const bValue = b[sortColumn];
		if (aValue < bValue) return sortDirection === "asc" ? -1 : 1;
		if (aValue > bValue) return sortDirection === "asc" ? 1 : -1;
		return 0;
	});
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: cn("bg-white border border-slate-200 rounded-lg", className),
			"data-tsd-source": "/src/components/ui/DataTable.tsx:93:7",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "p-8 flex items-center justify-center",
				"data-tsd-source": "/src/components/ui/DataTable.tsx:94:9",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600",
					"data-tsd-source": "/src/components/ui/DataTable.tsx:95:11"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 93,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn("bg-white border border-slate-200 rounded-lg overflow-hidden", className),
		"data-tsd-source": "/src/components/ui/DataTable.tsx:102:5",
		children: [
			searchable && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-4 border-b border-slate-200",
				"data-tsd-source": "/src/components/ui/DataTable.tsx:104:9",
				children: /* @__PURE__ */ _jsxDEV("input", {
					type: "text",
					placeholder: searchPlaceholder,
					value: searchTerm,
					onChange: (e) => setSearchTerm(e.target.value),
					className: "w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
					"data-tsd-source": "/src/components/ui/DataTable.tsx:105:11"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 105,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 104,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "overflow-x-auto",
				"data-tsd-source": "/src/components/ui/DataTable.tsx:115:7",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "w-full",
					"data-tsd-source": "/src/components/ui/DataTable.tsx:116:9",
					children: [/* @__PURE__ */ _jsxDEV("thead", {
						className: "bg-slate-50 border-b border-slate-200",
						"data-tsd-source": "/src/components/ui/DataTable.tsx:117:11",
						children: /* @__PURE__ */ _jsxDEV("tr", {
							"data-tsd-source": "/src/components/ui/DataTable.tsx:118:13",
							children: [columns.map((col) => /* @__PURE__ */ _jsxDEV("th", {
								className: cn("px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider", col.sortable && "cursor-pointer hover:bg-slate-100 transition-colors"),
								onClick: () => col.sortable && handleSort(col.key),
								"data-tsd-source": "/src/components/ui/DataTable.tsx:120:17",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1",
									"data-tsd-source": "/src/components/ui/DataTable.tsx:128:19",
									children: [col.header, col.sortable && sortColumn === col.key && (sortDirection === "asc" ? /* @__PURE__ */ _jsxDEV(ChevronUp, {
										className: "w-4 h-4",
										"data-tsd-source": "/src/components/ui/DataTable.tsx:132:25"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 132,
										columnNumber: 25
									}, this) : /* @__PURE__ */ _jsxDEV(ChevronDown, {
										className: "w-4 h-4",
										"data-tsd-source": "/src/components/ui/DataTable.tsx:134:25"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 134,
										columnNumber: 25
									}, this))]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 19
								}, this)
							}, col.key, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 17
							}, this)), /* @__PURE__ */ _jsxDEV("th", {
								className: "px-4 py-3 text-right",
								"data-tsd-source": "/src/components/ui/DataTable.tsx:140:15",
								children: expandable ? /* @__PURE__ */ _jsxDEV("span", {
									className: "sr-only",
									"data-tsd-source": "/src/components/ui/DataTable.tsx:141:31",
									children: "Expandir"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 31
								}, this) : /* @__PURE__ */ _jsxDEV(MoreHorizontal, {
									className: "w-4 h-4 text-slate-400",
									"data-tsd-source": "/src/components/ui/DataTable.tsx:141:75"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 133
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("tbody", {
						className: "divide-y divide-slate-100",
						"data-tsd-source": "/src/components/ui/DataTable.tsx:145:11",
						children: sortedData.length === 0 ? /* @__PURE__ */ _jsxDEV("tr", {
							"data-tsd-source": "/src/components/ui/DataTable.tsx:147:15",
							children: /* @__PURE__ */ _jsxDEV("td", {
								colSpan: columns.length + 1,
								className: "px-4 py-8 text-center text-sm text-slate-400",
								"data-tsd-source": "/src/components/ui/DataTable.tsx:148:17",
								children: emptyMessage
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 15
						}, this) : sortedData.map((row) => {
							const rowId = String(row[rowKey]);
							const expanded = isRowExpanded(row);
							if (expandable) {
								return /* @__PURE__ */ _jsxDEV(ExpandableRow, {
									isExpanded: expanded,
									onToggle: () => handleRowExpand(row),
									showExpandButton: true,
									expandedContent: renderExpandedRow?.(row),
									"data-tsd-source": "/src/components/ui/DataTable.tsx:159:21",
									children: columns.map((col) => /* @__PURE__ */ _jsxDEV("td", {
										className: "px-4 py-3 text-sm text-slate-700",
										"data-tsd-source": "/src/components/ui/DataTable.tsx:167:25",
										children: col.render ? col.render(row[col.key], row) : String(row[col.key])
									}, col.key, false, {
										fileName: _jsxFileName,
										lineNumber: 167,
										columnNumber: 25
									}, this))
								}, rowId, false, {
									fileName: _jsxFileName,
									lineNumber: 159,
									columnNumber: 21
								}, this);
							}
							return /* @__PURE__ */ _jsxDEV("tr", {
								className: cn("hover:bg-slate-50 transition-colors", onRowClick && "cursor-pointer"),
								onClick: () => onRowClick?.(row),
								"data-tsd-source": "/src/components/ui/DataTable.tsx:176:19",
								children: [columns.map((col) => /* @__PURE__ */ _jsxDEV("td", {
									className: "px-4 py-3 text-sm text-slate-700",
									"data-tsd-source": "/src/components/ui/DataTable.tsx:185:23",
									children: col.render ? col.render(row[col.key], row) : String(row[col.key])
								}, col.key, false, {
									fileName: _jsxFileName,
									lineNumber: 185,
									columnNumber: 23
								}, this)), /* @__PURE__ */ _jsxDEV("td", {
									className: "px-4 py-3 text-right",
									"data-tsd-source": "/src/components/ui/DataTable.tsx:189:21",
									children: /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "p-1 rounded hover:bg-slate-100 transition-colors",
										onClick: (e) => {
											e.stopPropagation();
											onRowClick?.(row);
										},
										"data-tsd-source": "/src/components/ui/DataTable.tsx:190:23",
										children: /* @__PURE__ */ _jsxDEV(MoreHorizontal, {
											className: "w-4 h-4 text-slate-400",
											"data-tsd-source": "/src/components/ui/DataTable.tsx:198:25"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 198,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 189,
									columnNumber: 21
								}, this)]
							}, rowId, true, {
								fileName: _jsxFileName,
								lineNumber: 176,
								columnNumber: 19
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 116,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 115,
				columnNumber: 7
			}, this),
			sortedData.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "px-4 py-3 border-t border-slate-200 bg-slate-50",
				"data-tsd-source": "/src/components/ui/DataTable.tsx:210:9",
				children: /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500",
					"data-tsd-source": "/src/components/ui/DataTable.tsx:211:11",
					children: [
						"Mostrando ",
						sortedData.length,
						" de ",
						data.length,
						" registos",
						expandable && expandedRows.size > 0 && ` (${expandedRows.size} expandido${expandedRows.size > 1 ? "s" : ""})`
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 211,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 210,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 102,
		columnNumber: 5
	}, this);
}
_s(DataTable, "/FjLonu8BXMn8hhS7Zw9OpaNiCw=");
_c = DataTable;
var _c;
$RefreshReg$(_c, "DataTable");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/DataTable.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/DataTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/DataTable.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/DataTable.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7Ozs7QUF3QkEsNEJBQ0EsTUFDQSxTQUNBLG1CQUNBLG9CQUNBLG9DQUNBLFlBQ0EseUNBQ0EsZ0JBQ0EsZUFDQSxvQkFDQSxtQkFDQSxlQUNBOztDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBRUE7RUFDQTtHQUNBO0VBQ0E7R0FDQTtHQUNBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7RUFDQTtFQUNBO0dBQ0E7RUFDQTtHQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0E7Q0FFQTtFQUNBO0NBQ0E7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0dBQ0E7RUFDQTtDQUNBO0NBRUE7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0EsT0FDQTtHQUFBO0dBQUE7YUFDQTtJQUFBO0lBQUE7Y0FDQTtLQUFBO0tBQUE7SUFBMEY7Ozs7O0dBQzFGOzs7OztFQUNBOzs7OztDQUVBO0NBRUEsT0FDQTtFQUFBO0VBQUE7WUFBQTtHQUNBLGNBQ0E7SUFBQTtJQUFBO2NBQ0E7S0FDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7SUFBVTs7Ozs7R0FDVjs7Ozs7R0FHQTtJQUFBO0lBQUE7Y0FDQTtLQUFBO0tBQUE7ZUFBQSxDQUNBO01BQUE7TUFBQTtnQkFDQTtPQUFBO2lCQUFBLENBQ0EscUJBQ0E7UUFFQSxjQUNBLHFGQUNBLHFFQUNBO1FBQ0E7UUFDQTtrQkFDQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQSxZQUNBLDJDQUNBLDBCQUNBO1VBQUE7VUFBQTtTQUF1RDs7OztvQkFFdkQ7VUFBQTtVQUFBO1NBQXlEOzs7O2tCQUd6RDs7Ozs7O09BQ0EsR0FqQkE7Ozs7Y0FpQkEsQ0FDQSxHQUNBO1FBQUE7UUFBQTtrQkFDQTtTQUFBO1NBQUE7bUJBQXVEO1FBQUE7Ozs7bUJBQUE7U0FBQTtTQUFBO1FBQXNFOzs7OztPQUM3SDs7OztlQUNBOzs7Ozs7S0FDQTs7OztlQUNBO01BQUE7TUFBQTtnQkFDQSwwQkFDQTtPQUFBO2lCQUNBO1FBQUE7UUFBQTtRQUFBO2tCQUNBO09BQ0E7Ozs7O01BQ0E7Ozs7aUJBRUE7T0FDQTtPQUNBO09BRUE7UUFDQSxPQUNBO1NBRUE7U0FDQTtTQUNBO1NBQ0E7U0FDQTttQkFDQSxxQkFDQTtVQUFBO1VBQUE7b0JBQ0E7U0FDQSxHQUZBOzs7O2dCQUVBLENBQ0E7UUFDQSxHQVhBOzs7O2VBV0E7T0FFQTtPQUVBLE9BQ0E7UUFFQSxjQUNBLHVDQUNBLDhCQUNBO1FBQ0E7UUFDQTtrQkFQQSxDQVFBLHFCQUNBO1NBQUE7U0FBQTttQkFDQTtRQUNBLEdBRkE7Ozs7ZUFFQSxDQUNBLEdBQ0E7U0FBQTtTQUFBO21CQUNBO1VBQ0E7VUFDQTtVQUNBO1dBQ0E7V0FDQTtVQUNBO1VBQ0E7b0JBQ0E7V0FBQTtXQUFBO1VBQTJFOzs7OztTQUMzRTs7Ozs7UUFDQTs7OztnQkFDQTtVQXhCQTs7OztjQXdCQTtNQUVBO0tBRUE7Ozs7YUFDQTs7Ozs7O0dBQ0E7Ozs7O0dBRUEseUJBQ0E7SUFBQTtJQUFBO2NBQ0E7S0FBQTtLQUFBO2VBQUE7TUFBK0M7TUFDL0M7TUFBQTtNQUFBO01BQUE7TUFDQTtLQUNBOzs7Ozs7R0FDQTs7Ozs7RUFFQTs7Ozs7O0FBRUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkRhdGFUYWJsZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENoZXZyb25VcCwgQ2hldnJvbkRvd24sIE1vcmVIb3Jpem9udGFsIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiIy9saWIvZGVzaWduLXN5c3RlbVwiO1xuaW1wb3J0IHsgRXhwYW5kYWJsZVJvdyB9IGZyb20gXCIuL0V4cGFuZGFibGVSb3dcIjtcblxuaW50ZXJmYWNlIENvbHVtbjxUPiB7XG4gIGtleTogc3RyaW5nO1xuICBoZWFkZXI6IHN0cmluZztcbiAgc29ydGFibGU/OiBib29sZWFuO1xuICByZW5kZXI/OiAodmFsdWU6IHVua25vd24sIHJvdzogVCkgPT4gUmVhY3QuUmVhY3ROb2RlO1xufVxuXG5pbnRlcmZhY2UgRGF0YVRhYmxlUHJvcHM8VD4ge1xuICBkYXRhOiBUW107XG4gIGNvbHVtbnM6IENvbHVtbjxUPltdO1xuICBpc0xvYWRpbmc/OiBib29sZWFuO1xuICBzZWFyY2hhYmxlPzogYm9vbGVhbjtcbiAgc2VhcmNoUGxhY2Vob2xkZXI/OiBzdHJpbmc7XG4gIG9uUm93Q2xpY2s/OiAocm93OiBUKSA9PiB2b2lkO1xuICBlbXB0eU1lc3NhZ2U/OiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgcm93S2V5Pzoga2V5b2YgVDtcbiAgZXhwYW5kYWJsZT86IGJvb2xlYW47XG4gIHJlbmRlckV4cGFuZGVkUm93PzogKHJvdzogVCkgPT4gUmVhY3QuUmVhY3ROb2RlO1xuICBvblJvd0V4cGFuZD86IChyb3c6IFQpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBEYXRhVGFibGU8VD4oe1xuICBkYXRhLFxuICBjb2x1bW5zLFxuICBpc0xvYWRpbmcgPSBmYWxzZSxcbiAgc2VhcmNoYWJsZSA9IGZhbHNlLFxuICBzZWFyY2hQbGFjZWhvbGRlciA9IFwiUGVzcXVpc2FyLi4uXCIsXG4gIG9uUm93Q2xpY2ssXG4gIGVtcHR5TWVzc2FnZSA9IFwiTmVuaHVtIGRhZG8gZW5jb250cmFkb1wiLFxuICBjbGFzc05hbWUgPSBcIlwiLFxuICByb3dLZXkgPSAnaWQnIGFzIGtleW9mIFQsXG4gIGV4cGFuZGFibGUgPSBmYWxzZSxcbiAgcmVuZGVyRXhwYW5kZWRSb3csXG4gIG9uUm93RXhwYW5kLFxufTogRGF0YVRhYmxlUHJvcHM8VD4pIHtcbiAgY29uc3QgW3NvcnRDb2x1bW4sIHNldFNvcnRDb2x1bW5dID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtzb3J0RGlyZWN0aW9uLCBzZXRTb3J0RGlyZWN0aW9uXSA9IHVzZVN0YXRlPFwiYXNjXCIgfCBcImRlc2NcIj4oXCJhc2NcIik7XG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZXhwYW5kZWRSb3dzLCBzZXRFeHBhbmRlZFJvd3NdID0gdXNlU3RhdGU8U2V0PHN0cmluZz4+KG5ldyBTZXQoKSk7XG5cbiAgY29uc3QgaGFuZGxlU29ydCA9IChrZXk6IHN0cmluZykgPT4ge1xuICAgIGlmIChzb3J0Q29sdW1uID09PSBrZXkpIHtcbiAgICAgIHNldFNvcnREaXJlY3Rpb24oc29ydERpcmVjdGlvbiA9PT0gXCJhc2NcIiA/IFwiZGVzY1wiIDogXCJhc2NcIik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldFNvcnRDb2x1bW4oa2V5KTtcbiAgICAgIHNldFNvcnREaXJlY3Rpb24oXCJhc2NcIik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVJvd0V4cGFuZCA9IChyb3c6IFQpID0+IHtcbiAgICBjb25zdCByb3dJZCA9IFN0cmluZyhyb3dbcm93S2V5XSk7XG4gICAgY29uc3QgbmV3RXhwYW5kZWRSb3dzID0gbmV3IFNldChleHBhbmRlZFJvd3MpO1xuICAgIGlmIChuZXdFeHBhbmRlZFJvd3MuaGFzKHJvd0lkKSkge1xuICAgICAgbmV3RXhwYW5kZWRSb3dzLmRlbGV0ZShyb3dJZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG5ld0V4cGFuZGVkUm93cy5hZGQocm93SWQpO1xuICAgIH1cbiAgICBzZXRFeHBhbmRlZFJvd3MobmV3RXhwYW5kZWRSb3dzKTtcbiAgICBvblJvd0V4cGFuZD8uKHJvdyk7XG4gIH07XG5cbiAgY29uc3QgaXNSb3dFeHBhbmRlZCA9IChyb3c6IFQpID0+IHtcbiAgICByZXR1cm4gZXhwYW5kZWRSb3dzLmhhcyhTdHJpbmcocm93W3Jvd0tleV0pKTtcbiAgfTtcblxuICBjb25zdCBmaWx0ZXJlZERhdGEgPSBkYXRhLmZpbHRlcigocm93KSA9PiB7XG4gICAgaWYgKCFzZWFyY2hUZXJtKSByZXR1cm4gdHJ1ZTtcbiAgICBjb25zdCBzZWFyY2hMb3dlciA9IHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKTtcbiAgICByZXR1cm4gY29sdW1ucy5zb21lKChjb2wpID0+IHtcbiAgICAgIGNvbnN0IHZhbHVlID0gcm93W2NvbC5rZXkgYXMga2V5b2YgVF07XG4gICAgICByZXR1cm4gU3RyaW5nKHZhbHVlKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaExvd2VyKTtcbiAgICB9KTtcbiAgfSk7XG5cbiAgY29uc3Qgc29ydGVkRGF0YSA9IFsuLi5maWx0ZXJlZERhdGFdLnNvcnQoKGEsIGIpID0+IHtcbiAgICBpZiAoIXNvcnRDb2x1bW4pIHJldHVybiAwO1xuICAgIGNvbnN0IGFWYWx1ZSA9IGFbc29ydENvbHVtbiBhcyBrZXlvZiBUXTtcbiAgICBjb25zdCBiVmFsdWUgPSBiW3NvcnRDb2x1bW4gYXMga2V5b2YgVF07XG5cbiAgICBpZiAoYVZhbHVlIDwgYlZhbHVlKSByZXR1cm4gc29ydERpcmVjdGlvbiA9PT0gXCJhc2NcIiA/IC0xIDogMTtcbiAgICBpZiAoYVZhbHVlID4gYlZhbHVlKSByZXR1cm4gc29ydERpcmVjdGlvbiA9PT0gXCJhc2NcIiA/IDEgOiAtMTtcbiAgICByZXR1cm4gMDtcbiAgfSk7XG5cbiAgaWYgKGlzTG9hZGluZykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17Y24oXCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnXCIsIGNsYXNzTmFtZSl9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTggdy04IGJvcmRlci1iLTIgYm9yZGVyLWVtZXJhbGQtNjAwXCI+PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2NuKFwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBvdmVyZmxvdy1oaWRkZW5cIiwgY2xhc3NOYW1lKX0+XG4gICAgICB7c2VhcmNoYWJsZSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtzZWFyY2hQbGFjZWhvbGRlcn1cbiAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hUZXJtfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hUZXJtKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC1zbSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbFwiPlxuICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgIHtjb2x1bW5zLm1hcCgoY29sKSA9PiAoXG4gICAgICAgICAgICAgICAgPHRoXG4gICAgICAgICAgICAgICAgICBrZXk9e2NvbC5rZXl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICBcInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNjAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiLFxuICAgICAgICAgICAgICAgICAgICBjb2wuc29ydGFibGUgJiYgXCJjdXJzb3ItcG9pbnRlciBob3ZlcjpiZy1zbGF0ZS0xMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNvbC5zb3J0YWJsZSAmJiBoYW5kbGVTb3J0KGNvbC5rZXkpfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAge2NvbC5oZWFkZXJ9XG4gICAgICAgICAgICAgICAgICAgIHtjb2wuc29ydGFibGUgJiYgc29ydENvbHVtbiA9PT0gY29sLmtleSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgc29ydERpcmVjdGlvbiA9PT0gXCJhc2NcIiA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uVXAgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uRG93biBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAge2V4cGFuZGFibGUgPyA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+RXhwYW5kaXI8L3NwYW4+IDogPE1vcmVIb3Jpem9udGFsIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS00MDBcIiAvPn1cbiAgICAgICAgICAgICAgPC90aD5cbiAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAge3NvcnRlZERhdGEubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49e2NvbHVtbnMubGVuZ3RoICsgMX0gY2xhc3NOYW1lPVwicHgtNCBweS04IHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgIHtlbXB0eU1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIHNvcnRlZERhdGEubWFwKChyb3cpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCByb3dJZCA9IFN0cmluZyhyb3dbcm93S2V5XSk7XG4gICAgICAgICAgICAgICAgY29uc3QgZXhwYW5kZWQgPSBpc1Jvd0V4cGFuZGVkKHJvdyk7XG5cbiAgICAgICAgICAgICAgICBpZiAoZXhwYW5kYWJsZSkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPEV4cGFuZGFibGVSb3dcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e3Jvd0lkfVxuICAgICAgICAgICAgICAgICAgICAgIGlzRXhwYW5kZWQ9e2V4cGFuZGVkfVxuICAgICAgICAgICAgICAgICAgICAgIG9uVG9nZ2xlPXsoKSA9PiBoYW5kbGVSb3dFeHBhbmQocm93KX1cbiAgICAgICAgICAgICAgICAgICAgICBzaG93RXhwYW5kQnV0dG9uPXt0cnVlfVxuICAgICAgICAgICAgICAgICAgICAgIGV4cGFuZGVkQ29udGVudD17cmVuZGVyRXhwYW5kZWRSb3c/Lihyb3cpfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge2NvbHVtbnMubWFwKChjb2wpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBrZXk9e2NvbC5rZXl9IGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LXNtIHRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjb2wucmVuZGVyID8gY29sLnJlbmRlcihyb3dbY29sLmtleSBhcyBrZXlvZiBUXSwgcm93KSA6IFN0cmluZyhyb3dbY29sLmtleSBhcyBrZXlvZiBUXSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L0V4cGFuZGFibGVSb3c+XG4gICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8dHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtyb3dJZH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICBcImhvdmVyOmJnLXNsYXRlLTUwIHRyYW5zaXRpb24tY29sb3JzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgb25Sb3dDbGljayAmJiBcImN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25Sb3dDbGljaz8uKHJvdyl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtjb2x1bW5zLm1hcCgoY29sKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGtleT17Y29sLmtleX0gY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtc20gdGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjb2wucmVuZGVyID8gY29sLnJlbmRlcihyb3dbY29sLmtleSBhcyBrZXlvZiBUXSwgcm93KSA6IFN0cmluZyhyb3dbY29sLmtleSBhcyBrZXlvZiBUXSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHJvdW5kZWQgaG92ZXI6Ymctc2xhdGUtMTAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uUm93Q2xpY2s/Lihyb3cpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8TW9yZUhvcml6b250YWwgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgIDwvdGFibGU+XG4gICAgICA8L2Rpdj5cblxuICAgICAge3NvcnRlZERhdGEubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgYmctc2xhdGUtNTBcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICBNb3N0cmFuZG8ge3NvcnRlZERhdGEubGVuZ3RofSBkZSB7ZGF0YS5sZW5ndGh9IHJlZ2lzdG9zXG4gICAgICAgICAgICB7ZXhwYW5kYWJsZSAmJiBleHBhbmRlZFJvd3Muc2l6ZSA+IDAgJiYgYCAoJHtleHBhbmRlZFJvd3Muc2l6ZX0gZXhwYW5kaWRvJHtleHBhbmRlZFJvd3Muc2l6ZSA+IDEgPyAncycgOiAnJ30pYH1cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvemVsdG8vT25lRHJpdmUvRG9jdW1lbnRvcy9HaXRIdWIvWGl0aXF1ZUFwcFVJL3NyYy9jb21wb25lbnRzL3VpL0RhdGFUYWJsZS50c3gifQ==