import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/dashboard/route.tsx?tsr-split=component");const useEffect = __vite__cjsImport1_react["useEffect"];// /routes/dashboard/route.tsx
import { useNavigate } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=03f72e91";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=03f72e91";
var _s = $RefreshSig$();
function DashboardRedirect() {
	_s();
	const navigate = useNavigate();
	useEffect(() => {
		navigate({ to: "/dashboard/overview" });
	}, [navigate]);
	return null;
}
_s(DashboardRedirect, "r6Y4cxllxeSwx3b1nMjC3P/JySI=", false, function() {
	return [useNavigate];
});
_c = DashboardRedirect;
export { DashboardRedirect as component };
var _c;
$RefreshReg$(_c, "DashboardRedirect");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/dashboard/route.tsx?tsr-split=component";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/route.tsx?tsr-split=component", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/route.tsx?tsr-split=component", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/route.tsx?tsr-split=component" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUNBLFNBQTBCQSxtQkFBbUI7QUFDN0MsU0FBU0MsaUJBQWlCOztBQU0xQixTQUFTQyxvQkFBb0I7O0NBQ3pCLE1BQU1DLFdBQVdILFlBQVk7Q0FFN0JDLGdCQUFnQjtFQUNaRSxTQUFTLEVBQUVDLElBQUksc0JBQXNCLENBQUM7Q0FDMUMsR0FBRyxDQUFDRCxRQUFRLENBQUM7Q0FFYixPQUFPO0FBQ1g7Ozs7O0FBQUMsU0FBQUQscUJBQUFHIiwibmFtZXMiOlsidXNlTmF2aWdhdGUiLCJ1c2VFZmZlY3QiLCJEYXNoYm9hcmRSZWRpcmVjdCIsIm5hdmlnYXRlIiwidG8iLCJjb21wb25lbnQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsicm91dGUudHN4P3Rzci1zcGxpdD1jb21wb25lbnQiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gL3JvdXRlcy9kYXNoYm9hcmQvcm91dGUudHN4XHJcbmltcG9ydCB7IGNyZWF0ZUZpbGVSb3V0ZSwgdXNlTmF2aWdhdGUgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJztcclxuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5cclxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKCcvZGFzaGJvYXJkJykoe1xyXG4gICAgY29tcG9uZW50OiBEYXNoYm9hcmRSZWRpcmVjdCxcclxufSk7XHJcblxyXG5mdW5jdGlvbiBEYXNoYm9hcmRSZWRpcmVjdCgpIHtcclxuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIG5hdmlnYXRlKHsgdG86ICcvZGFzaGJvYXJkL292ZXJ2aWV3JyB9KTtcclxuICAgIH0sIFtuYXZpZ2F0ZV0pO1xyXG5cclxuICAgIHJldHVybiBudWxsO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvemVsdG8vT25lRHJpdmUvRG9jdW1lbnRvcy9HaXRIdWIvWGl0aXF1ZUFwcFVJL3NyYy9yb3V0ZXMvZGFzaGJvYXJkL3JvdXRlLnRzeCJ9