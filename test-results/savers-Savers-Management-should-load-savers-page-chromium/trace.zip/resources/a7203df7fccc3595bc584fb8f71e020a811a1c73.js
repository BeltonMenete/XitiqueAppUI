import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Header.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Bell, Search } from "/node_modules/.vite/deps/lucide-react.js?v=03f72e91";
import { cn } from "/src/lib/design-system.ts";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/layout/Header.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
export function Header({ title, description, rightContent, className = "", showSearch = true, searchValue = "", onSearchChange, searchPlaceholder = "Pesquisar..." }) {
	return /* @__PURE__ */ _jsxDEV("header", {
		className: cn("h-16 border-b border-slate-200/80 bg-white px-6 flex items-center justify-between select-none shrink-0", className),
		"data-tsd-source": "/src/components/layout/Header.tsx:27:5",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			"data-tsd-source": "/src/components/layout/Header.tsx:28:7",
			children: [/* @__PURE__ */ _jsxDEV("h1", {
				className: "text-sm font-bold text-slate-950 tracking-tight",
				"data-tsd-source": "/src/components/layout/Header.tsx:29:9",
				children: title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 9
			}, this), description && /* @__PURE__ */ _jsxDEV("p", {
				className: "text-[11px] text-slate-400 hidden sm:block",
				"data-tsd-source": "/src/components/layout/Header.tsx:31:11",
				children: description
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-4",
			"data-tsd-source": "/src/components/layout/Header.tsx:35:7",
			children: [
				showSearch && /* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-48 sm:w-64 group",
					"data-tsd-source": "/src/components/layout/Header.tsx:37:11",
					children: [/* @__PURE__ */ _jsxDEV(Search, {
						className: "absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400 group-focus-within:text-emerald-600 transition-colors",
						"data-tsd-source": "/src/components/layout/Header.tsx:38:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: searchPlaceholder,
						value: searchValue,
						onChange: (e) => onSearchChange?.(e.target.value),
						className: "w-full pl-8 pr-3 py-2 bg-slate-50 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10 focus:bg-white transition-all duration-200",
						"data-tsd-source": "/src/components/layout/Header.tsx:39:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "p-2 text-slate-400 hover:text-slate-600 bg-slate-50 rounded-lg border border-slate-100 relative transition-all",
					"data-tsd-source": "/src/components/layout/Header.tsx:49:9",
					children: [/* @__PURE__ */ _jsxDEV(Bell, {
						size: 16,
						"data-tsd-source": "/src/components/layout/Header.tsx:53:11"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "absolute top-1.5 right-1.5 h-2 w-2 bg-emerald-500 rounded-full ring-2 ring-white",
						"data-tsd-source": "/src/components/layout/Header.tsx:54:11"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this),
				rightContent
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 5
	}, this);
}
_c = Header;
var _c;
$RefreshReg$(_c, "Header");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/Header.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/layout/Header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/layout/Header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/layout/Header.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQ0E7QUFDQTs7O0FBYUEseUJBQ0EsT0FDQSxhQUNBLGNBQ0EsZ0JBQ0EsbUJBQ0Esa0JBQ0EsZ0JBQ0Esc0NBQ0E7Q0FDQSxPQUNBO0VBQUE7RUFBQTtZQUFBLENBQ0E7R0FBQTthQUFBLENBQ0E7SUFBQTtJQUFBO2NBQXVFO0dBQUE7Ozs7YUFDdkUsZUFDQTtJQUFBO0lBQUE7Y0FBbUU7R0FBQTs7OztXQUVuRTs7Ozs7WUFFQTtHQUFBO0dBQUE7YUFBQTtJQUNBLGNBQ0E7S0FBQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO01BQUE7S0FBeUk7Ozs7ZUFDekk7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7S0FBWTs7OzthQUNaOzs7Ozs7SUFHQTtLQUNBO0tBQ0E7S0FDQTtlQUhBLENBSUE7TUFBQTtNQUFBO0tBQTBCOzs7O2VBQzFCO01BQUE7TUFBQTtLQUE0Rzs7OzthQUM1Rzs7Ozs7O0lBRUE7R0FDQTs7Ozs7VUFDQTs7Ozs7O0FBRUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkhlYWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEJlbGwsIFNlYXJjaCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIiMvbGliL2Rlc2lnbi1zeXN0ZW1cIjtcblxuaW50ZXJmYWNlIEhlYWRlclByb3BzIHtcbiAgdGl0bGU6IHN0cmluZztcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIHJpZ2h0Q29udGVudD86IFJlYWN0Tm9kZTtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBzaG93U2VhcmNoPzogYm9vbGVhbjtcbiAgc2VhcmNoVmFsdWU/OiBzdHJpbmc7XG4gIG9uU2VhcmNoQ2hhbmdlPzogKHZhbHVlOiBzdHJpbmcpID0+IHZvaWQ7XG4gIHNlYXJjaFBsYWNlaG9sZGVyPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gSGVhZGVyKHtcbiAgdGl0bGUsXG4gIGRlc2NyaXB0aW9uLFxuICByaWdodENvbnRlbnQsXG4gIGNsYXNzTmFtZSA9IFwiXCIsXG4gIHNob3dTZWFyY2ggPSB0cnVlLFxuICBzZWFyY2hWYWx1ZSA9IFwiXCIsXG4gIG9uU2VhcmNoQ2hhbmdlLFxuICBzZWFyY2hQbGFjZWhvbGRlciA9IFwiUGVzcXVpc2FyLi4uXCIsXG59OiBIZWFkZXJQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPXtjbihcImgtMTYgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMC84MCBiZy13aGl0ZSBweC02IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzZWxlY3Qtbm9uZSBzaHJpbmstMFwiLCBjbGFzc05hbWUpfT5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTk1MCB0cmFja2luZy10aWdodFwiPnt0aXRsZX08L2gxPlxuICAgICAgICB7ZGVzY3JpcHRpb24gJiYgKFxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGhpZGRlbiBzbTpibG9ja1wiPntkZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICB7c2hvd1NlYXJjaCAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTQ4IHNtOnctNjQgZ3JvdXBcIj5cbiAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zIHRvcC0yLjUgaC0zLjUgdy0zLjUgdGV4dC1zbGF0ZS00MDAgZ3JvdXAtZm9jdXMtd2l0aGluOnRleHQtZW1lcmFsZC02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIiAvPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3NlYXJjaFBsYWNlaG9sZGVyfVxuICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoVmFsdWV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25TZWFyY2hDaGFuZ2U/LihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC04IHByLTMgcHktMiBiZy1zbGF0ZS01MCB0ZXh0LXhzIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8xMCBmb2N1czpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgICAgXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgYmctc2xhdGUtNTAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTEwMCByZWxhdGl2ZSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgID5cbiAgICAgICAgICA8QmVsbCBzaXplPXsxNn0gLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMS41IHJpZ2h0LTEuNSBoLTIgdy0yIGJnLWVtZXJhbGQtNTAwIHJvdW5kZWQtZnVsbCByaW5nLTIgcmluZy13aGl0ZVwiPjwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIFxuICAgICAgICB7cmlnaHRDb250ZW50fVxuICAgICAgPC9kaXY+XG4gICAgPC9oZWFkZXI+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3plbHRvL09uZURyaXZlL0RvY3VtZW50b3MvR2l0SHViL1hpdGlxdWVBcHBVSS9zcmMvY29tcG9uZW50cy9sYXlvdXQvSGVhZGVyLnRzeCJ9