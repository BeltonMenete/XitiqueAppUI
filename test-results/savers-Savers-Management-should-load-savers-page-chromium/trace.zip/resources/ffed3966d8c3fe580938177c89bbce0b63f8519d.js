// Design System Configuration for Xitique App
// Cold Slate Theme with Emerald Accents
export const colors = {
	// Primary (Cold Slate)
	primary: {
		DEFAULT: "#475569",
		light: "#64748b",
		dark: "#334155",
		darker: "#1e293b"
	},
	// Secondary (Emerald - accent)
	secondary: {
		DEFAULT: "#059669",
		light: "#10b981",
		dark: "#047857",
		darker: "#065f46"
	},
	// Backgrounds
	background: {
		primary: "#f8fafc",
		secondary: "#f1f5f9",
		tertiary: "#e2e8f0",
		white: "#ffffff"
	},
	// Status Colors
	status: {
		success: "#10b981",
		warning: "#f59e0b",
		error: "#ef4444",
		info: "#3b82f6"
	},
	// Text Colors
	text: {
		primary: "#0f172a",
		secondary: "#475569",
		tertiary: "#94a3b8",
		inverse: "#ffffff"
	},
	// Border Colors
	border: {
		DEFAULT: "#e2e8f0",
		light: "#f1f5f9",
		dark: "#cbd5e1"
	}
};
export const typography = {
	fonts: {
		display: "Montserrat, sans-serif",
		body: "Inter, sans-serif",
		mono: "JetBrains Mono, monospace"
	},
	sizes: {
		// Display sizes
		displayHero: "40px",
		displayLarge: "32px",
		displayMedium: "24px",
		// Body sizes
		bodyLarge: "18px",
		bodyMedium: "16px",
		bodySmall: "14px",
		// Label sizes
		labelMedium: "12px",
		labelSmall: "10px",
		// Data sizes
		data: "14px"
	},
	weights: {
		light: "300",
		normal: "400",
		medium: "500",
		semibold: "600",
		bold: "700",
		extrabold: "800"
	},
	lineHeights: {
		tight: "1.2",
		normal: "1.5",
		relaxed: "1.75"
	}
};
export const spacing = {
	// Base unit: 4px
	xs: "4px",
	sm: "8px",
	md: "16px",
	lg: "24px",
	xl: "32px",
	"2xl": "48px",
	"3xl": "64px",
	// Functional spacing
	section: "24px",
	card: "20px",
	input: "12px"
};
export const borderRadius = {
	sm: "4px",
	DEFAULT: "8px",
	md: "12px",
	lg: "16px",
	xl: "24px",
	full: "9999px"
};
export const shadows = {
	sm: "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
	DEFAULT: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1)",
	md: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)",
	lg: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1)",
	xl: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)"
};
export const transitions = {
	fast: "150ms cubic-bezier(0.4, 0, 0.2, 1)",
	normal: "200ms cubic-bezier(0.4, 0, 0.2, 1)",
	slow: "300ms cubic-bezier(0.4, 0, 0.2, 1)"
};
export const zIndex = {
	dropdown: 1e3,
	sticky: 1020,
	modal: 1050,
	tooltip: 1060,
	notification: 1070
};
// Tailwind class mappings for consistent usage
export const tailwindClasses = {
	// Background colors
	bgPrimary: "bg-slate-50",
	bgSecondary: "bg-slate-100",
	bgTertiary: "bg-slate-200",
	bgWhite: "bg-white",
	// Text colors
	textPrimary: "text-slate-900",
	textSecondary: "text-slate-600",
	textTertiary: "text-slate-400",
	// Border colors
	border: "border-slate-200",
	borderLight: "border-slate-100",
	// Status colors
	success: "text-emerald-500 bg-emerald-50 border-emerald-200",
	warning: "text-amber-500 bg-amber-50 border-amber-200",
	error: "text-red-500 bg-red-50 border-red-200",
	info: "text-blue-500 bg-blue-50 border-blue-200",
	// Button variants
	buttonPrimary: "bg-emerald-600 text-white hover:bg-emerald-700",
	buttonSecondary: "bg-slate-100 text-slate-700 hover:bg-slate-200",
	buttonDanger: "bg-red-500 text-white hover:bg-red-600",
	buttonGhost: "bg-transparent text-slate-600 hover:bg-slate-100",
	buttonOutline: "border border-slate-300 text-slate-700 hover:bg-slate-50",
	// Card styles
	card: "bg-white border border-slate-200 rounded-lg shadow-sm",
	cardInteractive: "bg-white border border-slate-200 rounded-lg shadow-sm hover:shadow-md transition-shadow",
	// Input styles
	input: "bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
	// Typography
	display: "font-display font-bold",
	heading: "font-display font-semibold",
	body: "font-body font-normal",
	label: "font-body font-semibold text-xs uppercase tracking-wider",
	mono: "font-mono font-medium"
};
// Helper function for conditional classes
export function cn(...classes) {
	return classes.filter(Boolean).join(" ");
}
export function getStatusColor(status) {
	switch (status) {
		case "success":
		case "active": return tailwindClasses.success;
		case "warning":
		case "pending": return tailwindClasses.warning;
		case "error":
		case "inactive": return tailwindClasses.error;
		case "info": return tailwindClasses.info;
		default: return tailwindClasses.buttonSecondary;
	}
}
export function getButtonVariant(variant) {
	switch (variant) {
		case "primary": return tailwindClasses.buttonPrimary;
		case "secondary": return tailwindClasses.buttonSecondary;
		case "danger": return tailwindClasses.buttonDanger;
		case "ghost": return tailwindClasses.buttonGhost;
		case "outline": return tailwindClasses.buttonOutline;
		default: return tailwindClasses.buttonPrimary;
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFHQSxPQUFPLE1BQU0sU0FBUzs7Q0FFcEIsU0FBUztFQUNQLFNBQVM7RUFDVCxPQUFPO0VBQ1AsTUFBTTtFQUNOLFFBQVE7Q0FDVjs7Q0FHQSxXQUFXO0VBQ1QsU0FBUztFQUNULE9BQU87RUFDUCxNQUFNO0VBQ04sUUFBUTtDQUNWOztDQUdBLFlBQVk7RUFDVixTQUFTO0VBQ1QsV0FBVztFQUNYLFVBQVU7RUFDVixPQUFPO0NBQ1Q7O0NBR0EsUUFBUTtFQUNOLFNBQVM7RUFDVCxTQUFTO0VBQ1QsT0FBTztFQUNQLE1BQU07Q0FDUjs7Q0FHQSxNQUFNO0VBQ0osU0FBUztFQUNULFdBQVc7RUFDWCxVQUFVO0VBQ1YsU0FBUztDQUNYOztDQUdBLFFBQVE7RUFDTixTQUFTO0VBQ1QsT0FBTztFQUNQLE1BQU07Q0FDUjtBQUNGO0FBRUEsT0FBTyxNQUFNLGFBQWE7Q0FDeEIsT0FBTztFQUNMLFNBQVM7RUFDVCxNQUFNO0VBQ04sTUFBTTtDQUNSO0NBRUEsT0FBTzs7RUFFTCxhQUFhO0VBQ2IsY0FBYztFQUNkLGVBQWU7O0VBR2YsV0FBVztFQUNYLFlBQVk7RUFDWixXQUFXOztFQUdYLGFBQWE7RUFDYixZQUFZOztFQUdaLE1BQU07Q0FDUjtDQUVBLFNBQVM7RUFDUCxPQUFPO0VBQ1AsUUFBUTtFQUNSLFFBQVE7RUFDUixVQUFVO0VBQ1YsTUFBTTtFQUNOLFdBQVc7Q0FDYjtDQUVBLGFBQWE7RUFDWCxPQUFPO0VBQ1AsUUFBUTtFQUNSLFNBQVM7Q0FDWDtBQUNGO0FBRUEsT0FBTyxNQUFNLFVBQVU7O0NBRXJCLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osT0FBTztDQUNQLE9BQU87O0NBR1AsU0FBUztDQUNULE1BQU07Q0FDTixPQUFPO0FBQ1Q7QUFFQSxPQUFPLE1BQU0sZUFBZTtDQUMxQixJQUFJO0NBQ0osU0FBUztDQUNULElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLE1BQU07QUFDUjtBQUVBLE9BQU8sTUFBTSxVQUFVO0NBQ3JCLElBQUk7Q0FDSixTQUFTO0NBQ1QsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0FBQ047QUFFQSxPQUFPLE1BQU0sY0FBYztDQUN6QixNQUFNO0NBQ04sUUFBUTtDQUNSLE1BQU07QUFDUjtBQUVBLE9BQU8sTUFBTSxTQUFTO0NBQ3BCLFVBQVU7Q0FDVixRQUFRO0NBQ1IsT0FBTztDQUNQLFNBQVM7Q0FDVCxjQUFjO0FBQ2hCOztBQUdBLE9BQU8sTUFBTSxrQkFBa0I7O0NBRTdCLFdBQVc7Q0FDWCxhQUFhO0NBQ2IsWUFBWTtDQUNaLFNBQVM7O0NBR1QsYUFBYTtDQUNiLGVBQWU7Q0FDZixjQUFjOztDQUdkLFFBQVE7Q0FDUixhQUFhOztDQUdiLFNBQVM7Q0FDVCxTQUFTO0NBQ1QsT0FBTztDQUNQLE1BQU07O0NBR04sZUFBZTtDQUNmLGlCQUFpQjtDQUNqQixjQUFjO0NBQ2QsYUFBYTtDQUNiLGVBQWU7O0NBR2YsTUFBTTtDQUNOLGlCQUFpQjs7Q0FHakIsT0FBTzs7Q0FHUCxTQUFTO0NBQ1QsU0FBUztDQUNULE1BQU07Q0FDTixPQUFPO0NBQ1AsTUFBTTtBQUNSOztBQUdBLE9BQU8sU0FBUyxHQUFHLEdBQUcsU0FBd0Q7Q0FDNUUsT0FBTyxRQUFRLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0FBQ3pDO0FBS0EsT0FBTyxTQUFTLGVBQWUsUUFBNEI7Q0FDekQsUUFBUSxRQUFSO0VBQ0UsS0FBSztFQUNMLEtBQUssVUFDSCxPQUFPLGdCQUFnQjtFQUN6QixLQUFLO0VBQ0wsS0FBSyxXQUNILE9BQU8sZ0JBQWdCO0VBQ3pCLEtBQUs7RUFDTCxLQUFLLFlBQ0gsT0FBTyxnQkFBZ0I7RUFDekIsS0FBSyxRQUNILE9BQU8sZ0JBQWdCO0VBQ3pCLFNBQ0UsT0FBTyxnQkFBZ0I7Q0FDM0I7QUFDRjtBQUtBLE9BQU8sU0FBUyxpQkFBaUIsU0FBZ0M7Q0FDL0QsUUFBUSxTQUFSO0VBQ0UsS0FBSyxXQUNILE9BQU8sZ0JBQWdCO0VBQ3pCLEtBQUssYUFDSCxPQUFPLGdCQUFnQjtFQUN6QixLQUFLLFVBQ0gsT0FBTyxnQkFBZ0I7RUFDekIsS0FBSyxTQUNILE9BQU8sZ0JBQWdCO0VBQ3pCLEtBQUssV0FDSCxPQUFPLGdCQUFnQjtFQUN6QixTQUNFLE9BQU8sZ0JBQWdCO0NBQzNCO0FBQ0YiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiZGVzaWduLXN5c3RlbS50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvLyBEZXNpZ24gU3lzdGVtIENvbmZpZ3VyYXRpb24gZm9yIFhpdGlxdWUgQXBwXG4vLyBDb2xkIFNsYXRlIFRoZW1lIHdpdGggRW1lcmFsZCBBY2NlbnRzXG5cbmV4cG9ydCBjb25zdCBjb2xvcnMgPSB7XG4gIC8vIFByaW1hcnkgKENvbGQgU2xhdGUpXG4gIHByaW1hcnk6IHtcbiAgICBERUZBVUxUOiAnIzQ3NTU2OScsIC8vIHNsYXRlLTYwMFxuICAgIGxpZ2h0OiAnIzY0NzQ4YicsIC8vIHNsYXRlLTUwMFxuICAgIGRhcms6ICcjMzM0MTU1JywgLy8gc2xhdGUtNzAwXG4gICAgZGFya2VyOiAnIzFlMjkzYicsIC8vIHNsYXRlLTgwMFxuICB9LFxuXG4gIC8vIFNlY29uZGFyeSAoRW1lcmFsZCAtIGFjY2VudClcbiAgc2Vjb25kYXJ5OiB7XG4gICAgREVGQVVMVDogJyMwNTk2NjknLCAvLyBlbWVyYWxkLTYwMFxuICAgIGxpZ2h0OiAnIzEwYjk4MScsIC8vIGVtZXJhbGQtNTAwXG4gICAgZGFyazogJyMwNDc4NTcnLCAvLyBlbWVyYWxkLTcwMFxuICAgIGRhcmtlcjogJyMwNjVmNDYnLCAvLyBlbWVyYWxkLTgwMFxuICB9LFxuXG4gIC8vIEJhY2tncm91bmRzXG4gIGJhY2tncm91bmQ6IHtcbiAgICBwcmltYXJ5OiAnI2Y4ZmFmYycsIC8vIHNsYXRlLTUwXG4gICAgc2Vjb25kYXJ5OiAnI2YxZjVmOScsIC8vIHNsYXRlLTEwMFxuICAgIHRlcnRpYXJ5OiAnI2UyZThmMCcsIC8vIHNsYXRlLTIwMFxuICAgIHdoaXRlOiAnI2ZmZmZmZicsXG4gIH0sXG5cbiAgLy8gU3RhdHVzIENvbG9yc1xuICBzdGF0dXM6IHtcbiAgICBzdWNjZXNzOiAnIzEwYjk4MScsIC8vIGVtZXJhbGQtNTAwXG4gICAgd2FybmluZzogJyNmNTllMGInLCAvLyBhbWJlci01MDBcbiAgICBlcnJvcjogJyNlZjQ0NDQnLCAvLyByZWQtNTAwXG4gICAgaW5mbzogJyMzYjgyZjYnLCAvLyBibHVlLTUwMFxuICB9LFxuXG4gIC8vIFRleHQgQ29sb3JzXG4gIHRleHQ6IHtcbiAgICBwcmltYXJ5OiAnIzBmMTcyYScsIC8vIHNsYXRlLTkwMFxuICAgIHNlY29uZGFyeTogJyM0NzU1NjknLCAvLyBzbGF0ZS02MDBcbiAgICB0ZXJ0aWFyeTogJyM5NGEzYjgnLCAvLyBzbGF0ZS00MDBcbiAgICBpbnZlcnNlOiAnI2ZmZmZmZicsXG4gIH0sXG5cbiAgLy8gQm9yZGVyIENvbG9yc1xuICBib3JkZXI6IHtcbiAgICBERUZBVUxUOiAnI2UyZThmMCcsIC8vIHNsYXRlLTIwMFxuICAgIGxpZ2h0OiAnI2YxZjVmOScsIC8vIHNsYXRlLTEwMFxuICAgIGRhcms6ICcjY2JkNWUxJywgLy8gc2xhdGUtMzAwXG4gIH0sXG59O1xuXG5leHBvcnQgY29uc3QgdHlwb2dyYXBoeSA9IHtcbiAgZm9udHM6IHtcbiAgICBkaXNwbGF5OiAnTW9udHNlcnJhdCwgc2Fucy1zZXJpZicsXG4gICAgYm9keTogJ0ludGVyLCBzYW5zLXNlcmlmJyxcbiAgICBtb25vOiAnSmV0QnJhaW5zIE1vbm8sIG1vbm9zcGFjZScsXG4gIH0sXG5cbiAgc2l6ZXM6IHtcbiAgICAvLyBEaXNwbGF5IHNpemVzXG4gICAgZGlzcGxheUhlcm86ICc0MHB4JyxcbiAgICBkaXNwbGF5TGFyZ2U6ICczMnB4JyxcbiAgICBkaXNwbGF5TWVkaXVtOiAnMjRweCcsXG5cbiAgICAvLyBCb2R5IHNpemVzXG4gICAgYm9keUxhcmdlOiAnMThweCcsXG4gICAgYm9keU1lZGl1bTogJzE2cHgnLFxuICAgIGJvZHlTbWFsbDogJzE0cHgnLFxuXG4gICAgLy8gTGFiZWwgc2l6ZXNcbiAgICBsYWJlbE1lZGl1bTogJzEycHgnLFxuICAgIGxhYmVsU21hbGw6ICcxMHB4JyxcblxuICAgIC8vIERhdGEgc2l6ZXNcbiAgICBkYXRhOiAnMTRweCcsXG4gIH0sXG5cbiAgd2VpZ2h0czoge1xuICAgIGxpZ2h0OiAnMzAwJyxcbiAgICBub3JtYWw6ICc0MDAnLFxuICAgIG1lZGl1bTogJzUwMCcsXG4gICAgc2VtaWJvbGQ6ICc2MDAnLFxuICAgIGJvbGQ6ICc3MDAnLFxuICAgIGV4dHJhYm9sZDogJzgwMCcsXG4gIH0sXG5cbiAgbGluZUhlaWdodHM6IHtcbiAgICB0aWdodDogJzEuMicsXG4gICAgbm9ybWFsOiAnMS41JyxcbiAgICByZWxheGVkOiAnMS43NScsXG4gIH0sXG59O1xuXG5leHBvcnQgY29uc3Qgc3BhY2luZyA9IHtcbiAgLy8gQmFzZSB1bml0OiA0cHhcbiAgeHM6ICc0cHgnLFxuICBzbTogJzhweCcsXG4gIG1kOiAnMTZweCcsXG4gIGxnOiAnMjRweCcsXG4gIHhsOiAnMzJweCcsXG4gICcyeGwnOiAnNDhweCcsXG4gICczeGwnOiAnNjRweCcsXG5cbiAgLy8gRnVuY3Rpb25hbCBzcGFjaW5nXG4gIHNlY3Rpb246ICcyNHB4JyxcbiAgY2FyZDogJzIwcHgnLFxuICBpbnB1dDogJzEycHgnLFxufTtcblxuZXhwb3J0IGNvbnN0IGJvcmRlclJhZGl1cyA9IHtcbiAgc206ICc0cHgnLFxuICBERUZBVUxUOiAnOHB4JyxcbiAgbWQ6ICcxMnB4JyxcbiAgbGc6ICcxNnB4JyxcbiAgeGw6ICcyNHB4JyxcbiAgZnVsbDogJzk5OTlweCcsXG59O1xuXG5leHBvcnQgY29uc3Qgc2hhZG93cyA9IHtcbiAgc206ICcwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMDUpJyxcbiAgREVGQVVMVDogJzAgMXB4IDNweCAwIHJnYmEoMCwgMCwgMCwgMC4xKSwgMCAxcHggMnB4IC0xcHggcmdiYSgwLCAwLCAwLCAwLjEpJyxcbiAgbWQ6ICcwIDRweCA2cHggLTFweCByZ2JhKDAsIDAsIDAsIDAuMSksIDAgMnB4IDRweCAtMnB4IHJnYmEoMCwgMCwgMCwgMC4xKScsXG4gIGxnOiAnMCAxMHB4IDE1cHggLTNweCByZ2JhKDAsIDAsIDAsIDAuMSksIDAgNHB4IDZweCAtNHB4IHJnYmEoMCwgMCwgMCwgMC4xKScsXG4gIHhsOiAnMCAyMHB4IDI1cHggLTVweCByZ2JhKDAsIDAsIDAsIDAuMSksIDAgOHB4IDEwcHggLTZweCByZ2JhKDAsIDAsIDAsIDAuMSknLFxufTtcblxuZXhwb3J0IGNvbnN0IHRyYW5zaXRpb25zID0ge1xuICBmYXN0OiAnMTUwbXMgY3ViaWMtYmV6aWVyKDAuNCwgMCwgMC4yLCAxKScsXG4gIG5vcm1hbDogJzIwMG1zIGN1YmljLWJlemllcigwLjQsIDAsIDAuMiwgMSknLFxuICBzbG93OiAnMzAwbXMgY3ViaWMtYmV6aWVyKDAuNCwgMCwgMC4yLCAxKScsXG59O1xuXG5leHBvcnQgY29uc3QgekluZGV4ID0ge1xuICBkcm9wZG93bjogMTAwMCxcbiAgc3RpY2t5OiAxMDIwLFxuICBtb2RhbDogMTA1MCxcbiAgdG9vbHRpcDogMTA2MCxcbiAgbm90aWZpY2F0aW9uOiAxMDcwLFxufTtcblxuLy8gVGFpbHdpbmQgY2xhc3MgbWFwcGluZ3MgZm9yIGNvbnNpc3RlbnQgdXNhZ2VcbmV4cG9ydCBjb25zdCB0YWlsd2luZENsYXNzZXMgPSB7XG4gIC8vIEJhY2tncm91bmQgY29sb3JzXG4gIGJnUHJpbWFyeTogJ2JnLXNsYXRlLTUwJyxcbiAgYmdTZWNvbmRhcnk6ICdiZy1zbGF0ZS0xMDAnLFxuICBiZ1RlcnRpYXJ5OiAnYmctc2xhdGUtMjAwJyxcbiAgYmdXaGl0ZTogJ2JnLXdoaXRlJyxcblxuICAvLyBUZXh0IGNvbG9yc1xuICB0ZXh0UHJpbWFyeTogJ3RleHQtc2xhdGUtOTAwJyxcbiAgdGV4dFNlY29uZGFyeTogJ3RleHQtc2xhdGUtNjAwJyxcbiAgdGV4dFRlcnRpYXJ5OiAndGV4dC1zbGF0ZS00MDAnLFxuXG4gIC8vIEJvcmRlciBjb2xvcnNcbiAgYm9yZGVyOiAnYm9yZGVyLXNsYXRlLTIwMCcsXG4gIGJvcmRlckxpZ2h0OiAnYm9yZGVyLXNsYXRlLTEwMCcsXG5cbiAgLy8gU3RhdHVzIGNvbG9yc1xuICBzdWNjZXNzOiAndGV4dC1lbWVyYWxkLTUwMCBiZy1lbWVyYWxkLTUwIGJvcmRlci1lbWVyYWxkLTIwMCcsXG4gIHdhcm5pbmc6ICd0ZXh0LWFtYmVyLTUwMCBiZy1hbWJlci01MCBib3JkZXItYW1iZXItMjAwJyxcbiAgZXJyb3I6ICd0ZXh0LXJlZC01MDAgYmctcmVkLTUwIGJvcmRlci1yZWQtMjAwJyxcbiAgaW5mbzogJ3RleHQtYmx1ZS01MDAgYmctYmx1ZS01MCBib3JkZXItYmx1ZS0yMDAnLFxuXG4gIC8vIEJ1dHRvbiB2YXJpYW50c1xuICBidXR0b25QcmltYXJ5OiAnYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1lbWVyYWxkLTcwMCcsXG4gIGJ1dHRvblNlY29uZGFyeTogJ2JnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS0yMDAnLFxuICBidXR0b25EYW5nZXI6ICdiZy1yZWQtNTAwIHRleHQtd2hpdGUgaG92ZXI6YmctcmVkLTYwMCcsXG4gIGJ1dHRvbkdob3N0OiAnYmctdHJhbnNwYXJlbnQgdGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtMTAwJyxcbiAgYnV0dG9uT3V0bGluZTogJ2JvcmRlciBib3JkZXItc2xhdGUtMzAwIHRleHQtc2xhdGUtNzAwIGhvdmVyOmJnLXNsYXRlLTUwJyxcblxuICAvLyBDYXJkIHN0eWxlc1xuICBjYXJkOiAnYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBzaGFkb3ctc20nLFxuICBjYXJkSW50ZXJhY3RpdmU6ICdiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1zaGFkb3cnLFxuXG4gIC8vIElucHV0IHN0eWxlc1xuICBpbnB1dDogJ2JnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbGcgcHgtMyBweS0yIHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCcsXG5cbiAgLy8gVHlwb2dyYXBoeVxuICBkaXNwbGF5OiAnZm9udC1kaXNwbGF5IGZvbnQtYm9sZCcsXG4gIGhlYWRpbmc6ICdmb250LWRpc3BsYXkgZm9udC1zZW1pYm9sZCcsXG4gIGJvZHk6ICdmb250LWJvZHkgZm9udC1ub3JtYWwnLFxuICBsYWJlbDogJ2ZvbnQtYm9keSBmb250LXNlbWlib2xkIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyJyxcbiAgbW9ubzogJ2ZvbnQtbW9ubyBmb250LW1lZGl1bScsXG59O1xuXG4vLyBIZWxwZXIgZnVuY3Rpb24gZm9yIGNvbmRpdGlvbmFsIGNsYXNzZXNcbmV4cG9ydCBmdW5jdGlvbiBjbiguLi5jbGFzc2VzOiAoc3RyaW5nIHwgdW5kZWZpbmVkIHwgbnVsbCB8IGZhbHNlKVtdKTogc3RyaW5nIHtcbiAgcmV0dXJuIGNsYXNzZXMuZmlsdGVyKEJvb2xlYW4pLmpvaW4oJyAnKTtcbn1cblxuLy8gU3RhdHVzIHR5cGUgZm9yIHR5cGUtc2FmZSBzdGF0dXMgaGFuZGxpbmdcbmV4cG9ydCB0eXBlIFN0YXR1c1R5cGUgPSAnc3VjY2VzcycgfCAnd2FybmluZycgfCAnZXJyb3InIHwgJ2luZm8nIHwgJ3BlbmRpbmcnIHwgJ2FjdGl2ZScgfCAnaW5hY3RpdmUnO1xuXG5leHBvcnQgZnVuY3Rpb24gZ2V0U3RhdHVzQ29sb3Ioc3RhdHVzOiBTdGF0dXNUeXBlKTogc3RyaW5nIHtcbiAgc3dpdGNoIChzdGF0dXMpIHtcbiAgICBjYXNlICdzdWNjZXNzJzpcbiAgICBjYXNlICdhY3RpdmUnOlxuICAgICAgcmV0dXJuIHRhaWx3aW5kQ2xhc3Nlcy5zdWNjZXNzO1xuICAgIGNhc2UgJ3dhcm5pbmcnOlxuICAgIGNhc2UgJ3BlbmRpbmcnOlxuICAgICAgcmV0dXJuIHRhaWx3aW5kQ2xhc3Nlcy53YXJuaW5nO1xuICAgIGNhc2UgJ2Vycm9yJzpcbiAgICBjYXNlICdpbmFjdGl2ZSc6XG4gICAgICByZXR1cm4gdGFpbHdpbmRDbGFzc2VzLmVycm9yO1xuICAgIGNhc2UgJ2luZm8nOlxuICAgICAgcmV0dXJuIHRhaWx3aW5kQ2xhc3Nlcy5pbmZvO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gdGFpbHdpbmRDbGFzc2VzLmJ1dHRvblNlY29uZGFyeTtcbiAgfVxufVxuXG4vLyBCdXR0b24gdmFyaWFudCB0eXBlc1xuZXhwb3J0IHR5cGUgQnV0dG9uVmFyaWFudCA9ICdwcmltYXJ5JyB8ICdzZWNvbmRhcnknIHwgJ2RhbmdlcicgfCAnZ2hvc3QnIHwgJ291dGxpbmUnO1xuXG5leHBvcnQgZnVuY3Rpb24gZ2V0QnV0dG9uVmFyaWFudCh2YXJpYW50OiBCdXR0b25WYXJpYW50KTogc3RyaW5nIHtcbiAgc3dpdGNoICh2YXJpYW50KSB7XG4gICAgY2FzZSAncHJpbWFyeSc6XG4gICAgICByZXR1cm4gdGFpbHdpbmRDbGFzc2VzLmJ1dHRvblByaW1hcnk7XG4gICAgY2FzZSAnc2Vjb25kYXJ5JzpcbiAgICAgIHJldHVybiB0YWlsd2luZENsYXNzZXMuYnV0dG9uU2Vjb25kYXJ5O1xuICAgIGNhc2UgJ2Rhbmdlcic6XG4gICAgICByZXR1cm4gdGFpbHdpbmRDbGFzc2VzLmJ1dHRvbkRhbmdlcjtcbiAgICBjYXNlICdnaG9zdCc6XG4gICAgICByZXR1cm4gdGFpbHdpbmRDbGFzc2VzLmJ1dHRvbkdob3N0O1xuICAgIGNhc2UgJ291dGxpbmUnOlxuICAgICAgcmV0dXJuIHRhaWx3aW5kQ2xhc3Nlcy5idXR0b25PdXRsaW5lO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gdGFpbHdpbmRDbGFzc2VzLmJ1dHRvblByaW1hcnk7XG4gIH1cbn1cbiJdfQ==