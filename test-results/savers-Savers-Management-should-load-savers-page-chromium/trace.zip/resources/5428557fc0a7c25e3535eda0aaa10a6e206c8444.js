import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Sidebar.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { cn } from "/src/lib/design-system.ts";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/layout/Sidebar.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
export function Sidebar({ items, className = "" }) {
	return /* @__PURE__ */ _jsxDEV("aside", {
		className: cn("hidden md:flex flex-col w-64 bg-white border-r border-slate-200/80 justify-between p-6 select-none shrink-0", className),
		"data-tsd-source": "/src/components/layout/Sidebar.tsx:18:5",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "space-y-7",
			"data-tsd-source": "/src/components/layout/Sidebar.tsx:19:7",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2.5 px-2",
				"data-tsd-source": "/src/components/layout/Sidebar.tsx:21:9",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "w-8 h-8 rounded-xl bg-emerald-600 flex items-center justify-center text-white font-bold text-sm shadow-sm",
					"data-tsd-source": "/src/components/layout/Sidebar.tsx:22:11",
					children: "X"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col",
					"data-tsd-source": "/src/components/layout/Sidebar.tsx:25:11",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-sm font-extrabold tracking-tight text-slate-950",
						"data-tsd-source": "/src/components/layout/Sidebar.tsx:26:13",
						children: "Xitique"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-slate-400 font-medium tracking-wide",
						"data-tsd-source": "/src/components/layout/Sidebar.tsx:27:13",
						children: "Gestor de Poupança"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("nav", {
				className: "space-y-1",
				"data-tsd-source": "/src/components/layout/Sidebar.tsx:32:9",
				children: items.map((item) => /* @__PURE__ */ _jsxDEV("a", {
					href: item.href,
					className: cn("flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all", item.isActive ? "bg-emerald-600 text-white shadow-sm shadow-emerald-600/10" : "text-slate-600 hover:bg-slate-50 hover:text-slate-900 group"),
					"data-tsd-source": "/src/components/layout/Sidebar.tsx:34:13",
					children: [/* @__PURE__ */ _jsxDEV(item.icon, {
						size: 16,
						className: cn(item.isActive ? "text-white" : "text-slate-400 group-hover:text-slate-600"),
						"data-tsd-source": "/src/components/layout/Sidebar.tsx:44:15"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						"data-tsd-source": "/src/components/layout/Sidebar.tsx:50:15",
						children: item.label
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 15
					}, this)]
				}, item.href, true, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "pt-4 border-t border-slate-100 flex items-center justify-between text-slate-400 text-[10px] font-bold uppercase tracking-wider",
			"data-tsd-source": "/src/components/layout/Sidebar.tsx:57:7",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				"data-tsd-source": "/src/components/layout/Sidebar.tsx:58:9",
				children: "Licença Oficial"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-md text-[9px]",
				"data-tsd-source": "/src/components/layout/Sidebar.tsx:59:9",
				children: "MZ-2026"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
}
_c = Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/Sidebar.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/layout/Sidebar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/layout/Sidebar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/layout/Sidebar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQ0E7OztBQWNBO0NBQ0EsT0FDQTtFQUFBO0VBQUE7WUFBQSxDQUNBO0dBQUE7R0FBQTthQUFBLENBRUE7SUFBQTtJQUFBO2NBQUEsQ0FDQTtLQUFBO0tBQUE7ZUFBb0k7SUFFcEk7Ozs7Y0FDQTtLQUFBO0tBQUE7ZUFBQSxDQUNBO01BQUE7TUFBQTtnQkFBa0Y7S0FBQTs7OztlQUNsRjtNQUFBO01BQUE7Z0JBQWtGO0tBQUE7Ozs7YUFDbEY7Ozs7O1lBQ0E7Ozs7O2FBR0E7SUFBQTtJQUFBO2NBQ0Esb0JBQ0E7S0FFQTtLQUNBLGNBQ0EscUZBQ0EsZ0JBQ0EsOERBQ0EsNkRBQ0E7S0FDQTtlQVRBLENBVUE7TUFDQTtNQUNBLGNBQ0EsMEVBQ0E7TUFDQTtLQUFjOzs7O2VBQ2Q7TUFBQTtnQkFBbUI7S0FBQTs7OzthQUNuQjtPQWhCQTs7OztXQWdCQSxDQUNBO0dBQ0E7Ozs7V0FDQTs7Ozs7WUFHQTtHQUFBO0dBQUE7YUFBQSxDQUNBO0lBQUE7Y0FBYTtHQUFBOzs7O2FBQ2I7SUFBQTtJQUFBO2NBQTBGO0dBQUE7Ozs7V0FDMUY7Ozs7O1VBQ0E7Ozs7OztBQUVBIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTaWRlYmFyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IEx1Y2lkZUljb24gfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCIjL2xpYi9kZXNpZ24tc3lzdGVtXCI7XG5cbmludGVyZmFjZSBOYXZJdGVtIHtcbiAgbGFiZWw6IHN0cmluZztcbiAgaWNvbjogTHVjaWRlSWNvbjtcbiAgaHJlZjogc3RyaW5nO1xuICBpc0FjdGl2ZT86IGJvb2xlYW47XG59XG5cbmludGVyZmFjZSBTaWRlYmFyUHJvcHMge1xuICBpdGVtczogTmF2SXRlbVtdO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBTaWRlYmFyKHsgaXRlbXMsIGNsYXNzTmFtZSA9IFwiXCIgfTogU2lkZWJhclByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPGFzaWRlIGNsYXNzTmFtZT17Y24oXCJoaWRkZW4gbWQ6ZmxleCBmbGV4LWNvbCB3LTY0IGJnLXdoaXRlIGJvcmRlci1yIGJvcmRlci1zbGF0ZS0yMDAvODAganVzdGlmeS1iZXR3ZWVuIHAtNiBzZWxlY3Qtbm9uZSBzaHJpbmstMFwiLCBjbGFzc05hbWUpfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS03XCI+XG4gICAgICAgIHsvKiBMb2dvIFNlY3Rpb24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBweC0yXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQteGwgYmctZW1lcmFsZC02MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC1zbSBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgIFhcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1zbGF0ZS05NTBcIj5YaXRpcXVlPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW0gdHJhY2tpbmctd2lkZVwiPkdlc3RvciBkZSBQb3VwYW7Dp2E8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBOYXZpZ2F0aW9uICovfVxuICAgICAgICA8bmF2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgIHtpdGVtcy5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGtleT17aXRlbS5ocmVmfVxuICAgICAgICAgICAgICBocmVmPXtpdGVtLmhyZWZ9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgXCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC0zIHB5LTIuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGxcIixcbiAgICAgICAgICAgICAgICBpdGVtLmlzQWN0aXZlXG4gICAgICAgICAgICAgICAgICA/IFwiYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBzaGFkb3ctc20gc2hhZG93LWVtZXJhbGQtNjAwLzEwXCJcbiAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXNsYXRlLTYwMCBob3ZlcjpiZy1zbGF0ZS01MCBob3Zlcjp0ZXh0LXNsYXRlLTkwMCBncm91cFwiXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxpdGVtLmljb24gXG4gICAgICAgICAgICAgICAgc2l6ZT17MTZ9IFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICBpdGVtLmlzQWN0aXZlID8gXCJ0ZXh0LXdoaXRlXCIgOiBcInRleHQtc2xhdGUtNDAwIGdyb3VwLWhvdmVyOnRleHQtc2xhdGUtNjAwXCJcbiAgICAgICAgICAgICAgICApfSBcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0ubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L25hdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRm9vdGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNDAwIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgPHNwYW4+TGljZW7Dp2EgT2ZpY2lhbDwvc3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIHB4LTIgcHktMC41IHJvdW5kZWQtbWQgdGV4dC1bOXB4XVwiPk1aLTIwMjY8L3NwYW4+XG4gICAgICA8L2Rpdj5cbiAgICA8L2FzaWRlPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy96ZWx0by9PbmVEcml2ZS9Eb2N1bWVudG9zL0dpdEh1Yi9YaXRpcXVlQXBwVUkvc3JjL2NvbXBvbmVudHMvbGF5b3V0L1NpZGViYXIudHN4In0=