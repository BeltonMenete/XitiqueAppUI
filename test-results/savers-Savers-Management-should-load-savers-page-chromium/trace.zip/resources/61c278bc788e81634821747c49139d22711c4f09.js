import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Modal.tsx");const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03f72e91";
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=03f72e91";
import { cn } from "/src/lib/design-system.ts";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/Modal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
var _s = $RefreshSig$();
export function Modal({ isOpen, onClose, title, children, size = "md", showCloseButton = true, className = "" }) {
	_s();
	useEffect(() => {
		if (isOpen) {
			document.body.style.overflow = "hidden";
		} else {
			document.body.style.overflow = "unset";
		}
		return () => {
			document.body.style.overflow = "unset";
		};
	}, [isOpen]);
	if (!isOpen) return null;
	const sizeClasses = {
		sm: "max-w-md",
		md: "max-w-lg",
		lg: "max-w-2xl",
		xl: "max-w-4xl"
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center",
		"data-tsd-source": "/src/components/ui/Modal.tsx:46:5",
		children: [/* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			className: "absolute inset-0 bg-slate-900/40 backdrop-blur-sm",
			onClick: onClose,
			"aria-label": "Close modal",
			"data-tsd-source": "/src/components/ui/Modal.tsx:48:7"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: cn("relative bg-white rounded-xl shadow-xl w-full mx-4 animate-in fade-in zoom-in-95 duration-200", sizeClasses[size], className),
			"data-tsd-source": "/src/components/ui/Modal.tsx:56:7",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between p-5 border-b border-slate-200",
				"data-tsd-source": "/src/components/ui/Modal.tsx:64:9",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-lg font-semibold text-slate-900",
					"data-tsd-source": "/src/components/ui/Modal.tsx:65:11",
					children: title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 11
				}, this), showCloseButton && /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: onClose,
					className: "p-1 rounded-lg hover:bg-slate-100 transition-colors",
					"data-tsd-source": "/src/components/ui/Modal.tsx:67:13",
					children: /* @__PURE__ */ _jsxDEV(X, {
						className: "w-5 h-5 text-slate-400",
						"data-tsd-source": "/src/components/ui/Modal.tsx:72:15"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "p-5 max-h-[70vh] overflow-y-auto",
				"data-tsd-source": "/src/components/ui/Modal.tsx:78:9",
				children
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 5
	}, this);
}
_s(Modal, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = Modal;
export function ModalFooter({ children, className = "" }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn("flex items-center justify-end gap-3 pt-4 border-t border-slate-200", className),
		"data-tsd-source": "/src/components/ui/Modal.tsx:93:5",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 93,
		columnNumber: 5
	}, this);
}
_c2 = ModalFooter;
var _c, _c2;
$RefreshReg$(_c, "Modal");
$RefreshReg$(_c2, "ModalFooter");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/Modal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/Modal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/Modal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/Modal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBOzs7O0FBWUEsd0JBQ0EsUUFDQSxTQUNBLE9BQ0EsVUFDQSxhQUNBLHdCQUNBLGtCQUNBOztDQUNBO0VBQ0E7R0FDQTtFQUNBO0dBQ0E7RUFDQTtFQUVBO0dBQ0E7RUFDQTtDQUNBO0NBRUE7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0E7Q0FFQSxPQUNBO0VBQUE7RUFBQTtZQUFBLENBRUE7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQU07Ozs7WUFHTjtHQUNBLGNBQ0EsaUdBQ0EsbUJBQ0EsU0FDQTtHQUNBO2FBTkEsQ0FRQTtJQUFBO0lBQUE7Y0FBQSxDQUNBO0tBQUE7S0FBQTtlQUE4RDtJQUFBOzs7O2NBQzlELG1CQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7ZUFDQTtNQUFBO01BQUE7S0FBb0Q7Ozs7O0lBQ3BEOzs7O1lBRUE7Ozs7O2FBR0E7SUFBQTtJQUFBO0lBQ0E7R0FDQTs7OztXQUNBOzs7OztVQUNBOzs7Ozs7QUFFQTs7O0FBT0E7Q0FDQSxPQUNBO0VBQUE7RUFBQTtFQUNBO0NBQ0E7Ozs7O0FBRUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFggfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCIjL2xpYi9kZXNpZ24tc3lzdGVtXCI7XG5cbmludGVyZmFjZSBNb2RhbFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICB0aXRsZTogc3RyaW5nO1xuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xuICBzaXplPzogXCJzbVwiIHwgXCJtZFwiIHwgXCJsZ1wiIHwgXCJ4bFwiO1xuICBzaG93Q2xvc2VCdXR0b24/OiBib29sZWFuO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBNb2RhbCh7XG4gIGlzT3BlbixcbiAgb25DbG9zZSxcbiAgdGl0bGUsXG4gIGNoaWxkcmVuLFxuICBzaXplID0gXCJtZFwiLFxuICBzaG93Q2xvc2VCdXR0b24gPSB0cnVlLFxuICBjbGFzc05hbWUgPSBcIlwiLFxufTogTW9kYWxQcm9wcykge1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc09wZW4pIHtcbiAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSBcImhpZGRlblwiO1xuICAgIH0gZWxzZSB7XG4gICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gXCJ1bnNldFwiO1xuICAgIH1cblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gXCJ1bnNldFwiO1xuICAgIH07XG4gIH0sIFtpc09wZW5dKTtcblxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgY29uc3Qgc2l6ZUNsYXNzZXMgPSB7XG4gICAgc206IFwibWF4LXctbWRcIixcbiAgICBtZDogXCJtYXgtdy1sZ1wiLFxuICAgIGxnOiBcIm1heC13LTJ4bFwiLFxuICAgIHhsOiBcIm1heC13LTR4bFwiLFxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgIHsvKiBCYWNrZHJvcCAqL31cbiAgICAgIDxidXR0b25cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctc2xhdGUtOTAwLzQwIGJhY2tkcm9wLWJsdXItc21cIlxuICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICBhcmlhLWxhYmVsPVwiQ2xvc2UgbW9kYWxcIlxuICAgICAgLz5cblxuICAgICAgey8qIE1vZGFsICovfVxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgIFwicmVsYXRpdmUgYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3cteGwgdy1mdWxsIG14LTQgYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMjAwXCIsXG4gICAgICAgICAgc2l6ZUNsYXNzZXNbc2l6ZV0sXG4gICAgICAgICAgY2xhc3NOYW1lXG4gICAgICAgICl9XG4gICAgICA+XG4gICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtNSBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPnt0aXRsZX08L2gyPlxuICAgICAgICAgIHtzaG93Q2xvc2VCdXR0b24gJiYgKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHJvdW5kZWQtbGcgaG92ZXI6Ymctc2xhdGUtMTAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ29udGVudCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgbWF4LWgtWzcwdmhdIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuaW50ZXJmYWNlIE1vZGFsRm9vdGVyUHJvcHMge1xuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBNb2RhbEZvb3Rlcih7IGNoaWxkcmVuLCBjbGFzc05hbWUgPSBcIlwiIH06IE1vZGFsRm9vdGVyUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17Y24oXCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMyBwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDBcIiwgY2xhc3NOYW1lKX0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3plbHRvL09uZURyaXZlL0RvY3VtZW50b3MvR2l0SHViL1hpdGlxdWVBcHBVSS9zcmMvY29tcG9uZW50cy91aS9Nb2RhbC50c3gifQ==