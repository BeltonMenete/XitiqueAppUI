import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/dashboard/savers.tsx?tsr-split=component");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport16_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03f72e91";
import { Users, Plus, Search, Filter, ChevronDown, TrendingUp, AlertCircle, Wallet, DollarSign, Phone, Calendar, MoreVertical } from "/node_modules/.vite/deps/lucide-react.js?v=03f72e91";
import { DashboardLayout } from "/src/components/layout/DashboardLayout.tsx";
import { Sidebar } from "/src/components/layout/Sidebar.tsx";
import { Header } from "/src/components/layout/Header.tsx";
import { DataTable } from "/src/components/ui/DataTable.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { KPICard } from "/src/components/ui/KPICard.tsx";
import { Card, CardContent } from "/src/components/ui/Card.tsx";
import { DebtBadge, ActiveBadge, InactiveBadge } from "/src/components/ui/StatusBadge.tsx";
import { ExpandableRowContent } from "/src/components/ui/ExpandableRow.tsx";
import { cn } from "/src/lib/design-system.ts";
import { useSavers } from "/src/features/savers/index.ts";
import { RegisterSaverModal } from "/src/components/business/RegisterSaverModal.tsx";
import { QuickDepositModal } from "/src/components/business/QuickDepositModal.tsx";
import { QuickLoanModal } from "/src/components/business/QuickLoanModal.tsx";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/savers.tsx?tsr-split=component";
import __vite__cjsImport16_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
var _s = $RefreshSig$();
const mockSavers = [
	{
		id: "1",
		cardNumber: 1001,
		name: "Carlos Mondlane",
		dailyAmount: 500,
		organizationId: "org-1",
		isActive: true,
		registrationDate: "2024-01-15",
		totalSaved: 7500,
		currentDebt: 2300,
		daysInCycle: 15,
		status: "in_debt",
		organization: {
			id: "org-1",
			name: "Xitique Central"
		}
	},
	{
		id: "2",
		cardNumber: 1002,
		name: "Ana Vilanculos",
		dailyAmount: 250,
		organizationId: "org-1",
		isActive: true,
		registrationDate: "2024-02-01",
		totalSaved: 2500,
		currentDebt: 1500,
		daysInCycle: 5,
		status: "in_debt",
		organization: {
			id: "org-1",
			name: "Xitique Central"
		}
	},
	{
		id: "3",
		cardNumber: 1003,
		name: "Bento Sitoe",
		dailyAmount: 300,
		organizationId: "org-1",
		isActive: true,
		registrationDate: "2024-03-10",
		totalSaved: 6600,
		currentDebt: 0,
		daysInCycle: 22,
		status: "active",
		organization: {
			id: "org-1",
			name: "Xitique Central"
		}
	},
	{
		id: "4",
		cardNumber: 1004,
		name: "Eduarda Langa",
		dailyAmount: 1e3,
		organizationId: "org-1",
		isActive: true,
		registrationDate: "2024-01-10",
		totalSaved: 12e3,
		currentDebt: 2e3,
		daysInCycle: 12,
		status: "in_debt",
		organization: {
			id: "org-1",
			name: "Xitique Central"
		}
	},
	{
		id: "5",
		cardNumber: 1005,
		name: "Geraldo Mucavele",
		dailyAmount: 150,
		organizationId: "org-1",
		isActive: true,
		registrationDate: "2024-01-05",
		totalSaved: 4500,
		currentDebt: 0,
		daysInCycle: 30,
		status: "active",
		organization: {
			id: "org-1",
			name: "Xitique Central"
		}
	},
	{
		id: "6",
		cardNumber: 1006,
		name: "Isabel Tembe",
		dailyAmount: 200,
		organizationId: "org-1",
		isActive: true,
		registrationDate: "2024-02-15",
		totalSaved: 5e3,
		currentDebt: 0,
		daysInCycle: 25,
		status: "active",
		organization: {
			id: "org-1",
			name: "Xitique Central"
		}
	}
];
function SaversManagement() {
	_s();
	const [searchTerm, setSearchTerm] = useState("");
	const [selectedMonth, setSelectedMonth] = useState("Maio 2024");
	const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
	const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
	const [isLoanModalOpen, setIsLoanModalOpen] = useState(false);
	const [selectedSaver, setSelectedSaver] = useState(null);
	const { data: saversData } = useSavers({
		page: 1,
		pageSize: 20
	});
	const savers = saversData?.data || mockSavers;
	// Use savers in the component
	console.log(...typeof window === "undefined" ? ["\x1B[35mLOG\x1B[39m \x1B[94m/src/routes/dashboard/savers.tsx:130:3\x1B[39m\n → "] : [
		"%cLOG%c %cGo to Source: http://localhost:4000/__tsd/open-source?source=%2Fsrc%2Froutes%2Fdashboard%2Fsavers.tsx%3A130%3A3%c \n → ",
		"color:#A0A",
		"color:#FFF",
		"color:#55F",
		"color:#FFF"
	], "Savers count:", savers.length);
	const sidebarItems = [
		{
			label: "Painel",
			icon: Users,
			href: "/dashboard/overview"
		},
		{
			label: "Gestão",
			icon: Users,
			href: "/dashboard/savers",
			isActive: true
		},
		{
			label: "Financeiro",
			icon: Wallet,
			href: "/dashboard/financial"
		},
		{
			label: "Relatórios",
			icon: TrendingUp,
			href: "/dashboard/reports"
		},
		{
			label: "Configurações",
			icon: Search,
			href: "/dashboard/settings"
		}
	];
	const kpiData = [
		{
			title: "Total Ticantes",
			value: String(savers.length),
			subtext: "Total registado",
			icon: Users,
			color: "text-emerald-600 bg-emerald-50 border-emerald-100",
			isDebt: false
		},
		{
			title: "Total Sob Gestão",
			value: "450.000 MZN",
			subtext: "+12.5% vs mês anterior",
			icon: Wallet,
			color: "text-slate-600 bg-slate-50 border-slate-100",
			isDebt: false,
			trend: {
				value: "12.5%",
				isPositive: true
			}
		},
		{
			title: "Empréstimos Activos",
			value: "8.000 MZN",
			subtext: "3 empréstimos activos",
			icon: Wallet,
			color: "text-amber-600 bg-amber-50 border-amber-100",
			isDebt: false
		},
		{
			title: "Em Incumprimento",
			value: String(savers.filter((s) => s.status === "in_debt").length),
			subtext: "Ticantes em dívida",
			icon: AlertCircle,
			color: "text-red-600 bg-red-50 border-red-100",
			isDebt: true
		}
	];
	const columns = [
		{
			key: "cardNumber",
			header: "TICANTE",
			render: (value, row) => /* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col",
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:189:45",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1",
					"data-tsd-source": "/src/routes/dashboard/savers.tsx:190:11",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "font-mono text-[11px] text-slate-400",
						"data-tsd-source": "/src/routes/dashboard/savers.tsx:191:13",
						children: String(value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: cn("w-1.5 h-1.5 rounded-full", row.status === "active" ? "bg-emerald-500" : "bg-red-500"),
						"data-tsd-source": "/src/routes/dashboard/savers.tsx:192:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 190,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "font-bold text-sm text-slate-900 truncate w-32",
					"data-tsd-source": "/src/routes/dashboard/savers.tsx:194:11",
					children: row.name
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 194,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 189,
				columnNumber: 45
			}, this)
		},
		{
			key: "dailyAmount",
			header: "VALOR DIÁRIO",
			render: (value) => /* @__PURE__ */ _jsxDEV("span", {
				className: "text-sm",
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:199:33",
				children: [Number(value).toLocaleString(), " MZN"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 199,
				columnNumber: 33
			}, this)
		},
		{
			key: "totalSaved",
			header: "TOTAL POUPADO",
			render: (value) => /* @__PURE__ */ _jsxDEV("span", {
				className: "text-sm",
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:203:33",
				children: [Number(value).toLocaleString(), " MZN"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 203,
				columnNumber: 33
			}, this)
		},
		{
			key: "currentDebt",
			header: "DÍVIDA ATUAL",
			render: (value) => /* @__PURE__ */ _jsxDEV("span", {
				className: cn("text-sm", Number(value) > 0 ? "text-red-600" : "text-slate-500"),
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:207:33",
				children: [Number(value).toLocaleString(), " MZN"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 207,
				columnNumber: 33
			}, this)
		},
		{
			key: "daysInCycle",
			header: "DIAS NO CICLO",
			render: (value) => /* @__PURE__ */ _jsxDEV("span", {
				className: "text-sm",
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:213:33",
				children: [String(value), " Dias"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 33
			}, this)
		},
		{
			key: "status",
			header: "ESTADO",
			render: (_, row) => {
				if (row.status === "active") return /* @__PURE__ */ _jsxDEV(ActiveBadge, { "data-tsd-source": "/src/routes/dashboard/savers.tsx:218:43" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 218,
					columnNumber: 43
				}, this);
				if (row.status === "in_debt") return /* @__PURE__ */ _jsxDEV(DebtBadge, { "data-tsd-source": "/src/routes/dashboard/savers.tsx:219:44" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 219,
					columnNumber: 44
				}, this);
				if (row.status === "inactive") return /* @__PURE__ */ _jsxDEV(InactiveBadge, { "data-tsd-source": "/src/routes/dashboard/savers.tsx:220:45" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 220,
					columnNumber: 45
				}, this);
				return /* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs text-slate-400",
					"data-tsd-source": "/src/routes/dashboard/savers.tsx:221:14",
					children: "-"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 221,
					columnNumber: 14
				}, this);
			}
		}
	];
	const renderExpandedRow = (row) => /* @__PURE__ */ _jsxDEV(ExpandableRowContent, {
		title: `Detalhes de ${row.name}`,
		onViewFullDetails: () => console.log(...typeof window === "undefined" ? ["\x1B[35mLOG\x1B[39m \x1B[94m/src/routes/dashboard/savers.tsx:224:126\x1B[39m\n → "] : [
			"%cLOG%c %cGo to Source: http://localhost:4000/__tsd/open-source?source=%2Fsrc%2Froutes%2Fdashboard%2Fsavers.tsx%3A224%3A126%c \n → ",
			"color:#A0A",
			"color:#FFF",
			"color:#55F",
			"color:#FFF"
		], "Navigate to full details:", row.id),
		"data-tsd-source": "/src/routes/dashboard/savers.tsx:224:45",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-3 gap-4",
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:225:7",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						"data-tsd-source": "/src/routes/dashboard/savers.tsx:226:9",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-xs text-slate-500",
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:227:11",
							children: [/* @__PURE__ */ _jsxDEV(DollarSign, {
								size: 14,
								"data-tsd-source": "/src/routes/dashboard/savers.tsx:228:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 228,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/routes/dashboard/savers.tsx:229:13",
								children: "Total Poupança"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 229,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 227,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-lg font-bold text-slate-900",
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:231:11",
							children: [row.totalSaved.toLocaleString(), " MZN"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 231,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 226,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						"data-tsd-source": "/src/routes/dashboard/savers.tsx:233:9",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-xs text-slate-500",
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:234:11",
							children: [/* @__PURE__ */ _jsxDEV(AlertCircle, {
								size: 14,
								"data-tsd-source": "/src/routes/dashboard/savers.tsx:235:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 235,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/routes/dashboard/savers.tsx:236:13",
								children: "Dívida Atual"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 236,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: cn("text-lg font-bold", row.currentDebt > 0 ? "text-red-600" : "text-slate-900"),
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:238:11",
							children: [row.currentDebt.toLocaleString(), " MZN"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 233,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						"data-tsd-source": "/src/routes/dashboard/savers.tsx:242:9",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-xs text-slate-500",
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:243:11",
							children: [/* @__PURE__ */ _jsxDEV(Calendar, {
								size: 14,
								"data-tsd-source": "/src/routes/dashboard/savers.tsx:244:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 244,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/routes/dashboard/savers.tsx:245:13",
								children: "Dias no Ciclo"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 245,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 243,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-lg font-bold text-slate-900",
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:247:11",
							children: [row.daysInCycle, " dias"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 247,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 242,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 225,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "pt-4 border-t border-slate-200",
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:251:7",
				children: [/* @__PURE__ */ _jsxDEV("h5", {
					className: "text-xs font-semibold text-slate-500 uppercase mb-3",
					"data-tsd-source": "/src/routes/dashboard/savers.tsx:252:9",
					children: "Acções Rápidas"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 252,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap gap-2",
					"data-tsd-source": "/src/routes/dashboard/savers.tsx:253:9",
					children: [
						/* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							variant: "outline",
							leftIcon: /* @__PURE__ */ _jsxDEV(DollarSign, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 254,
								columnNumber: 57
							}, this),
							onClick: (e) => {
								e.stopPropagation();
								setSelectedSaver(row);
								setIsDepositModalOpen(true);
							},
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:254:11",
							children: "Registar Depósito"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 254,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							variant: "outline",
							leftIcon: /* @__PURE__ */ _jsxDEV(Phone, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 261,
								columnNumber: 57
							}, this),
							onClick: (e) => {
								e.stopPropagation();
								setSelectedSaver(row);
								setIsLoanModalOpen(true);
							},
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:261:11",
							children: "Solicitar Empréstimo"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 261,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							variant: "outline",
							leftIcon: /* @__PURE__ */ _jsxDEV(MoreVertical, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 268,
								columnNumber: 57
							}, this),
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:268:11",
							children: "Mais Opções"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 268,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 253,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 251,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "pt-4 border-t border-slate-200",
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:274:7",
				children: [/* @__PURE__ */ _jsxDEV("h5", {
					className: "text-xs font-semibold text-slate-500 uppercase mb-3",
					"data-tsd-source": "/src/routes/dashboard/savers.tsx:275:9",
					children: "Informação de Contacto"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 275,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 gap-4 text-sm",
					"data-tsd-source": "/src/routes/dashboard/savers.tsx:276:9",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						"data-tsd-source": "/src/routes/dashboard/savers.tsx:277:11",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-500",
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:278:13",
							children: "Organização:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 278,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "ml-2 font-medium text-slate-900",
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:279:13",
							children: row.organization?.name || "N/A"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 279,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 277,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						"data-tsd-source": "/src/routes/dashboard/savers.tsx:281:11",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-500",
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:282:13",
							children: "Data de Registo:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 282,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "ml-2 font-medium text-slate-900",
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:283:13",
							children: row.registrationDate
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 283,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 281,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 276,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 274,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 224,
		columnNumber: 45
	}, this);
	return /* @__PURE__ */ _jsxDEV(DashboardLayout, {
		"data-tsd-source": "/src/routes/dashboard/savers.tsx:288:10",
		children: [
			/* @__PURE__ */ _jsxDEV(Sidebar, {
				items: sidebarItems,
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:289:7"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 289,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col h-full overflow-hidden",
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:291:7",
				children: [/* @__PURE__ */ _jsxDEV(Header, {
					title: "Gestão de Ticantes",
					description: "Visão expandida e financeira dos membros",
					searchValue: searchTerm,
					onSearchChange: setSearchTerm,
					searchPlaceholder: "Pesquisar ticante...",
					rightContent: /* @__PURE__ */ _jsxDEV(Button, {
						size: "sm",
						leftIcon: /* @__PURE__ */ _jsxDEV(Plus, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 292,
							columnNumber: 238
						}, this),
						onClick: () => setIsRegisterModalOpen(true),
						children: "Novo Ticante"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 292,
						columnNumber: 210
					}, this),
					"data-tsd-source": "/src/routes/dashboard/savers.tsx:292:9"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 292,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("main", {
					className: "flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 max-w-7xl w-full mx-auto animate-in fade-in slide-in-from-bottom-3 duration-500",
					"data-tsd-source": "/src/routes/dashboard/savers.tsx:296:9",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200/60 shadow-sm",
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:298:11",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								"data-tsd-source": "/src/routes/dashboard/savers.tsx:299:13",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-sm font-bold text-slate-950 tracking-tight",
									"data-tsd-source": "/src/routes/dashboard/savers.tsx:300:15",
									children: "Gestão de Ticantes"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 300,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-400",
									"data-tsd-source": "/src/routes/dashboard/savers.tsx:301:15",
									children: "Visão expandida e financeira dos membros"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 301,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 299,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								"data-tsd-source": "/src/routes/dashboard/savers.tsx:303:13",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									"data-tsd-source": "/src/routes/dashboard/savers.tsx:304:15",
									children: [
										"Março 2024",
										"Abril 2024",
										"Maio 2024"
									].map((month) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: cn("px-3 py-1.5 rounded-full text-xs font-semibold transition-colors", selectedMonth === month ? "bg-slate-200 text-slate-700" : "bg-slate-100 text-slate-500 hover:bg-slate-200"),
										onClick: () => setSelectedMonth(month),
										"data-tsd-source": "/src/routes/dashboard/savers.tsx:305:73",
										children: month
									}, month, false, {
										fileName: _jsxFileName,
										lineNumber: 305,
										columnNumber: 73
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 304,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									"data-tsd-source": "/src/routes/dashboard/savers.tsx:309:15",
									children: [/* @__PURE__ */ _jsxDEV(Button, {
										size: "sm",
										variant: "secondary",
										leftIcon: /* @__PURE__ */ _jsxDEV(Filter, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 310,
											columnNumber: 65
										}, this),
										"data-tsd-source": "/src/routes/dashboard/savers.tsx:310:17",
										children: "Filtros"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 310,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV(Button, {
										size: "sm",
										variant: "secondary",
										leftIcon: /* @__PURE__ */ _jsxDEV(ChevronDown, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 313,
											columnNumber: 65
										}, this),
										"data-tsd-source": "/src/routes/dashboard/savers.tsx:313:17",
										children: "Vista Expandida"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 313,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 309,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 298,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4",
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:321:11",
							children: kpiData.map((kpi) => /* @__PURE__ */ _jsxDEV(KPICard, { ...kpi }, kpi.title, false, {
								fileName: _jsxFileName,
								lineNumber: 322,
								columnNumber: 33
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 321,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-12 gap-6",
							"data-tsd-source": "/src/routes/dashboard/savers.tsx:326:11",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "col-span-12",
									"data-tsd-source": "/src/routes/dashboard/savers.tsx:328:13",
									children: /* @__PURE__ */ _jsxDEV(Card, {
										"data-tsd-source": "/src/routes/dashboard/savers.tsx:329:15",
										children: /* @__PURE__ */ _jsxDEV(CardContent, {
											className: "p-0",
											"data-tsd-source": "/src/routes/dashboard/savers.tsx:330:17",
											children: /* @__PURE__ */ _jsxDEV(DataTable, {
												data: savers,
												columns,
												searchable: true,
												searchPlaceholder: "Pesquisar por nome ou número de cartão...",
												onRowClick: (row) => console.log(...typeof window === "undefined" ? ["\x1B[35mLOG\x1B[39m \x1B[94m/src/routes/dashboard/savers.tsx:331:161\x1B[39m\n → "] : [
													"%cLOG%c %cGo to Source: http://localhost:4000/__tsd/open-source?source=%2Fsrc%2Froutes%2Fdashboard%2Fsavers.tsx%3A331%3A161%c \n → ",
													"color:#A0A",
													"color:#FFF",
													"color:#55F",
													"color:#FFF"
												], "View saver:", row),
												emptyMessage: "Nenhum ticante encontrado",
												expandable: true,
												renderExpandedRow,
												onRowExpand: (row) => console.log(...typeof window === "undefined" ? ["\x1B[35mLOG\x1B[39m \x1B[94m/src/routes/dashboard/savers.tsx:331:311\x1B[39m\n → "] : [
													"%cLOG%c %cGo to Source: http://localhost:4000/__tsd/open-source?source=%2Fsrc%2Froutes%2Fdashboard%2Fsavers.tsx%3A331%3A311%c \n → ",
													"color:#A0A",
													"color:#FFF",
													"color:#55F",
													"color:#FFF"
												], "Row expanded:", row.id),
												"data-tsd-source": "/src/routes/dashboard/savers.tsx:331:19"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 331,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 330,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 329,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 328,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "col-span-12 lg:col-span-4",
									"data-tsd-source": "/src/routes/dashboard/savers.tsx:337:13",
									children: /* @__PURE__ */ _jsxDEV(Card, {
										"data-tsd-source": "/src/routes/dashboard/savers.tsx:338:15",
										children: /* @__PURE__ */ _jsxDEV(CardContent, {
											className: "p-5",
											"data-tsd-source": "/src/routes/dashboard/savers.tsx:339:17",
											children: [/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-sm font-semibold text-slate-900 mb-4",
												"data-tsd-source": "/src/routes/dashboard/savers.tsx:340:19",
												children: "Resumo Financeiro"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 340,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "space-y-4",
												"data-tsd-source": "/src/routes/dashboard/savers.tsx:341:19",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "p-4 bg-emerald-50 rounded-lg",
														"data-tsd-source": "/src/routes/dashboard/savers.tsx:342:21",
														children: [
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-xs text-slate-500 mb-1",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:343:23",
																children: "Colectado Este Mês"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 343,
																columnNumber: 23
															}, this),
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-xl font-bold text-emerald-600",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:344:23",
																children: "75.000 MZN"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 344,
																columnNumber: 23
															}, this),
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-[10px] text-emerald-600 mt-1",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:345:23",
																children: "+15% vs mês anterior"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 345,
																columnNumber: 23
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 342,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "p-4 bg-red-50 rounded-lg",
														"data-tsd-source": "/src/routes/dashboard/savers.tsx:347:21",
														children: [
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-xs text-slate-500 mb-1",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:348:23",
																children: "Em Dívida"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 348,
																columnNumber: 23
															}, this),
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-xl font-bold text-red-600",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:349:23",
																children: "2.300 MZN"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 349,
																columnNumber: 23
															}, this),
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-[10px] text-red-600 mt-1",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:350:23",
																children: "4 ticantes afectados"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 350,
																columnNumber: 23
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 347,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "p-4 bg-slate-50 rounded-lg",
														"data-tsd-source": "/src/routes/dashboard/savers.tsx:352:21",
														children: [
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-xs text-slate-500 mb-1",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:353:23",
																children: "Taxa de Assiduidade"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 353,
																columnNumber: 23
															}, this),
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-xl font-bold text-slate-900",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:354:23",
																children: "94.2%"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 354,
																columnNumber: 23
															}, this),
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-[10px] text-slate-400 mt-1",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:355:23",
																children: "322 de 342 ticantes"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 355,
																columnNumber: 23
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 352,
														columnNumber: 21
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 341,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 339,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 338,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 337,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "col-span-12 lg:col-span-8",
									"data-tsd-source": "/src/routes/dashboard/savers.tsx:363:13",
									children: /* @__PURE__ */ _jsxDEV(Card, {
										"data-tsd-source": "/src/routes/dashboard/savers.tsx:364:15",
										children: /* @__PURE__ */ _jsxDEV(CardContent, {
											className: "p-5",
											"data-tsd-source": "/src/routes/dashboard/savers.tsx:365:17",
											children: [/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-sm font-semibold text-slate-900 mb-4",
												"data-tsd-source": "/src/routes/dashboard/savers.tsx:366:19",
												children: "Actividade Recente"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 366,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "space-y-3",
												"data-tsd-source": "/src/routes/dashboard/savers.tsx:367:19",
												children: [
													{
														id: "1",
														action: "Novo depósito",
														user: "Carlos Mondlane",
														amount: "500 MZN",
														time: "Há 5 min"
													},
													{
														id: "2",
														action: "Empréstimo aprovado",
														user: "Ana Vilanculos",
														amount: "1.000 MZN",
														time: "Há 15 min"
													},
													{
														id: "3",
														action: "Pagamento recebido",
														user: "Bento Sitoe",
														amount: "300 MZN",
														time: "Há 30 min"
													},
													{
														id: "4",
														action: "Novo ticante registado",
														user: "Eduarda Langa",
														amount: "-",
														time: "Há 1 hora"
													}
												].map((activity) => /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-3 p-3 bg-slate-50 rounded-lg",
													"data-tsd-source": "/src/routes/dashboard/savers.tsx:392:38",
													children: [
														/* @__PURE__ */ _jsxDEV("div", {
															className: "w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center",
															"data-tsd-source": "/src/routes/dashboard/savers.tsx:393:25",
															children: /* @__PURE__ */ _jsxDEV(Users, {
																size: 16,
																className: "text-emerald-600",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:394:27"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 394,
																columnNumber: 27
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 393,
															columnNumber: 25
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "flex-1",
															"data-tsd-source": "/src/routes/dashboard/savers.tsx:396:25",
															children: [/* @__PURE__ */ _jsxDEV("p", {
																className: "text-xs font-medium text-slate-900",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:397:27",
																children: activity.action
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 397,
																columnNumber: 27
															}, this), /* @__PURE__ */ _jsxDEV("p", {
																className: "text-[10px] text-slate-400",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:398:27",
																children: activity.user
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 398,
																columnNumber: 27
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 396,
															columnNumber: 25
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "text-right",
															"data-tsd-source": "/src/routes/dashboard/savers.tsx:400:25",
															children: [/* @__PURE__ */ _jsxDEV("p", {
																className: "text-xs font-semibold text-slate-900",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:401:27",
																children: activity.amount
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 401,
																columnNumber: 27
															}, this), /* @__PURE__ */ _jsxDEV("p", {
																className: "text-[10px] text-slate-400",
																"data-tsd-source": "/src/routes/dashboard/savers.tsx:402:27",
																children: activity.time
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 402,
																columnNumber: 27
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 400,
															columnNumber: 25
														}, this)
													]
												}, activity.id, true, {
													fileName: _jsxFileName,
													lineNumber: 392,
													columnNumber: 38
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 367,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 365,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 364,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 363,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 326,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 296,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 291,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(RegisterSaverModal, {
				isOpen: isRegisterModalOpen,
				onClose: () => setIsRegisterModalOpen(false),
				onSubmit: (data) => console.log(...typeof window === "undefined" ? ["\x1B[35mLOG\x1B[39m \x1B[94m/src/routes/dashboard/savers.tsx:413:120\x1B[39m\n → "] : [
					"%cLOG%c %cGo to Source: http://localhost:4000/__tsd/open-source?source=%2Fsrc%2Froutes%2Fdashboard%2Fsavers.tsx%3A413%3A120%c \n → ",
					"color:#A0A",
					"color:#FFF",
					"color:#55F",
					"color:#FFF"
				], "Register saver:", data),
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:413:7"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 413,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(QuickDepositModal, {
				isOpen: isDepositModalOpen,
				onClose: () => {
					setIsDepositModalOpen(false);
					setSelectedSaver(null);
				},
				onSubmit: (data) => console.log(...typeof window === "undefined" ? ["\x1B[35mLOG\x1B[39m \x1B[94m/src/routes/dashboard/savers.tsx:418:26\x1B[39m\n → "] : [
					"%cLOG%c %cGo to Source: http://localhost:4000/__tsd/open-source?source=%2Fsrc%2Froutes%2Fdashboard%2Fsavers.tsx%3A418%3A26%c \n → ",
					"color:#A0A",
					"color:#FFF",
					"color:#55F",
					"color:#FFF"
				], "Deposit:", data),
				saverName: selectedSaver?.name,
				lastAmount: selectedSaver?.dailyAmount,
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:415:7"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 415,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(QuickLoanModal, {
				isOpen: isLoanModalOpen,
				onClose: () => {
					setIsLoanModalOpen(false);
					setSelectedSaver(null);
				},
				onSubmit: (data) => console.log(...typeof window === "undefined" ? ["\x1B[35mLOG\x1B[39m \x1B[94m/src/routes/dashboard/savers.tsx:423:26\x1B[39m\n → "] : [
					"%cLOG%c %cGo to Source: http://localhost:4000/__tsd/open-source?source=%2Fsrc%2Froutes%2Fdashboard%2Fsavers.tsx%3A423%3A26%c \n → ",
					"color:#A0A",
					"color:#FFF",
					"color:#55F",
					"color:#FFF"
				], "Loan:", data),
				saverName: selectedSaver?.name,
				maxLoanAmount: selectedSaver?.totalSaved ? selectedSaver.totalSaved * 2 : 5e4,
				"data-tsd-source": "/src/routes/dashboard/savers.tsx:420:7"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 420,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 288,
		columnNumber: 10
	}, this);
}
_s(SaversManagement, "FfFbyidJZRlLhKLRH4USEgUevn0=", false, function() {
	return [useSavers];
});
_c = SaversManagement;
export { SaversManagement as component };
var _c;
$RefreshReg$(_c, "SaversManagement");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/dashboard/savers.tsx?tsr-split=component";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/savers.tsx?tsr-split=component", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/savers.tsx?tsr-split=component", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/savers.tsx?tsr-split=component" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQ0E7QUFDQTtBQWNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFPQTtDQUFBOzs7Ozs7Ozs7Ozs7Ozs7O0NBY0U7Q0FBQTs7Ozs7Ozs7Ozs7Ozs7OztDQWNBO0NBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FjQTtDQUFBOzs7Ozs7Ozs7Ozs7Ozs7O0NBY0E7Q0FBQTs7Ozs7Ozs7Ozs7Ozs7OztDQWNBO0NBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FjQTtBQUFBO0FBR0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7ZUFnRUE7S0FBQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO01BQUE7Z0JBQUE7S0FBQTs7OztlQUNBO01BQUE7TUFBQTtLQUFBOzs7O2FBSUE7Ozs7O2NBQ0E7S0FBQTtLQUFBO2VBQUE7SUFBQTs7OztZQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7ZUF5QkEsc0NBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBMkJBO0lBQUE7SUFBQTtjQUFBO0tBQ0E7TUFBQTtNQUFBO2dCQUFBLENBQ0E7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFBQTtRQUFBO09BQUE7Ozs7aUJBQ0E7UUFBQTtrQkFBQTtPQUFBOzs7O2VBQ0E7Ozs7O2dCQUNBO09BQUE7T0FBQTtpQkFBQTs7Ozs7Y0FDQTs7Ozs7O0tBQ0E7TUFBQTtNQUFBO2dCQUFBLENBQ0E7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFBQTtRQUFBO09BQUE7Ozs7aUJBQ0E7UUFBQTtrQkFBQTtPQUFBOzs7O2VBQ0E7Ozs7O2dCQUNBO09BQUE7T0FBQTtpQkFBQSxDQUNBLHdDQUNBOzs7OztjQUNBOzs7Ozs7S0FDQTtNQUFBO01BQUE7Z0JBQUEsQ0FDQTtPQUFBO09BQUE7aUJBQUEsQ0FDQTtRQUFBO1FBQUE7T0FBQTs7OztpQkFDQTtRQUFBO2tCQUFBO09BQUE7Ozs7ZUFDQTs7Ozs7Z0JBQ0E7T0FBQTtPQUFBO2lCQUFBOzs7OztjQUNBOzs7Ozs7SUFDQTs7Ozs7O0dBRUE7SUFBQTtJQUFBO2NBQUEsQ0FDQTtLQUFBO0tBQUE7ZUFBQTtJQUFBOzs7O2NBQ0E7S0FBQTtLQUFBO2VBQUE7TUFDQTtPQUFBO09BQUE7T0FBQTs7Ozs7T0FBQTs7Ozs7OztNQVdBOzs7OztNQUNBO09BQUE7T0FBQTtPQUFBOzs7OztPQUFBOzs7Ozs7O01BV0E7Ozs7O01BQ0E7T0FBQTtPQUFBO09BQUE7Ozs7O09BQUE7aUJBQUE7TUFFQTs7Ozs7S0FDQTs7Ozs7WUFDQTs7Ozs7O0dBRUE7SUFBQTtJQUFBO2NBQUEsQ0FDQTtLQUFBO0tBQUE7ZUFBQTtJQUFBOzs7O2NBQ0E7S0FBQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO2dCQUFBLENBQ0E7T0FBQTtPQUFBO2lCQUFBO01BQUE7Ozs7Z0JBQ0E7T0FBQTtPQUFBO2lCQUFBO01BQUE7Ozs7Y0FDQTs7Ozs7ZUFDQTtNQUFBO2dCQUFBLENBQ0E7T0FBQTtPQUFBO2lCQUFBO01BQUE7Ozs7Z0JBQ0E7T0FBQTtPQUFBO2lCQUFBO01BQUE7Ozs7Y0FDQTs7Ozs7YUFDQTs7Ozs7WUFDQTs7Ozs7O0VBQ0E7Ozs7Ozs7OztHQUtBO0lBQUE7SUFBQTtHQUFBOzs7OztHQUVBO0lBQUE7SUFBQTtjQUFBLENBQ0E7S0FBQTtLQUFBO0tBQUE7S0FBQTtLQUFBO0tBQUE7TUFBQTtNQUFBOzs7OztNQUFBO2dCQUFBO0tBU0E7Ozs7O0tBQUE7SUFBQTs7OztjQUlBO0tBQUE7S0FBQTtlQUFBO01BRUE7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFBQTtrQkFBQSxDQUNBO1NBQUE7U0FBQTttQkFBQTtRQUFBOzs7O2tCQUNBO1NBQUE7U0FBQTttQkFBQTtRQUFBOzs7O2dCQUNBOzs7OztpQkFDQTtRQUFBO1FBQUE7a0JBQUEsQ0FDQTtTQUFBO1NBQUE7bUJBQ0E7VUFBQTtVQUFBO1VBQUE7U0FBQTtVQUFBO1VBQUE7VUFBQTtVQUFBO29CQVlBO1NBQ0EsR0FiQTs7OztnQkFhQTtRQUVBOzs7O2tCQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtVQUFBOzs7OztVQUFBO29CQUFBO1NBRUE7Ozs7bUJBQ0E7VUFBQTtVQUFBO1VBQUE7Ozs7O1VBQUE7b0JBQUE7U0FFQTs7OztpQkFDQTs7Ozs7Z0JBQ0E7Ozs7O2VBQ0E7Ozs7OztNQUdBO09BQUE7T0FBQTtpQkFDQTs7OztjQUFBO01BR0E7Ozs7O01BR0E7T0FBQTtPQUFBO2lCQUFBO1FBRUE7U0FBQTtTQUFBO21CQUNBO1VBQUE7b0JBQ0E7V0FBQTtXQUFBO3FCQUNBO1lBQUE7WUFBQTtZQUFBO1lBQUE7WUFBQTthQUFBO2FBQUE7YUFBQTthQUFBO2FBQUE7WUFBQTtZQUFBO1lBQUE7WUFBQTtZQUFBO2FBQUE7YUFBQTthQUFBO2FBQUE7YUFBQTtZQUFBO1lBQUE7V0FBQTs7Ozs7VUFXQTs7Ozs7U0FDQTs7Ozs7UUFDQTs7Ozs7UUFHQTtTQUFBO1NBQUE7bUJBQ0E7VUFBQTtvQkFDQTtXQUFBO1dBQUE7cUJBQUEsQ0FDQTtZQUFBO1lBQUE7c0JBQUE7V0FBQTs7OztxQkFDQTtZQUFBO1lBQUE7c0JBQUE7YUFDQTtjQUFBO2NBQUE7d0JBQUE7ZUFDQTtnQkFBQTtnQkFBQTswQkFBQTtlQUFBOzs7OztlQUNBO2dCQUFBO2dCQUFBOzBCQUFBO2VBQUE7Ozs7O2VBQ0E7Z0JBQUE7Z0JBQUE7MEJBQUE7ZUFBQTs7Ozs7Y0FDQTs7Ozs7O2FBQ0E7Y0FBQTtjQUFBO3dCQUFBO2VBQ0E7Z0JBQUE7Z0JBQUE7MEJBQUE7ZUFBQTs7Ozs7ZUFDQTtnQkFBQTtnQkFBQTswQkFBQTtlQUFBOzs7OztlQUNBO2dCQUFBO2dCQUFBOzBCQUFBO2VBQUE7Ozs7O2NBQ0E7Ozs7OzthQUNBO2NBQUE7Y0FBQTt3QkFBQTtlQUNBO2dCQUFBO2dCQUFBOzBCQUFBO2VBQUE7Ozs7O2VBQ0E7Z0JBQUE7Z0JBQUE7MEJBQUE7ZUFBQTs7Ozs7ZUFDQTtnQkFBQTtnQkFBQTswQkFBQTtlQUFBOzs7OztjQUNBOzs7Ozs7WUFDQTs7Ozs7bUJBQ0E7Ozs7OztTQUNBOzs7OztRQUNBOzs7OztRQUdBO1NBQUE7U0FBQTttQkFDQTtVQUFBO29CQUNBO1dBQUE7V0FBQTtxQkFBQSxDQUNBO1lBQUE7WUFBQTtzQkFBQTtXQUFBOzs7O3FCQUNBO1lBQUE7WUFBQTtzQkFDQTthQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztjQU9BO2VBQUE7ZUFBQTt5QkFDQTtnQkFBQTtnQkFBQTtnQkFBQTtlQUFBOzs7OztjQUNBOzs7OztjQUNBO2VBQUE7ZUFBQTt5QkFBQSxDQUNBO2dCQUFBO2dCQUFBOzBCQUFBO2VBQUE7Ozs7eUJBQ0E7Z0JBQUE7Z0JBQUE7MEJBQUE7ZUFBQTs7Ozt1QkFDQTs7Ozs7O2NBQ0E7ZUFBQTtlQUFBO3lCQUFBLENBQ0E7Z0JBQUE7Z0JBQUE7MEJBQUE7ZUFBQTs7Ozt5QkFDQTtnQkFBQTtnQkFBQTswQkFBQTtlQUFBOzs7O3VCQUNBOzs7Ozs7YUFDQTs7Ozs7bUJBQUE7V0FFQTs7OzttQkFDQTs7Ozs7O1NBQ0E7Ozs7O1FBQ0E7Ozs7O09BQ0E7Ozs7OztLQUNBOzs7OztZQUNBOzs7Ozs7R0FFQTtJQUFBO0lBQUE7SUFBQTtLQUFBO0tBQUE7S0FBQTtLQUFBO0tBQUE7SUFBQTtJQUFBO0dBQUE7Ozs7O0dBTUE7SUFBQTtJQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBV0E7SUFBQTtJQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBVUE7Ozs7OztBQUVBOzs7OztBQUFDIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJzYXZlcnMudHN4P3Rzci1zcGxpdD1jb21wb25lbnQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlRmlsZVJvdXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcic7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7XG4gIFVzZXJzLFxuICBQbHVzLFxuICBTZWFyY2gsXG4gIEZpbHRlcixcbiAgQ2hldnJvbkRvd24sXG4gIFRyZW5kaW5nVXAsXG4gIEFsZXJ0Q2lyY2xlLFxuICBXYWxsZXQsXG4gIERvbGxhclNpZ24sXG4gIFBob25lLFxuICBDYWxlbmRhcixcbiAgTW9yZVZlcnRpY2FsXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBEYXNoYm9hcmRMYXlvdXQgfSBmcm9tICcjL2NvbXBvbmVudHMvbGF5b3V0L0Rhc2hib2FyZExheW91dCc7XG5pbXBvcnQgeyBTaWRlYmFyIH0gZnJvbSAnIy9jb21wb25lbnRzL2xheW91dC9TaWRlYmFyJztcbmltcG9ydCB7IEhlYWRlciB9IGZyb20gJyMvY29tcG9uZW50cy9sYXlvdXQvSGVhZGVyJztcbmltcG9ydCB7IERhdGFUYWJsZSB9IGZyb20gJyMvY29tcG9uZW50cy91aS9EYXRhVGFibGUnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnIy9jb21wb25lbnRzL3VpL0J1dHRvbic7XG5pbXBvcnQgeyBLUElDYXJkIH0gZnJvbSAnIy9jb21wb25lbnRzL3VpL0tQSUNhcmQnO1xuaW1wb3J0IHsgQ2FyZCwgQ2FyZENvbnRlbnQgfSBmcm9tICcjL2NvbXBvbmVudHMvdWkvQ2FyZCc7XG5pbXBvcnQgeyBEZWJ0QmFkZ2UsIEFjdGl2ZUJhZGdlLCBJbmFjdGl2ZUJhZGdlIH0gZnJvbSAnIy9jb21wb25lbnRzL3VpL1N0YXR1c0JhZGdlJztcbmltcG9ydCB7IEV4cGFuZGFibGVSb3dDb250ZW50IH0gZnJvbSAnIy9jb21wb25lbnRzL3VpL0V4cGFuZGFibGVSb3cnO1xuaW1wb3J0IHsgY24gfSBmcm9tICcjL2xpYi9kZXNpZ24tc3lzdGVtJztcbmltcG9ydCB7IHVzZVNhdmVycyB9IGZyb20gJyMvZmVhdHVyZXMvc2F2ZXJzJztcbmltcG9ydCB7IFJlZ2lzdGVyU2F2ZXJNb2RhbCB9IGZyb20gJyMvY29tcG9uZW50cy9idXNpbmVzcy9SZWdpc3RlclNhdmVyTW9kYWwnO1xuaW1wb3J0IHsgUXVpY2tEZXBvc2l0TW9kYWwgfSBmcm9tICcjL2NvbXBvbmVudHMvYnVzaW5lc3MvUXVpY2tEZXBvc2l0TW9kYWwnO1xuaW1wb3J0IHsgUXVpY2tMb2FuTW9kYWwgfSBmcm9tICcjL2NvbXBvbmVudHMvYnVzaW5lc3MvUXVpY2tMb2FuTW9kYWwnO1xuaW1wb3J0IHR5cGUgeyBTYXZlciB9IGZyb20gJyMvZmVhdHVyZXMvc2F2ZXJzL3R5cGVzJztcblxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKCcvZGFzaGJvYXJkL3NhdmVycycpKHtcbiAgY29tcG9uZW50OiBTYXZlcnNNYW5hZ2VtZW50LFxufSk7XG5cbmNvbnN0IG1vY2tTYXZlcnM6IFNhdmVyW10gPSBbXG4gIHtcbiAgICBpZDogJzEnLFxuICAgIGNhcmROdW1iZXI6IDEwMDEsXG4gICAgbmFtZTogJ0NhcmxvcyBNb25kbGFuZScsXG4gICAgZGFpbHlBbW91bnQ6IDUwMCxcbiAgICBvcmdhbml6YXRpb25JZDogJ29yZy0xJyxcbiAgICBpc0FjdGl2ZTogdHJ1ZSxcbiAgICByZWdpc3RyYXRpb25EYXRlOiAnMjAyNC0wMS0xNScsXG4gICAgdG90YWxTYXZlZDogNzUwMCxcbiAgICBjdXJyZW50RGVidDogMjMwMCxcbiAgICBkYXlzSW5DeWNsZTogMTUsXG4gICAgc3RhdHVzOiAnaW5fZGVidCcsXG4gICAgb3JnYW5pemF0aW9uOiB7IGlkOiAnb3JnLTEnLCBuYW1lOiAnWGl0aXF1ZSBDZW50cmFsJyB9LFxuICB9LFxuICB7XG4gICAgaWQ6ICcyJyxcbiAgICBjYXJkTnVtYmVyOiAxMDAyLFxuICAgIG5hbWU6ICdBbmEgVmlsYW5jdWxvcycsXG4gICAgZGFpbHlBbW91bnQ6IDI1MCxcbiAgICBvcmdhbml6YXRpb25JZDogJ29yZy0xJyxcbiAgICBpc0FjdGl2ZTogdHJ1ZSxcbiAgICByZWdpc3RyYXRpb25EYXRlOiAnMjAyNC0wMi0wMScsXG4gICAgdG90YWxTYXZlZDogMjUwMCxcbiAgICBjdXJyZW50RGVidDogMTUwMCxcbiAgICBkYXlzSW5DeWNsZTogNSxcbiAgICBzdGF0dXM6ICdpbl9kZWJ0JyxcbiAgICBvcmdhbml6YXRpb246IHsgaWQ6ICdvcmctMScsIG5hbWU6ICdYaXRpcXVlIENlbnRyYWwnIH0sXG4gIH0sXG4gIHtcbiAgICBpZDogJzMnLFxuICAgIGNhcmROdW1iZXI6IDEwMDMsXG4gICAgbmFtZTogJ0JlbnRvIFNpdG9lJyxcbiAgICBkYWlseUFtb3VudDogMzAwLFxuICAgIG9yZ2FuaXphdGlvbklkOiAnb3JnLTEnLFxuICAgIGlzQWN0aXZlOiB0cnVlLFxuICAgIHJlZ2lzdHJhdGlvbkRhdGU6ICcyMDI0LTAzLTEwJyxcbiAgICB0b3RhbFNhdmVkOiA2NjAwLFxuICAgIGN1cnJlbnREZWJ0OiAwLFxuICAgIGRheXNJbkN5Y2xlOiAyMixcbiAgICBzdGF0dXM6ICdhY3RpdmUnLFxuICAgIG9yZ2FuaXphdGlvbjogeyBpZDogJ29yZy0xJywgbmFtZTogJ1hpdGlxdWUgQ2VudHJhbCcgfSxcbiAgfSxcbiAge1xuICAgIGlkOiAnNCcsXG4gICAgY2FyZE51bWJlcjogMTAwNCxcbiAgICBuYW1lOiAnRWR1YXJkYSBMYW5nYScsXG4gICAgZGFpbHlBbW91bnQ6IDEwMDAsXG4gICAgb3JnYW5pemF0aW9uSWQ6ICdvcmctMScsXG4gICAgaXNBY3RpdmU6IHRydWUsXG4gICAgcmVnaXN0cmF0aW9uRGF0ZTogJzIwMjQtMDEtMTAnLFxuICAgIHRvdGFsU2F2ZWQ6IDEyMDAwLFxuICAgIGN1cnJlbnREZWJ0OiAyMDAwLFxuICAgIGRheXNJbkN5Y2xlOiAxMixcbiAgICBzdGF0dXM6ICdpbl9kZWJ0JyxcbiAgICBvcmdhbml6YXRpb246IHsgaWQ6ICdvcmctMScsIG5hbWU6ICdYaXRpcXVlIENlbnRyYWwnIH0sXG4gIH0sXG4gIHtcbiAgICBpZDogJzUnLFxuICAgIGNhcmROdW1iZXI6IDEwMDUsXG4gICAgbmFtZTogJ0dlcmFsZG8gTXVjYXZlbGUnLFxuICAgIGRhaWx5QW1vdW50OiAxNTAsXG4gICAgb3JnYW5pemF0aW9uSWQ6ICdvcmctMScsXG4gICAgaXNBY3RpdmU6IHRydWUsXG4gICAgcmVnaXN0cmF0aW9uRGF0ZTogJzIwMjQtMDEtMDUnLFxuICAgIHRvdGFsU2F2ZWQ6IDQ1MDAsXG4gICAgY3VycmVudERlYnQ6IDAsXG4gICAgZGF5c0luQ3ljbGU6IDMwLFxuICAgIHN0YXR1czogJ2FjdGl2ZScsXG4gICAgb3JnYW5pemF0aW9uOiB7IGlkOiAnb3JnLTEnLCBuYW1lOiAnWGl0aXF1ZSBDZW50cmFsJyB9LFxuICB9LFxuICB7XG4gICAgaWQ6ICc2JyxcbiAgICBjYXJkTnVtYmVyOiAxMDA2LFxuICAgIG5hbWU6ICdJc2FiZWwgVGVtYmUnLFxuICAgIGRhaWx5QW1vdW50OiAyMDAsXG4gICAgb3JnYW5pemF0aW9uSWQ6ICdvcmctMScsXG4gICAgaXNBY3RpdmU6IHRydWUsXG4gICAgcmVnaXN0cmF0aW9uRGF0ZTogJzIwMjQtMDItMTUnLFxuICAgIHRvdGFsU2F2ZWQ6IDUwMDAsXG4gICAgY3VycmVudERlYnQ6IDAsXG4gICAgZGF5c0luQ3ljbGU6IDI1LFxuICAgIHN0YXR1czogJ2FjdGl2ZScsXG4gICAgb3JnYW5pemF0aW9uOiB7IGlkOiAnb3JnLTEnLCBuYW1lOiAnWGl0aXF1ZSBDZW50cmFsJyB9LFxuICB9LFxuXTtcblxuZnVuY3Rpb24gU2F2ZXJzTWFuYWdlbWVudCgpIHtcbiAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2VsZWN0ZWRNb250aCwgc2V0U2VsZWN0ZWRNb250aF0gPSB1c2VTdGF0ZSgnTWFpbyAyMDI0Jyk7XG4gIGNvbnN0IFtpc1JlZ2lzdGVyTW9kYWxPcGVuLCBzZXRJc1JlZ2lzdGVyTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzRGVwb3NpdE1vZGFsT3Blbiwgc2V0SXNEZXBvc2l0TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzTG9hbk1vZGFsT3Blbiwgc2V0SXNMb2FuTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NlbGVjdGVkU2F2ZXIsIHNldFNlbGVjdGVkU2F2ZXJdID0gdXNlU3RhdGU8U2F2ZXIgfCBudWxsPihudWxsKTtcblxuICBjb25zdCB7IGRhdGE6IHNhdmVyc0RhdGEgfSA9IHVzZVNhdmVycyh7IHBhZ2U6IDEsIHBhZ2VTaXplOiAyMCB9KTtcbiAgY29uc3Qgc2F2ZXJzID0gc2F2ZXJzRGF0YT8uZGF0YSB8fCBtb2NrU2F2ZXJzO1xuXG4gIC8vIFVzZSBzYXZlcnMgaW4gdGhlIGNvbXBvbmVudFxuICBjb25zb2xlLmxvZygnU2F2ZXJzIGNvdW50OicsIHNhdmVycy5sZW5ndGgpO1xuXG4gIGNvbnN0IHNpZGViYXJJdGVtcyA9IFtcbiAgICB7IGxhYmVsOiAnUGFpbmVsJywgaWNvbjogVXNlcnMsIGhyZWY6ICcvZGFzaGJvYXJkL292ZXJ2aWV3JyB9LFxuICAgIHsgbGFiZWw6ICdHZXN0w6NvJywgaWNvbjogVXNlcnMsIGhyZWY6ICcvZGFzaGJvYXJkL3NhdmVycycsIGlzQWN0aXZlOiB0cnVlIH0sXG4gICAgeyBsYWJlbDogJ0ZpbmFuY2Vpcm8nLCBpY29uOiBXYWxsZXQsIGhyZWY6ICcvZGFzaGJvYXJkL2ZpbmFuY2lhbCcgfSxcbiAgICB7IGxhYmVsOiAnUmVsYXTDs3Jpb3MnLCBpY29uOiBUcmVuZGluZ1VwLCBocmVmOiAnL2Rhc2hib2FyZC9yZXBvcnRzJyB9LFxuICAgIHsgbGFiZWw6ICdDb25maWd1cmHDp8O1ZXMnLCBpY29uOiBTZWFyY2gsIGhyZWY6ICcvZGFzaGJvYXJkL3NldHRpbmdzJyB9LFxuICBdO1xuXG4gIGNvbnN0IGtwaURhdGEgPSBbXG4gICAge1xuICAgICAgdGl0bGU6ICdUb3RhbCBUaWNhbnRlcycsXG4gICAgICB2YWx1ZTogU3RyaW5nKHNhdmVycy5sZW5ndGgpLFxuICAgICAgc3VidGV4dDogJ1RvdGFsIHJlZ2lzdGFkbycsXG4gICAgICBpY29uOiBVc2VycyxcbiAgICAgIGNvbG9yOiAndGV4dC1lbWVyYWxkLTYwMCBiZy1lbWVyYWxkLTUwIGJvcmRlci1lbWVyYWxkLTEwMCcsXG4gICAgICBpc0RlYnQ6IGZhbHNlLFxuICAgIH0sXG4gICAge1xuICAgICAgdGl0bGU6ICdUb3RhbCBTb2IgR2VzdMOjbycsXG4gICAgICB2YWx1ZTogJzQ1MC4wMDAgTVpOJyxcbiAgICAgIHN1YnRleHQ6ICcrMTIuNSUgdnMgbcOqcyBhbnRlcmlvcicsXG4gICAgICBpY29uOiBXYWxsZXQsXG4gICAgICBjb2xvcjogJ3RleHQtc2xhdGUtNjAwIGJnLXNsYXRlLTUwIGJvcmRlci1zbGF0ZS0xMDAnLFxuICAgICAgaXNEZWJ0OiBmYWxzZSxcbiAgICAgIHRyZW5kOiB7IHZhbHVlOiAnMTIuNSUnLCBpc1Bvc2l0aXZlOiB0cnVlIH0sXG4gICAgfSxcbiAgICB7XG4gICAgICB0aXRsZTogJ0VtcHLDqXN0aW1vcyBBY3Rpdm9zJyxcbiAgICAgIHZhbHVlOiAnOC4wMDAgTVpOJyxcbiAgICAgIHN1YnRleHQ6ICczIGVtcHLDqXN0aW1vcyBhY3Rpdm9zJyxcbiAgICAgIGljb246IFdhbGxldCxcbiAgICAgIGNvbG9yOiAndGV4dC1hbWJlci02MDAgYmctYW1iZXItNTAgYm9yZGVyLWFtYmVyLTEwMCcsXG4gICAgICBpc0RlYnQ6IGZhbHNlLFxuICAgIH0sXG4gICAge1xuICAgICAgdGl0bGU6ICdFbSBJbmN1bXByaW1lbnRvJyxcbiAgICAgIHZhbHVlOiBTdHJpbmcoc2F2ZXJzLmZpbHRlcigocykgPT4gcy5zdGF0dXMgPT09ICdpbl9kZWJ0JykubGVuZ3RoKSxcbiAgICAgIHN1YnRleHQ6ICdUaWNhbnRlcyBlbSBkw612aWRhJyxcbiAgICAgIGljb246IEFsZXJ0Q2lyY2xlLFxuICAgICAgY29sb3I6ICd0ZXh0LXJlZC02MDAgYmctcmVkLTUwIGJvcmRlci1yZWQtMTAwJyxcbiAgICAgIGlzRGVidDogdHJ1ZSxcbiAgICB9LFxuICBdO1xuXG4gIGNvbnN0IGNvbHVtbnMgPSBbXG4gICAge1xuICAgICAga2V5OiAnY2FyZE51bWJlcicsXG4gICAgICBoZWFkZXI6ICdUSUNBTlRFJyxcbiAgICAgIHJlbmRlcjogKHZhbHVlOiB1bmtub3duLCByb3c6IFNhdmVyKSA9PiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPntTdHJpbmcodmFsdWUpfTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgIFwidy0xLjUgaC0xLjUgcm91bmRlZC1mdWxsXCIsXG4gICAgICAgICAgICAgIHJvdy5zdGF0dXMgPT09ICdhY3RpdmUnID8gJ2JnLWVtZXJhbGQtNTAwJyA6ICdiZy1yZWQtNTAwJ1xuICAgICAgICAgICAgKX0gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCB0cnVuY2F0ZSB3LTMyXCI+e3Jvdy5uYW1lfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApLFxuICAgIH0sXG4gICAge1xuICAgICAga2V5OiAnZGFpbHlBbW91bnQnLFxuICAgICAgaGVhZGVyOiAnVkFMT1IgREnDgVJJTycsXG4gICAgICByZW5kZXI6ICh2YWx1ZTogdW5rbm93bikgPT4gKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+e051bWJlcih2YWx1ZSkudG9Mb2NhbGVTdHJpbmcoKX0gTVpOPC9zcGFuPlxuICAgICAgKSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGtleTogJ3RvdGFsU2F2ZWQnLFxuICAgICAgaGVhZGVyOiAnVE9UQUwgUE9VUEFETycsXG4gICAgICByZW5kZXI6ICh2YWx1ZTogdW5rbm93bikgPT4gKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+e051bWJlcih2YWx1ZSkudG9Mb2NhbGVTdHJpbmcoKX0gTVpOPC9zcGFuPlxuICAgICAgKSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGtleTogJ2N1cnJlbnREZWJ0JyxcbiAgICAgIGhlYWRlcjogJ0TDjVZJREEgQVRVQUwnLFxuICAgICAgcmVuZGVyOiAodmFsdWU6IHVua25vd24pID0+IChcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICBcInRleHQtc21cIixcbiAgICAgICAgICBOdW1iZXIodmFsdWUpID4gMCA/ICd0ZXh0LXJlZC02MDAnIDogJ3RleHQtc2xhdGUtNTAwJ1xuICAgICAgICApfT5cbiAgICAgICAgICB7TnVtYmVyKHZhbHVlKS50b0xvY2FsZVN0cmluZygpfSBNWk5cbiAgICAgICAgPC9zcGFuPlxuICAgICAgKSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGtleTogJ2RheXNJbkN5Y2xlJyxcbiAgICAgIGhlYWRlcjogJ0RJQVMgTk8gQ0lDTE8nLFxuICAgICAgcmVuZGVyOiAodmFsdWU6IHVua25vd24pID0+IChcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbVwiPntTdHJpbmcodmFsdWUpfSBEaWFzPC9zcGFuPlxuICAgICAgKSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGtleTogJ3N0YXR1cycsXG4gICAgICBoZWFkZXI6ICdFU1RBRE8nLFxuICAgICAgcmVuZGVyOiAoXzogdW5rbm93biwgcm93OiBTYXZlcikgPT4ge1xuICAgICAgICBpZiAocm93LnN0YXR1cyA9PT0gJ2FjdGl2ZScpIHJldHVybiA8QWN0aXZlQmFkZ2UgLz47XG4gICAgICAgIGlmIChyb3cuc3RhdHVzID09PSAnaW5fZGVidCcpIHJldHVybiA8RGVidEJhZGdlIC8+O1xuICAgICAgICBpZiAocm93LnN0YXR1cyA9PT0gJ2luYWN0aXZlJykgcmV0dXJuIDxJbmFjdGl2ZUJhZGdlIC8+O1xuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPi08L3NwYW4+O1xuICAgICAgfSxcbiAgICB9LFxuICBdO1xuXG4gIGNvbnN0IHJlbmRlckV4cGFuZGVkUm93ID0gKHJvdzogU2F2ZXIpID0+IChcbiAgICA8RXhwYW5kYWJsZVJvd0NvbnRlbnRcbiAgICAgIHRpdGxlPXtgRGV0YWxoZXMgZGUgJHtyb3cubmFtZX1gfVxuICAgICAgb25WaWV3RnVsbERldGFpbHM9eygpID0+IGNvbnNvbGUubG9nKCdOYXZpZ2F0ZSB0byBmdWxsIGRldGFpbHM6Jywgcm93LmlkKX1cbiAgICA+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgIDxEb2xsYXJTaWduIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgPHNwYW4+VG90YWwgUG91cGFuw6dhPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+e3Jvdy50b3RhbFNhdmVkLnRvTG9jYWxlU3RyaW5nKCl9IE1aTjwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICA8QWxlcnRDaXJjbGUgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICA8c3Bhbj5Ew612aWRhIEF0dWFsPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT17Y24oXCJ0ZXh0LWxnIGZvbnQtYm9sZFwiLCByb3cuY3VycmVudERlYnQgPiAwID8gXCJ0ZXh0LXJlZC02MDBcIiA6IFwidGV4dC1zbGF0ZS05MDBcIil9PlxuICAgICAgICAgICAge3Jvdy5jdXJyZW50RGVidC50b0xvY2FsZVN0cmluZygpfSBNWk5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgPENhbGVuZGFyIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgPHNwYW4+RGlhcyBubyBDaWNsbzwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPntyb3cuZGF5c0luQ3ljbGV9IGRpYXM8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgIDxoNSBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIG1iLTNcIj5BY8Onw7VlcyBSw6FwaWRhczwvaDU+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgbGVmdEljb249ezxEb2xsYXJTaWduIHNpemU9ezE0fSAvPn1cbiAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XG4gICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgICAgICAgIHNldFNlbGVjdGVkU2F2ZXIocm93KTtcbiAgICAgICAgICAgICAgc2V0SXNEZXBvc2l0TW9kYWxPcGVuKHRydWUpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICBSZWdpc3RhciBEZXDDs3NpdG9cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgbGVmdEljb249ezxQaG9uZSBzaXplPXsxNH0gLz59XG4gICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgICBzZXRTZWxlY3RlZFNhdmVyKHJvdyk7XG4gICAgICAgICAgICAgIHNldElzTG9hbk1vZGFsT3Blbih0cnVlKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgU29saWNpdGFyIEVtcHLDqXN0aW1vXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIGxlZnRJY29uPXs8TW9yZVZlcnRpY2FsIHNpemU9ezE0fSAvPn0+XG4gICAgICAgICAgICBNYWlzIE9ww6fDtWVzXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgIDxoNSBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIG1iLTNcIj5JbmZvcm1hw6fDo28gZGUgQ29udGFjdG88L2g1PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTQgdGV4dC1zbVwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMFwiPk9yZ2FuaXphw6fDo286PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTkwMFwiPntyb3cub3JnYW5pemF0aW9uPy5uYW1lIHx8ICdOL0EnfTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDBcIj5EYXRhIGRlIFJlZ2lzdG86PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTkwMFwiPntyb3cucmVnaXN0cmF0aW9uRGF0ZX08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9FeHBhbmRhYmxlUm93Q29udGVudD5cbiAgKTtcblxuICByZXR1cm4gKFxuICAgIDxEYXNoYm9hcmRMYXlvdXQ+XG4gICAgICA8U2lkZWJhciBpdGVtcz17c2lkZWJhckl0ZW1zfSAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGZsZXgtY29sIGgtZnVsbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgPEhlYWRlclxuICAgICAgICAgIHRpdGxlPVwiR2VzdMOjbyBkZSBUaWNhbnRlc1wiXG4gICAgICAgICAgZGVzY3JpcHRpb249XCJWaXPDo28gZXhwYW5kaWRhIGUgZmluYW5jZWlyYSBkb3MgbWVtYnJvc1wiXG4gICAgICAgICAgc2VhcmNoVmFsdWU9e3NlYXJjaFRlcm19XG4gICAgICAgICAgb25TZWFyY2hDaGFuZ2U9e3NldFNlYXJjaFRlcm19XG4gICAgICAgICAgc2VhcmNoUGxhY2Vob2xkZXI9XCJQZXNxdWlzYXIgdGljYW50ZS4uLlwiXG4gICAgICAgICAgcmlnaHRDb250ZW50PXtcbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgbGVmdEljb249ezxQbHVzIHNpemU9ezE2fSAvPn0gb25DbGljaz17KCkgPT4gc2V0SXNSZWdpc3Rlck1vZGFsT3Blbih0cnVlKX0+XG4gICAgICAgICAgICAgIE5vdm8gVGljYW50ZVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgfVxuICAgICAgICAvPlxuXG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcC02IHNtOnAtOCBzcGFjZS15LTYgbWF4LXctN3hsIHctZnVsbCBteC1hdXRvIGFuaW1hdGUtaW4gZmFkZS1pbiBzbGlkZS1pbi1mcm9tLWJvdHRvbS0zIGR1cmF0aW9uLTUwMFwiPlxuICAgICAgICAgIHsvKiBBY3Rpb24gQmFubmVyICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IGJnLXdoaXRlIHAtNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzYwIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTUwIHRyYWNraW5nLXRpZ2h0XCI+R2VzdMOjbyBkZSBUaWNhbnRlczwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+Vmlzw6NvIGV4cGFuZGlkYSBlIGZpbmFuY2VpcmEgZG9zIG1lbWJyb3M8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIHtbJ01hcsOnbyAyMDI0JywgJ0FicmlsIDIwMjQnLCAnTWFpbyAyMDI0J10ubWFwKChtb250aCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBrZXk9e21vbnRofVxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICBcInB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1jb2xvcnNcIixcbiAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZE1vbnRoID09PSBtb250aFxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTcwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNTAwIGhvdmVyOmJnLXNsYXRlLTIwMFwiXG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkTW9udGgobW9udGgpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7bW9udGh9XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBsZWZ0SWNvbj17PEZpbHRlciBzaXplPXsxNn0gLz59PlxuICAgICAgICAgICAgICAgICAgRmlsdHJvc1xuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cInNlY29uZGFyeVwiIGxlZnRJY29uPXs8Q2hldnJvbkRvd24gc2l6ZT17MTZ9IC8+fT5cbiAgICAgICAgICAgICAgICAgIFZpc3RhIEV4cGFuZGlkYVxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEtQSSBDYXJkcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cbiAgICAgICAgICAgIHtrcGlEYXRhLm1hcCgoa3BpKSA9PiAoXG4gICAgICAgICAgICAgIDxLUElDYXJkIGtleT17a3BpLnRpdGxlfSB7Li4ua3BpfSAvPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogTWFpbiBDb250ZW50ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMTIgZ2FwLTZcIj5cbiAgICAgICAgICAgIHsvKiBTYXZlcnMgVGFibGUgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTEyXCI+XG4gICAgICAgICAgICAgIDxDYXJkPlxuICAgICAgICAgICAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJwLTBcIj5cbiAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcbiAgICAgICAgICAgICAgICAgICAgZGF0YT17c2F2ZXJzfVxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxuICAgICAgICAgICAgICAgICAgICBzZWFyY2hhYmxlPXt0cnVlfVxuICAgICAgICAgICAgICAgICAgICBzZWFyY2hQbGFjZWhvbGRlcj1cIlBlc3F1aXNhciBwb3Igbm9tZSBvdSBuw7ptZXJvIGRlIGNhcnTDo28uLi5cIlxuICAgICAgICAgICAgICAgICAgICBvblJvd0NsaWNrPXsocm93KSA9PiBjb25zb2xlLmxvZygnVmlldyBzYXZlcjonLCByb3cpfVxuICAgICAgICAgICAgICAgICAgICBlbXB0eU1lc3NhZ2U9XCJOZW5odW0gdGljYW50ZSBlbmNvbnRyYWRvXCJcbiAgICAgICAgICAgICAgICAgICAgZXhwYW5kYWJsZT17dHJ1ZX1cbiAgICAgICAgICAgICAgICAgICAgcmVuZGVyRXhwYW5kZWRSb3c9e3JlbmRlckV4cGFuZGVkUm93fVxuICAgICAgICAgICAgICAgICAgICBvblJvd0V4cGFuZD17KHJvdykgPT4gY29uc29sZS5sb2coJ1JvdyBleHBhbmRlZDonLCByb3cuaWQpfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEZpbmFuY2lhbCBTdW1tYXJ5ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi0xMiBsZzpjb2wtc3Bhbi00XCI+XG4gICAgICAgICAgICAgIDxDYXJkPlxuICAgICAgICAgICAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJwLTVcIj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItNFwiPlJlc3VtbyBGaW5hbmNlaXJvPC9oMz5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLWVtZXJhbGQtNTAgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbWItMVwiPkNvbGVjdGFkbyBFc3RlIE3DqnM8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTYwMFwiPjc1LjAwMCBNWk48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1lbWVyYWxkLTYwMCBtdC0xXCI+KzE1JSB2cyBtw6pzIGFudGVyaW9yPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctcmVkLTUwIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIG1iLTFcIj5FbSBEw612aWRhPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtcmVkLTYwMFwiPjIuMzAwIE1aTjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXJlZC02MDAgbXQtMVwiPjQgdGljYW50ZXMgYWZlY3RhZG9zPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctc2xhdGUtNTAgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbWItMVwiPlRheGEgZGUgQXNzaWR1aWRhZGU8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj45NC4yJTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+MzIyIGRlIDM0MiB0aWNhbnRlczwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFJlY2VudCBBY3Rpdml0eSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMTIgbGc6Y29sLXNwYW4tOFwiPlxuICAgICAgICAgICAgICA8Q2FyZD5cbiAgICAgICAgICAgICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPVwicC01XCI+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIG1iLTRcIj5BY3RpdmlkYWRlIFJlY2VudGU8L2gzPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgICAgICB7IGlkOiAnMScsIGFjdGlvbjogJ05vdm8gZGVww7NzaXRvJywgdXNlcjogJ0NhcmxvcyBNb25kbGFuZScsIGFtb3VudDogJzUwMCBNWk4nLCB0aW1lOiAnSMOhIDUgbWluJyB9LFxuICAgICAgICAgICAgICAgICAgICAgIHsgaWQ6ICcyJywgYWN0aW9uOiAnRW1wcsOpc3RpbW8gYXByb3ZhZG8nLCB1c2VyOiAnQW5hIFZpbGFuY3Vsb3MnLCBhbW91bnQ6ICcxLjAwMCBNWk4nLCB0aW1lOiAnSMOhIDE1IG1pbicgfSxcbiAgICAgICAgICAgICAgICAgICAgICB7IGlkOiAnMycsIGFjdGlvbjogJ1BhZ2FtZW50byByZWNlYmlkbycsIHVzZXI6ICdCZW50byBTaXRvZScsIGFtb3VudDogJzMwMCBNWk4nLCB0aW1lOiAnSMOhIDMwIG1pbicgfSxcbiAgICAgICAgICAgICAgICAgICAgICB7IGlkOiAnNCcsIGFjdGlvbjogJ05vdm8gdGljYW50ZSByZWdpc3RhZG8nLCB1c2VyOiAnRWR1YXJkYSBMYW5nYScsIGFtb3VudDogJy0nLCB0aW1lOiAnSMOhIDEgaG9yYScgfSxcbiAgICAgICAgICAgICAgICAgICAgXS5tYXAoKGFjdGl2aXR5KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2FjdGl2aXR5LmlkfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwLTMgYmctc2xhdGUtNTAgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTEwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlcnMgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtOTAwXCI+e2FjdGl2aXR5LmFjdGlvbn08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+e2FjdGl2aXR5LnVzZXJ9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+e2FjdGl2aXR5LmFtb3VudH08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+e2FjdGl2aXR5LnRpbWV9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9DYXJkQ29udGVudD5cbiAgICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvbWFpbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8UmVnaXN0ZXJTYXZlck1vZGFsXG4gICAgICAgIGlzT3Blbj17aXNSZWdpc3Rlck1vZGFsT3Blbn1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNSZWdpc3Rlck1vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgIG9uU3VibWl0PXsoZGF0YSkgPT4gY29uc29sZS5sb2coJ1JlZ2lzdGVyIHNhdmVyOicsIGRhdGEpfVxuICAgICAgLz5cblxuICAgICAgPFF1aWNrRGVwb3NpdE1vZGFsXG4gICAgICAgIGlzT3Blbj17aXNEZXBvc2l0TW9kYWxPcGVufVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XG4gICAgICAgICAgc2V0SXNEZXBvc2l0TW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgICBzZXRTZWxlY3RlZFNhdmVyKG51bGwpO1xuICAgICAgICB9fVxuICAgICAgICBvblN1Ym1pdD17KGRhdGEpID0+IGNvbnNvbGUubG9nKCdEZXBvc2l0OicsIGRhdGEpfVxuICAgICAgICBzYXZlck5hbWU9e3NlbGVjdGVkU2F2ZXI/Lm5hbWV9XG4gICAgICAgIGxhc3RBbW91bnQ9e3NlbGVjdGVkU2F2ZXI/LmRhaWx5QW1vdW50fVxuICAgICAgLz5cblxuICAgICAgPFF1aWNrTG9hbk1vZGFsXG4gICAgICAgIGlzT3Blbj17aXNMb2FuTW9kYWxPcGVufVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XG4gICAgICAgICAgc2V0SXNMb2FuTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgICBzZXRTZWxlY3RlZFNhdmVyKG51bGwpO1xuICAgICAgICB9fVxuICAgICAgICBvblN1Ym1pdD17KGRhdGEpID0+IGNvbnNvbGUubG9nKCdMb2FuOicsIGRhdGEpfVxuICAgICAgICBzYXZlck5hbWU9e3NlbGVjdGVkU2F2ZXI/Lm5hbWV9XG4gICAgICAgIG1heExvYW5BbW91bnQ9e3NlbGVjdGVkU2F2ZXI/LnRvdGFsU2F2ZWQgPyBzZWxlY3RlZFNhdmVyLnRvdGFsU2F2ZWQgKiAyIDogNTAwMDB9XG4gICAgICAvPlxuICAgIDwvRGFzaGJvYXJkTGF5b3V0PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy96ZWx0by9PbmVEcml2ZS9Eb2N1bWVudG9zL0dpdEh1Yi9YaXRpcXVlQXBwVUkvc3JjL3JvdXRlcy9kYXNoYm9hcmQvc2F2ZXJzLnRzeCJ9