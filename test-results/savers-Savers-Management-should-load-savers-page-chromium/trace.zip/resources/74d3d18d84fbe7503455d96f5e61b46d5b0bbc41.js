import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Card.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { cn } from "/src/lib/design-system.ts";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/Card.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
export function Card({ children, className = "", isInteractive = false, onClick }) {
	const baseClasses = "bg-white border border-slate-200 rounded-lg shadow-sm";
	const interactiveClasses = isInteractive ? "hover:shadow-md cursor-pointer transition-shadow duration-200" : "";
	if (isInteractive) {
		return /* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			className: cn(baseClasses, interactiveClasses, className),
			onClick,
			"data-tsd-source": "/src/components/ui/Card.tsx:19:7",
			children
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn(baseClasses, className),
		"data-tsd-source": "/src/components/ui/Card.tsx:30:5",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 5
	}, this);
}
_c = Card;
export function CardHeader({ children, className = "" }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn("p-5 border-b border-slate-100", className),
		"data-tsd-source": "/src/components/ui/Card.tsx:43:5",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 5
	}, this);
}
_c2 = CardHeader;
export function CardContent({ children, className = "" }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn("p-5", className),
		"data-tsd-source": "/src/components/ui/Card.tsx:56:5",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 5
	}, this);
}
_c3 = CardContent;
export function CardFooter({ children, className = "" }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn("p-5 border-t border-slate-100 bg-slate-50/50", className),
		"data-tsd-source": "/src/components/ui/Card.tsx:69:5",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 69,
		columnNumber: 5
	}, this);
}
_c4 = CardFooter;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "Card");
$RefreshReg$(_c2, "CardHeader");
$RefreshReg$(_c3, "CardContent");
$RefreshReg$(_c4, "CardFooter");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/Card.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/Card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/Card.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/ui/Card.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQ0E7OztBQVNBO0NBQ0E7Q0FDQSwyQ0FDQSxrRUFDQTtDQUVBO0VBQ0EsT0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDQTs7Ozs7Q0FFQTtDQUVBLE9BQ0E7RUFBQTtFQUFBO0VBQ0E7Q0FDQTs7Ozs7QUFFQTs7QUFPQTtDQUNBLE9BQ0E7RUFBQTtFQUFBO0VBQ0E7Q0FDQTs7Ozs7QUFFQTs7QUFPQTtDQUNBLE9BQ0E7RUFBQTtFQUFBO0VBQ0E7Q0FDQTs7Ozs7QUFFQTs7QUFPQTtDQUNBLE9BQ0E7RUFBQTtFQUFBO0VBQ0E7Q0FDQTs7Ozs7QUFFQSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIiMvbGliL2Rlc2lnbi1zeXN0ZW1cIjtcblxuaW50ZXJmYWNlIENhcmRQcm9wcyB7XG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgaXNJbnRlcmFjdGl2ZT86IGJvb2xlYW47XG4gIG9uQ2xpY2s/OiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQ2FyZCh7IGNoaWxkcmVuLCBjbGFzc05hbWUgPSBcIlwiLCBpc0ludGVyYWN0aXZlID0gZmFsc2UsIG9uQ2xpY2sgfTogQ2FyZFByb3BzKSB7XG4gIGNvbnN0IGJhc2VDbGFzc2VzID0gXCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHNoYWRvdy1zbVwiO1xuICBjb25zdCBpbnRlcmFjdGl2ZUNsYXNzZXMgPSBpc0ludGVyYWN0aXZlXG4gICAgPyBcImhvdmVyOnNoYWRvdy1tZCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLXNoYWRvdyBkdXJhdGlvbi0yMDBcIlxuICAgIDogXCJcIjtcblxuICBpZiAoaXNJbnRlcmFjdGl2ZSkge1xuICAgIHJldHVybiAoXG4gICAgICA8YnV0dG9uXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICBjbGFzc05hbWU9e2NuKGJhc2VDbGFzc2VzLCBpbnRlcmFjdGl2ZUNsYXNzZXMsIGNsYXNzTmFtZSl9XG4gICAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICA+XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDwvYnV0dG9uPlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtjbihiYXNlQ2xhc3NlcywgY2xhc3NOYW1lKX0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmludGVyZmFjZSBDYXJkSGVhZGVyUHJvcHMge1xuICBjaGlsZHJlbjogUmVhY3ROb2RlO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBDYXJkSGVhZGVyKHsgY2hpbGRyZW4sIGNsYXNzTmFtZSA9IFwiXCIgfTogQ2FyZEhlYWRlclByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2NuKFwicC01IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDBcIiwgY2xhc3NOYW1lKX0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmludGVyZmFjZSBDYXJkQ29udGVudFByb3BzIHtcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQ2FyZENvbnRlbnQoeyBjaGlsZHJlbiwgY2xhc3NOYW1lID0gXCJcIiB9OiBDYXJkQ29udGVudFByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2NuKFwicC01XCIsIGNsYXNzTmFtZSl9PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvZGl2PlxuICApO1xufVxuXG5pbnRlcmZhY2UgQ2FyZEZvb3RlclByb3BzIHtcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQ2FyZEZvb3Rlcih7IGNoaWxkcmVuLCBjbGFzc05hbWUgPSBcIlwiIH06IENhcmRGb290ZXJQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtjbihcInAtNSBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGJnLXNsYXRlLTUwLzUwXCIsIGNsYXNzTmFtZSl9PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy96ZWx0by9PbmVEcml2ZS9Eb2N1bWVudG9zL0dpdEh1Yi9YaXRpcXVlQXBwVUkvc3JjL2NvbXBvbmVudHMvdWkvQ2FyZC50c3gifQ==