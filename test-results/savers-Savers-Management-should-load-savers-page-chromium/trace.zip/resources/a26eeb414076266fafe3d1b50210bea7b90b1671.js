import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/business/QuickLoanModal.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03f72e91";
import { Modal, ModalFooter } from "/src/components/ui/Modal.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { AlertCircle, CheckCircle2, Wallet } from "/node_modules/.vite/deps/lucide-react.js?v=03f72e91";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/QuickLoanModal.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
var _s = $RefreshSig$();
export function QuickLoanModal({ isOpen, onClose, onSubmit, saverName, maxLoanAmount = 5e4 }) {
	_s();
	const [formData, setFormData] = useState({
		amount: "",
		reason: "",
		isEmergency: false,
		repaymentDate: ""
	});
	const [showToast, setShowToast] = useState(false);
	const handleSubmit = (e) => {
		e.preventDefault();
		onSubmit(formData);
		setShowToast(true);
		setTimeout(() => {
			setShowToast(false);
			onClose();
		}, 2e3);
	};
	const handleCancel = () => {
		setFormData({
			amount: "",
			reason: "",
			isEmergency: false,
			repaymentDate: ""
		});
		onClose();
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Modal, {
		isOpen,
		onClose: handleCancel,
		title: "Solicitar Empréstimo",
		size: "md",
		"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:53:7",
		children: /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			className: "space-y-4",
			"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:54:9",
			children: [
				saverName && /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-50 p-3 rounded-lg",
					"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:56:13",
					children: /* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-slate-600",
						"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:57:15",
						children: ["Empréstimo para: ", /* @__PURE__ */ _jsxDEV("span", {
							className: "font-semibold text-slate-900",
							"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:57:70",
							children: saverName
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 138
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:61:11",
					children: [
						/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "amount",
							className: "block text-sm font-medium text-slate-700 mb-1",
							"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:62:13",
							children: "Valor do Empréstimo (MZN) *"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:65:13",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",
								"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:66:15",
								children: /* @__PURE__ */ _jsxDEV(Wallet, {
									size: 16,
									className: "text-slate-400",
									"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:67:17"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								id: "amount",
								type: "number",
								placeholder: "0.00",
								required: true,
								value: formData.amount,
								onChange: (e) => setFormData({
									...formData,
									amount: e.target.value
								}),
								className: "block w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
								min: "0",
								max: maxLoanAmount,
								step: "0.01",
								"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:69:15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 mt-1",
							"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:82:13",
							children: [
								"Máximo disponível: ",
								maxLoanAmount.toLocaleString(),
								" MZN"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:85:11",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "reason",
						className: "block text-sm font-medium text-slate-700 mb-1",
						"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:86:13",
						children: "Motivo do Empréstimo *"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "reason",
						type: "text",
						placeholder: "Descreva o motivo do empréstimo...",
						required: true,
						value: formData.reason,
						onChange: (e) => setFormData({
							...formData,
							reason: e.target.value
						}),
						className: "block w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
						"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:89:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:100:11",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "repaymentDate",
						className: "block text-sm font-medium text-slate-700 mb-1",
						"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:101:13",
						children: "Data de Pagamento Prevista *"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "repaymentDate",
						type: "date",
						required: true,
						value: formData.repaymentDate,
						onChange: (e) => setFormData({
							...formData,
							repaymentDate: e.target.value
						}),
						className: "block w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
						"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:104:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 100,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:114:11",
					children: [/* @__PURE__ */ _jsxDEV("input", {
						type: "checkbox",
						id: "isEmergency",
						checked: formData.isEmergency,
						onChange: (e) => setFormData({
							...formData,
							isEmergency: e.target.checked
						}),
						className: "w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500",
						"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:115:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "isEmergency",
						className: "flex items-center gap-2 text-sm text-slate-700",
						"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:122:13",
						children: [/* @__PURE__ */ _jsxDEV(AlertCircle, {
							size: 16,
							className: "text-amber-500",
							"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:123:15"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:124:15",
							children: "Empréstimo de Emergência"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 122,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 114,
					columnNumber: 11
				}, this),
				formData.isEmergency && /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-amber-50 border border-amber-200 rounded-lg p-3",
					"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:129:13",
					children: /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-amber-800",
						"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:130:15",
						children: "⚠️ Empréstimos de emergência são processados prioritariamente mas podem ter taxas mais elevadas."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV(ModalFooter, {
					"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:136:11",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						type: "button",
						variant: "outline",
						onClick: handleCancel,
						"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:137:13",
						children: "Cancelar"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						type: "submit",
						leftIcon: /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 45
						}, this),
						"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:140:13",
						children: "Solicitar Empréstimo"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 54,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 53,
		columnNumber: 7
	}, this), showToast && /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed bottom-6 right-6 bg-white border-l-4 border-emerald-500 shadow-lg rounded-lg p-4 transform transition-all duration-300 z-50 flex items-start gap-4 max-w-sm",
		"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:149:9",
		children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
			className: "text-emerald-500 mt-0.5",
			size: 20,
			"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:150:11"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 150,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex-1",
			"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:151:11",
			children: [/* @__PURE__ */ _jsxDEV("h4", {
				className: "text-sm font-medium text-slate-900",
				"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:152:13",
				children: "Solicitação Enviada"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 152,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-slate-500 mt-1",
				"data-tsd-source": "/src/components/business/QuickLoanModal.tsx:153:13",
				children: "O empréstimo será analisado e você receberá uma resposta breve."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 153,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 151,
			columnNumber: 11
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 149,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 52,
		columnNumber: 5
	}, this);
}
_s(QuickLoanModal, "SNErwAFPC/K2nb4eSqPR2r/Ig60=");
_c = QuickLoanModal;
var _c;
$RefreshReg$(_c, "QuickLoanModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/business/QuickLoanModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/QuickLoanModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/QuickLoanModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/QuickLoanModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFpQkE7O0NBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNBO0NBRUE7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0dBQ0E7R0FDQTtFQUNBO0NBQ0E7Q0FFQTtFQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDQTtFQUNBO0NBQ0E7Q0FFQSxPQUNBLGdEQUNBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtZQUNBO0dBQUE7R0FBQTtHQUFBO2FBQUE7SUFDQSxhQUNBO0tBQUE7S0FBQTtlQUNBO01BQUE7TUFBQTtnQkFBQSxDQUFtRDtPQUFBO09BQUE7aUJBQWdFO01BQUE7Ozs7Y0FBQTs7Ozs7O0lBQ25IOzs7OztJQUdBO0tBQUE7ZUFBQTtNQUNBO09BQUE7T0FBQTtPQUFBO2lCQUE2RjtNQUU3Rjs7Ozs7TUFDQTtPQUFBO09BQUE7aUJBQUEsQ0FDQTtRQUFBO1FBQUE7a0JBQ0E7U0FBQTtTQUFBO1NBQUE7UUFBNkQ7Ozs7O09BQzdEOzs7O2lCQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1NBQUE7U0FBQTtRQUFBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtPQUFjOzs7O2VBQ2Q7Ozs7OztNQUNBO09BQUE7T0FBQTtpQkFBQTtRQUFzRDtRQUFBO1FBQUE7T0FBQTs7Ozs7O0tBQ3REOzs7Ozs7SUFFQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO01BQUE7TUFBQTtnQkFBNkY7S0FFN0Y7Ozs7ZUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtPQUFBO09BQUE7TUFBQTtNQUNBO01BQ0E7S0FBWTs7OzthQUNaOzs7Ozs7SUFFQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO01BQUE7TUFBQTtnQkFBb0c7S0FFcEc7Ozs7ZUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7T0FBQTtPQUFBO01BQUE7TUFDQTtNQUNBO0tBQVk7Ozs7YUFDWjs7Ozs7O0lBRUE7S0FBQTtLQUFBO2VBQUEsQ0FDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO09BQUE7T0FBQTtNQUFBO01BQ0E7TUFDQTtLQUFZOzs7O2VBQ1o7TUFBQTtNQUFBO01BQUE7Z0JBQUEsQ0FDQTtPQUFBO09BQUE7T0FBQTtNQUFnRTs7OztnQkFDaEU7T0FBQTtpQkFBbUI7TUFBQTs7OztjQUNuQjs7Ozs7YUFDQTs7Ozs7O0lBRUEsd0JBQ0E7S0FBQTtLQUFBO2VBQ0E7TUFBQTtNQUFBO2dCQUFtRDtLQUVuRDs7Ozs7SUFDQTs7Ozs7SUFHQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO01BQUE7TUFBQTtNQUFBO2dCQUEwRTtLQUUxRTs7OztlQUNBO01BQUE7TUFBQTs7Ozs7TUFBQTtnQkFBdUU7S0FFdkU7Ozs7YUFDQTs7Ozs7O0dBQ0E7Ozs7OztDQUNBOzs7O1dBR0EsYUFDQTtFQUFBO0VBQUE7WUFBQSxDQUNBO0dBQUE7R0FBQTtHQUFBO0VBQXNFOzs7O1lBQ3RFO0dBQUE7R0FBQTthQUFBLENBQ0E7SUFBQTtJQUFBO2NBQThEO0dBQUE7Ozs7YUFDOUQ7SUFBQTtJQUFBO2NBQXNEO0dBQUE7Ozs7V0FDdEQ7Ozs7O1VBQ0E7Ozs7O1NBRUE7Ozs7O0FBRUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlF1aWNrTG9hbk1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IE1vZGFsLCBNb2RhbEZvb3RlciB9IGZyb20gJyMvY29tcG9uZW50cy91aS9Nb2RhbCc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcjL2NvbXBvbmVudHMvdWkvQnV0dG9uJztcbmltcG9ydCB7IEFsZXJ0Q2lyY2xlLCBDaGVja0NpcmNsZTIsIFdhbGxldCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmludGVyZmFjZSBRdWlja0xvYW5Nb2RhbFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvblN1Ym1pdDogKGRhdGE6IExvYW5EYXRhKSA9PiB2b2lkO1xuICBzYXZlck5hbWU/OiBzdHJpbmc7XG4gIG1heExvYW5BbW91bnQ/OiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBMb2FuRGF0YSB7XG4gIGFtb3VudDogc3RyaW5nO1xuICByZWFzb246IHN0cmluZztcbiAgaXNFbWVyZ2VuY3k6IGJvb2xlYW47XG4gIHJlcGF5bWVudERhdGU6IHN0cmluZztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFF1aWNrTG9hbk1vZGFsKHsgaXNPcGVuLCBvbkNsb3NlLCBvblN1Ym1pdCwgc2F2ZXJOYW1lLCBtYXhMb2FuQW1vdW50ID0gNTAwMDAgfTogUXVpY2tMb2FuTW9kYWxQcm9wcykge1xuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlPExvYW5EYXRhPih7XG4gICAgYW1vdW50OiAnJyxcbiAgICByZWFzb246ICcnLFxuICAgIGlzRW1lcmdlbmN5OiBmYWxzZSxcbiAgICByZXBheW1lbnREYXRlOiAnJyxcbiAgfSk7XG5cbiAgY29uc3QgW3Nob3dUb2FzdCwgc2V0U2hvd1RvYXN0XSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIG9uU3VibWl0KGZvcm1EYXRhKTtcbiAgICBzZXRTaG93VG9hc3QodHJ1ZSk7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXRTaG93VG9hc3QoZmFsc2UpO1xuICAgICAgb25DbG9zZSgpO1xuICAgIH0sIDIwMDApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNhbmNlbCA9ICgpID0+IHtcbiAgICBzZXRGb3JtRGF0YSh7XG4gICAgICBhbW91bnQ6ICcnLFxuICAgICAgcmVhc29uOiAnJyxcbiAgICAgIGlzRW1lcmdlbmN5OiBmYWxzZSxcbiAgICAgIHJlcGF5bWVudERhdGU6ICcnLFxuICAgIH0pO1xuICAgIG9uQ2xvc2UoKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8TW9kYWwgaXNPcGVuPXtpc09wZW59IG9uQ2xvc2U9e2hhbmRsZUNhbmNlbH0gdGl0bGU9XCJTb2xpY2l0YXIgRW1wcsOpc3RpbW9cIiBzaXplPVwibWRcIj5cbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAge3NhdmVyTmFtZSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIHAtMyByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS02MDBcIj5FbXByw6lzdGltbyBwYXJhOiA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+e3NhdmVyTmFtZX08L3NwYW4+PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImFtb3VudFwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICBWYWxvciBkbyBFbXByw6lzdGltbyAoTVpOKSAqXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcGwtMyBmbGV4IGl0ZW1zLWNlbnRlciBwb2ludGVyLWV2ZW50cy1ub25lXCI+XG4gICAgICAgICAgICAgICAgPFdhbGxldCBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgaWQ9XCJhbW91bnRcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMC4wMFwiXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYW1vdW50fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgYW1vdW50OiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcGwtMTAgcHItMyBweS0yIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgbWF4PXttYXhMb2FuQW1vdW50fVxuICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtdC0xXCI+TcOheGltbyBkaXNwb27DrXZlbDoge21heExvYW5BbW91bnQudG9Mb2NhbGVTdHJpbmcoKX0gTVpOPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicmVhc29uXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgICAgICAgIE1vdGl2byBkbyBFbXByw6lzdGltbyAqXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIGlkPVwicmVhc29uXCJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRlc2NyZXZhIG8gbW90aXZvIGRvIGVtcHLDqXN0aW1vLi4uXCJcbiAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnJlYXNvbn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCByZWFzb246IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicmVwYXltZW50RGF0ZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICBEYXRhIGRlIFBhZ2FtZW50byBQcmV2aXN0YSAqXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIGlkPVwicmVwYXltZW50RGF0ZVwiXG4gICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnJlcGF5bWVudERhdGV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgcmVwYXltZW50RGF0ZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAvMjAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgaWQ9XCJpc0VtZXJnZW5jeVwiXG4gICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmlzRW1lcmdlbmN5fVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIGlzRW1lcmdlbmN5OiBlLnRhcmdldC5jaGVja2VkIH0pfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IHJvdW5kZWQgYm9yZGVyLXNsYXRlLTMwMCB0ZXh0LWVtZXJhbGQtNjAwIGZvY3VzOnJpbmctZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiaXNFbWVyZ2VuY3lcIiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIHRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgIDxBbGVydENpcmNsZSBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1hbWJlci01MDBcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5FbXByw6lzdGltbyBkZSBFbWVyZ8OqbmNpYTwvc3Bhbj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7Zm9ybURhdGEuaXNFbWVyZ2VuY3kgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1hbWJlci01MCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCByb3VuZGVkLWxnIHAtM1wiPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtYW1iZXItODAwXCI+XG4gICAgICAgICAgICAgICAg4pqg77iPIEVtcHLDqXN0aW1vcyBkZSBlbWVyZ8OqbmNpYSBzw6NvIHByb2Nlc3NhZG9zIHByaW9yaXRhcmlhbWVudGUgbWFzIHBvZGVtIHRlciB0YXhhcyBtYWlzIGVsZXZhZGFzLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgPE1vZGFsRm9vdGVyPlxuICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgdmFyaWFudD1cIm91dGxpbmVcIiBvbkNsaWNrPXtoYW5kbGVDYW5jZWx9PlxuICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBsZWZ0SWNvbj17PENoZWNrQ2lyY2xlMiBzaXplPXsxNn0gLz59PlxuICAgICAgICAgICAgICBTb2xpY2l0YXIgRW1wcsOpc3RpbW9cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvTW9kYWxGb290ZXI+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvTW9kYWw+XG5cbiAgICAgIHsvKiBUb2FzdCBOb3RpZmljYXRpb24gKi99XG4gICAgICB7c2hvd1RvYXN0ICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBib3R0b20tNiByaWdodC02IGJnLXdoaXRlIGJvcmRlci1sLTQgYm9yZGVyLWVtZXJhbGQtNTAwIHNoYWRvdy1sZyByb3VuZGVkLWxnIHAtNCB0cmFuc2Zvcm0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHotNTAgZmxleCBpdGVtcy1zdGFydCBnYXAtNCBtYXgtdy1zbVwiPlxuICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTUwMCBtdC0wLjVcIiBzaXplPXsyMH0gLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS05MDBcIj5Tb2xpY2l0YcOnw6NvIEVudmlhZGE8L2g0PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtdC0xXCI+TyBlbXByw6lzdGltbyBzZXLDoSBhbmFsaXNhZG8gZSB2b2PDqiByZWNlYmVyw6EgdW1hIHJlc3Bvc3RhIGJyZXZlLjwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy96ZWx0by9PbmVEcml2ZS9Eb2N1bWVudG9zL0dpdEh1Yi9YaXRpcXVlQXBwVUkvc3JjL2NvbXBvbmVudHMvYnVzaW5lc3MvUXVpY2tMb2FuTW9kYWwudHN4In0=