import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/business/RegisterSaverModal.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03f72e91";
import { Modal, ModalFooter } from "/src/components/ui/Modal.tsx";
import { Button } from "/src/components/ui/Button.tsx";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/RegisterSaverModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
var _s = $RefreshSig$();
export function RegisterSaverModal({ isOpen, onClose, onSubmit }) {
	_s();
	const [formData, setFormData] = useState({
		cardNumber: "",
		name: "",
		phone: "",
		dailyAmount: "",
		organizationId: "",
		contact: "",
		identityDocument: "",
		pin: "",
		occupation: ""
	});
	const handleSubmit = (e) => {
		e.preventDefault();
		onSubmit(formData);
		onClose();
	};
	return /* @__PURE__ */ _jsxDEV(Modal, {
		isOpen,
		onClose,
		title: "Registar Novo Ticante",
		size: "lg",
		"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:43:5",
		children: /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			className: "space-y-4",
			"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:44:7",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 gap-4",
					"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:45:9",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:46:11",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "cardNumber",
							className: "block text-xs font-semibold text-slate-700 mb-1",
							"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:47:13",
							children: "Número de Cartão *"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							id: "cardNumber",
							type: "number",
							value: formData.cardNumber,
							onChange: (e) => setFormData({
								...formData,
								cardNumber: e.target.value
							}),
							className: "w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
							placeholder: "Ex: 1001",
							required: true,
							"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:50:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:60:11",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "name",
							className: "block text-xs font-semibold text-slate-700 mb-1",
							"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:61:13",
							children: "Nome Completo *"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							id: "name",
							type: "text",
							value: formData.name,
							onChange: (e) => setFormData({
								...formData,
								name: e.target.value
							}),
							className: "w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
							placeholder: "Nome do ticante",
							required: true,
							"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:64:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 gap-4",
					"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:76:9",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:77:11",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "phone",
							className: "block text-xs font-semibold text-slate-700 mb-1",
							"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:78:13",
							children: "Telefone *"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							id: "phone",
							type: "tel",
							value: formData.phone,
							onChange: (e) => setFormData({
								...formData,
								phone: e.target.value
							}),
							className: "w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
							placeholder: "+258 84 XXX XXXX",
							required: true,
							"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:81:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:91:11",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "dailyAmount",
							className: "block text-xs font-semibold text-slate-700 mb-1",
							"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:92:13",
							children: "Valor Diário (MZN) *"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							id: "dailyAmount",
							type: "number",
							value: formData.dailyAmount,
							onChange: (e) => setFormData({
								...formData,
								dailyAmount: e.target.value
							}),
							className: "w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
							placeholder: "Ex: 500",
							required: true,
							"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:95:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:107:9",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "contact",
						className: "block text-xs font-semibold text-slate-700 mb-1",
						"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:108:11",
						children: "Localização"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "contact",
						type: "text",
						value: formData.contact,
						onChange: (e) => setFormData({
							...formData,
							contact: e.target.value
						}),
						className: "w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
						placeholder: "Ex: Mercado Central, Maputo",
						"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:111:11"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 gap-4",
					"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:121:9",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:122:11",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "identityDocument",
							className: "block text-xs font-semibold text-slate-700 mb-1",
							"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:123:13",
							children: "Documento de Identidade"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							id: "identityDocument",
							type: "text",
							value: formData.identityDocument,
							onChange: (e) => setFormData({
								...formData,
								identityDocument: e.target.value
							}),
							className: "w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
							placeholder: "Número BI",
							"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:126:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 122,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:135:11",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "pin",
							className: "block text-xs font-semibold text-slate-700 mb-1",
							"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:136:13",
							children: "PIN (Opcional)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							id: "pin",
							type: "text",
							value: formData.pin,
							onChange: (e) => setFormData({
								...formData,
								pin: e.target.value
							}),
							className: "w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
							placeholder: "4-6 dígitos",
							maxLength: 6,
							"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:139:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 135,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:151:9",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "occupation",
						className: "block text-xs font-semibold text-slate-700 mb-1",
						"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:152:11",
						children: "Profissão"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "occupation",
						type: "text",
						value: formData.occupation,
						onChange: (e) => setFormData({
							...formData,
							occupation: e.target.value
						}),
						className: "w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
						placeholder: "Ex: Vendedor",
						"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:155:11"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 155,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 151,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(ModalFooter, {
					"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:165:9",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "secondary",
						onClick: onClose,
						"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:166:11",
						children: "Cancelar"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						type: "submit",
						"data-tsd-source": "/src/components/business/RegisterSaverModal.tsx:169:11",
						children: "Registar Ticante"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 169,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 165,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 5
	}, this);
}
_s(RegisterSaverModal, "7G54BRwkGBY4+FAOq3SvuTXrnyg=");
_c = RegisterSaverModal;
var _c;
$RefreshReg$(_c, "RegisterSaverModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/business/RegisterSaverModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/RegisterSaverModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/RegisterSaverModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/RegisterSaverModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBOzs7O0FBb0JBOztDQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0E7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtDQUNBO0NBRUEsT0FDQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7WUFDQTtHQUFBO0dBQUE7R0FBQTthQUFBO0lBQ0E7S0FBQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO2dCQUFBLENBQ0E7T0FBQTtPQUFBO09BQUE7aUJBQW1HO01BRW5HOzs7O2dCQUNBO09BQ0E7T0FDQTtPQUNBO09BQ0E7UUFBQTtRQUFBO09BQUE7T0FDQTtPQUNBO09BQ0E7T0FDQTtNQUFZOzs7O2NBQ1o7Ozs7O2VBQ0E7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtPQUFBO2lCQUE2RjtNQUU3Rjs7OztnQkFDQTtPQUNBO09BQ0E7T0FDQTtPQUNBO1FBQUE7UUFBQTtPQUFBO09BQ0E7T0FDQTtPQUNBO09BQ0E7TUFBWTs7OztjQUNaOzs7OzthQUNBOzs7Ozs7SUFFQTtLQUFBO0tBQUE7ZUFBQSxDQUNBO01BQUE7Z0JBQUEsQ0FDQTtPQUFBO09BQUE7T0FBQTtpQkFBOEY7TUFFOUY7Ozs7Z0JBQ0E7T0FDQTtPQUNBO09BQ0E7T0FDQTtRQUFBO1FBQUE7T0FBQTtPQUNBO09BQ0E7T0FDQTtPQUNBO01BQVk7Ozs7Y0FDWjs7Ozs7ZUFDQTtNQUFBO2dCQUFBLENBQ0E7T0FBQTtPQUFBO09BQUE7aUJBQW9HO01BRXBHOzs7O2dCQUNBO09BQ0E7T0FDQTtPQUNBO09BQ0E7UUFBQTtRQUFBO09BQUE7T0FDQTtPQUNBO09BQ0E7T0FDQTtNQUFZOzs7O2NBQ1o7Ozs7O2FBQ0E7Ozs7OztJQUVBO0tBQUE7ZUFBQSxDQUNBO01BQUE7TUFBQTtNQUFBO2dCQUE4RjtLQUU5Rjs7OztlQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7T0FBQTtPQUFBO01BQUE7TUFDQTtNQUNBO01BQ0E7S0FBVTs7OzthQUNWOzs7Ozs7SUFFQTtLQUFBO0tBQUE7ZUFBQSxDQUNBO01BQUE7Z0JBQUEsQ0FDQTtPQUFBO09BQUE7T0FBQTtpQkFBeUc7TUFFekc7Ozs7Z0JBQ0E7T0FDQTtPQUNBO09BQ0E7T0FDQTtRQUFBO1FBQUE7T0FBQTtPQUNBO09BQ0E7T0FDQTtNQUFZOzs7O2NBQ1o7Ozs7O2VBQ0E7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtPQUFBO2lCQUE0RjtNQUU1Rjs7OztnQkFDQTtPQUNBO09BQ0E7T0FDQTtPQUNBO1FBQUE7UUFBQTtPQUFBO09BQ0E7T0FDQTtPQUNBO09BQ0E7TUFBWTs7OztjQUNaOzs7OzthQUNBOzs7Ozs7SUFFQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO01BQUE7TUFBQTtnQkFBaUc7S0FFakc7Ozs7ZUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO09BQUE7T0FBQTtNQUFBO01BQ0E7TUFDQTtNQUNBO0tBQVU7Ozs7YUFDVjs7Ozs7O0lBRUE7S0FBQTtlQUFBLENBQ0E7TUFBQTtNQUFBO01BQUE7Z0JBQXVEO0tBRXZEOzs7O2VBQ0E7TUFBQTtNQUFBO2dCQUErQjtLQUUvQjs7OzthQUNBOzs7Ozs7R0FDQTs7Ozs7O0NBQ0E7Ozs7O0FBRUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlZ2lzdGVyU2F2ZXJNb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBNb2RhbCwgTW9kYWxGb290ZXIgfSBmcm9tICcjL2NvbXBvbmVudHMvdWkvTW9kYWwnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnIy9jb21wb25lbnRzL3VpL0J1dHRvbic7XG5cbmludGVyZmFjZSBSZWdpc3RlclNhdmVyTW9kYWxQcm9wcyB7XG4gIGlzT3BlbjogYm9vbGVhbjtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgb25TdWJtaXQ6IChkYXRhOiBSZWdpc3RlclNhdmVyRGF0YSkgPT4gdm9pZDtcbn1cblxuaW50ZXJmYWNlIFJlZ2lzdGVyU2F2ZXJEYXRhIHtcbiAgY2FyZE51bWJlcjogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG4gIHBob25lOiBzdHJpbmc7XG4gIGRhaWx5QW1vdW50OiBzdHJpbmc7XG4gIG9yZ2FuaXphdGlvbklkOiBzdHJpbmc7XG4gIGNvbnRhY3Q/OiBzdHJpbmc7XG4gIGlkZW50aXR5RG9jdW1lbnQ/OiBzdHJpbmc7XG4gIHBpbj86IHN0cmluZztcbiAgb2NjdXBhdGlvbj86IHN0cmluZztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFJlZ2lzdGVyU2F2ZXJNb2RhbCh7IGlzT3Blbiwgb25DbG9zZSwgb25TdWJtaXQgfTogUmVnaXN0ZXJTYXZlck1vZGFsUHJvcHMpIHtcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZTxSZWdpc3RlclNhdmVyRGF0YT4oe1xuICAgIGNhcmROdW1iZXI6ICcnLFxuICAgIG5hbWU6ICcnLFxuICAgIHBob25lOiAnJyxcbiAgICBkYWlseUFtb3VudDogJycsXG4gICAgb3JnYW5pemF0aW9uSWQ6ICcnLFxuICAgIGNvbnRhY3Q6ICcnLFxuICAgIGlkZW50aXR5RG9jdW1lbnQ6ICcnLFxuICAgIHBpbjogJycsXG4gICAgb2NjdXBhdGlvbjogJycsXG4gIH0pO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgb25TdWJtaXQoZm9ybURhdGEpO1xuICAgIG9uQ2xvc2UoKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxNb2RhbCBpc09wZW49e2lzT3Blbn0gb25DbG9zZT17b25DbG9zZX0gdGl0bGU9XCJSZWdpc3RhciBOb3ZvIFRpY2FudGVcIiBzaXplPVwibGdcIj5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJjYXJkTnVtYmVyXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgTsO6bWVybyBkZSBDYXJ0w6NvICpcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgaWQ9XCJjYXJkTnVtYmVyXCJcbiAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jYXJkTnVtYmVyfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIGNhcmROdW1iZXI6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAvMjAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFeDogMTAwMVwiXG4gICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm5hbWVcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICBOb21lIENvbXBsZXRvICpcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubmFtZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBuYW1lOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXNtIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tZSBkbyB0aWNhbnRlXCJcbiAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNFwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBob25lXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgVGVsZWZvbmUgKlxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICBpZD1cInBob25lXCJcbiAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5waG9uZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBwaG9uZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC1zbSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIisyNTggODQgWFhYIFhYWFhcIlxuICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkYWlseUFtb3VudFwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgICAgICAgIFZhbG9yIERpw6FyaW8gKE1aTikgKlxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICBpZD1cImRhaWx5QW1vdW50XCJcbiAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5kYWlseUFtb3VudH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBkYWlseUFtb3VudDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC1zbSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiA1MDBcIlxuICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImNvbnRhY3RcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgTG9jYWxpemHDp8Ojb1xuICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICBpZD1cImNvbnRhY3RcIlxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvbnRhY3R9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIGNvbnRhY3Q6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXNtIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBNZXJjYWRvIENlbnRyYWwsIE1hcHV0b1wiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiaWRlbnRpdHlEb2N1bWVudFwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgICAgICAgIERvY3VtZW50byBkZSBJZGVudGlkYWRlXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIGlkPVwiaWRlbnRpdHlEb2N1bWVudFwiXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmlkZW50aXR5RG9jdW1lbnR9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgaWRlbnRpdHlEb2N1bWVudDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC1zbSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk7Dum1lcm8gQklcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwaW5cIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICBQSU4gKE9wY2lvbmFsKVxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICBpZD1cInBpblwiXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBpbn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBwaW46IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAvMjAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCI0LTYgZMOtZ2l0b3NcIlxuICAgICAgICAgICAgICBtYXhMZW5ndGg9ezZ9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwib2NjdXBhdGlvblwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgICAgICBQcm9maXNzw6NvXG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGlkPVwib2NjdXBhdGlvblwiXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEub2NjdXBhdGlvbn1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgb2NjdXBhdGlvbjogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAvMjAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwXCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXg6IFZlbmRlZG9yXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8TW9kYWxGb290ZXI+XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17b25DbG9zZX0+XG4gICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiPlxuICAgICAgICAgICAgUmVnaXN0YXIgVGljYW50ZVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L01vZGFsRm9vdGVyPlxuICAgICAgPC9mb3JtPlxuICAgIDwvTW9kYWw+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3plbHRvL09uZURyaXZlL0RvY3VtZW50b3MvR2l0SHViL1hpdGlxdWVBcHBVSS9zcmMvY29tcG9uZW50cy9idXNpbmVzcy9SZWdpc3RlclNhdmVyTW9kYWwudHN4In0=