import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/dashboard/route.tsx");const $$splitComponentImporter = () => import("/src/routes/dashboard/route.tsx?tsr-split=component");
import { lazyRouteComponent } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=03f72e91";
// /routes/dashboard/route.tsx
import { createFileRoute } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=03f72e91";
const TSRSplitComponent = (() => {
	const hot = import.meta.hot;
	const hotData = hot ? hot.data ??= {} : undefined;
	return hotData?.["tsr-split-component:component"] ?? lazyRouteComponent($$splitComponentImporter, "component");
})();
if (import.meta.hot) {
	(import.meta.hot.data ??= {})["tsr-split-component:component"] = TSRSplitComponent;
}
export const Route = createFileRoute("/dashboard")({ component: TSRSplitComponent });
const hot = import.meta.hot;
if (hot && typeof window !== "undefined") {
	hot.data ??= {};
	const tsrReactRefresh = window.__TSR_REACT_REFRESH__ ??= (() => {
		const ignoredExportsById = new Map();
		const previousGetIgnoredExports = window.__getReactRefreshIgnoredExports;
		window.__getReactRefreshIgnoredExports = (ctx) => {
			const ignoredExports = previousGetIgnoredExports?.(ctx) ?? [];
			const moduleIgnored = ignoredExportsById.get(ctx.id) ?? [];
			return [...ignoredExports, ...moduleIgnored];
		};
		return { ignoredExportsById };
	})();
	tsrReactRefresh.ignoredExportsById.set("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/route.tsx", ["Route"]);
}
export function TSRFastRefreshAnchor() {
	return null;
}
_c = TSRFastRefreshAnchor;
if (import.meta.hot) {
	const hot = import.meta.hot;
	const hotData = hot.data ??= {};
	const handleRouteUpdate = function handleRouteUpdate(routeId, newRoute) {
		const router = window.__TSR_ROUTER__;
		const oldRoute = router.routesById[routeId];
		if (!oldRoute) return;
		const generatedRouteOptionKeys = new Set([
			"id",
			"path",
			"getParentRoute"
		]);
		const generatedRouteOptions = {};
		generatedRouteOptionKeys.forEach((key) => {
			if (key in oldRoute.options) generatedRouteOptions[key] = oldRoute.options[key];
		});
		const preserveComponentIdentity = "shellComponent" in oldRoute.options === "shellComponent" in newRoute.options;
		const componentKeys = [
			"component",
			"shellComponent",
			"pendingComponent",
			"errorComponent",
			"notFoundComponent"
		];
		if (preserveComponentIdentity) componentKeys.forEach((key) => {
			if (key in oldRoute.options && key in newRoute.options) newRoute.options[key] = oldRoute.options[key];
		});
		const nextOptions = {
			...newRoute.options,
			...generatedRouteOptions
		};
		oldRoute.options = nextOptions;
		oldRoute.update(nextOptions);
		router._replaceRouteChunk(oldRoute, newRoute.lazyFn);
		router.setRoutes(router.buildRouteTree());
		syncHotRouteExport(oldRoute);
		router.resolvePathCache.clear();
		router._refreshRoute?.();
		function syncHotRouteExport(liveRoute) {
			newRoute.options = liveRoute.options;
			newRoute.parentRoute = liveRoute.parentRoute;
			newRoute._path = liveRoute._path;
			newRoute._id = liveRoute._id;
			newRoute._fullPath = liveRoute._fullPath;
			newRoute._to = liveRoute._to;
		}
	};
	const initialRouteId = "/dashboard" ?? hotData["tsr-route-id"];
	if (initialRouteId) {
		hotData["tsr-route-id"] = initialRouteId;
	}
	const existingRoute = typeof window !== "undefined" && initialRouteId ? window.__TSR_ROUTER__?.routesById?.[initialRouteId] : undefined;
	if (initialRouteId && existingRoute && existingRoute !== Route) {
		handleRouteUpdate(initialRouteId, Route);
		hotData["tsr-route-update-handled"] = Route;
	}
	hot.accept((newModule) => {
		if (Route && newModule && newModule.Route) {
			const routeId = hotData["tsr-route-id"] ?? "/dashboard";
			if (routeId) {
				hotData["tsr-route-id"] = routeId;
			}
			if (hotData["tsr-route-update-handled"] === newModule.Route) {
				delete hotData["tsr-route-update-handled"];
				return;
			}
			handleRouteUpdate(routeId, newModule.Route);
		}
	});
}
var _c;
$RefreshReg$(_c, "TSRFastRefreshAnchor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/dashboard/route.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/route.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/route.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/dashboard/route.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7O0FBQ0EsU0FBU0EsdUJBQW9DO0FBQXlCLE1BQUFDLDJCQUFBO0NBQUEsTUFBQUMsTUFBQUMsWUFBQUQ7Q0FBQSxNQUFBRSxVQUFBRixVQUFBRyxTQUFBLEtBQUFDO0NBQUEsT0FBQUYsVUFBQSxvQ0FBQUcsbUJBQUFDLDBCQUFBO0FBQUE7QUFBQSxJQUFBTCxZQUFBRCxLQUFBO0NBQUEsQ0FBQUMsWUFBQUQsSUFBQUcsU0FBQSx1Q0FBQUo7QUFBQTtBQUd0RSxPQUFPLE1BQU1RLFFBQVFULGdCQUFnQixZQUFZLENBQUMsQ0FBQyxFQUMvQ1UsV0FBU1Qsa0JBQ2IsQ0FBQztBQUFFLE1BQUFDLE1BQUFDLFlBQUFEO0FBQUEsSUFBQUEsT0FBQSxPQUFBUyxXQUFBO0NBQUFULElBQUFHLFNBQUE7Q0FBQSxNQUFBTyxrQkFBQUQsT0FBQUUsaUNBQUE7RUFBQSxNQUFBQyxxQkFBQSxJQUFBQyxJQUFBO0VBQUEsTUFBQUMsNEJBQUFMLE9BQUFNO0VBQUFOLE9BQUFNLG1DQUFBQyxRQUFBO0dBQUEsTUFBQUMsaUJBQUFILDRCQUFBRSxHQUFBO0dBQUEsTUFBQUUsZ0JBQUFOLG1CQUFBTyxJQUFBSCxJQUFBSSxFQUFBO0dBQUEsV0FBQUgsZ0JBQUEsR0FBQUMsYUFBQTtFQUFBO0VBQUEsU0FBQU4sbUJBQUE7Q0FBQTtDQUFBRixnQkFBQUUsbUJBQUFTLElBQUE7QUFBQTtBQUFBLGdCQUFBQyx1QkFBQTtDQUFBO0FBQUE7O0FBQUEsSUFBQXJCLFlBQUFELEtBQUE7Q0FBQSxNQUFBQSxNQUFBQyxZQUFBRDtDQUFBLE1BQUFFLFVBQUFGLElBQUFHLFNBQUE7Q0FBQSxNQUFBb0Isb0JBQUEsU0FBQUEsa0JBQUFDLFNBQUFDLFVBQUE7RUFBQSxNQUFBQyxTQUFBakIsT0FBQWtCO0VBQUEsTUFBQUMsV0FBQUYsT0FBQUcsV0FBQUw7RUFBQSxLQUFBSSxVQUFBO0VBQUEsTUFBQUUsMkJBQUEsSUFBQUMsSUFBQTtHQUFBO0dBQUE7R0FBQTtFQUFBO0VBQUEsTUFBQUMsd0JBQUE7RUFBQUYseUJBQUFHLFNBQUFDLFFBQUE7R0FBQSxJQUFBQSxPQUFBTixTQUFBTyxTQUFBSCxzQkFBQUUsT0FBQU4sU0FBQU8sUUFBQUQ7RUFBQTtFQUFBLE1BQUFFLDRCQUFBLG9CQUFBUixTQUFBTyxZQUFBLG9CQUFBVixTQUFBVTtFQUFBLE1BQUFFLGdCQUFBO0dBQUE7R0FBQTtHQUFBO0dBQUE7R0FBQTtFQUFBO0VBQUEsSUFBQUQsMkJBQUFDLGNBQUFKLFNBQUFDLFFBQUE7R0FBQSxJQUFBQSxPQUFBTixTQUFBTyxXQUFBRCxPQUFBVCxTQUFBVSxTQUFBVixTQUFBVSxRQUFBRCxPQUFBTixTQUFBTyxRQUFBRDtFQUFBO0VBQUEsTUFBQUksY0FBQTtHQUFBLEdBQUFiLFNBQUFVO0dBQUEsR0FBQUg7RUFBQTtFQUFBSixTQUFBTyxVQUFBRztFQUFBVixTQUFBVyxPQUFBRCxXQUFBO0VBQUFaLE9BQUFjLG1CQUFBWixVQUFBSCxTQUFBZ0IsTUFBQTtFQUFBZixPQUFBZ0IsVUFBQWhCLE9BQUFpQixlQUFBO0VBQUFDLG1CQUFBaEIsUUFBQTtFQUFBRixPQUFBbUIsaUJBQUFDLE1BQUE7RUFBQXBCLE9BQUFxQixnQkFBQTtFQUFBLFNBQUFILG1CQUFBSSxXQUFBO0dBQUF2QixTQUFBVSxVQUFBYSxVQUFBYjtHQUFBVixTQUFBd0IsY0FBQUQsVUFBQUM7R0FBQXhCLFNBQUF5QixRQUFBRixVQUFBRTtHQUFBekIsU0FBQTBCLE1BQUFILFVBQUFHO0dBQUExQixTQUFBMkIsWUFBQUosVUFBQUk7R0FBQTNCLFNBQUE0QixNQUFBTCxVQUFBSztFQUFBO0NBQUE7Q0FBQSxNQUFBQyxpQkFBQSxnQkFBQXBELFFBQUE7Q0FBQSxJQUFBb0QsZ0JBQUE7RUFBQXBELFFBQUEsa0JBQUFvRDtDQUFBO0NBQUEsTUFBQUMsZ0JBQUEsT0FBQTlDLFdBQUEsZUFBQTZDLGlCQUFBN0MsT0FBQWtCLGdCQUFBRSxhQUFBeUIsa0JBQUFsRDtDQUFBLElBQUFrRCxrQkFBQUMsbUNBQUFoRCxPQUFBO0VBQUFnQixrQkFBQStCLGdCQUFBL0MsS0FBQTtFQUFBTCxRQUFBLDhCQUFBSztDQUFBO0NBQUFQLElBQUF3RCxRQUFBQyxjQUFBO0VBQUEsSUFBQWxELFNBQUFrRCx1QkFBQWxELE9BQUE7R0FBQSxNQUFBaUIsVUFBQXRCLFFBQUE7R0FBQSxJQUFBc0IsU0FBQTtJQUFBdEIsUUFBQSxrQkFBQXNCO0dBQUE7R0FBQSxJQUFBdEIsUUFBQSxnQ0FBQXVELFVBQUFsRCxPQUFBO0lBQUEsT0FBQUwsUUFBQTtJQUFBO0dBQUE7R0FBQXFCLGtCQUFBQyxTQUFBaUMsVUFBQWxELEtBQUE7RUFBQTtDQUFBO0FBQUEiLCJuYW1lcyI6WyJjcmVhdGVGaWxlUm91dGUiLCJUU1JTcGxpdENvbXBvbmVudCIsImhvdCIsImltcG9ydCIsImhvdERhdGEiLCJkYXRhIiwidW5kZWZpbmVkIiwibGF6eVJvdXRlQ29tcG9uZW50IiwiJCRzcGxpdENvbXBvbmVudEltcG9ydGVyIiwiUm91dGUiLCJjb21wb25lbnQiLCJ3aW5kb3ciLCJ0c3JSZWFjdFJlZnJlc2giLCJfX1RTUl9SRUFDVF9SRUZSRVNIX18iLCJpZ25vcmVkRXhwb3J0c0J5SWQiLCJNYXAiLCJwcmV2aW91c0dldElnbm9yZWRFeHBvcnRzIiwiX19nZXRSZWFjdFJlZnJlc2hJZ25vcmVkRXhwb3J0cyIsImN0eCIsImlnbm9yZWRFeHBvcnRzIiwibW9kdWxlSWdub3JlZCIsImdldCIsImlkIiwic2V0IiwiVFNSRmFzdFJlZnJlc2hBbmNob3IiLCJoYW5kbGVSb3V0ZVVwZGF0ZSIsInJvdXRlSWQiLCJuZXdSb3V0ZSIsInJvdXRlciIsIl9fVFNSX1JPVVRFUl9fIiwib2xkUm91dGUiLCJyb3V0ZXNCeUlkIiwiZ2VuZXJhdGVkUm91dGVPcHRpb25LZXlzIiwiU2V0IiwiZ2VuZXJhdGVkUm91dGVPcHRpb25zIiwiZm9yRWFjaCIsImtleSIsIm9wdGlvbnMiLCJwcmVzZXJ2ZUNvbXBvbmVudElkZW50aXR5IiwiY29tcG9uZW50S2V5cyIsIm5leHRPcHRpb25zIiwidXBkYXRlIiwiX3JlcGxhY2VSb3V0ZUNodW5rIiwibGF6eUZuIiwic2V0Um91dGVzIiwiYnVpbGRSb3V0ZVRyZWUiLCJzeW5jSG90Um91dGVFeHBvcnQiLCJyZXNvbHZlUGF0aENhY2hlIiwiY2xlYXIiLCJfcmVmcmVzaFJvdXRlIiwibGl2ZVJvdXRlIiwicGFyZW50Um91dGUiLCJfcGF0aCIsIl9pZCIsIl9mdWxsUGF0aCIsIl90byIsImluaXRpYWxSb3V0ZUlkIiwiZXhpc3RpbmdSb3V0ZSIsImFjY2VwdCIsIm5ld01vZHVsZSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJyb3V0ZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gL3JvdXRlcy9kYXNoYm9hcmQvcm91dGUudHN4XHJcbmltcG9ydCB7IGNyZWF0ZUZpbGVSb3V0ZSwgdXNlTmF2aWdhdGUgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJztcclxuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5cclxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKCcvZGFzaGJvYXJkJykoe1xyXG4gICAgY29tcG9uZW50OiBEYXNoYm9hcmRSZWRpcmVjdCxcclxufSk7XHJcblxyXG5mdW5jdGlvbiBEYXNoYm9hcmRSZWRpcmVjdCgpIHtcclxuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIG5hdmlnYXRlKHsgdG86ICcvZGFzaGJvYXJkL292ZXJ2aWV3JyB9KTtcclxuICAgIH0sIFtuYXZpZ2F0ZV0pO1xyXG5cclxuICAgIHJldHVybiBudWxsO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvemVsdG8vT25lRHJpdmUvRG9jdW1lbnRvcy9HaXRIdWIvWGl0aXF1ZUFwcFVJL3NyYy9yb3V0ZXMvZGFzaGJvYXJkL3JvdXRlLnRzeCJ9