import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/client/_auth.tsx");const $$splitNotFoundComponentImporter = () => import("/src/routes/client/_auth.tsx?tsr-split=notFoundComponent");
const $$splitComponentImporter = () => import("/src/routes/client/_auth.tsx?tsr-split=component");
import { lazyRouteComponent } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=03f72e91";
import { createFileRoute } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=03f72e91";
const TSRSplitComponent = (() => {
	const hot = import.meta.hot;
	const hotData = hot ? hot.data ??= {} : undefined;
	return hotData?.["tsr-split-component:component"] ?? lazyRouteComponent($$splitComponentImporter, "component");
})();
if (import.meta.hot) {
	(import.meta.hot.data ??= {})["tsr-split-component:component"] = TSRSplitComponent;
}
const TSRSplitNotFoundComponent = (() => {
	const hot = import.meta.hot;
	const hotData = hot ? hot.data ??= {} : undefined;
	return hotData?.["tsr-split-component:notFoundComponent"] ?? lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent");
})();
if (import.meta.hot) {
	(import.meta.hot.data ??= {})["tsr-split-component:notFoundComponent"] = TSRSplitNotFoundComponent;
}
export const Route = createFileRoute("/client/_auth")({
	component: TSRSplitComponent,
	notFoundComponent: TSRSplitNotFoundComponent
});
const hot = import.meta.hot;
if (hot && typeof window !== "undefined") {
	hot.data ??= {};
	const tsrReactRefresh = window.__TSR_REACT_REFRESH__ ??= (() => {
		const ignoredExportsById = new Map();
		const previousGetIgnoredExports = window.__getReactRefreshIgnoredExports;
		window.__getReactRefreshIgnoredExports = (ctx) => {
			const ignoredExports = previousGetIgnoredExports?.(ctx) ?? [];
			const moduleIgnored = ignoredExportsById.get(ctx.id) ?? [];
			return [...ignoredExports, ...moduleIgnored];
		};
		return { ignoredExportsById };
	})();
	tsrReactRefresh.ignoredExportsById.set("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/client/_auth.tsx", ["Route"]);
}
export function TSRFastRefreshAnchor() {
	return null;
}
_c = TSRFastRefreshAnchor;
if (import.meta.hot) {
	const hot = import.meta.hot;
	const hotData = hot.data ??= {};
	const handleRouteUpdate = function handleRouteUpdate(routeId, newRoute) {
		const router = window.__TSR_ROUTER__;
		const oldRoute = router.routesById[routeId];
		if (!oldRoute) return;
		const generatedRouteOptionKeys = new Set([
			"id",
			"path",
			"getParentRoute"
		]);
		const generatedRouteOptions = {};
		generatedRouteOptionKeys.forEach((key) => {
			if (key in oldRoute.options) generatedRouteOptions[key] = oldRoute.options[key];
		});
		const preserveComponentIdentity = "shellComponent" in oldRoute.options === "shellComponent" in newRoute.options;
		const componentKeys = [
			"component",
			"shellComponent",
			"pendingComponent",
			"errorComponent",
			"notFoundComponent"
		];
		if (preserveComponentIdentity) componentKeys.forEach((key) => {
			if (key in oldRoute.options && key in newRoute.options) newRoute.options[key] = oldRoute.options[key];
		});
		const nextOptions = {
			...newRoute.options,
			...generatedRouteOptions
		};
		oldRoute.options = nextOptions;
		oldRoute.update(nextOptions);
		router._replaceRouteChunk(oldRoute, newRoute.lazyFn);
		router.setRoutes(router.buildRouteTree());
		syncHotRouteExport(oldRoute);
		router.resolvePathCache.clear();
		router._refreshRoute?.();
		function syncHotRouteExport(liveRoute) {
			newRoute.options = liveRoute.options;
			newRoute.parentRoute = liveRoute.parentRoute;
			newRoute._path = liveRoute._path;
			newRoute._id = liveRoute._id;
			newRoute._fullPath = liveRoute._fullPath;
			newRoute._to = liveRoute._to;
		}
	};
	const initialRouteId = "/client/_auth" ?? hotData["tsr-route-id"];
	if (initialRouteId) {
		hotData["tsr-route-id"] = initialRouteId;
	}
	const existingRoute = typeof window !== "undefined" && initialRouteId ? window.__TSR_ROUTER__?.routesById?.[initialRouteId] : undefined;
	if (initialRouteId && existingRoute && existingRoute !== Route) {
		handleRouteUpdate(initialRouteId, Route);
		hotData["tsr-route-update-handled"] = Route;
	}
	hot.accept((newModule) => {
		if (Route && newModule && newModule.Route) {
			const routeId = hotData["tsr-route-id"] ?? "/client/_auth";
			if (routeId) {
				hotData["tsr-route-id"] = routeId;
			}
			if (hotData["tsr-route-update-handled"] === newModule.Route) {
				delete hotData["tsr-route-update-handled"];
				return;
			}
			handleRouteUpdate(routeId, newModule.Route);
		}
	});
}
var _c;
$RefreshReg$(_c, "TSRFastRefreshAnchor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/client/_auth.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/client/_auth.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/client/_auth.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/client/_auth.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7O0FBQUEsU0FBU0EsdUJBQXVCO0FBQXlCLE1BQUFDLDJCQUFBO0NBQUEsTUFBQUMsTUFBQUMsWUFBQUQ7Q0FBQSxNQUFBRSxVQUFBRixVQUFBRyxTQUFBLEtBQUFDO0NBQUEsT0FBQUYsVUFBQSxvQ0FBQUcsbUJBQUFDLDBCQUFBO0FBQUE7QUFBQSxJQUFBTCxZQUFBRCxLQUFBO0NBQUEsQ0FBQUMsWUFBQUQsSUFBQUcsU0FBQSx1Q0FBQUo7QUFBQTtBQUFBLE1BQUFRLG1DQUFBO0NBQUEsTUFBQVAsTUFBQUMsWUFBQUQ7Q0FBQSxNQUFBRSxVQUFBRixVQUFBRyxTQUFBLEtBQUFDO0NBQUEsT0FBQUYsVUFBQSw0Q0FBQUcsbUJBQUFHLGtDQUFBO0FBQUE7QUFBQSxJQUFBUCxZQUFBRCxLQUFBO0NBQUEsQ0FBQUMsWUFBQUQsSUFBQUcsU0FBQSwrQ0FBQUk7QUFBQTtBQUt6RCxPQUFPLE1BQU1FLFFBQVFYLGdCQUFnQixlQUFlLENBQUMsQ0FBQztDQUNyRFksV0FBU1g7Q0FDVFksbUJBQWlCSjtBQUNsQixDQUFDO0FBQUUsTUFBQVAsTUFBQUMsWUFBQUQ7QUFBQSxJQUFBQSxPQUFBLE9BQUFZLFdBQUE7Q0FBQVosSUFBQUcsU0FBQTtDQUFBLE1BQUFVLGtCQUFBRCxPQUFBRSxpQ0FBQTtFQUFBLE1BQUFDLHFCQUFBLElBQUFDLElBQUE7RUFBQSxNQUFBQyw0QkFBQUwsT0FBQU07RUFBQU4sT0FBQU0sbUNBQUFDLFFBQUE7R0FBQSxNQUFBQyxpQkFBQUgsNEJBQUFFLEdBQUE7R0FBQSxNQUFBRSxnQkFBQU4sbUJBQUFPLElBQUFILElBQUFJLEVBQUE7R0FBQSxXQUFBSCxnQkFBQSxHQUFBQyxhQUFBO0VBQUE7RUFBQSxTQUFBTixtQkFBQTtDQUFBO0NBQUFGLGdCQUFBRSxtQkFBQVMsSUFBQTtBQUFBO0FBQUEsZ0JBQUFDLHVCQUFBO0NBQUE7QUFBQTs7QUFBQSxJQUFBeEIsWUFBQUQsS0FBQTtDQUFBLE1BQUFBLE1BQUFDLFlBQUFEO0NBQUEsTUFBQUUsVUFBQUYsSUFBQUcsU0FBQTtDQUFBLE1BQUF1QixvQkFBQSxTQUFBQSxrQkFBQUMsU0FBQUMsVUFBQTtFQUFBLE1BQUFDLFNBQUFqQixPQUFBa0I7RUFBQSxNQUFBQyxXQUFBRixPQUFBRyxXQUFBTDtFQUFBLEtBQUFJLFVBQUE7RUFBQSxNQUFBRSwyQkFBQSxJQUFBQyxJQUFBO0dBQUE7R0FBQTtHQUFBO0VBQUE7RUFBQSxNQUFBQyx3QkFBQTtFQUFBRix5QkFBQUcsU0FBQUMsUUFBQTtHQUFBLElBQUFBLE9BQUFOLFNBQUFPLFNBQUFILHNCQUFBRSxPQUFBTixTQUFBTyxRQUFBRDtFQUFBO0VBQUEsTUFBQUUsNEJBQUEsb0JBQUFSLFNBQUFPLFlBQUEsb0JBQUFWLFNBQUFVO0VBQUEsTUFBQUUsZ0JBQUE7R0FBQTtHQUFBO0dBQUE7R0FBQTtHQUFBO0VBQUE7RUFBQSxJQUFBRCwyQkFBQUMsY0FBQUosU0FBQUMsUUFBQTtHQUFBLElBQUFBLE9BQUFOLFNBQUFPLFdBQUFELE9BQUFULFNBQUFVLFNBQUFWLFNBQUFVLFFBQUFELE9BQUFOLFNBQUFPLFFBQUFEO0VBQUE7RUFBQSxNQUFBSSxjQUFBO0dBQUEsR0FBQWIsU0FBQVU7R0FBQSxHQUFBSDtFQUFBO0VBQUFKLFNBQUFPLFVBQUFHO0VBQUFWLFNBQUFXLE9BQUFELFdBQUE7RUFBQVosT0FBQWMsbUJBQUFaLFVBQUFILFNBQUFnQixNQUFBO0VBQUFmLE9BQUFnQixVQUFBaEIsT0FBQWlCLGVBQUE7RUFBQUMsbUJBQUFoQixRQUFBO0VBQUFGLE9BQUFtQixpQkFBQUMsTUFBQTtFQUFBcEIsT0FBQXFCLGdCQUFBO0VBQUEsU0FBQUgsbUJBQUFJLFdBQUE7R0FBQXZCLFNBQUFVLFVBQUFhLFVBQUFiO0dBQUFWLFNBQUF3QixjQUFBRCxVQUFBQztHQUFBeEIsU0FBQXlCLFFBQUFGLFVBQUFFO0dBQUF6QixTQUFBMEIsTUFBQUgsVUFBQUc7R0FBQTFCLFNBQUEyQixZQUFBSixVQUFBSTtHQUFBM0IsU0FBQTRCLE1BQUFMLFVBQUFLO0VBQUE7Q0FBQTtDQUFBLE1BQUFDLGlCQUFBLG1CQUFBdkQsUUFBQTtDQUFBLElBQUF1RCxnQkFBQTtFQUFBdkQsUUFBQSxrQkFBQXVEO0NBQUE7Q0FBQSxNQUFBQyxnQkFBQSxPQUFBOUMsV0FBQSxlQUFBNkMsaUJBQUE3QyxPQUFBa0IsZ0JBQUFFLGFBQUF5QixrQkFBQXJEO0NBQUEsSUFBQXFELGtCQUFBQyxtQ0FBQWpELE9BQUE7RUFBQWlCLGtCQUFBK0IsZ0JBQUFoRCxLQUFBO0VBQUFQLFFBQUEsOEJBQUFPO0NBQUE7Q0FBQVQsSUFBQTJELFFBQUFDLGNBQUE7RUFBQSxJQUFBbkQsU0FBQW1ELHVCQUFBbkQsT0FBQTtHQUFBLE1BQUFrQixVQUFBekIsUUFBQTtHQUFBLElBQUF5QixTQUFBO0lBQUF6QixRQUFBLGtCQUFBeUI7R0FBQTtHQUFBLElBQUF6QixRQUFBLGdDQUFBMEQsVUFBQW5ELE9BQUE7SUFBQSxPQUFBUCxRQUFBO0lBQUE7R0FBQTtHQUFBd0Isa0JBQUFDLFNBQUFpQyxVQUFBbkQsS0FBQTtFQUFBO0NBQUE7QUFBQSIsIm5hbWVzIjpbImNyZWF0ZUZpbGVSb3V0ZSIsIlRTUlNwbGl0Q29tcG9uZW50IiwiaG90IiwiaW1wb3J0IiwiaG90RGF0YSIsImRhdGEiLCJ1bmRlZmluZWQiLCJsYXp5Um91dGVDb21wb25lbnQiLCIkJHNwbGl0Q29tcG9uZW50SW1wb3J0ZXIiLCJUU1JTcGxpdE5vdEZvdW5kQ29tcG9uZW50IiwiJCRzcGxpdE5vdEZvdW5kQ29tcG9uZW50SW1wb3J0ZXIiLCJSb3V0ZSIsImNvbXBvbmVudCIsIm5vdEZvdW5kQ29tcG9uZW50Iiwid2luZG93IiwidHNyUmVhY3RSZWZyZXNoIiwiX19UU1JfUkVBQ1RfUkVGUkVTSF9fIiwiaWdub3JlZEV4cG9ydHNCeUlkIiwiTWFwIiwicHJldmlvdXNHZXRJZ25vcmVkRXhwb3J0cyIsIl9fZ2V0UmVhY3RSZWZyZXNoSWdub3JlZEV4cG9ydHMiLCJjdHgiLCJpZ25vcmVkRXhwb3J0cyIsIm1vZHVsZUlnbm9yZWQiLCJnZXQiLCJpZCIsInNldCIsIlRTUkZhc3RSZWZyZXNoQW5jaG9yIiwiaGFuZGxlUm91dGVVcGRhdGUiLCJyb3V0ZUlkIiwibmV3Um91dGUiLCJyb3V0ZXIiLCJfX1RTUl9ST1VURVJfXyIsIm9sZFJvdXRlIiwicm91dGVzQnlJZCIsImdlbmVyYXRlZFJvdXRlT3B0aW9uS2V5cyIsIlNldCIsImdlbmVyYXRlZFJvdXRlT3B0aW9ucyIsImZvckVhY2giLCJrZXkiLCJvcHRpb25zIiwicHJlc2VydmVDb21wb25lbnRJZGVudGl0eSIsImNvbXBvbmVudEtleXMiLCJuZXh0T3B0aW9ucyIsInVwZGF0ZSIsIl9yZXBsYWNlUm91dGVDaHVuayIsImxhenlGbiIsInNldFJvdXRlcyIsImJ1aWxkUm91dGVUcmVlIiwic3luY0hvdFJvdXRlRXhwb3J0IiwicmVzb2x2ZVBhdGhDYWNoZSIsImNsZWFyIiwiX3JlZnJlc2hSb3V0ZSIsImxpdmVSb3V0ZSIsInBhcmVudFJvdXRlIiwiX3BhdGgiLCJfaWQiLCJfZnVsbFBhdGgiLCJfdG8iLCJpbml0aWFsUm91dGVJZCIsImV4aXN0aW5nUm91dGUiLCJhY2NlcHQiLCJuZXdNb2R1bGUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiX2F1dGgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUZpbGVSb3V0ZSB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtcm91dGVyXCI7XHJcbmltcG9ydCB7IENsaWVudFNpZGViYXIgfSBmcm9tIFwiIy9jb21wb25lbnRzL0NsaWVudFNpZGViYXJcIjtcclxuaW1wb3J0IE5vdEZvdW5kIGZyb20gXCIjL2NvbXBvbmVudHMvTm90Rm91bmRcIjtcclxuaW1wb3J0IHsgUm91dGVUcmFuc2l0aW9uTGF5b3V0IH0gZnJvbSBcIiMvY29tcG9uZW50cy9Sb3V0ZVRyYW5zaXRpb25MYXlvdXRcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBSb3V0ZSA9IGNyZWF0ZUZpbGVSb3V0ZShcIi9jbGllbnQvX2F1dGhcIikoe1xyXG5cdGNvbXBvbmVudDogQ2xpZW50QXV0aExheW91dCxcclxuXHRub3RGb3VuZENvbXBvbmVudDogKCkgPT4gPE5vdEZvdW5kIC8+LFxyXG59KTtcclxuXHJcbmZ1bmN0aW9uIENsaWVudEF1dGhMYXlvdXQoKSB7XHJcblx0cmV0dXJuIDxSb3V0ZVRyYW5zaXRpb25MYXlvdXQgc2lkZWJhcj17Q2xpZW50U2lkZWJhcn0gLz47XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy96ZWx0by9PbmVEcml2ZS9Eb2N1bWVudG9zL0dpdEh1Yi9YaXRpcXVlQXBwVUkvc3JjL3JvdXRlcy9jbGllbnQvX2F1dGgudHN4In0=