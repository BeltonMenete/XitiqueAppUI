import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NotFound.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];import { useNavigate } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=03f72e91";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=03f72e91";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/NotFound.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
var _s = $RefreshSig$();
//
// 1. Definições de Ícones (SVG)
//
const IconShield = () => /* @__PURE__ */ _jsxDEV("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	width: "20",
	height: "20",
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: "2.25",
	strokeLinecap: "round",
	strokeLinejoin: "round",
	"aria-label": "Shield icon",
	role: "img",
	"data-tsd-source": "/src/components/NotFound.tsx:8:2",
	children: [/* @__PURE__ */ _jsxDEV("title", {
		"data-tsd-source": "/src/components/NotFound.tsx:21:3",
		children: "Shield icon"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 3
	}, this), /* @__PURE__ */ _jsxDEV("path", {
		d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10",
		"data-tsd-source": "/src/components/NotFound.tsx:22:3"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 3
	}, this)]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 8,
	columnNumber: 2
}, this);
_c = IconShield;
const IconHome = () => /* @__PURE__ */ _jsxDEV("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	width: "20",
	height: "20",
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: "2.25",
	strokeLinecap: "round",
	strokeLinejoin: "round",
	"aria-label": "Home icon",
	role: "img",
	"data-tsd-source": "/src/components/NotFound.tsx:27:2",
	children: [
		/* @__PURE__ */ _jsxDEV("title", {
			"data-tsd-source": "/src/components/NotFound.tsx:40:3",
			children: "Home icon"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 3
		}, this),
		/* @__PURE__ */ _jsxDEV("path", {
			d: "m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
			"data-tsd-source": "/src/components/NotFound.tsx:41:3"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 3
		}, this),
		/* @__PURE__ */ _jsxDEV("polyline", {
			points: "9 22 9 12 15 12 15 22",
			"data-tsd-source": "/src/components/NotFound.tsx:42:3"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 3
		}, this)
	]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 27,
	columnNumber: 2
}, this);
_c2 = IconHome;
const IconMessage = () => /* @__PURE__ */ _jsxDEV("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	width: "20",
	height: "20",
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: "2.25",
	strokeLinecap: "round",
	strokeLinejoin: "round",
	"aria-label": "Message icon",
	role: "img",
	"data-tsd-source": "/src/components/NotFound.tsx:47:2",
	children: [/* @__PURE__ */ _jsxDEV("title", {
		"data-tsd-source": "/src/components/NotFound.tsx:60:3",
		children: "Message icon"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 3
	}, this), /* @__PURE__ */ _jsxDEV("path", {
		d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",
		"data-tsd-source": "/src/components/NotFound.tsx:61:3"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 61,
		columnNumber: 3
	}, this)]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 47,
	columnNumber: 2
}, this);
_c3 = IconMessage;
const IconCompass = () => /* @__PURE__ */ _jsxDEV("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	width: "20",
	height: "20",
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: "2.25",
	strokeLinecap: "round",
	strokeLinejoin: "round",
	"aria-label": "Compass icon",
	role: "img",
	"data-tsd-source": "/src/components/NotFound.tsx:66:2",
	children: [
		/* @__PURE__ */ _jsxDEV("title", {
			"data-tsd-source": "/src/components/NotFound.tsx:79:3",
			children: "Compass icon"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 3
		}, this),
		/* @__PURE__ */ _jsxDEV("circle", {
			cx: "12",
			cy: "12",
			r: "10",
			"data-tsd-source": "/src/components/NotFound.tsx:80:3"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 3
		}, this),
		/* @__PURE__ */ _jsxDEV("polygon", {
			points: "16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76",
			"data-tsd-source": "/src/components/NotFound.tsx:81:3"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 81,
			columnNumber: 3
		}, this)
	]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 66,
	columnNumber: 2
}, this);
_c4 = IconCompass;
//
// 2. Componente de Fundo Grid Decorativo
//
const DecorativeGrid = () => /* @__PURE__ */ _jsxDEV("div", {
	className: "absolute inset-0 pointer-events-none z-0",
	style: {
		backgroundImage: `
                linear-gradient(to right, rgba(64, 73, 68, 0.08) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(64, 73, 68, 0.08) 1px, transparent 1px)
            `,
		backgroundSize: "44px 44px",
		maskImage: "radial-gradient(ellipse 80% 60% at 50% 45%, black 30%, transparent 90%)",
		WebkitMaskImage: "radial-gradient(ellipse 80% 60% at 50% 45%, black 30%, transparent 90%)"
	},
	"data-tsd-source": "/src/components/NotFound.tsx:89:2"
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 89,
	columnNumber: 2
}, this);
_c5 = DecorativeGrid;
//
// 3. Componente de Círculos de Desfoque Decorativos
//
const DecorativeBlurs = () => /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
	/* @__PURE__ */ _jsxDEV("div", {
		className: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[320px] h-80 sm:w-120 sm:h-120 md:w-160 md:h-160 bg-[#80bea6]/20 rounded-full blur-[90px] sm:blur-[130px] animate-pulse pointer-events-none z-0",
		"data-tsd-source": "/src/components/NotFound.tsx:110:3"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 110,
		columnNumber: 3
	}, this),
	/* @__PURE__ */ _jsxDEV("div", {
		className: "absolute top-[-12%] right-[-8%] w-65 h-65 sm:w-105 sm:h-105 bg-[#80bea6]/14 rounded-full blur-[90px] pointer-events-none z-0",
		"data-tsd-source": "/src/components/NotFound.tsx:111:3"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 111,
		columnNumber: 3
	}, this),
	/* @__PURE__ */ _jsxDEV("div", {
		className: "absolute bottom-[-12%] left-[-8%] w-65 h-65 sm:w-105 sm:h-105 bg-[#80bea6]/14 rounded-full blur-[90px] pointer-events-none z-0",
		"data-tsd-source": "/src/components/NotFound.tsx:112:3"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 112,
		columnNumber: 3
	}, this)
] }, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 109,
	columnNumber: 2
}, this);
_c6 = DecorativeBlurs;
//
// 4. Componente de Cartões Flutuantes
// Reposicionados para as margens externas do ecrã, fora da coluna central de texto
// (max-w-2xl), e só visíveis a partir de "lg" para nunca colidir com o conteúdo.
//
const FloatingCards = () => /* @__PURE__ */ _jsxDEV("div", {
	className: "hidden lg:block pointer-events-none select-none absolute inset-0 z-10",
	"data-tsd-source": "/src/components/NotFound.tsx:122:2",
	children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "absolute top-[12%] left-[4%] xl:left-[8%] 2xl:left-[14%] bg-linear-to-br from-[#80bea6] to-[#5fa088] rounded-2xl p-3 xl:p-3.5 shadow-[0_8px_24px_-4px_rgba(95,160,136,0.55)] border border-white/40 animate-[float_2.2s_ease-in-out_infinite]",
			style: { "--rot": "10deg" },
			"data-tsd-source": "/src/components/NotFound.tsx:124:3",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "text-white drop-shadow-sm",
				"data-tsd-source": "/src/components/NotFound.tsx:128:4",
				children: /* @__PURE__ */ _jsxDEV(IconShield, { "data-tsd-source": "/src/components/NotFound.tsx:129:5" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 5
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 128,
				columnNumber: 4
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 124,
			columnNumber: 3
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "absolute top-[16%] right-[4%] xl:right-[8%] 2xl:right-[14%] bg-linear-to-br from-[#80bea6] to-[#5fa088] rounded-2xl p-3 xl:p-3.5 shadow-[0_8px_24px_-4px_rgba(95,160,136,0.55)] border border-white/40 animate-[float_2.6s_ease-in-out_infinite] [animation-delay:0.3s]",
			style: { "--rot": "-8deg" },
			"data-tsd-source": "/src/components/NotFound.tsx:134:3",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "text-white drop-shadow-sm",
				"data-tsd-source": "/src/components/NotFound.tsx:138:4",
				children: /* @__PURE__ */ _jsxDEV(IconHome, { "data-tsd-source": "/src/components/NotFound.tsx:139:5" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 139,
					columnNumber: 5
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 138,
				columnNumber: 4
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 134,
			columnNumber: 3
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "absolute bottom-[14%] left-[5%] xl:left-[10%] 2xl:left-[16%] bg-linear-to-br from-[#80bea6] to-[#5fa088] rounded-2xl p-3 xl:p-3.5 shadow-[0_8px_24px_-4px_rgba(95,160,136,0.55)] border border-white/40 animate-[float_2.4s_ease-in-out_infinite] [animation-delay:0.6s]",
			style: { "--rot": "7deg" },
			"data-tsd-source": "/src/components/NotFound.tsx:144:3",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "text-white drop-shadow-sm",
				"data-tsd-source": "/src/components/NotFound.tsx:148:4",
				children: /* @__PURE__ */ _jsxDEV(IconMessage, { "data-tsd-source": "/src/components/NotFound.tsx:149:5" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 5
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 148,
				columnNumber: 4
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 144,
			columnNumber: 3
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "absolute bottom-[18%] right-[5%] xl:right-[10%] 2xl:right-[16%] bg-linear-to-br from-[#80bea6] to-[#5fa088] rounded-2xl p-3 xl:p-3.5 shadow-[0_8px_24px_-4px_rgba(95,160,136,0.55)] border border-white/40 animate-[float_2.8s_ease-in-out_infinite] [animation-delay:0.9s]",
			style: { "--rot": "-10deg" },
			"data-tsd-source": "/src/components/NotFound.tsx:154:3",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "text-white drop-shadow-sm",
				"data-tsd-source": "/src/components/NotFound.tsx:158:4",
				children: /* @__PURE__ */ _jsxDEV(IconCompass, { "data-tsd-source": "/src/components/NotFound.tsx:159:5" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 5
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 158,
				columnNumber: 4
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 154,
			columnNumber: 3
		}, this)
	]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 122,
	columnNumber: 2
}, this);
_c7 = FloatingCards;
//
// 5. Componente Principal NotFound
//
export default function NotFound() {
	_s();
	const [mounted, setMounted] = useState(false);
	const navigate = useNavigate();
	useEffect(() => {
		setMounted(true);
	}, []);
	const handleHomePage = () => {
		navigate({
			to: "/",
			search: { welcome: true }
		});
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-[#eceeeb] relative overflow-hidden flex flex-col selection:bg-[#80bea6]/30 font-sans",
		"data-tsd-source": "/src/components/NotFound.tsx:184:3",
		children: [
			/* @__PURE__ */ _jsxDEV("style", {
				"data-tsd-source": "/src/components/NotFound.tsx:186:4",
				children: `
                @keyframes float {
                    0%, 100% { transform: translateY(0px) rotate(var(--rot, 0deg)); }
                    50% { transform: translateY(-18px) rotate(var(--rot, 0deg)); }
                }
            `
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 186,
				columnNumber: 4
			}, this),
			/* @__PURE__ */ _jsxDEV(DecorativeGrid, { "data-tsd-source": "/src/components/NotFound.tsx:194:4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 194,
				columnNumber: 4
			}, this),
			/* @__PURE__ */ _jsxDEV(DecorativeBlurs, { "data-tsd-source": "/src/components/NotFound.tsx:195:4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 195,
				columnNumber: 4
			}, this),
			/* @__PURE__ */ _jsxDEV(FloatingCards, { "data-tsd-source": "/src/components/NotFound.tsx:198:4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 198,
				columnNumber: 4
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 flex items-center justify-center px-6 py-12 relative z-20",
				"data-tsd-source": "/src/components/NotFound.tsx:201:4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: `max-w-2xl w-full text-center transition-all duration-700 ease-out ${mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`,
					"data-tsd-source": "/src/components/NotFound.tsx:202:5",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "inline-flex items-center gap-2 mb-5 px-3.5 py-1.5 rounded-full bg-white/70 border border-[#80bea6]/30 backdrop-blur-sm",
							"data-tsd-source": "/src/components/NotFound.tsx:206:6",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "w-1.5 h-1.5 rounded-full bg-[#5fa088] animate-pulse",
								"data-tsd-source": "/src/components/NotFound.tsx:207:7"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 207,
								columnNumber: 7
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] font-bold tracking-[0.18em] text-[#3c5048] uppercase",
								"data-tsd-source": "/src/components/NotFound.tsx:208:7",
								children: "Erro 404"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 208,
								columnNumber: 7
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 206,
							columnNumber: 6
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative mb-4 sm:mb-6 inline-block select-none group",
							"data-tsd-source": "/src/components/NotFound.tsx:214:6",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-40 h-40 sm:w-56 sm:h-56 md:w-72 md:h-72 bg-[#80bea6]/25 rounded-full blur-md transition-transform duration-700 group-hover:scale-110",
								"data-tsd-source": "/src/components/NotFound.tsx:216:7"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 7
							}, this), /* @__PURE__ */ _jsxDEV("h1", {
								className: "text-[100px] sm:text-[150px] md:text-[200px] lg:text-[240px] font-black leading-none relative tracking-tighter selection:bg-white/0 bg-linear-to-b from-[#6cab92] via-[#5a9d83] to-[#3c5048] bg-clip-text text-transparent drop-shadow-[0_6px_18px_rgba(60,80,72,0.25)]",
								"data-tsd-source": "/src/components/NotFound.tsx:219:7",
								children: "404"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 219,
								columnNumber: 7
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 214,
							columnNumber: 6
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#191c1b] mb-4 tracking-tight relative z-30",
							"data-tsd-source": "/src/components/NotFound.tsx:225:6",
							children: "Página não encontrada"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 225,
							columnNumber: 6
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm sm:text-base md:text-lg text-[#404944] mb-8 max-w-md md:max-w-xl mx-auto leading-relaxed text-balance font-medium relative z-30",
							"data-tsd-source": "/src/components/NotFound.tsx:230:6",
							children: "Desculpe, o ecrã que procura não existe ou foi movido. Verifique o endereço ou volte ao seu painel administrativo."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 230,
							columnNumber: 6
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 202,
					columnNumber: 5
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 201,
				columnNumber: 4
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "relative z-20 pb-8 sm:pb-12 pt-2 transition-all duration-700 delay-100",
				"data-tsd-source": "/src/components/NotFound.tsx:238:4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-center px-6",
					"data-tsd-source": "/src/components/NotFound.tsx:239:5",
					children: /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: handleHomePage,
						className: "group inline-flex items-center gap-3 px-8 py-4 bg-[#191c1b] rounded-xl border border-[#191c1b] shadow-lg shadow-black/10 transition-all duration-300 hover:bg-[#5fa088] hover:border-[#5fa088] hover:shadow-xl hover:shadow-[#80bea6]/30 active:scale-[0.98] cursor-pointer w-full sm:w-auto justify-center",
						"data-tsd-source": "/src/components/NotFound.tsx:240:6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-2.5 h-2.5 bg-[#80bea6] rounded-full transition-all duration-300 group-hover:bg-white group-hover:scale-125 shrink-0",
							"data-tsd-source": "/src/components/NotFound.tsx:245:7"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 245,
							columnNumber: 7
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-white tracking-widest transition-colors duration-300 whitespace-nowrap",
							"data-tsd-source": "/src/components/NotFound.tsx:247:7",
							children: "VOLTAR AO SISTEMA DE GESTÃO"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 247,
							columnNumber: 7
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 240,
						columnNumber: 6
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 239,
					columnNumber: 5
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 238,
				columnNumber: 4
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 184,
		columnNumber: 3
	}, this);
}
_s(NotFound, "b1dee4aiDYvtLXagvBT/dXsd23o=", false, function() {
	return [useNavigate];
});
_c8 = NotFound;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8;
$RefreshReg$(_c, "IconShield");
$RefreshReg$(_c2, "IconHome");
$RefreshReg$(_c3, "IconMessage");
$RefreshReg$(_c4, "IconCompass");
$RefreshReg$(_c5, "DecorativeGrid");
$RefreshReg$(_c6, "DecorativeBlurs");
$RefreshReg$(_c7, "FloatingCards");
$RefreshReg$(_c8, "NotFound");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/NotFound.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/NotFound.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/NotFound.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/NotFound.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTs7Ozs7OztBQUtBLHlCQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO1dBWkEsQ0FhQTtFQUFBO1lBQVE7Q0FBQTs7OztXQUNSO0VBQUE7RUFBQTtDQUF1RDs7OztTQUN2RDs7Ozs7OztBQUdBLHVCQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO1dBWkE7RUFhQTtHQUFBO2FBQVE7RUFBQTs7Ozs7RUFDUjtHQUFBO0dBQUE7RUFBMkQ7Ozs7O0VBQzNEO0dBQUE7R0FBQTtFQUEyQzs7Ozs7Q0FDM0M7Ozs7Ozs7QUFHQSwwQkFDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtXQVpBLENBYUE7RUFBQTtZQUFRO0NBQUE7Ozs7V0FDUjtFQUFBO0VBQUE7Q0FBMEU7Ozs7U0FDMUU7Ozs7Ozs7QUFHQSwwQkFDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtXQVpBO0VBYUE7R0FBQTthQUFRO0VBQUE7Ozs7O0VBQ1I7R0FBQTtHQUFBO0dBQUE7R0FBQTtFQUFpQzs7Ozs7RUFDakM7R0FBQTtHQUFBO0VBQTJFOzs7OztDQUMzRTs7Ozs7Ozs7OztBQU1BLDZCQUNBO0NBQ0E7Q0FDQTtFQUNBOzs7O0VBSUE7RUFDQSxXQUNBO0VBQ0EsaUJBQ0E7Q0FDQTtDQUNBO0FBQUM7Ozs7Ozs7OztBQU1ELDhCQUNBO0NBQ0E7RUFBQTtFQUFBO0NBQWlPOzs7OztDQUNqTztFQUFBO0VBQUE7Q0FBZ0o7Ozs7O0NBQ2hKO0VBQUE7RUFBQTtDQUFrSjs7Ozs7QUFDbEo7Ozs7Ozs7Ozs7O0FBUUEsNEJBQ0E7Q0FBQTtDQUFBO1dBQUE7RUFFQTtHQUNBO0dBQ0E7R0FDQTthQUNBO0lBQUE7SUFBQTtjQUNBLDhGQUFnQjs7Ozs7R0FDaEI7Ozs7O0VBQ0E7Ozs7O0VBR0E7R0FDQTtHQUNBO0dBQ0E7YUFDQTtJQUFBO0lBQUE7Y0FDQSw0RkFBYzs7Ozs7R0FDZDs7Ozs7RUFDQTs7Ozs7RUFHQTtHQUNBO0dBQ0E7R0FDQTthQUNBO0lBQUE7SUFBQTtjQUNBLCtGQUFpQjs7Ozs7R0FDakI7Ozs7O0VBQ0E7Ozs7O0VBR0E7R0FDQTtHQUNBO0dBQ0E7YUFDQTtJQUFBO0lBQUE7Y0FDQSwrRkFBaUI7Ozs7O0dBQ2pCOzs7OztFQUNBOzs7OztDQUNBOzs7Ozs7Ozs7O0FBTUE7O0NBQ0E7Q0FDQTtDQUVBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7R0FDQTtHQUNBO0VBQ0E7Q0FDQTtDQUVBLE9BQ0E7RUFBQTtFQUFBO1lBQUE7R0FFQTtJQUFBO2NBQVM7Ozs7OztHQUtUOzs7OztHQUdBLGtHQUFtQjs7Ozs7R0FDbkIsbUdBQW9COzs7OztHQUdwQixpR0FBa0I7Ozs7O0dBR2xCO0lBQUE7SUFBQTtjQUNBO0tBQ0E7S0FDQTtlQUZBO01BSUE7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFBQTtRQUFBO09BQTRFOzs7O2lCQUM1RTtRQUFBO1FBQUE7a0JBQXdGO09BRXhGOzs7O2VBQ0E7Ozs7OztNQUdBO09BQUE7T0FBQTtpQkFBQSxDQUVBO1FBQUE7UUFBQTtPQUEwTjs7OztpQkFHMU47UUFBQTtRQUFBO2tCQUE2UjtPQUU3Ujs7OztlQUNBOzs7Ozs7TUFHQTtPQUFBO09BQUE7aUJBQXFIO01BRXJIOzs7OztNQUdBO09BQUE7T0FBQTtpQkFBMko7TUFHM0o7Ozs7O0tBQ0E7Ozs7OztHQUNBOzs7OztHQUdBO0lBQUE7SUFBQTtjQUNBO0tBQUE7S0FBQTtlQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7Z0JBSkEsQ0FLQTtPQUFBO09BQUE7TUFBNkk7Ozs7Z0JBRTdJO09BQUE7T0FBQTtpQkFBcUg7TUFFckg7Ozs7Y0FDQTs7Ozs7O0lBQ0E7Ozs7O0dBQ0E7Ozs7O0VBQ0E7Ozs7OztBQUVBIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOb3RGb3VuZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXJvdXRlclwiO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcblxyXG4vL1xyXG4vLyAxLiBEZWZpbmnDp8O1ZXMgZGUgw41jb25lcyAoU1ZHKVxyXG4vL1xyXG5jb25zdCBJY29uU2hpZWxkID0gKCkgPT4gKFxyXG5cdDxzdmdcclxuXHRcdHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxyXG5cdFx0d2lkdGg9XCIyMFwiXHJcblx0XHRoZWlnaHQ9XCIyMFwiXHJcblx0XHR2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuXHRcdGZpbGw9XCJub25lXCJcclxuXHRcdHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcblx0XHRzdHJva2VXaWR0aD1cIjIuMjVcIlxyXG5cdFx0c3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuXHRcdHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG5cdFx0YXJpYS1sYWJlbD1cIlNoaWVsZCBpY29uXCJcclxuXHRcdHJvbGU9XCJpbWdcIlxyXG5cdD5cclxuXHRcdDx0aXRsZT5TaGllbGQgaWNvbjwvdGl0bGU+XHJcblx0XHQ8cGF0aCBkPVwiTTEyIDIyczgtNCA4LTEwVjVsLTgtMy04IDN2N2MwIDYgOCAxMCA4IDEwXCIgLz5cclxuXHQ8L3N2Zz5cclxuKTtcclxuXHJcbmNvbnN0IEljb25Ib21lID0gKCkgPT4gKFxyXG5cdDxzdmdcclxuXHRcdHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxyXG5cdFx0d2lkdGg9XCIyMFwiXHJcblx0XHRoZWlnaHQ9XCIyMFwiXHJcblx0XHR2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuXHRcdGZpbGw9XCJub25lXCJcclxuXHRcdHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcblx0XHRzdHJva2VXaWR0aD1cIjIuMjVcIlxyXG5cdFx0c3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuXHRcdHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG5cdFx0YXJpYS1sYWJlbD1cIkhvbWUgaWNvblwiXHJcblx0XHRyb2xlPVwiaW1nXCJcclxuXHQ+XHJcblx0XHQ8dGl0bGU+SG9tZSBpY29uPC90aXRsZT5cclxuXHRcdDxwYXRoIGQ9XCJtMyA5IDktNyA5IDd2MTFhMiAyIDAgMCAxLTIgMkg1YTIgMiAwIDAgMS0yLTJ6XCIgLz5cclxuXHRcdDxwb2x5bGluZSBwb2ludHM9XCI5IDIyIDkgMTIgMTUgMTIgMTUgMjJcIiAvPlxyXG5cdDwvc3ZnPlxyXG4pO1xyXG5cclxuY29uc3QgSWNvbk1lc3NhZ2UgPSAoKSA9PiAoXHJcblx0PHN2Z1xyXG5cdFx0eG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXHJcblx0XHR3aWR0aD1cIjIwXCJcclxuXHRcdGhlaWdodD1cIjIwXCJcclxuXHRcdHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG5cdFx0ZmlsbD1cIm5vbmVcIlxyXG5cdFx0c3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuXHRcdHN0cm9rZVdpZHRoPVwiMi4yNVwiXHJcblx0XHRzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG5cdFx0c3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcblx0XHRhcmlhLWxhYmVsPVwiTWVzc2FnZSBpY29uXCJcclxuXHRcdHJvbGU9XCJpbWdcIlxyXG5cdD5cclxuXHRcdDx0aXRsZT5NZXNzYWdlIGljb248L3RpdGxlPlxyXG5cdFx0PHBhdGggZD1cIk0yMSAxNWEyIDIgMCAwIDEtMiAySDdsLTQgNFY1YTIgMiAwIDAgMSAyLTJoMTRhMiAyIDAgMCAxIDIgMnpcIiAvPlxyXG5cdDwvc3ZnPlxyXG4pO1xyXG5cclxuY29uc3QgSWNvbkNvbXBhc3MgPSAoKSA9PiAoXHJcblx0PHN2Z1xyXG5cdFx0eG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXHJcblx0XHR3aWR0aD1cIjIwXCJcclxuXHRcdGhlaWdodD1cIjIwXCJcclxuXHRcdHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG5cdFx0ZmlsbD1cIm5vbmVcIlxyXG5cdFx0c3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuXHRcdHN0cm9rZVdpZHRoPVwiMi4yNVwiXHJcblx0XHRzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG5cdFx0c3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcblx0XHRhcmlhLWxhYmVsPVwiQ29tcGFzcyBpY29uXCJcclxuXHRcdHJvbGU9XCJpbWdcIlxyXG5cdD5cclxuXHRcdDx0aXRsZT5Db21wYXNzIGljb248L3RpdGxlPlxyXG5cdFx0PGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIxMFwiIC8+XHJcblx0XHQ8cG9seWdvbiBwb2ludHM9XCIxNi4yNCA3Ljc2IDE0LjEyIDE0LjEyIDcuNzYgMTYuMjQgOS44OCA5Ljg4IDE2LjI0IDcuNzZcIiAvPlxyXG5cdDwvc3ZnPlxyXG4pO1xyXG5cclxuLy9cclxuLy8gMi4gQ29tcG9uZW50ZSBkZSBGdW5kbyBHcmlkIERlY29yYXRpdm9cclxuLy9cclxuY29uc3QgRGVjb3JhdGl2ZUdyaWQgPSAoKSA9PiAoXHJcblx0PGRpdlxyXG5cdFx0Y2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBwb2ludGVyLWV2ZW50cy1ub25lIHotMFwiXHJcblx0XHRzdHlsZT17e1xyXG5cdFx0XHRiYWNrZ3JvdW5kSW1hZ2U6IGBcclxuICAgICAgICAgICAgICAgIGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgcmdiYSg2NCwgNzMsIDY4LCAwLjA4KSAxcHgsIHRyYW5zcGFyZW50IDFweCksXHJcbiAgICAgICAgICAgICAgICBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCByZ2JhKDY0LCA3MywgNjgsIDAuMDgpIDFweCwgdHJhbnNwYXJlbnQgMXB4KVxyXG4gICAgICAgICAgICBgLFxyXG5cdFx0XHRiYWNrZ3JvdW5kU2l6ZTogXCI0NHB4IDQ0cHhcIixcclxuXHRcdFx0bWFza0ltYWdlOlxyXG5cdFx0XHRcdFwicmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgODAlIDYwJSBhdCA1MCUgNDUlLCBibGFjayAzMCUsIHRyYW5zcGFyZW50IDkwJSlcIixcclxuXHRcdFx0V2Via2l0TWFza0ltYWdlOlxyXG5cdFx0XHRcdFwicmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgODAlIDYwJSBhdCA1MCUgNDUlLCBibGFjayAzMCUsIHRyYW5zcGFyZW50IDkwJSlcIixcclxuXHRcdH19XHJcblx0Lz5cclxuKTtcclxuXHJcbi8vXHJcbi8vIDMuIENvbXBvbmVudGUgZGUgQ8OtcmN1bG9zIGRlIERlc2ZvcXVlIERlY29yYXRpdm9zXHJcbi8vXHJcbmNvbnN0IERlY29yYXRpdmVCbHVycyA9ICgpID0+IChcclxuXHQ8PlxyXG5cdFx0PGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMS8yIGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB3LVszMjBweF0gaC04MCBzbTp3LTEyMCBzbTpoLTEyMCBtZDp3LTE2MCBtZDpoLTE2MCBiZy1bIzgwYmVhNl0vMjAgcm91bmRlZC1mdWxsIGJsdXItWzkwcHhdIHNtOmJsdXItWzEzMHB4XSBhbmltYXRlLXB1bHNlIHBvaW50ZXItZXZlbnRzLW5vbmUgei0wXCIgLz5cclxuXHRcdDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLVstMTIlXSByaWdodC1bLTglXSB3LTY1IGgtNjUgc206dy0xMDUgc206aC0xMDUgYmctWyM4MGJlYTZdLzE0IHJvdW5kZWQtZnVsbCBibHVyLVs5MHB4XSBwb2ludGVyLWV2ZW50cy1ub25lIHotMFwiIC8+XHJcblx0XHQ8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS1bLTEyJV0gbGVmdC1bLTglXSB3LTY1IGgtNjUgc206dy0xMDUgc206aC0xMDUgYmctWyM4MGJlYTZdLzE0IHJvdW5kZWQtZnVsbCBibHVyLVs5MHB4XSBwb2ludGVyLWV2ZW50cy1ub25lIHotMFwiIC8+XHJcblx0PC8+XHJcbik7XHJcblxyXG4vL1xyXG4vLyA0LiBDb21wb25lbnRlIGRlIENhcnTDtWVzIEZsdXR1YW50ZXNcclxuLy8gUmVwb3NpY2lvbmFkb3MgcGFyYSBhcyBtYXJnZW5zIGV4dGVybmFzIGRvIGVjcsOjLCBmb3JhIGRhIGNvbHVuYSBjZW50cmFsIGRlIHRleHRvXHJcbi8vIChtYXgtdy0yeGwpLCBlIHPDsyB2aXPDrXZlaXMgYSBwYXJ0aXIgZGUgXCJsZ1wiIHBhcmEgbnVuY2EgY29saWRpciBjb20gbyBjb250ZcO6ZG8uXHJcbi8vXHJcbmNvbnN0IEZsb2F0aW5nQ2FyZHMgPSAoKSA9PiAoXHJcblx0PGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gbGc6YmxvY2sgcG9pbnRlci1ldmVudHMtbm9uZSBzZWxlY3Qtbm9uZSBhYnNvbHV0ZSBpbnNldC0wIHotMTBcIj5cclxuXHRcdHsvKiBDYXJ0w6NvIFNoaWVsZCDigJQgY2FudG8gc3VwZXJpb3IgZXNxdWVyZG8sIGp1bnRvIMOgIG1hcmdlbSAqL31cclxuXHRcdDxkaXZcclxuXHRcdFx0Y2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLVsxMiVdIGxlZnQtWzQlXSB4bDpsZWZ0LVs4JV0gMnhsOmxlZnQtWzE0JV0gYmctbGluZWFyLXRvLWJyIGZyb20tWyM4MGJlYTZdIHRvLVsjNWZhMDg4XSByb3VuZGVkLTJ4bCBwLTMgeGw6cC0zLjUgc2hhZG93LVswXzhweF8yNHB4Xy00cHhfcmdiYSg5NSwxNjAsMTM2LDAuNTUpXSBib3JkZXIgYm9yZGVyLXdoaXRlLzQwIGFuaW1hdGUtW2Zsb2F0XzIuMnNfZWFzZS1pbi1vdXRfaW5maW5pdGVdXCJcclxuXHRcdFx0c3R5bGU9e3sgXCItLXJvdFwiOiBcIjEwZGVnXCIgfSBhcyBSZWFjdC5DU1NQcm9wZXJ0aWVzfVxyXG5cdFx0PlxyXG5cdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZHJvcC1zaGFkb3ctc21cIj5cclxuXHRcdFx0XHQ8SWNvblNoaWVsZCAvPlxyXG5cdFx0XHQ8L2Rpdj5cclxuXHRcdDwvZGl2PlxyXG5cclxuXHRcdHsvKiBDYXJ0w6NvIEhvbWUg4oCUIGNhbnRvIHN1cGVyaW9yIGRpcmVpdG8sIGp1bnRvIMOgIG1hcmdlbSAqL31cclxuXHRcdDxkaXZcclxuXHRcdFx0Y2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLVsxNiVdIHJpZ2h0LVs0JV0geGw6cmlnaHQtWzglXSAyeGw6cmlnaHQtWzE0JV0gYmctbGluZWFyLXRvLWJyIGZyb20tWyM4MGJlYTZdIHRvLVsjNWZhMDg4XSByb3VuZGVkLTJ4bCBwLTMgeGw6cC0zLjUgc2hhZG93LVswXzhweF8yNHB4Xy00cHhfcmdiYSg5NSwxNjAsMTM2LDAuNTUpXSBib3JkZXIgYm9yZGVyLXdoaXRlLzQwIGFuaW1hdGUtW2Zsb2F0XzIuNnNfZWFzZS1pbi1vdXRfaW5maW5pdGVdIFthbmltYXRpb24tZGVsYXk6MC4zc11cIlxyXG5cdFx0XHRzdHlsZT17eyBcIi0tcm90XCI6IFwiLThkZWdcIiB9IGFzIFJlYWN0LkNTU1Byb3BlcnRpZXN9XHJcblx0XHQ+XHJcblx0XHRcdDxkaXYgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBkcm9wLXNoYWRvdy1zbVwiPlxyXG5cdFx0XHRcdDxJY29uSG9tZSAvPlxyXG5cdFx0XHQ8L2Rpdj5cclxuXHRcdDwvZGl2PlxyXG5cclxuXHRcdHsvKiBDYXJ0w6NvIE1lc3NhZ2Ug4oCUIGNhbnRvIGluZmVyaW9yIGVzcXVlcmRvLCBhYmFpeG8gZGEgY29sdW5hIGRlIHRleHRvICovfVxyXG5cdFx0PGRpdlxyXG5cdFx0XHRjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tWzE0JV0gbGVmdC1bNSVdIHhsOmxlZnQtWzEwJV0gMnhsOmxlZnQtWzE2JV0gYmctbGluZWFyLXRvLWJyIGZyb20tWyM4MGJlYTZdIHRvLVsjNWZhMDg4XSByb3VuZGVkLTJ4bCBwLTMgeGw6cC0zLjUgc2hhZG93LVswXzhweF8yNHB4Xy00cHhfcmdiYSg5NSwxNjAsMTM2LDAuNTUpXSBib3JkZXIgYm9yZGVyLXdoaXRlLzQwIGFuaW1hdGUtW2Zsb2F0XzIuNHNfZWFzZS1pbi1vdXRfaW5maW5pdGVdIFthbmltYXRpb24tZGVsYXk6MC42c11cIlxyXG5cdFx0XHRzdHlsZT17eyBcIi0tcm90XCI6IFwiN2RlZ1wiIH0gYXMgUmVhY3QuQ1NTUHJvcGVydGllc31cclxuXHRcdD5cclxuXHRcdFx0PGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGRyb3Atc2hhZG93LXNtXCI+XHJcblx0XHRcdFx0PEljb25NZXNzYWdlIC8+XHJcblx0XHRcdDwvZGl2PlxyXG5cdFx0PC9kaXY+XHJcblxyXG5cdFx0ey8qIENhcnTDo28gQ29tcGFzcyDigJQgY2FudG8gaW5mZXJpb3IgZGlyZWl0bywgYWJhaXhvIGRhIGNvbHVuYSBkZSB0ZXh0byAqL31cclxuXHRcdDxkaXZcclxuXHRcdFx0Y2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLVsxOCVdIHJpZ2h0LVs1JV0geGw6cmlnaHQtWzEwJV0gMnhsOnJpZ2h0LVsxNiVdIGJnLWxpbmVhci10by1iciBmcm9tLVsjODBiZWE2XSB0by1bIzVmYTA4OF0gcm91bmRlZC0yeGwgcC0zIHhsOnAtMy41IHNoYWRvdy1bMF84cHhfMjRweF8tNHB4X3JnYmEoOTUsMTYwLDEzNiwwLjU1KV0gYm9yZGVyIGJvcmRlci13aGl0ZS80MCBhbmltYXRlLVtmbG9hdF8yLjhzX2Vhc2UtaW4tb3V0X2luZmluaXRlXSBbYW5pbWF0aW9uLWRlbGF5OjAuOXNdXCJcclxuXHRcdFx0c3R5bGU9e3sgXCItLXJvdFwiOiBcIi0xMGRlZ1wiIH0gYXMgUmVhY3QuQ1NTUHJvcGVydGllc31cclxuXHRcdD5cclxuXHRcdFx0PGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGRyb3Atc2hhZG93LXNtXCI+XHJcblx0XHRcdFx0PEljb25Db21wYXNzIC8+XHJcblx0XHRcdDwvZGl2PlxyXG5cdFx0PC9kaXY+XHJcblx0PC9kaXY+XHJcbik7XHJcblxyXG4vL1xyXG4vLyA1LiBDb21wb25lbnRlIFByaW5jaXBhbCBOb3RGb3VuZFxyXG4vL1xyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBOb3RGb3VuZCgpIHtcclxuXHRjb25zdCBbbW91bnRlZCwgc2V0TW91bnRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblx0Y29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG5cclxuXHR1c2VFZmZlY3QoKCkgPT4ge1xyXG5cdFx0c2V0TW91bnRlZCh0cnVlKTtcclxuXHR9LCBbXSk7XHJcblxyXG5cdGNvbnN0IGhhbmRsZUhvbWVQYWdlID0gKCkgPT4ge1xyXG5cdFx0bmF2aWdhdGUoe1xyXG5cdFx0XHR0bzogXCIvXCIsXHJcblx0XHRcdHNlYXJjaDogeyB3ZWxjb21lOiB0cnVlIH0sXHJcblx0XHR9KTtcclxuXHR9O1xyXG5cclxuXHRyZXR1cm4gKFxyXG5cdFx0PGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctWyNlY2VlZWJdIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sIHNlbGVjdGlvbjpiZy1bIzgwYmVhNl0vMzAgZm9udC1zYW5zXCI+XHJcblx0XHRcdHsvKiBDU1MgSW5qZXRhZG8gcGFyYSBhbmltYcOnw7VlcyAoS2V5ZnJhbWVzKSAqL31cclxuXHRcdFx0PHN0eWxlPntgXHJcbiAgICAgICAgICAgICAgICBAa2V5ZnJhbWVzIGZsb2F0IHtcclxuICAgICAgICAgICAgICAgICAgICAwJSwgMTAwJSB7IHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwcHgpIHJvdGF0ZSh2YXIoLS1yb3QsIDBkZWcpKTsgfVxyXG4gICAgICAgICAgICAgICAgICAgIDUwJSB7IHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtMThweCkgcm90YXRlKHZhcigtLXJvdCwgMGRlZykpOyB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGB9PC9zdHlsZT5cclxuXHJcblx0XHRcdHsvKiBFbGVtZW50b3MgRGVjb3JhdGl2b3MgZGUgRnVuZG8gKi99XHJcblx0XHRcdDxEZWNvcmF0aXZlR3JpZCAvPlxyXG5cdFx0XHQ8RGVjb3JhdGl2ZUJsdXJzIC8+XHJcblxyXG5cdFx0XHR7LyogRWxlbWVudG9zIEludGVyYXRpdm9zIEZsdXR1YW50ZXMgKi99XHJcblx0XHRcdDxGbG9hdGluZ0NhcmRzIC8+XHJcblxyXG5cdFx0XHR7Lyogw4FyZWEgZGUgQ29udGXDumRvIFByaW5jaXBhbCAtIENlbnRyYWxpemFkYSAqL31cclxuXHRcdFx0PG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB4LTYgcHktMTIgcmVsYXRpdmUgei0yMFwiPlxyXG5cdFx0XHRcdDxkaXZcclxuXHRcdFx0XHRcdGNsYXNzTmFtZT17YG1heC13LTJ4bCB3LWZ1bGwgdGV4dC1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNzAwIGVhc2Utb3V0ICR7bW91bnRlZCA/IFwib3BhY2l0eS0xMDAgdHJhbnNsYXRlLXktMFwiIDogXCJvcGFjaXR5LTAgdHJhbnNsYXRlLXktOFwifWB9XHJcblx0XHRcdFx0PlxyXG5cdFx0XHRcdFx0ey8qIEV0aXF1ZXRhIGRlIGVzdGFkbywgYWNpbWEgZG8gNDA0ICovfVxyXG5cdFx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNSBweC0zLjUgcHktMS41IHJvdW5kZWQtZnVsbCBiZy13aGl0ZS83MCBib3JkZXIgYm9yZGVyLVsjODBiZWE2XS8zMCBiYWNrZHJvcC1ibHVyLXNtXCI+XHJcblx0XHRcdFx0XHRcdDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1bIzVmYTA4OF0gYW5pbWF0ZS1wdWxzZVwiIC8+XHJcblx0XHRcdFx0XHRcdDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0cmFja2luZy1bMC4xOGVtXSB0ZXh0LVsjM2M1MDQ4XSB1cHBlcmNhc2VcIj5cclxuXHRcdFx0XHRcdFx0XHRFcnJvIDQwNFxyXG5cdFx0XHRcdFx0XHQ8L3NwYW4+XHJcblx0XHRcdFx0XHQ8L2Rpdj5cclxuXHJcblx0XHRcdFx0XHR7LyogSW52w7NsdWNybyBkbyBUZXh0byA0MDQgKGNvbSBlZmVpdG8gaG92ZXIpICovfVxyXG5cdFx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtYi00IHNtOm1iLTYgaW5saW5lLWJsb2NrIHNlbGVjdC1ub25lIGdyb3VwXCI+XHJcblx0XHRcdFx0XHRcdHsvKiBCcmlsaG8gZGUgZnVuZG8gaW50ZXJhdGl2byAqL31cclxuXHRcdFx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMS8yIGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB3LTQwIGgtNDAgc206dy01NiBzbTpoLTU2IG1kOnctNzIgbWQ6aC03MiBiZy1bIzgwYmVhNl0vMjUgcm91bmRlZC1mdWxsIGJsdXItbWQgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tNzAwIGdyb3VwLWhvdmVyOnNjYWxlLTExMFwiIC8+XHJcblxyXG5cdFx0XHRcdFx0XHR7LyogTyBUZXh0byA0MDQgZW0gc2kgKi99XHJcblx0XHRcdFx0XHRcdDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsxMDBweF0gc206dGV4dC1bMTUwcHhdIG1kOnRleHQtWzIwMHB4XSBsZzp0ZXh0LVsyNDBweF0gZm9udC1ibGFjayBsZWFkaW5nLW5vbmUgcmVsYXRpdmUgdHJhY2tpbmctdGlnaHRlciBzZWxlY3Rpb246Ymctd2hpdGUvMCBiZy1saW5lYXItdG8tYiBmcm9tLVsjNmNhYjkyXSB2aWEtWyM1YTlkODNdIHRvLVsjM2M1MDQ4XSBiZy1jbGlwLXRleHQgdGV4dC10cmFuc3BhcmVudCBkcm9wLXNoYWRvdy1bMF82cHhfMThweF9yZ2JhKDYwLDgwLDcyLDAuMjUpXVwiPlxyXG5cdFx0XHRcdFx0XHRcdDQwNFxyXG5cdFx0XHRcdFx0XHQ8L2gxPlxyXG5cdFx0XHRcdFx0PC9kaXY+XHJcblxyXG5cdFx0XHRcdFx0ey8qIFTDrXR1bG8gZGEgUMOhZ2luYSAqL31cclxuXHRcdFx0XHRcdDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBzbTp0ZXh0LTN4bCBtZDp0ZXh0LTR4bCBmb250LWV4dHJhYm9sZCB0ZXh0LVsjMTkxYzFiXSBtYi00IHRyYWNraW5nLXRpZ2h0IHJlbGF0aXZlIHotMzBcIj5cclxuXHRcdFx0XHRcdFx0UMOhZ2luYSBuw6NvIGVuY29udHJhZGFcclxuXHRcdFx0XHRcdDwvaDI+XHJcblxyXG5cdFx0XHRcdFx0ey8qIFRleHRvIERlc2NyaXRpdm8gKi99XHJcblx0XHRcdFx0XHQ8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHNtOnRleHQtYmFzZSBtZDp0ZXh0LWxnIHRleHQtWyM0MDQ5NDRdIG1iLTggbWF4LXctbWQgbWQ6bWF4LXcteGwgbXgtYXV0byBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1iYWxhbmNlIGZvbnQtbWVkaXVtIHJlbGF0aXZlIHotMzBcIj5cclxuXHRcdFx0XHRcdFx0RGVzY3VscGUsIG8gZWNyw6MgcXVlIHByb2N1cmEgbsOjbyBleGlzdGUgb3UgZm9pIG1vdmlkby4gVmVyaWZpcXVlIG9cclxuXHRcdFx0XHRcdFx0ZW5kZXJlw6dvIG91IHZvbHRlIGFvIHNldSBwYWluZWwgYWRtaW5pc3RyYXRpdm8uXHJcblx0XHRcdFx0XHQ8L3A+XHJcblx0XHRcdFx0PC9kaXY+XHJcblx0XHRcdDwvbWFpbj5cclxuXHJcblx0XHRcdHsvKiBSb2RhcMOpIC0gQ29udGVuZG8gbyBCb3TDo28gZGUgQcOnw6NvICovfVxyXG5cdFx0XHQ8Zm9vdGVyIGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMjAgcGItOCBzbTpwYi0xMiBwdC0yIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTcwMCBkZWxheS0xMDBcIj5cclxuXHRcdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHgtNlwiPlxyXG5cdFx0XHRcdFx0PGJ1dHRvblxyXG5cdFx0XHRcdFx0XHR0eXBlPVwiYnV0dG9uXCJcclxuXHRcdFx0XHRcdFx0b25DbGljaz17aGFuZGxlSG9tZVBhZ2V9XHJcblx0XHRcdFx0XHRcdGNsYXNzTmFtZT1cImdyb3VwIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC04IHB5LTQgYmctWyMxOTFjMWJdIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1bIzE5MWMxYl0gc2hhZG93LWxnIHNoYWRvdy1ibGFjay8xMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgaG92ZXI6YmctWyM1ZmEwODhdIGhvdmVyOmJvcmRlci1bIzVmYTA4OF0gaG92ZXI6c2hhZG93LXhsIGhvdmVyOnNoYWRvdy1bIzgwYmVhNl0vMzAgYWN0aXZlOnNjYWxlLVswLjk4XSBjdXJzb3ItcG9pbnRlciB3LWZ1bGwgc206dy1hdXRvIGp1c3RpZnktY2VudGVyXCJcclxuXHRcdFx0XHRcdD5cclxuXHRcdFx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJ3LTIuNSBoLTIuNSBiZy1bIzgwYmVhNl0gcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBncm91cC1ob3ZlcjpiZy13aGl0ZSBncm91cC1ob3ZlcjpzY2FsZS0xMjUgc2hyaW5rLTBcIiAvPlxyXG5cclxuXHRcdFx0XHRcdFx0PHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSB0cmFja2luZy13aWRlc3QgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwIHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcblx0XHRcdFx0XHRcdFx0Vk9MVEFSIEFPIFNJU1RFTUEgREUgR0VTVMODT1xyXG5cdFx0XHRcdFx0XHQ8L3NwYW4+XHJcblx0XHRcdFx0XHQ8L2J1dHRvbj5cclxuXHRcdFx0XHQ8L2Rpdj5cclxuXHRcdFx0PC9mb290ZXI+XHJcblx0XHQ8L2Rpdj5cclxuXHQpO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvemVsdG8vT25lRHJpdmUvRG9jdW1lbnRvcy9HaXRIdWIvWGl0aXF1ZUFwcFVJL3NyYy9jb21wb25lbnRzL05vdEZvdW5kLnRzeCJ9