//#region node_modules/.pnpm/valibot@1.4.2_typescript@6.0.3/node_modules/valibot/dist/index.mjs
var store$4;
var DEFAULT_CONFIG = {
	lang: void 0,
	message: void 0,
	abortEarly: void 0,
	abortPipeEarly: void 0
};
/**
* Sets the global configuration.
*
* @param config The configuration.
*/
function setGlobalConfig(config$1) {
	store$4 = {
		...store$4,
		...config$1
	};
}
/**
* Returns the global configuration.
*
* @param config The config to merge.
*
* @returns The configuration.
*/
/* @__NO_SIDE_EFFECTS__ */
function getGlobalConfig(config$1) {
	if (!config$1 && !store$4) return DEFAULT_CONFIG;
	return {
		lang: config$1?.lang ?? store$4?.lang,
		message: config$1?.message,
		abortEarly: config$1?.abortEarly ?? store$4?.abortEarly,
		abortPipeEarly: config$1?.abortPipeEarly ?? store$4?.abortPipeEarly
	};
}
/**
* Deletes the global configuration.
*/
function deleteGlobalConfig() {
	store$4 = void 0;
}
var store$3;
/**
* Sets a global error message.
*
* @param message The error message.
* @param lang The language of the message.
*/
function setGlobalMessage(message$1, lang) {
	if (!store$3) store$3 = /* @__PURE__ */ new Map();
	store$3.set(lang, message$1);
}
/**
* Returns a global error message.
*
* @param lang The language of the message.
*
* @returns The error message.
*/
/* @__NO_SIDE_EFFECTS__ */
function getGlobalMessage(lang) {
	return store$3?.get(lang);
}
/**
* Deletes a global error message.
*
* @param lang The language of the message.
*/
function deleteGlobalMessage(lang) {
	store$3?.delete(lang);
}
var store$2;
/**
* Sets a schema error message.
*
* @param message The error message.
* @param lang The language of the message.
*/
function setSchemaMessage(message$1, lang) {
	if (!store$2) store$2 = /* @__PURE__ */ new Map();
	store$2.set(lang, message$1);
}
/**
* Returns a schema error message.
*
* @param lang The language of the message.
*
* @returns The error message.
*/
/* @__NO_SIDE_EFFECTS__ */
function getSchemaMessage(lang) {
	return store$2?.get(lang);
}
/**
* Deletes a schema error message.
*
* @param lang The language of the message.
*/
function deleteSchemaMessage(lang) {
	store$2?.delete(lang);
}
var store$1;
/**
* Sets a specific error message.
*
* @param reference The identifier reference.
* @param message The error message.
* @param lang The language of the message.
*/
function setSpecificMessage(reference, message$1, lang) {
	if (!store$1) store$1 = /* @__PURE__ */ new Map();
	if (!store$1.get(reference)) store$1.set(reference, /* @__PURE__ */ new Map());
	store$1.get(reference).set(lang, message$1);
}
/**
* Returns a specific error message.
*
* @param reference The identifier reference.
* @param lang The language of the message.
*
* @returns The error message.
*/
/* @__NO_SIDE_EFFECTS__ */
function getSpecificMessage(reference, lang) {
	return store$1?.get(reference)?.get(lang);
}
/**
* Deletes a specific error message.
*
* @param reference The identifier reference.
* @param lang The language of the message.
*/
function deleteSpecificMessage(reference, lang) {
	store$1?.get(reference)?.delete(lang);
}
/**
* Stringifies an unknown input to a literal or type string.
*
* @param input The unknown input.
*
* @returns A literal or type string.
*
* @internal
*/
/* @__NO_SIDE_EFFECTS__ */
function _stringify(input) {
	const type = typeof input;
	if (type === "string") return `"${input}"`;
	if (type === "number" || type === "bigint" || type === "boolean") return `${input}`;
	if (type === "object" || type === "function") return (input && Object.getPrototypeOf(input)?.constructor?.name) ?? "null";
	return type;
}
/**
* Adds an issue to the dataset.
*
* @param context The issue context.
* @param label The issue label.
* @param dataset The input dataset.
* @param config The configuration.
* @param other The optional props.
*
* @internal
*/
function _addIssue(context, label, dataset, config$1, other) {
	const input = other && "input" in other ? other.input : dataset.value;
	const expected = other?.expected ?? context.expects ?? null;
	const received = other?.received ?? /* @__PURE__ */ _stringify(input);
	const issue = {
		kind: context.kind,
		type: context.type,
		input,
		expected,
		received,
		message: `Invalid ${label}: ${expected ? `Expected ${expected} but r` : "R"}eceived ${received}`,
		requirement: context.requirement,
		path: other?.path,
		issues: other?.issues,
		lang: config$1.lang,
		abortEarly: config$1.abortEarly,
		abortPipeEarly: config$1.abortPipeEarly
	};
	const isSchema = context.kind === "schema";
	const message$1 = other?.message ?? context.message ?? /* @__PURE__ */ getSpecificMessage(context.reference, issue.lang) ?? (isSchema ? /* @__PURE__ */ getSchemaMessage(issue.lang) : null) ?? config$1.message ?? /* @__PURE__ */ getGlobalMessage(issue.lang);
	if (message$1 !== void 0) issue.message = typeof message$1 === "function" ? message$1(issue) : message$1;
	if (isSchema) dataset.typed = false;
	if (dataset.issues) dataset.issues.push(issue);
	else dataset.issues = [issue];
}
/**
* Creates a shallow copy of a dataset.
*
* Hint: The `value` is copied by reference, but the `issues` array is cloned
* to avoid reusing mutable dataset state across multiple runs. Mutating a
* returned object or array value can therefore affect later cache hits that
* reuse the same cached output.
*
* @param dataset The output dataset.
*
* @returns The copied output dataset.
*/
/* @__NO_SIDE_EFFECTS__ */
function _cloneDataset(dataset) {
	return {
		typed: dataset.typed,
		value: dataset.value,
		issues: dataset.issues && [...dataset.issues]
	};
}
/**
* Splits a string into lowercase words and rejoins them with the given
* separator and capitalization rules.
*
* Words are separated by `_`, `-` and ASCII whitespace, as well as by case
* and acronym boundaries. Whether the first or subsequent words are
* capitalized is controlled by `capFirst` and `capRest`.
*
* Hint: Implemented in a single pass that emits directly to the result
* string to avoid an intermediate `string[]` allocation. ASCII chars are
* classified via char codes to skip `.toLowerCase()` and `.toUpperCase()`
* method calls in the common case.
*
* Hint: Digits are treated as a separate character class, so `item2Name`
* yields `item2` and `name` rather than `item`, `2` and `name`.
*
* @param input The input string.
* @param separator The string inserted between words.
* @param capFirst Whether to capitalize the first word.
* @param capRest Whether to capitalize subsequent words.
*
* @returns The formatted string.
*
* @internal
*/
/* @__NO_SIDE_EFFECTS__ */
function _formatCase(input, separator, capFirst, capRest) {
	let result = "";
	let firstWord = true;
	let start = 0;
	let prev = 0;
	let prevPrev = 0;
	const flush = (end) => {
		if (end > start) {
			let word = input.slice(start, end).toLowerCase();
			if (firstWord ? capFirst : capRest) {
				const firstCode = word.charCodeAt(0);
				if (firstCode >= 97 && firstCode <= 122) word = String.fromCharCode(firstCode - 32) + word.slice(1);
				else {
					const charLen = firstCode >= 55296 && firstCode <= 56319 ? 2 : 1;
					word = word.slice(0, charLen).toUpperCase() + word.slice(charLen);
				}
			}
			result += firstWord ? word : separator + word;
			firstWord = false;
		}
	};
	for (let index = 0; index < input.length; index++) {
		const code = input.charCodeAt(index);
		let type;
		if (code === 32 || code === 9 || code === 10 || code === 11 || code === 12 || code === 13 || code === 45 || code === 95) {
			flush(index);
			start = index + 1;
			type = 0;
		} else if (code < 128) type = code >= 65 && code <= 90 ? 1 : code >= 97 && code <= 122 ? 2 : 3;
		else {
			const char = input[index];
			const charLower = char.toLowerCase();
			type = charLower === char.toUpperCase() ? 3 : char === charLower ? 2 : 1;
		}
		if (type === 1 && (prev === 2 || prev === 3) && index > start) {
			flush(index);
			start = index;
		} else if (type === 2 && prev === 1 && prevPrev === 1 && index - 1 > start) {
			flush(index - 1);
			start = index - 1;
		}
		prevPrev = prev;
		prev = type;
	}
	flush(input.length);
	return result;
}
var textEncoder;
/**
* Returns the byte count of the input.
*
* @param input The input to be measured.
*
* @returns The byte count.
*
* @internal
*/
/* @__NO_SIDE_EFFECTS__ */
function _getByteCount(input) {
	if (!textEncoder) textEncoder = new TextEncoder();
	return textEncoder.encode(input).length;
}
var segmenter;
/**
* Returns the grapheme count of the input.
*
* @param input The input to be measured.
*
* @returns The grapheme count.
*
* @internal
*/
/* @__NO_SIDE_EFFECTS__ */
function _getGraphemeCount(input) {
	if (!segmenter) segmenter = new Intl.Segmenter();
	const segments = segmenter.segment(input);
	let count = 0;
	for (const _ of segments) count++;
	return count;
}
/**
* Returns the last top-level value of a given metadata type from a schema
* using a breadth-first search that starts with the last item in the pipeline.
*
* @param schema The schema to search.
* @param type The metadata type.
*
* @returns The value, if any.
*
* @internal
*/
/* @__NO_SIDE_EFFECTS__ */
function _getLastMetadata(schema, type) {
	if ("pipe" in schema) {
		const nestedSchemas = [];
		for (let index = schema.pipe.length - 1; index >= 0; index--) {
			const item = schema.pipe[index];
			if (item.kind === "schema" && "pipe" in item) nestedSchemas.push(item);
			else if (item.kind === "metadata" && item.type === type) return item[type];
		}
		for (const nestedSchema of nestedSchemas) {
			const result = /* @__PURE__ */ _getLastMetadata(nestedSchema, type);
			if (result !== void 0) return result;
		}
	}
}
var _standardCache = /* @__PURE__ */ new WeakMap();
/**
* Returns the Standard Schema properties.
*
* @param context The schema context.
*
* @returns The Standard Schema properties.
*/
/* @__NO_SIDE_EFFECTS__ */
function _getStandardProps(context) {
	let cached = _standardCache.get(context);
	if (!cached) {
		cached = {
			version: 1,
			vendor: "valibot",
			validate(value$1) {
				return context["~run"]({ value: value$1 }, /* @__PURE__ */ getGlobalConfig());
			}
		};
		_standardCache.set(context, cached);
	}
	return cached;
}
var store;
/**
* Returns the word count of the input.
*
* @param locales The locales to be used.
* @param input The input to be measured.
*
* @returns The word count.
*
* @internal
*/
/* @__NO_SIDE_EFFECTS__ */
function _getWordCount(locales, input) {
	if (!store) store = /* @__PURE__ */ new Map();
	const key = String(locales);
	let segmenter$1 = store.get(key);
	if (!segmenter$1) {
		segmenter$1 = new Intl.Segmenter(locales, { granularity: "word" });
		store.set(key, segmenter$1);
	}
	const segments = segmenter$1.segment(input);
	let count = 0;
	for (const segment of segments) if (segment.isWordLike) count++;
	return count;
}
/**
* Non-digit regex.
*/
var NON_DIGIT_REGEX = /\D/gu;
/**
* Checks whether a string with numbers corresponds to the luhn algorithm.
*
* @param input The input to be checked.
*
* @returns Whether input is valid.
*
* @internal
*/
/* @__NO_SIDE_EFFECTS__ */
function _isLuhnAlgo(input) {
	const number$1 = input.replace(NON_DIGIT_REGEX, "");
	let length$1 = number$1.length;
	let bit = 1;
	let sum = 0;
	while (length$1) {
		const value$1 = +number$1[--length$1];
		bit ^= 1;
		sum += bit ? [
			0,
			2,
			4,
			6,
			8,
			1,
			3,
			5,
			7,
			9
		][value$1] : value$1;
	}
	return sum % 10 === 0;
}
/**
* Disallows inherited object properties and prevents object prototype
* pollution by disallowing certain keys.
*
* @param object The object to check.
* @param key The key to check.
*
* @returns Whether the key is allowed.
*
* @internal
*/
/* @__NO_SIDE_EFFECTS__ */
function _isValidObjectKey(object$1, key) {
	return Object.prototype.hasOwnProperty.call(object$1, key) && key !== "__proto__" && key !== "prototype" && key !== "constructor";
}
/**
* Joins multiple `expects` values with the given separator.
*
* @param values The `expects` values.
* @param separator The separator.
*
* @returns The joined `expects` property.
*
* @internal
*/
/* @__NO_SIDE_EFFECTS__ */
function _joinExpects(values$1, separator) {
	const list = [...new Set(values$1)];
	if (list.length > 1) return `(${list.join(` ${separator} `)})`;
	return list[0] ?? "never";
}
/**
* Creates an object entries definition from a list of keys and a schema.
*
* @param list A list of keys.
* @param schema The schema of the keys.
*
* @returns The object entries.
*/
/* @__NO_SIDE_EFFECTS__ */
function entriesFromList(list, schema) {
	const entries$1 = {};
	for (const key of list) entries$1[key] = schema;
	return entries$1;
}
/* @__NO_SIDE_EFFECTS__ */
function entriesFromObjects(schemas) {
	const entries$1 = {};
	for (const schema of schemas) Object.assign(entries$1, schema.entries);
	return entries$1;
}
/* @__NO_SIDE_EFFECTS__ */
function getDotPath(issue) {
	if (issue.path) {
		let key = "";
		for (const item of issue.path) if (typeof item.key === "string" || typeof item.key === "number") if (key) key += `.${item.key}`;
		else key += item.key;
		else return null;
		return key;
	}
	return null;
}
/**
* A generic type guard to check the kind of an object.
*
* @param kind The kind to check for.
* @param object The object to check.
*
* @returns Whether it matches.
*/
/* @__NO_SIDE_EFFECTS__ */
function isOfKind(kind, object$1) {
	return object$1.kind === kind;
}
/**
* A generic type guard to check the type of an object.
*
* @param type The type to check for.
* @param object The object to check.
*
* @returns Whether it matches.
*/
/* @__NO_SIDE_EFFECTS__ */
function isOfType(type, object$1) {
	return object$1.type === type;
}
/**
* A type guard to check if an error is a ValiError.
*
* @param error The error to check.
*
* @returns Whether its a ValiError.
*/
/* @__NO_SIDE_EFFECTS__ */
function isValiError(error) {
	return error instanceof ValiError;
}
/**
* A Valibot error with useful information.
*/
var ValiError = class extends Error {
	/**
	* Creates a Valibot error with useful information.
	*
	* @param issues The error issues.
	*/
	constructor(issues) {
		super(issues[0].message);
		this.name = "ValiError";
		this.issues = issues;
	}
};
/* @__NO_SIDE_EFFECTS__ */
function args(schema) {
	return {
		kind: "transformation",
		type: "args",
		reference: args,
		async: false,
		schema,
		"~run"(dataset, config$1) {
			const func = dataset.value;
			dataset.value = (...args_) => {
				const argsDataset = this.schema["~run"]({ value: args_ }, config$1);
				if (argsDataset.issues) throw new ValiError(argsDataset.issues);
				return func(...argsDataset.value);
			};
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function argsAsync(schema) {
	return {
		kind: "transformation",
		type: "args",
		reference: argsAsync,
		async: false,
		schema,
		"~run"(dataset, config$1) {
			const func = dataset.value;
			dataset.value = async (...args$1) => {
				const argsDataset = await schema["~run"]({ value: args$1 }, config$1);
				if (argsDataset.issues) throw new ValiError(argsDataset.issues);
				return func(...argsDataset.value);
			};
			return dataset;
		}
	};
}
/**
* Creates an await transformation action.
*
* @returns An await action.
*/
/* @__NO_SIDE_EFFECTS__ */
function awaitAsync() {
	return {
		kind: "transformation",
		type: "await",
		reference: awaitAsync,
		async: true,
		async "~run"(dataset) {
			dataset.value = await dataset.value;
			return dataset;
		}
	};
}
/**
* [Base64](https://en.wikipedia.org/wiki/Base64) regex.
*/
var BASE64_REGEX = /^(?:[\da-z+/]{4})*(?:[\da-z+/]{2}==|[\da-z+/]{3}=)?$/iu;
/**
* [BIC](https://en.wikipedia.org/wiki/ISO_9362) regex.
*/
var BIC_REGEX = /^[A-Z]{6}(?!00)[\dA-Z]{2}(?:[\dA-Z]{3})?$/u;
/**
* [Cuid2](https://github.com/paralleldrive/cuid2) regex.
*/
var CUID2_REGEX = /^[a-z][\da-z]*$/u;
/**
* [Decimal](https://en.wikipedia.org/wiki/Decimal) regex.
*/
var DECIMAL_REGEX = /^[+-]?(?:\d*\.)?\d+$/u;
/**
* [Digits](https://en.wikipedia.org/wiki/Numerical_digit) regex.
*/
var DIGITS_REGEX = /^\d+$/u;
/**
* [Domain name](https://en.wikipedia.org/wiki/Domain_name) regex.
*
* Hint: We decided against the `i` flag for better JSON Schema compatibility.
* ASCII-only validation. Internationalized domain names (IDNs) are not
* supported, including Punycode-encoded labels.
*/
var DOMAIN_REGEX = /^(?=.{1,253}$)(?:(?![Xx][Nn]--)[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}$/u;
/**
* [Email address](https://en.wikipedia.org/wiki/Email_address) regex.
*/
var EMAIL_REGEX = /^[\w+-]+(?:\.[\w+-]+)*@[\da-z]+(?:[.-][\da-z]+)*\.[a-z]{2,}$/iu;
/**
* Emoji regex from [emoji-regex-xs](https://github.com/slevithan/emoji-regex-xs) v1.0.0 (MIT license).
*
* Hint: We decided against the newer `/^\p{RGI_Emoji}+$/v` regex because it is
* not supported in older runtimes and does not match all emoji.
*/
var EMOJI_REGEX = /^(?:[\u{1F1E6}-\u{1F1FF}]{2}|\u{1F3F4}[\u{E0061}-\u{E007A}]{2}[\u{E0030}-\u{E0039}\u{E0061}-\u{E007A}]{1,3}\u{E007F}|(?:\p{Emoji}\uFE0F\u20E3?|\p{Emoji_Modifier_Base}\p{Emoji_Modifier}?|(?![\p{Emoji_Modifier_Base}\u{1F1E6}-\u{1F1FF}])\p{Emoji_Presentation})(?:\u200D(?:\p{Emoji}\uFE0F\u20E3?|\p{Emoji_Modifier_Base}\p{Emoji_Modifier}?|(?![\p{Emoji_Modifier_Base}\u{1F1E6}-\u{1F1FF}])\p{Emoji_Presentation}))*)+$/u;
/**
* [Hexadecimal](https://en.wikipedia.org/wiki/Hexadecimal) regex.
*
* Hint: We decided against the `i` flag for better JSON Schema compatibility.
*/
var HEXADECIMAL_REGEX = /^(?:0[hx])?[\da-fA-F]+$/u;
/**
* [Hex color](https://en.wikipedia.org/wiki/Web_colors#Hex_triplet) regex.
*
* Hint: We decided against the `i` flag for better JSON Schema compatibility.
*/
var HEX_COLOR_REGEX = /^#(?:[\da-fA-F]{3,4}|[\da-fA-F]{6}|[\da-fA-F]{8})$/u;
/**
* [IMEI](https://en.wikipedia.org/wiki/International_Mobile_Equipment_Identity) regex.
*/
var IMEI_REGEX = /^\d{15}$|^\d{2}-\d{6}-\d{6}-\d$/u;
/**
* [IPv4](https://en.wikipedia.org/wiki/IPv4) regex.
*/
var IPV4_REGEX = /^(?:(?:[1-9]|1\d|2[0-4])?\d|25[0-5])(?:\.(?:(?:[1-9]|1\d|2[0-4])?\d|25[0-5])){3}$/u;
/**
* [IPv6](https://en.wikipedia.org/wiki/IPv6) regex.
*/
var IPV6_REGEX = /^(?:(?:[\da-f]{1,4}:){7}[\da-f]{1,4}|(?:[\da-f]{1,4}:){1,7}:|(?:[\da-f]{1,4}:){1,6}:[\da-f]{1,4}|(?:[\da-f]{1,4}:){1,5}(?::[\da-f]{1,4}){1,2}|(?:[\da-f]{1,4}:){1,4}(?::[\da-f]{1,4}){1,3}|(?:[\da-f]{1,4}:){1,3}(?::[\da-f]{1,4}){1,4}|(?:[\da-f]{1,4}:){1,2}(?::[\da-f]{1,4}){1,5}|[\da-f]{1,4}:(?::[\da-f]{1,4}){1,6}|:(?:(?::[\da-f]{1,4}){1,7}|:)|fe80:(?::[\da-f]{0,4}){0,4}%[\da-z]+|::(?:f{4}(?::0{1,4})?:)?(?:(?:25[0-5]|(?:2[0-4]|1?\d)?\d)\.){3}(?:25[0-5]|(?:2[0-4]|1?\d)?\d)|(?:[\da-f]{1,4}:){1,4}:(?:(?:25[0-5]|(?:2[0-4]|1?\d)?\d)\.){3}(?:25[0-5]|(?:2[0-4]|1?\d)?\d))$/iu;
/**
* [IP](https://en.wikipedia.org/wiki/IP_address) regex.
*/
var IP_REGEX = /^(?:(?:[1-9]|1\d|2[0-4])?\d|25[0-5])(?:\.(?:(?:[1-9]|1\d|2[0-4])?\d|25[0-5])){3}$|^(?:(?:[\da-f]{1,4}:){7}[\da-f]{1,4}|(?:[\da-f]{1,4}:){1,7}:|(?:[\da-f]{1,4}:){1,6}:[\da-f]{1,4}|(?:[\da-f]{1,4}:){1,5}(?::[\da-f]{1,4}){1,2}|(?:[\da-f]{1,4}:){1,4}(?::[\da-f]{1,4}){1,3}|(?:[\da-f]{1,4}:){1,3}(?::[\da-f]{1,4}){1,4}|(?:[\da-f]{1,4}:){1,2}(?::[\da-f]{1,4}){1,5}|[\da-f]{1,4}:(?::[\da-f]{1,4}){1,6}|:(?:(?::[\da-f]{1,4}){1,7}|:)|fe80:(?::[\da-f]{0,4}){0,4}%[\da-z]+|::(?:f{4}(?::0{1,4})?:)?(?:(?:25[0-5]|(?:2[0-4]|1?\d)?\d)\.){3}(?:25[0-5]|(?:2[0-4]|1?\d)?\d)|(?:[\da-f]{1,4}:){1,4}:(?:(?:25[0-5]|(?:2[0-4]|1?\d)?\d)\.){3}(?:25[0-5]|(?:2[0-4]|1?\d)?\d))$/iu;
/**
* [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) date regex.
*/
var ISO_DATE_REGEX = /^\d{4}-(?:0[1-9]|1[0-2])-(?:[12]\d|0[1-9]|3[01])$/u;
/**
* [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) date-time regex.
*/
var ISO_DATE_TIME_REGEX = /^\d{4}-(?:0[1-9]|1[0-2])-(?:[12]\d|0[1-9]|3[01])[T ](?:0\d|1\d|2[0-3]):[0-5]\d$/u;
/**
* [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) date-time with seconds regex.
*/
var ISO_DATE_TIME_SECOND_REGEX = /^\d{4}-(?:0[1-9]|1[0-2])-(?:[12]\d|0[1-9]|3[01])[T ](?:0\d|1\d|2[0-3])(?::[0-5]\d){2}$/u;
/**
* [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) time regex.
*/
var ISO_TIME_REGEX = /^(?:0\d|1\d|2[0-3]):[0-5]\d$/u;
/**
* [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) time with seconds regex.
*/
var ISO_TIME_SECOND_REGEX = /^(?:0\d|1\d|2[0-3])(?::[0-5]\d){2}$/u;
/**
* [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) timestamp regex. Allows a
* space as a date/time separator and an optional space before the UTC offset.
*/
var ISO_TIMESTAMP_REGEX = /^\d{4}-(?:0[1-9]|1[0-2])-(?:[12]\d|0[1-9]|3[01])[T ](?:0\d|1\d|2[0-3])(?::[0-5]\d){2}(?:\.\d{1,9})?(?:Z| ?[+-](?:0\d|1\d|2[0-3])(?::?[0-5]\d)?)$/u;
/**
* [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) week regex.
*/
var ISO_WEEK_REGEX = /^\d{4}-W(?:0[1-9]|[1-4]\d|5[0-3])$/u;
/**
* [JWS compact serialization](https://datatracker.ietf.org/doc/html/rfc7515#section-3.1)
* regex.
*
* Hint: Empty payload and signature segments are allowed because the
* Base64URL-encoded representation of an empty octet sequence is an empty
* string.
*/
var JWS_COMPACT_REGEX = /^(?:[\w-]{2,3}|(?:[\w-]{4})+(?:[\w-]{2,3})?)\.(?:[\w-]{2,3}|(?:[\w-]{4})+(?:[\w-]{2,3})?)?\.(?:[\w-]{2,3}|(?:[\w-]{4})+(?:[\w-]{2,3})?)?$/u;
/**
* [ISRC](https://en.wikipedia.org/wiki/International_Standard_Recording_Code) regex.
*/
var ISRC_REGEX = /^(?:[A-Z]{2}[A-Z\d]{3}\d{7}|[A-Z]{2}-[A-Z\d]{3}-\d{2}-\d{5})$/u;
/**
* [MAC](https://en.wikipedia.org/wiki/MAC_address) 48 bit regex.
*
* Hint: We decided against the `i` flag for better JSON Schema compatibility.
*/
var MAC48_REGEX = /^(?:[\da-fA-F]{2}:){5}[\da-fA-F]{2}$|^(?:[\da-fA-F]{2}-){5}[\da-fA-F]{2}$|^(?:[\da-fA-F]{4}\.){2}[\da-fA-F]{4}$/u;
/**
* [MAC](https://en.wikipedia.org/wiki/MAC_address) 64 bit regex.
*
* Hint: We decided against the `i` flag for better JSON Schema compatibility.
*/
var MAC64_REGEX = /^(?:[\da-fA-F]{2}:){7}[\da-fA-F]{2}$|^(?:[\da-fA-F]{2}-){7}[\da-fA-F]{2}$|^(?:[\da-fA-F]{4}\.){3}[\da-fA-F]{4}$|^(?:[\da-fA-F]{4}:){3}[\da-fA-F]{4}$/u;
/**
* [MAC](https://en.wikipedia.org/wiki/MAC_address) regex.
*
* Hint: We decided against the `i` flag for better JSON Schema compatibility.
*/
var MAC_REGEX = /^(?:[\da-fA-F]{2}:){5}[\da-fA-F]{2}$|^(?:[\da-fA-F]{2}-){5}[\da-fA-F]{2}$|^(?:[\da-fA-F]{4}\.){2}[\da-fA-F]{4}$|^(?:[\da-fA-F]{2}:){7}[\da-fA-F]{2}$|^(?:[\da-fA-F]{2}-){7}[\da-fA-F]{2}$|^(?:[\da-fA-F]{4}\.){3}[\da-fA-F]{4}$|^(?:[\da-fA-F]{4}:){3}[\da-fA-F]{4}$/u;
/**
* [Nano ID](https://github.com/ai/nanoid) regex.
*/
var NANO_ID_REGEX = /^[\w-]+$/u;
/**
* [Octal](https://en.wikipedia.org/wiki/Octal) regex.
*/
var OCTAL_REGEX = /^(?:0o)?[0-7]+$/u;
/**
* [RFC 5322 email address](https://datatracker.ietf.org/doc/html/rfc5322#section-3.4.1) regex.
*
* Hint: This regex was taken from the [HTML Living Standard Specification](https://html.spec.whatwg.org/multipage/input.html#valid-e-mail-address) and does not perfectly represent RFC 5322.
*/
var RFC_EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
/**
* [Slug](https://en.wikipedia.org/wiki/Clean_URL#Slug) regex.
*/
var SLUG_REGEX = /^[\da-z]+(?:[-_][\da-z]+)*$/u;
/**
* [ULID](https://github.com/ulid/spec) regex.
*
* Hint: We decided against the `i` flag for better JSON Schema compatibility.
*/
var ULID_REGEX = /^[\da-hjkmnp-tv-zA-HJKMNP-TV-Z]{26}$/u;
/**
* [UUID](https://en.wikipedia.org/wiki/Universally_unique_identifier) regex.
*/
var UUID_REGEX = /^[\da-f]{8}(?:-[\da-f]{4}){3}-[\da-f]{12}$/iu;
/* @__NO_SIDE_EFFECTS__ */
function base64(message$1) {
	return {
		kind: "validation",
		type: "base64",
		reference: base64,
		async: false,
		expects: null,
		requirement: BASE64_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "Base64", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function bic(message$1) {
	return {
		kind: "validation",
		type: "bic",
		reference: bic,
		async: false,
		expects: null,
		requirement: BIC_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "BIC", dataset, config$1);
			return dataset;
		}
	};
}
/**
* Creates a brand transformation action.
*
* @param name The brand name.
*
* @returns A brand action.
*/
/* @__NO_SIDE_EFFECTS__ */
function brand(name) {
	return {
		kind: "transformation",
		type: "brand",
		reference: brand,
		async: false,
		name,
		"~run"(dataset) {
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function bytes(requirement, message$1) {
	return {
		kind: "validation",
		type: "bytes",
		reference: bytes,
		async: false,
		expects: `${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) {
				const length$1 = /* @__PURE__ */ _getByteCount(dataset.value);
				if (length$1 !== this.requirement) _addIssue(this, "bytes", dataset, config$1, { received: `${length$1}` });
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function check(requirement, message$1) {
	return {
		kind: "validation",
		type: "check",
		reference: check,
		async: false,
		expects: null,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "input", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function checkAsync(requirement, message$1) {
	return {
		kind: "validation",
		type: "check",
		reference: checkAsync,
		async: true,
		expects: null,
		requirement,
		message: message$1,
		async "~run"(dataset, config$1) {
			if (dataset.typed && !await this.requirement(dataset.value)) _addIssue(this, "input", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function checkItems(requirement, message$1) {
	return {
		kind: "validation",
		type: "check_items",
		reference: checkItems,
		async: false,
		expects: null,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) for (let index = 0; index < dataset.value.length; index++) {
				const item = dataset.value[index];
				if (!this.requirement(item, index, dataset.value)) _addIssue(this, "item", dataset, config$1, {
					input: item,
					path: [{
						type: "array",
						origin: "value",
						input: dataset.value,
						key: index,
						value: item
					}]
				});
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function checkItemsAsync(requirement, message$1) {
	return {
		kind: "validation",
		type: "check_items",
		reference: checkItemsAsync,
		async: true,
		expects: null,
		requirement,
		message: message$1,
		async "~run"(dataset, config$1) {
			if (dataset.typed) {
				const requirementResults = await Promise.all(dataset.value.map(this.requirement));
				for (let index = 0; index < dataset.value.length; index++) if (!requirementResults[index]) {
					const item = dataset.value[index];
					_addIssue(this, "item", dataset, config$1, {
						input: item,
						path: [{
							type: "array",
							origin: "value",
							input: dataset.value,
							key: index,
							value: item
						}]
					});
				}
			}
			return dataset;
		}
	};
}
/**
* Credit card regex.
*/
var CREDIT_CARD_REGEX = /^(?:\d{13,19}|\d{4}(?: \d{3,6}){2,4}|\d{4}(?:-\d{3,6}){2,4})$/u;
/**
* Sanitize regex.
*/
var SANITIZE_REGEX = /[- ]/gu;
/**
* Provider regex list.
*/
var PROVIDER_REGEX_LIST = [
	/^3[47]\d{13}$/u,
	/^3(?:0[0-5]|[68]\d)\d{11,13}$/u,
	/^6(?:011|5\d{2})\d{12,15}$/u,
	/^(?:2131|1800|35\d{3})\d{11}$/u,
	/^(?:5[1-5]\d{2}|222\d|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)\d{12}$/u,
	/^(?:6[27]\d{14,17}|81\d{14,17})$/u,
	/^4\d{12}(?:\d{3,6})?$/u
];
/* @__NO_SIDE_EFFECTS__ */
function creditCard(message$1) {
	return {
		kind: "validation",
		type: "credit_card",
		reference: creditCard,
		async: false,
		expects: null,
		requirement(input) {
			let sanitized;
			return CREDIT_CARD_REGEX.test(input) && (sanitized = input.replace(SANITIZE_REGEX, "")) && PROVIDER_REGEX_LIST.some((regex$1) => regex$1.test(sanitized)) && /* @__PURE__ */ _isLuhnAlgo(sanitized);
		},
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "credit card", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function cuid2(message$1) {
	return {
		kind: "validation",
		type: "cuid2",
		reference: cuid2,
		async: false,
		expects: null,
		requirement: CUID2_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "Cuid2", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function decimal(message$1) {
	return {
		kind: "validation",
		type: "decimal",
		reference: decimal,
		async: false,
		expects: null,
		requirement: DECIMAL_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "decimal", dataset, config$1);
			return dataset;
		}
	};
}
/**
* Creates a description metadata action.
*
* @param description_ The description text.
*
* @returns A description action.
*/
/* @__NO_SIDE_EFFECTS__ */
function description(description_) {
	return {
		kind: "metadata",
		type: "description",
		reference: description,
		description: description_
	};
}
/* @__NO_SIDE_EFFECTS__ */
function digits(message$1) {
	return {
		kind: "validation",
		type: "digits",
		reference: digits,
		async: false,
		expects: null,
		requirement: DIGITS_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "digits", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function domain(message$1) {
	return {
		kind: "validation",
		type: "domain",
		reference: domain,
		expects: null,
		async: false,
		requirement: DOMAIN_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "domain", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function email(message$1) {
	return {
		kind: "validation",
		type: "email",
		reference: email,
		expects: null,
		async: false,
		requirement: EMAIL_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "email", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function emoji(message$1) {
	return {
		kind: "validation",
		type: "emoji",
		reference: emoji,
		async: false,
		expects: null,
		requirement: EMOJI_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "emoji", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function empty(message$1) {
	return {
		kind: "validation",
		type: "empty",
		reference: empty,
		async: false,
		expects: "0",
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && dataset.value.length > 0) _addIssue(this, "length", dataset, config$1, { received: `${dataset.value.length}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function endsWith(requirement, message$1) {
	return {
		kind: "validation",
		type: "ends_with",
		reference: endsWith,
		async: false,
		expects: `"${requirement}"`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !dataset.value.endsWith(this.requirement)) _addIssue(this, "end", dataset, config$1, { received: `"${dataset.value.slice(-this.requirement.length)}"` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function entries(requirement, message$1) {
	return {
		kind: "validation",
		type: "entries",
		reference: entries,
		async: false,
		expects: `${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (!dataset.typed) return dataset;
			const count = Object.keys(dataset.value).length;
			if (dataset.typed && count !== this.requirement) _addIssue(this, "entries", dataset, config$1, { received: `${count}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function everyItem(requirement, message$1) {
	return {
		kind: "validation",
		type: "every_item",
		reference: everyItem,
		async: false,
		expects: null,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !dataset.value.every(this.requirement)) _addIssue(this, "item", dataset, config$1);
			return dataset;
		}
	};
}
/**
* Creates an examples metadata action.
*
* @param examples_ The examples.
*
* @returns An examples action.
*
* @beta
*/
/* @__NO_SIDE_EFFECTS__ */
function examples(examples_) {
	return {
		kind: "metadata",
		type: "examples",
		reference: examples,
		examples: examples_
	};
}
/* @__NO_SIDE_EFFECTS__ */
function excludes(requirement, message$1) {
	const received = /* @__PURE__ */ _stringify(requirement);
	return {
		kind: "validation",
		type: "excludes",
		reference: excludes,
		async: false,
		expects: `!${received}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && dataset.value.includes(this.requirement)) _addIssue(this, "content", dataset, config$1, { received });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function filterItems(operation) {
	return {
		kind: "transformation",
		type: "filter_items",
		reference: filterItems,
		async: false,
		operation,
		"~run"(dataset) {
			dataset.value = dataset.value.filter(this.operation);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function findItem(operation) {
	return {
		kind: "transformation",
		type: "find_item",
		reference: findItem,
		async: false,
		operation,
		"~run"(dataset) {
			dataset.value = dataset.value.find(this.operation);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function finite(message$1) {
	return {
		kind: "validation",
		type: "finite",
		reference: finite,
		async: false,
		expects: null,
		requirement: Number.isFinite,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "finite", dataset, config$1);
			return dataset;
		}
	};
}
/**
* Creates a flavor transformation action.
*
* @param name The flavor name.
*
* @returns A flavor action.
*
* @beta
*/
/* @__NO_SIDE_EFFECTS__ */
function flavor(name) {
	return {
		kind: "transformation",
		type: "flavor",
		reference: flavor,
		async: false,
		name,
		"~run"(dataset) {
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function graphemes(requirement, message$1) {
	return {
		kind: "validation",
		type: "graphemes",
		reference: graphemes,
		async: false,
		expects: `${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) {
				const count = /* @__PURE__ */ _getGraphemeCount(dataset.value);
				if (count !== this.requirement) _addIssue(this, "graphemes", dataset, config$1, { received: `${count}` });
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function gtValue(requirement, message$1) {
	return {
		kind: "validation",
		type: "gt_value",
		reference: gtValue,
		async: false,
		expects: `>${requirement instanceof Date ? requirement.toJSON() : /* @__PURE__ */ _stringify(requirement)}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !(dataset.value > this.requirement)) _addIssue(this, "value", dataset, config$1, { received: dataset.value instanceof Date ? dataset.value.toJSON() : /* @__PURE__ */ _stringify(dataset.value) });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function guard(requirement, message$1) {
	return {
		kind: "transformation",
		type: "guard",
		reference: guard,
		async: false,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement(dataset.value)) {
				_addIssue(this, "input", dataset, config$1);
				dataset.typed = false;
			}
			return dataset;
		}
	};
}
/**
* Hash lengths object.
*/
var HASH_LENGTHS = {
	md4: 32,
	md5: 32,
	sha1: 40,
	sha256: 64,
	sha384: 96,
	sha512: 128,
	ripemd128: 32,
	ripemd160: 40,
	tiger128: 32,
	tiger160: 40,
	tiger192: 48,
	crc32: 8,
	crc32b: 8,
	adler32: 8
};
/* @__NO_SIDE_EFFECTS__ */
function hash(types, message$1) {
	return {
		kind: "validation",
		type: "hash",
		reference: hash,
		expects: null,
		async: false,
		requirement: RegExp(types.map((type) => `^[a-fA-F0-9]{${HASH_LENGTHS[type]}}$`).join("|"), "u"),
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "hash", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function hexadecimal(message$1) {
	return {
		kind: "validation",
		type: "hexadecimal",
		reference: hexadecimal,
		async: false,
		expects: null,
		requirement: HEXADECIMAL_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "hexadecimal", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function hexColor(message$1) {
	return {
		kind: "validation",
		type: "hex_color",
		reference: hexColor,
		async: false,
		expects: null,
		requirement: HEX_COLOR_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "hex color", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function imei(message$1) {
	return {
		kind: "validation",
		type: "imei",
		reference: imei,
		async: false,
		expects: null,
		requirement(input) {
			return IMEI_REGEX.test(input) && /* @__PURE__ */ _isLuhnAlgo(input);
		},
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "IMEI", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function includes(requirement, message$1) {
	const expects = /* @__PURE__ */ _stringify(requirement);
	return {
		kind: "validation",
		type: "includes",
		reference: includes,
		async: false,
		expects,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !dataset.value.includes(this.requirement)) _addIssue(this, "content", dataset, config$1, { received: `!${expects}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function integer(message$1) {
	return {
		kind: "validation",
		type: "integer",
		reference: integer,
		async: false,
		expects: null,
		requirement: Number.isInteger,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "integer", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function ip(message$1) {
	return {
		kind: "validation",
		type: "ip",
		reference: ip,
		async: false,
		expects: null,
		requirement: IP_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "IP", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function ipv4(message$1) {
	return {
		kind: "validation",
		type: "ipv4",
		reference: ipv4,
		async: false,
		expects: null,
		requirement: IPV4_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "IPv4", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function ipv6(message$1) {
	return {
		kind: "validation",
		type: "ipv6",
		reference: ipv6,
		async: false,
		expects: null,
		requirement: IPV6_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "IPv6", dataset, config$1);
			return dataset;
		}
	};
}
/**
* [Validates an ISBN-10](https://en.wikipedia.org/wiki/ISBN#ISBN-10_check_digits).
*
* @param input The input value.
*
* @returns `true` if the input is a valid ISBN-10, `false` otherwise.
*
* @internal
*/
function _isIsbn10(input) {
	const digits$1 = input.split("").map((c) => c === "X" ? 10 : parseInt(c));
	let sum = 0;
	for (let i = 0; i < 10; i++) sum += digits$1[i] * (10 - i);
	return sum % 11 === 0;
}
/**
* [Validates an ISBN-13](https://en.wikipedia.org/wiki/ISBN#ISBN-13_check_digit_calculation).
*
* @param input The input value.
*
* @returns `true` if the input is a valid ISBN-13, `false` otherwise.
*
* @internal
*/
function _isIsbn13(input) {
	const digits$1 = input.split("").map((c) => parseInt(c));
	let sum = 0;
	for (let i = 0; i < 13; i++) sum += digits$1[i] * (i % 2 === 0 ? 1 : 3);
	return sum % 10 === 0;
}
/**
* ISBN separator regex.
*/
var ISBN_SEPARATOR_REGEX = /[- ]/gu;
/**
* ISBN-10 detection regex.
*/
var ISBN_10_DETECTION_REGEX = /^\d{9}[\dX]$/u;
/**
* ISBN-13 detection regex.
*/
var ISBN_13_DETECTION_REGEX = /^\d{13}$/u;
/* @__NO_SIDE_EFFECTS__ */
function isbn(message$1) {
	return {
		kind: "validation",
		type: "isbn",
		reference: isbn,
		async: false,
		expects: null,
		requirement(input) {
			const replacedInput = input.replace(ISBN_SEPARATOR_REGEX, "");
			if (ISBN_10_DETECTION_REGEX.test(replacedInput)) return _isIsbn10(replacedInput);
			else if (ISBN_13_DETECTION_REGEX.test(replacedInput)) return _isIsbn13(replacedInput);
			return false;
		},
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "ISBN", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function isrc(message$1) {
	return {
		kind: "validation",
		type: "isrc",
		reference: isrc,
		async: false,
		expects: null,
		requirement: ISRC_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "ISRC", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function isoDate(message$1) {
	return {
		kind: "validation",
		type: "iso_date",
		reference: isoDate,
		async: false,
		expects: null,
		requirement: ISO_DATE_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "date", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function isoDateTime(message$1) {
	return {
		kind: "validation",
		type: "iso_date_time",
		reference: isoDateTime,
		async: false,
		expects: null,
		requirement: ISO_DATE_TIME_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "date-time", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function isoDateTimeSecond(message$1) {
	return {
		kind: "validation",
		type: "iso_date_time_second",
		reference: isoDateTimeSecond,
		async: false,
		expects: null,
		requirement: ISO_DATE_TIME_SECOND_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "date-time-second", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function isoTime(message$1) {
	return {
		kind: "validation",
		type: "iso_time",
		reference: isoTime,
		async: false,
		expects: null,
		requirement: ISO_TIME_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "time", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function isoTimeSecond(message$1) {
	return {
		kind: "validation",
		type: "iso_time_second",
		reference: isoTimeSecond,
		async: false,
		expects: null,
		requirement: ISO_TIME_SECOND_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "time-second", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function isoTimestamp(message$1) {
	return {
		kind: "validation",
		type: "iso_timestamp",
		reference: isoTimestamp,
		async: false,
		expects: null,
		requirement: ISO_TIMESTAMP_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "timestamp", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function isoWeek(message$1) {
	return {
		kind: "validation",
		type: "iso_week",
		reference: isoWeek,
		async: false,
		expects: null,
		requirement: ISO_WEEK_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "week", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function jwsCompact(message$1) {
	return {
		kind: "validation",
		type: "jws_compact",
		reference: jwsCompact,
		async: false,
		expects: null,
		requirement: JWS_COMPACT_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "JWS compact", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function length(requirement, message$1) {
	return {
		kind: "validation",
		type: "length",
		reference: length,
		async: false,
		expects: `${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && dataset.value.length !== this.requirement) _addIssue(this, "length", dataset, config$1, { received: `${dataset.value.length}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function ltValue(requirement, message$1) {
	return {
		kind: "validation",
		type: "lt_value",
		reference: ltValue,
		async: false,
		expects: `<${requirement instanceof Date ? requirement.toJSON() : /* @__PURE__ */ _stringify(requirement)}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !(dataset.value < this.requirement)) _addIssue(this, "value", dataset, config$1, { received: dataset.value instanceof Date ? dataset.value.toJSON() : /* @__PURE__ */ _stringify(dataset.value) });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function mac(message$1) {
	return {
		kind: "validation",
		type: "mac",
		reference: mac,
		async: false,
		expects: null,
		requirement: MAC_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "MAC", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function mac48(message$1) {
	return {
		kind: "validation",
		type: "mac48",
		reference: mac48,
		async: false,
		expects: null,
		requirement: MAC48_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "48-bit MAC", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function mac64(message$1) {
	return {
		kind: "validation",
		type: "mac64",
		reference: mac64,
		async: false,
		expects: null,
		requirement: MAC64_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "64-bit MAC", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function mapItems(operation) {
	return {
		kind: "transformation",
		type: "map_items",
		reference: mapItems,
		async: false,
		operation,
		"~run"(dataset) {
			dataset.value = dataset.value.map(this.operation);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function maxBytes(requirement, message$1) {
	return {
		kind: "validation",
		type: "max_bytes",
		reference: maxBytes,
		async: false,
		expects: `<=${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) {
				const length$1 = /* @__PURE__ */ _getByteCount(dataset.value);
				if (length$1 > this.requirement) _addIssue(this, "bytes", dataset, config$1, { received: `${length$1}` });
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function maxEntries(requirement, message$1) {
	return {
		kind: "validation",
		type: "max_entries",
		reference: maxEntries,
		async: false,
		expects: `<=${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (!dataset.typed) return dataset;
			const count = Object.keys(dataset.value).length;
			if (dataset.typed && count > this.requirement) _addIssue(this, "entries", dataset, config$1, { received: `${count}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function maxGraphemes(requirement, message$1) {
	return {
		kind: "validation",
		type: "max_graphemes",
		reference: maxGraphemes,
		async: false,
		expects: `<=${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) {
				const count = /* @__PURE__ */ _getGraphemeCount(dataset.value);
				if (count > this.requirement) _addIssue(this, "graphemes", dataset, config$1, { received: `${count}` });
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function maxLength(requirement, message$1) {
	return {
		kind: "validation",
		type: "max_length",
		reference: maxLength,
		async: false,
		expects: `<=${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && dataset.value.length > this.requirement) _addIssue(this, "length", dataset, config$1, { received: `${dataset.value.length}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function maxSize(requirement, message$1) {
	return {
		kind: "validation",
		type: "max_size",
		reference: maxSize,
		async: false,
		expects: `<=${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && dataset.value.size > this.requirement) _addIssue(this, "size", dataset, config$1, { received: `${dataset.value.size}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function maxValue(requirement, message$1) {
	return {
		kind: "validation",
		type: "max_value",
		reference: maxValue,
		async: false,
		expects: `<=${requirement instanceof Date ? requirement.toJSON() : /* @__PURE__ */ _stringify(requirement)}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !(dataset.value <= this.requirement)) _addIssue(this, "value", dataset, config$1, { received: dataset.value instanceof Date ? dataset.value.toJSON() : /* @__PURE__ */ _stringify(dataset.value) });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function maxWords(locales, requirement, message$1) {
	return {
		kind: "validation",
		type: "max_words",
		reference: maxWords,
		async: false,
		expects: `<=${requirement}`,
		locales,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) {
				const count = /* @__PURE__ */ _getWordCount(this.locales, dataset.value);
				if (count > this.requirement) _addIssue(this, "words", dataset, config$1, { received: `${count}` });
			}
			return dataset;
		}
	};
}
/**
* Creates a custom metadata action.
*
* @param metadata_ The metadata object.
*
* @returns A metadata action.
*/
/* @__NO_SIDE_EFFECTS__ */
function metadata(metadata_) {
	return {
		kind: "metadata",
		type: "metadata",
		reference: metadata,
		metadata: metadata_
	};
}
/* @__NO_SIDE_EFFECTS__ */
function mimeType(requirement, message$1) {
	return {
		kind: "validation",
		type: "mime_type",
		reference: mimeType,
		async: false,
		expects: /* @__PURE__ */ _joinExpects(requirement.map((option) => `"${option}"`), "|"),
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.includes(dataset.value.type)) _addIssue(this, "MIME type", dataset, config$1, { received: `"${dataset.value.type}"` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function minBytes(requirement, message$1) {
	return {
		kind: "validation",
		type: "min_bytes",
		reference: minBytes,
		async: false,
		expects: `>=${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) {
				const length$1 = /* @__PURE__ */ _getByteCount(dataset.value);
				if (length$1 < this.requirement) _addIssue(this, "bytes", dataset, config$1, { received: `${length$1}` });
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function minEntries(requirement, message$1) {
	return {
		kind: "validation",
		type: "min_entries",
		reference: minEntries,
		async: false,
		expects: `>=${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (!dataset.typed) return dataset;
			const count = Object.keys(dataset.value).length;
			if (dataset.typed && count < this.requirement) _addIssue(this, "entries", dataset, config$1, { received: `${count}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function minGraphemes(requirement, message$1) {
	return {
		kind: "validation",
		type: "min_graphemes",
		reference: minGraphemes,
		async: false,
		expects: `>=${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) {
				const count = /* @__PURE__ */ _getGraphemeCount(dataset.value);
				if (count < this.requirement) _addIssue(this, "graphemes", dataset, config$1, { received: `${count}` });
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function minLength(requirement, message$1) {
	return {
		kind: "validation",
		type: "min_length",
		reference: minLength,
		async: false,
		expects: `>=${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && dataset.value.length < this.requirement) _addIssue(this, "length", dataset, config$1, { received: `${dataset.value.length}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function minSize(requirement, message$1) {
	return {
		kind: "validation",
		type: "min_size",
		reference: minSize,
		async: false,
		expects: `>=${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && dataset.value.size < this.requirement) _addIssue(this, "size", dataset, config$1, { received: `${dataset.value.size}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function minValue(requirement, message$1) {
	return {
		kind: "validation",
		type: "min_value",
		reference: minValue,
		async: false,
		expects: `>=${requirement instanceof Date ? requirement.toJSON() : /* @__PURE__ */ _stringify(requirement)}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !(dataset.value >= this.requirement)) _addIssue(this, "value", dataset, config$1, { received: dataset.value instanceof Date ? dataset.value.toJSON() : /* @__PURE__ */ _stringify(dataset.value) });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function minWords(locales, requirement, message$1) {
	return {
		kind: "validation",
		type: "min_words",
		reference: minWords,
		async: false,
		expects: `>=${requirement}`,
		locales,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) {
				const count = /* @__PURE__ */ _getWordCount(this.locales, dataset.value);
				if (count < this.requirement) _addIssue(this, "words", dataset, config$1, { received: `${count}` });
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function multipleOf(requirement, message$1) {
	return {
		kind: "validation",
		type: "multiple_of",
		reference: multipleOf,
		async: false,
		expects: `%${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && dataset.value % this.requirement != 0) _addIssue(this, "multiple", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nanoid(message$1) {
	return {
		kind: "validation",
		type: "nanoid",
		reference: nanoid,
		async: false,
		expects: null,
		requirement: NANO_ID_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "Nano ID", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nonEmpty(message$1) {
	return {
		kind: "validation",
		type: "non_empty",
		reference: nonEmpty,
		async: false,
		expects: "!0",
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && dataset.value.length === 0) _addIssue(this, "length", dataset, config$1, { received: "0" });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function normalize(form) {
	return {
		kind: "transformation",
		type: "normalize",
		reference: normalize,
		async: false,
		form,
		"~run"(dataset) {
			dataset.value = dataset.value.normalize(this.form);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function notBytes(requirement, message$1) {
	return {
		kind: "validation",
		type: "not_bytes",
		reference: notBytes,
		async: false,
		expects: `!${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) {
				const length$1 = /* @__PURE__ */ _getByteCount(dataset.value);
				if (length$1 === this.requirement) _addIssue(this, "bytes", dataset, config$1, { received: `${length$1}` });
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function notEntries(requirement, message$1) {
	return {
		kind: "validation",
		type: "not_entries",
		reference: notEntries,
		async: false,
		expects: `!${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (!dataset.typed) return dataset;
			const count = Object.keys(dataset.value).length;
			if (dataset.typed && count === this.requirement) _addIssue(this, "entries", dataset, config$1, { received: `${count}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function notGraphemes(requirement, message$1) {
	return {
		kind: "validation",
		type: "not_graphemes",
		reference: notGraphemes,
		async: false,
		expects: `!${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) {
				const count = /* @__PURE__ */ _getGraphemeCount(dataset.value);
				if (count === this.requirement) _addIssue(this, "graphemes", dataset, config$1, { received: `${count}` });
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function notLength(requirement, message$1) {
	return {
		kind: "validation",
		type: "not_length",
		reference: notLength,
		async: false,
		expects: `!${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && dataset.value.length === this.requirement) _addIssue(this, "length", dataset, config$1, { received: `${dataset.value.length}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function notSize(requirement, message$1) {
	return {
		kind: "validation",
		type: "not_size",
		reference: notSize,
		async: false,
		expects: `!${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && dataset.value.size === this.requirement) _addIssue(this, "size", dataset, config$1, { received: `${dataset.value.size}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function notValue(requirement, message$1) {
	return {
		kind: "validation",
		type: "not_value",
		reference: notValue,
		async: false,
		expects: requirement instanceof Date ? `!${requirement.toJSON()}` : `!${/* @__PURE__ */ _stringify(requirement)}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && this.requirement <= dataset.value && this.requirement >= dataset.value) _addIssue(this, "value", dataset, config$1, { received: dataset.value instanceof Date ? dataset.value.toJSON() : /* @__PURE__ */ _stringify(dataset.value) });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function notValues(requirement, message$1) {
	return {
		kind: "validation",
		type: "not_values",
		reference: notValues,
		async: false,
		expects: `!${/* @__PURE__ */ _joinExpects(requirement.map((value$1) => value$1 instanceof Date ? value$1.toJSON() : /* @__PURE__ */ _stringify(value$1)), "|")}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && this.requirement.some((value$1) => value$1 <= dataset.value && value$1 >= dataset.value)) _addIssue(this, "value", dataset, config$1, { received: dataset.value instanceof Date ? dataset.value.toJSON() : /* @__PURE__ */ _stringify(dataset.value) });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function notWords(locales, requirement, message$1) {
	return {
		kind: "validation",
		type: "not_words",
		reference: notWords,
		async: false,
		expects: `!${requirement}`,
		locales,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) {
				const count = /* @__PURE__ */ _getWordCount(this.locales, dataset.value);
				if (count === this.requirement) _addIssue(this, "words", dataset, config$1, { received: `${count}` });
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function octal(message$1) {
	return {
		kind: "validation",
		type: "octal",
		reference: octal,
		async: false,
		expects: null,
		requirement: OCTAL_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "octal", dataset, config$1);
			return dataset;
		}
	};
}
var TRUTHY = [
	true,
	1,
	"true",
	"1",
	"yes",
	"y",
	"on",
	"enabled"
];
var FALSY = [
	false,
	0,
	"false",
	"0",
	"no",
	"n",
	"off",
	"disabled"
];
/* @__NO_SIDE_EFFECTS__ */
function parseBoolean(config$1, message$1) {
	const normalize$1 = (v) => typeof v === "string" ? v.toLowerCase() : v;
	const truthyRaw = config$1?.truthy ?? TRUTHY;
	const falsyRaw = config$1?.falsy ?? FALSY;
	const truthy = config$1?.truthy ? config$1.truthy.map(normalize$1) : TRUTHY;
	const falsy = config$1?.falsy ? config$1.falsy.map(normalize$1) : FALSY;
	return {
		kind: "transformation",
		type: "parse_boolean",
		reference: parseBoolean,
		expects: /* @__PURE__ */ _joinExpects([...truthyRaw, ...falsyRaw].map(_stringify), "|"),
		config: config$1,
		message: message$1,
		async: false,
		"~run"(dataset, config$2) {
			const input = normalize$1(dataset.value);
			if (truthy.includes(input)) dataset.value = true;
			else if (falsy.includes(input)) dataset.value = false;
			else {
				_addIssue(this, "boolean", dataset, config$2);
				dataset.typed = false;
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function parseJson(config$1, message$1) {
	return {
		kind: "transformation",
		type: "parse_json",
		reference: parseJson,
		config: config$1,
		message: message$1,
		async: false,
		"~run"(dataset, config$2) {
			try {
				dataset.value = JSON.parse(dataset.value, this.config?.reviver);
			} catch (error) {
				if (error instanceof Error) {
					_addIssue(this, "JSON", dataset, config$2, { received: `"${error.message}"` });
					dataset.typed = false;
				} else throw error;
			}
			return dataset;
		}
	};
}
/**
* Checks if a dataset is partially typed.
*
* @param dataset The dataset to check.
* @param paths The paths to check.
*
* @returns Whether it is partially typed.
*
* @internal
*/
/* @__NO_SIDE_EFFECTS__ */
function _isPartiallyTyped(dataset, paths) {
	if (dataset.issues) for (const path of paths) for (const issue of dataset.issues) {
		let typed = false;
		const bound = Math.min(path.length, issue.path?.length ?? 0);
		for (let index = 0; index < bound; index++) if (path[index] !== issue.path[index].key && (path[index] !== "$" || issue.path[index].type !== "array")) {
			typed = true;
			break;
		}
		if (!typed) return false;
	}
	return true;
}
/* @__NO_SIDE_EFFECTS__ */
function partialCheck(paths, requirement, message$1) {
	return {
		kind: "validation",
		type: "partial_check",
		reference: partialCheck,
		async: false,
		expects: null,
		paths,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if ((dataset.typed || /* @__PURE__ */ _isPartiallyTyped(dataset, paths)) && !this.requirement(dataset.value)) _addIssue(this, "input", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function partialCheckAsync(paths, requirement, message$1) {
	return {
		kind: "validation",
		type: "partial_check",
		reference: partialCheckAsync,
		async: true,
		expects: null,
		paths,
		requirement,
		message: message$1,
		async "~run"(dataset, config$1) {
			if ((dataset.typed || /* @__PURE__ */ _isPartiallyTyped(dataset, paths)) && !await this.requirement(dataset.value)) _addIssue(this, "input", dataset, config$1);
			return dataset;
		}
	};
}
/**
* Creates a raw check validation action.
*
* @param action The validation action.
*
* @returns A raw check action.
*/
/* @__NO_SIDE_EFFECTS__ */
function rawCheck(action) {
	return {
		kind: "validation",
		type: "raw_check",
		reference: rawCheck,
		async: false,
		expects: null,
		"~run"(dataset, config$1) {
			action({
				dataset,
				config: config$1,
				addIssue: (info) => _addIssue(this, info?.label ?? "input", dataset, config$1, info)
			});
			return dataset;
		}
	};
}
/**
* Creates a raw check validation action.
*
* @param action The validation action.
*
* @returns A raw check action.
*/
/* @__NO_SIDE_EFFECTS__ */
function rawCheckAsync(action) {
	return {
		kind: "validation",
		type: "raw_check",
		reference: rawCheckAsync,
		async: true,
		expects: null,
		async "~run"(dataset, config$1) {
			await action({
				dataset,
				config: config$1,
				addIssue: (info) => _addIssue(this, info?.label ?? "input", dataset, config$1, info)
			});
			return dataset;
		}
	};
}
/**
* Creates a raw transformation action.
*
* @param action The transformation action.
*
* @returns A raw transform action.
*/
/* @__NO_SIDE_EFFECTS__ */
function rawTransform(action) {
	return {
		kind: "transformation",
		type: "raw_transform",
		reference: rawTransform,
		async: false,
		"~run"(dataset, config$1) {
			const output = action({
				dataset,
				config: config$1,
				addIssue: (info) => _addIssue(this, info?.label ?? "input", dataset, config$1, info),
				NEVER: null
			});
			if (dataset.issues) dataset.typed = false;
			else dataset.value = output;
			return dataset;
		}
	};
}
/**
* Creates a raw transformation action.
*
* @param action The transformation action.
*
* @returns A raw transform action.
*/
/* @__NO_SIDE_EFFECTS__ */
function rawTransformAsync(action) {
	return {
		kind: "transformation",
		type: "raw_transform",
		reference: rawTransformAsync,
		async: true,
		async "~run"(dataset, config$1) {
			const output = await action({
				dataset,
				config: config$1,
				addIssue: (info) => _addIssue(this, info?.label ?? "input", dataset, config$1, info),
				NEVER: null
			});
			if (dataset.issues) dataset.typed = false;
			else dataset.value = output;
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function readonly() {
	return {
		kind: "transformation",
		type: "readonly",
		reference: readonly,
		async: false,
		"~run"(dataset) {
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function reduceItems(operation, initial) {
	return {
		kind: "transformation",
		type: "reduce_items",
		reference: reduceItems,
		async: false,
		operation,
		initial,
		"~run"(dataset) {
			dataset.value = dataset.value.reduce(this.operation, this.initial);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function regex(requirement, message$1) {
	return {
		kind: "validation",
		type: "regex",
		reference: regex,
		async: false,
		expects: `${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "format", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function returns(schema) {
	return {
		kind: "transformation",
		type: "returns",
		reference: returns,
		async: false,
		schema,
		"~run"(dataset, config$1) {
			const func = dataset.value;
			dataset.value = (...args_) => {
				const returnsDataset = this.schema["~run"]({ value: func(...args_) }, config$1);
				if (returnsDataset.issues) throw new ValiError(returnsDataset.issues);
				return returnsDataset.value;
			};
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function returnsAsync(schema) {
	return {
		kind: "transformation",
		type: "returns",
		reference: returnsAsync,
		async: false,
		schema,
		"~run"(dataset, config$1) {
			const func = dataset.value;
			dataset.value = async (...args_) => {
				const returnsDataset = await this.schema["~run"]({ value: await func(...args_) }, config$1);
				if (returnsDataset.issues) throw new ValiError(returnsDataset.issues);
				return returnsDataset.value;
			};
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function rfcEmail(message$1) {
	return {
		kind: "validation",
		type: "rfc_email",
		reference: rfcEmail,
		expects: null,
		async: false,
		requirement: RFC_EMAIL_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "email", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function safeInteger(message$1) {
	return {
		kind: "validation",
		type: "safe_integer",
		reference: safeInteger,
		async: false,
		expects: null,
		requirement: Number.isSafeInteger,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "safe integer", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function size(requirement, message$1) {
	return {
		kind: "validation",
		type: "size",
		reference: size,
		async: false,
		expects: `${requirement}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && dataset.value.size !== this.requirement) _addIssue(this, "size", dataset, config$1, { received: `${dataset.value.size}` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function slug(message$1) {
	return {
		kind: "validation",
		type: "slug",
		reference: slug,
		async: false,
		expects: null,
		requirement: SLUG_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "slug", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function someItem(requirement, message$1) {
	return {
		kind: "validation",
		type: "some_item",
		reference: someItem,
		async: false,
		expects: null,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !dataset.value.some(this.requirement)) _addIssue(this, "item", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function sortItems(operation) {
	return {
		kind: "transformation",
		type: "sort_items",
		reference: sortItems,
		async: false,
		operation,
		"~run"(dataset) {
			dataset.value = dataset.value.sort(this.operation);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function startsWith(requirement, message$1) {
	return {
		kind: "validation",
		type: "starts_with",
		reference: startsWith,
		async: false,
		expects: `"${requirement}"`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !dataset.value.startsWith(this.requirement)) _addIssue(this, "start", dataset, config$1, { received: `"${dataset.value.slice(0, this.requirement.length)}"` });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function stringifyJson(config$1, message$1) {
	return {
		kind: "transformation",
		type: "stringify_json",
		reference: stringifyJson,
		message: message$1,
		config: config$1,
		async: false,
		"~run"(dataset, config$2) {
			try {
				const output = JSON.stringify(dataset.value, this.config?.replacer, this.config?.space);
				if (output === void 0) {
					_addIssue(this, "JSON", dataset, config$2);
					dataset.typed = false;
				}
				dataset.value = output;
			} catch (error) {
				if (error instanceof Error) {
					_addIssue(this, "JSON", dataset, config$2, { received: `"${error.message}"` });
					dataset.typed = false;
				} else throw error;
			}
			return dataset;
		}
	};
}
/**
* Creates a title metadata action.
*
* @param title_ The title text.
*
* @returns A title action.
*/
/* @__NO_SIDE_EFFECTS__ */
function title(title_) {
	return {
		kind: "metadata",
		type: "title",
		reference: title,
		title: title_
	};
}
/* @__NO_SIDE_EFFECTS__ */
function toBigint(message$1) {
	return {
		kind: "transformation",
		type: "to_bigint",
		reference: toBigint,
		async: false,
		message: message$1,
		"~run"(dataset, config$1) {
			try {
				dataset.value = BigInt(dataset.value);
			} catch {
				_addIssue(this, "bigint", dataset, config$1);
				dataset.typed = false;
			}
			return dataset;
		}
	};
}
/**
* Creates a to boolean transformation action.
*
* @returns A to boolean action.
*
* @beta
*/
/* @__NO_SIDE_EFFECTS__ */
function toBoolean() {
	return {
		kind: "transformation",
		type: "to_boolean",
		reference: toBoolean,
		async: false,
		"~run"(dataset) {
			dataset.value = Boolean(dataset.value);
			return dataset;
		}
	};
}
/**
* Creates a to camel case transformation action.
*
* Words are separated by `_`, `-` and ASCII whitespace, as well as by case
* and acronym boundaries.
*
* Hint: Acronym runs are normalized to lowercase (e.g. `parseURLValue` →
* `parseUrlValue`) and digits stay attached to the preceding token (e.g.
* `item2Name` → `item2Name`).
*
* @returns A to camel case action.
*
* @beta
*/
/* @__NO_SIDE_EFFECTS__ */
function toCamelCase() {
	return {
		kind: "transformation",
		type: "to_camel_case",
		reference: toCamelCase,
		async: false,
		"~run"(dataset) {
			dataset.value = /* @__PURE__ */ _formatCase(dataset.value, "", false, true);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function toDate(message$1) {
	return {
		kind: "transformation",
		type: "to_date",
		reference: toDate,
		async: false,
		message: message$1,
		"~run"(dataset, config$1) {
			try {
				dataset.value = new Date(dataset.value);
				if (isNaN(dataset.value)) {
					_addIssue(this, "date", dataset, config$1, { received: "\"Invalid Date\"" });
					dataset.typed = false;
				}
			} catch {
				_addIssue(this, "date", dataset, config$1);
				dataset.typed = false;
			}
			return dataset;
		}
	};
}
/**
* Creates a to kebab case transformation action.
*
* Words are separated by `_`, `-` and ASCII whitespace, as well as by case
* and acronym boundaries.
*
* Hint: Acronym runs are normalized to lowercase (e.g. `parseURLValue` →
* `parse-url-value`) and digits stay attached to the preceding token (e.g.
* `item2Name` → `item2-name`).
*
* @returns A to kebab case action.
*
* @beta
*/
/* @__NO_SIDE_EFFECTS__ */
function toKebabCase() {
	return {
		kind: "transformation",
		type: "to_kebab_case",
		reference: toKebabCase,
		async: false,
		"~run"(dataset) {
			dataset.value = /* @__PURE__ */ _formatCase(dataset.value, "-", false, false);
			return dataset;
		}
	};
}
/**
* Creates a to lower case transformation action.
*
* @returns A to lower case action.
*/
/* @__NO_SIDE_EFFECTS__ */
function toLowerCase() {
	return {
		kind: "transformation",
		type: "to_lower_case",
		reference: toLowerCase,
		async: false,
		"~run"(dataset) {
			dataset.value = dataset.value.toLowerCase();
			return dataset;
		}
	};
}
/**
* Creates a to max value transformation action.
*
* @param requirement The maximum value.
*
* @returns A to max value action.
*/
/* @__NO_SIDE_EFFECTS__ */
function toMaxValue(requirement) {
	return {
		kind: "transformation",
		type: "to_max_value",
		reference: toMaxValue,
		async: false,
		requirement,
		"~run"(dataset) {
			dataset.value = dataset.value > this.requirement ? this.requirement : dataset.value;
			return dataset;
		}
	};
}
/**
* Creates a to min value transformation action.
*
* @param requirement The minimum value.
*
* @returns A to min value action.
*/
/* @__NO_SIDE_EFFECTS__ */
function toMinValue(requirement) {
	return {
		kind: "transformation",
		type: "to_min_value",
		reference: toMinValue,
		async: false,
		requirement,
		"~run"(dataset) {
			dataset.value = dataset.value < this.requirement ? this.requirement : dataset.value;
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function toNumber(message$1) {
	return {
		kind: "transformation",
		type: "to_number",
		reference: toNumber,
		async: false,
		message: message$1,
		"~run"(dataset, config$1) {
			try {
				dataset.value = Number(dataset.value);
				if (isNaN(dataset.value)) {
					_addIssue(this, "number", dataset, config$1);
					dataset.typed = false;
				}
			} catch {
				_addIssue(this, "number", dataset, config$1);
				dataset.typed = false;
			}
			return dataset;
		}
	};
}
/**
* Creates a to pascal case transformation action.
*
* Words are separated by `_`, `-` and ASCII whitespace, as well as by case
* and acronym boundaries.
*
* Hint: Acronym runs are normalized to lowercase (e.g. `parseURLValue` →
* `ParseUrlValue`) and digits stay attached to the preceding token (e.g.
* `item2Name` → `Item2Name`).
*
* @returns A to pascal case action.
*
* @beta
*/
/* @__NO_SIDE_EFFECTS__ */
function toPascalCase() {
	return {
		kind: "transformation",
		type: "to_pascal_case",
		reference: toPascalCase,
		async: false,
		"~run"(dataset) {
			dataset.value = /* @__PURE__ */ _formatCase(dataset.value, "", true, true);
			return dataset;
		}
	};
}
/**
* Creates a to snake case transformation action.
*
* Words are separated by `_`, `-` and ASCII whitespace, as well as by case
* and acronym boundaries.
*
* Hint: Acronym runs are normalized to lowercase (e.g. `parseURLValue` →
* `parse_url_value`) and digits stay attached to the preceding token (e.g.
* `item2Name` → `item2_name`).
*
* @returns A to snake case action.
*
* @beta
*/
/* @__NO_SIDE_EFFECTS__ */
function toSnakeCase() {
	return {
		kind: "transformation",
		type: "to_snake_case",
		reference: toSnakeCase,
		async: false,
		"~run"(dataset) {
			dataset.value = /* @__PURE__ */ _formatCase(dataset.value, "_", false, false);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function toString(message$1) {
	return {
		kind: "transformation",
		type: "to_string",
		reference: toString,
		async: false,
		message: message$1,
		"~run"(dataset, config$1) {
			try {
				dataset.value = String(dataset.value);
			} catch {
				_addIssue(this, "string", dataset, config$1);
				dataset.typed = false;
			}
			return dataset;
		}
	};
}
/**
* Creates a to upper case transformation action.
*
* @returns A to upper case action.
*/
/* @__NO_SIDE_EFFECTS__ */
function toUpperCase() {
	return {
		kind: "transformation",
		type: "to_upper_case",
		reference: toUpperCase,
		async: false,
		"~run"(dataset) {
			dataset.value = dataset.value.toUpperCase();
			return dataset;
		}
	};
}
/**
* Creates a custom transformation action.
*
* @param operation The transformation operation.
*
* @returns A transform action.
*/
/* @__NO_SIDE_EFFECTS__ */
function transform(operation) {
	return {
		kind: "transformation",
		type: "transform",
		reference: transform,
		async: false,
		operation,
		"~run"(dataset) {
			dataset.value = this.operation(dataset.value);
			return dataset;
		}
	};
}
/**
* Creates a custom transformation action.
*
* @param operation The transformation operation.
*
* @returns A transform action.
*/
/* @__NO_SIDE_EFFECTS__ */
function transformAsync(operation) {
	return {
		kind: "transformation",
		type: "transform",
		reference: transformAsync,
		async: true,
		operation,
		async "~run"(dataset) {
			dataset.value = await this.operation(dataset.value);
			return dataset;
		}
	};
}
/**
* Creates a trim transformation action.
*
* @returns A trim action.
*/
/* @__NO_SIDE_EFFECTS__ */
function trim() {
	return {
		kind: "transformation",
		type: "trim",
		reference: trim,
		async: false,
		"~run"(dataset) {
			dataset.value = dataset.value.trim();
			return dataset;
		}
	};
}
/**
* Creates a trim end transformation action.
*
* @returns A trim end action.
*/
/* @__NO_SIDE_EFFECTS__ */
function trimEnd() {
	return {
		kind: "transformation",
		type: "trim_end",
		reference: trimEnd,
		async: false,
		"~run"(dataset) {
			dataset.value = dataset.value.trimEnd();
			return dataset;
		}
	};
}
/**
* Creates a trim start transformation action.
*
* @returns A trim start action.
*/
/* @__NO_SIDE_EFFECTS__ */
function trimStart() {
	return {
		kind: "transformation",
		type: "trim_start",
		reference: trimStart,
		async: false,
		"~run"(dataset) {
			dataset.value = dataset.value.trimStart();
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function ulid(message$1) {
	return {
		kind: "validation",
		type: "ulid",
		reference: ulid,
		async: false,
		expects: null,
		requirement: ULID_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "ULID", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function url(message$1) {
	return {
		kind: "validation",
		type: "url",
		reference: url,
		async: false,
		expects: null,
		requirement(input) {
			try {
				new URL(input);
				return true;
			} catch {
				return false;
			}
		},
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "URL", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function uuid(message$1) {
	return {
		kind: "validation",
		type: "uuid",
		reference: uuid,
		async: false,
		expects: null,
		requirement: UUID_REGEX,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.test(dataset.value)) _addIssue(this, "UUID", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function value(requirement, message$1) {
	return {
		kind: "validation",
		type: "value",
		reference: value,
		async: false,
		expects: requirement instanceof Date ? requirement.toJSON() : /* @__PURE__ */ _stringify(requirement),
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !(this.requirement <= dataset.value && this.requirement >= dataset.value)) _addIssue(this, "value", dataset, config$1, { received: dataset.value instanceof Date ? dataset.value.toJSON() : /* @__PURE__ */ _stringify(dataset.value) });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function values(requirement, message$1) {
	return {
		kind: "validation",
		type: "values",
		reference: values,
		async: false,
		expects: `${/* @__PURE__ */ _joinExpects(requirement.map((value$1) => value$1 instanceof Date ? value$1.toJSON() : /* @__PURE__ */ _stringify(value$1)), "|")}`,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed && !this.requirement.some((value$1) => value$1 <= dataset.value && value$1 >= dataset.value)) _addIssue(this, "value", dataset, config$1, { received: dataset.value instanceof Date ? dataset.value.toJSON() : /* @__PURE__ */ _stringify(dataset.value) });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function words(locales, requirement, message$1) {
	return {
		kind: "validation",
		type: "words",
		reference: words,
		async: false,
		expects: `${requirement}`,
		locales,
		requirement,
		message: message$1,
		"~run"(dataset, config$1) {
			if (dataset.typed) {
				const count = /* @__PURE__ */ _getWordCount(this.locales, dataset.value);
				if (count !== this.requirement) _addIssue(this, "words", dataset, config$1, { received: `${count}` });
			}
			return dataset;
		}
	};
}
var ABORT_EARLY_CONFIG = { abortEarly: true };
/**
* Checks if the input matches the schema. As this is an assertion function, it
* can be used as a type guard.
*
* @param schema The schema to be used.
* @param input The input to be tested.
*/
function assert(schema, input) {
	const issues = schema["~run"]({ value: input }, ABORT_EARLY_CONFIG).issues;
	if (issues) throw new ValiError(issues);
}
/**
* Efficient LRU cache using Map iteration order.
*/
var _LruCache = class {
	constructor(config$1) {
		this.refCount = 0;
		this.maxSize = config$1?.maxSize ?? 1e3;
		this.maxAge = config$1?.maxAge ?? Infinity;
		this.hasMaxAge = isFinite(this.maxAge);
	}
	/**
	* Stringifies an unknown input to a cache key component.
	*
	* @param input The unknown input.
	*
	* @returns A cache key component.
	*/
	stringify(input) {
		const type = typeof input;
		if (type === "string") return `"${input}"`;
		if (type === "number" || type === "boolean") return `${input}`;
		if (type === "bigint") return `${input}n`;
		if (type === "object" || type === "function") {
			if (input) {
				this.refIds ?? (this.refIds = /* @__PURE__ */ new WeakMap());
				let id = this.refIds.get(input);
				if (!id) {
					id = ++this.refCount;
					this.refIds.set(input, id);
				}
				return `#${id}`;
			}
			return "null";
		}
		return type;
	}
	/**
	* Creates a cache key from input and config.
	*
	* @param input The input value.
	* @param config The parse configuration.
	*
	* @returns The cache key.
	*/
	key(input, config$1 = {}) {
		return `${this.stringify(input)}|${this.stringify(config$1.lang)}|${this.stringify(config$1.message)}|${this.stringify(config$1.abortEarly)}|${this.stringify(config$1.abortPipeEarly)}`;
	}
	/**
	* Gets a value from the cache by key.
	*
	* @param key The cache key.
	*
	* @returns The cached value.
	*/
	get(key) {
		if (!this.store) return void 0;
		const entry = this.store.get(key);
		if (!entry) return void 0;
		if (this.hasMaxAge && Date.now() - entry[1] > this.maxAge) {
			this.store.delete(key);
			return;
		}
		this.store.delete(key);
		this.store.set(key, entry);
		return entry[0];
	}
	/**
	* Sets a value in the cache by key.
	*
	* @param key The cache key.
	* @param value The cached value.
	*/
	set(key, value$1) {
		this.store ?? (this.store = /* @__PURE__ */ new Map());
		this.store.delete(key);
		const timestamp = this.hasMaxAge ? Date.now() : 0;
		this.store.set(key, [value$1, timestamp]);
		if (this.store.size > this.maxSize) this.store.delete(this.store.keys().next().value);
	}
	/**
	* Clears all entries from the cache.
	*/
	clear() {
		this.store?.clear();
	}
};
/* @__NO_SIDE_EFFECTS__ */
function cache(schema, config$1) {
	return {
		...schema,
		cacheConfig: config$1,
		cache: new _LruCache(config$1),
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, runConfig) {
			const key = this.cache.key(dataset.value, runConfig);
			let outputDataset = this.cache.get(key);
			if (!outputDataset) this.cache.set(key, outputDataset = schema["~run"](dataset, runConfig));
			return /* @__PURE__ */ _cloneDataset(outputDataset);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function cacheAsync(schema, config$1) {
	let activeRuns;
	return {
		...schema,
		async: true,
		cacheConfig: config$1,
		cache: new _LruCache(config$1),
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, runConfig) {
			const key = this.cache.key(dataset.value, runConfig);
			const cached = this.cache.get(key);
			if (cached) return /* @__PURE__ */ _cloneDataset(cached);
			let promise$1 = activeRuns?.get(key);
			if (!promise$1) {
				activeRuns ?? (activeRuns = /* @__PURE__ */ new Map());
				promise$1 = Promise.resolve(schema["~run"](dataset, runConfig));
				activeRuns.set(key, promise$1);
			}
			try {
				const outputDataset = await promise$1;
				this.cache.set(key, outputDataset);
				return /* @__PURE__ */ _cloneDataset(outputDataset);
			} finally {
				activeRuns?.delete(key);
			}
		}
	};
}
/**
* Changes the local configuration of a schema.
*
* @param schema The schema to configure.
* @param config The parse configuration.
*
* @returns The configured schema.
*/
/* @__NO_SIDE_EFFECTS__ */
function config(schema, config$1) {
	return {
		...schema,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config_) {
			return schema["~run"](dataset, {
				...config_,
				...config$1
			});
		}
	};
}
/**
* Returns the fallback value of the schema.
*
* @param schema The schema to get it from.
* @param dataset The output dataset if available.
* @param config The config if available.
*
* @returns The fallback value.
*/
/* @__NO_SIDE_EFFECTS__ */
function getFallback(schema, dataset, config$1) {
	return typeof schema.fallback === "function" ? schema.fallback(dataset, config$1) : schema.fallback;
}
/**
* Returns a fallback value as output if the input does not match the schema.
*
* @param schema The schema to catch.
* @param fallback The fallback value.
*
* @returns The passed schema.
*/
/* @__NO_SIDE_EFFECTS__ */
function fallback(schema, fallback$1) {
	return {
		...schema,
		fallback: fallback$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const outputDataset = schema["~run"](dataset, config$1);
			return outputDataset.issues ? {
				typed: true,
				value: /* @__PURE__ */ getFallback(this, outputDataset, config$1)
			} : outputDataset;
		}
	};
}
/**
* Returns a fallback value as output if the input does not match the schema.
*
* @param schema The schema to catch.
* @param fallback The fallback value.
*
* @returns The passed schema.
*/
/* @__NO_SIDE_EFFECTS__ */
function fallbackAsync(schema, fallback$1) {
	return {
		...schema,
		fallback: fallback$1,
		async: true,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const outputDataset = await schema["~run"](dataset, config$1);
			return outputDataset.issues ? {
				typed: true,
				value: await /* @__PURE__ */ getFallback(this, outputDataset, config$1)
			} : outputDataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function flatten(issues) {
	const flatErrors = {};
	for (const issue of issues) if (issue.path) {
		const dotPath = /* @__PURE__ */ getDotPath(issue);
		if (dotPath) {
			if (!flatErrors.nested) flatErrors.nested = {};
			if (Object.prototype.hasOwnProperty.call(flatErrors.nested, dotPath)) flatErrors.nested[dotPath].push(issue.message);
			else flatErrors.nested[dotPath] = [issue.message];
		} else if (flatErrors.other) flatErrors.other.push(issue.message);
		else flatErrors.other = [issue.message];
	} else if (flatErrors.root) flatErrors.root.push(issue.message);
	else flatErrors.root = [issue.message];
	return flatErrors;
}
/**
* Forwards the issues of the passed validation action.
*
* @param action The validation action.
* @param path The path to forward the issues to.
*
* @returns The modified action.
*/
/* @__NO_SIDE_EFFECTS__ */
function forward(action, path) {
	return {
		...action,
		"~run"(dataset, config$1) {
			const prevIssues = dataset.issues && [...dataset.issues];
			dataset = action["~run"](dataset, config$1);
			if (dataset.issues) {
				for (const issue of dataset.issues) if (!prevIssues?.includes(issue)) {
					let pathInput = dataset.value;
					for (const key of path) {
						const pathValue = pathInput[key];
						const pathItem = {
							type: "unknown",
							origin: "value",
							input: pathInput,
							key,
							value: pathValue
						};
						if (issue.path) issue.path.push(pathItem);
						else issue.path = [pathItem];
						if (!pathValue) break;
						pathInput = pathValue;
					}
				}
			}
			return dataset;
		}
	};
}
/**
* Forwards the issues of the passed validation action.
*
* @param action The validation action.
* @param path The path to forward the issues to.
*
* @returns The modified action.
*/
/* @__NO_SIDE_EFFECTS__ */
function forwardAsync(action, path) {
	return {
		...action,
		async: true,
		async "~run"(dataset, config$1) {
			const prevIssues = dataset.issues && [...dataset.issues];
			dataset = await action["~run"](dataset, config$1);
			if (dataset.issues) {
				for (const issue of dataset.issues) if (!prevIssues?.includes(issue)) {
					let pathInput = dataset.value;
					for (const key of path) {
						const pathValue = pathInput[key];
						const pathItem = {
							type: "unknown",
							origin: "value",
							input: pathInput,
							key,
							value: pathValue
						};
						if (issue.path) issue.path.push(pathItem);
						else issue.path = [pathItem];
						if (!pathValue) break;
						pathInput = pathValue;
					}
				}
			}
			return dataset;
		}
	};
}
/**
* Returns the default value of the schema.
*
* @param schema The schema to get it from.
* @param dataset The input dataset if available.
* @param config The config if available.
*
* @returns The default value.
*/
/* @__NO_SIDE_EFFECTS__ */
function getDefault(schema, dataset, config$1) {
	return typeof schema.default === "function" ? schema.default(dataset, config$1) : schema.default;
}
/**
* Returns the default values of the schema.
*
* Hint: The difference to `getDefault` is that for object and tuple schemas
* this function recursively returns the default values of the subschemas
* instead of `undefined`.
*
* @param schema The schema to get them from.
*
* @returns The default values.
*/
/* @__NO_SIDE_EFFECTS__ */
function getDefaults(schema) {
	if ("entries" in schema) {
		const object$1 = {};
		for (const key in schema.entries) object$1[key] = /* @__PURE__ */ getDefaults(schema.entries[key]);
		return object$1;
	}
	if ("items" in schema) return schema.items.map(getDefaults);
	return /* @__PURE__ */ getDefault(schema);
}
/**
* Returns the default values of the schema.
*
* Hint: The difference to `getDefault` is that for object and tuple schemas
* this function recursively returns the default values of the subschemas
* instead of `undefined`.
*
* @param schema The schema to get them from.
*
* @returns The default values.
*/
/* @__NO_SIDE_EFFECTS__ */
async function getDefaultsAsync(schema) {
	if ("entries" in schema) return Object.fromEntries(await Promise.all(Object.entries(schema.entries).map(async ([key, value$1]) => [key, await /* @__PURE__ */ getDefaultsAsync(value$1)])));
	if ("items" in schema) return Promise.all(schema.items.map(getDefaultsAsync));
	return /* @__PURE__ */ getDefault(schema);
}
/**
* Returns the description of the schema.
*
* If multiple descriptions are defined, the last one of the highest level is
* returned. If no description is defined, `undefined` is returned.
*
* @param schema The schema to get the description from.
*
* @returns The description, if any.
*
* @beta
*/
/* @__NO_SIDE_EFFECTS__ */
function getDescription(schema) {
	return /* @__PURE__ */ _getLastMetadata(schema, "description");
}
/**
* Returns the examples of a schema.
*
* If multiple examples are defined, it concatenates them using depth-first
* search. If no examples are defined, an empty array is returned.
*
* @param schema The schema to get the examples from.
*
* @returns The examples, if any.
*
* @beta
*/
/* @__NO_SIDE_EFFECTS__ */
function getExamples(schema) {
	const examples$1 = [];
	function depthFirstCollect(schema$1) {
		if ("pipe" in schema$1) {
			for (const item of schema$1.pipe) if (item.kind === "schema" && "pipe" in item) depthFirstCollect(item);
			else if (item.kind === "metadata" && item.type === "examples") for (const example of item.examples) examples$1.push(example);
		}
	}
	depthFirstCollect(schema);
	return examples$1;
}
/**
* Returns the fallback values of the schema.
*
* Hint: The difference to `getFallback` is that for object and tuple schemas
* this function recursively returns the fallback values of the subschemas
* instead of `undefined`.
*
* @param schema The schema to get them from.
*
* @returns The fallback values.
*/
/* @__NO_SIDE_EFFECTS__ */
function getFallbacks(schema) {
	if ("entries" in schema) {
		const object$1 = {};
		for (const key in schema.entries) object$1[key] = /* @__PURE__ */ getFallbacks(schema.entries[key]);
		return object$1;
	}
	if ("items" in schema) return schema.items.map(getFallbacks);
	return /* @__PURE__ */ getFallback(schema);
}
/**
* Returns the fallback values of the schema.
*
* Hint: The difference to `getFallback` is that for object and tuple schemas
* this function recursively returns the fallback values of the subschemas
* instead of `undefined`.
*
* @param schema The schema to get them from.
*
* @returns The fallback values.
*/
/* @__NO_SIDE_EFFECTS__ */
async function getFallbacksAsync(schema) {
	if ("entries" in schema) return Object.fromEntries(await Promise.all(Object.entries(schema.entries).map(async ([key, value$1]) => [key, await /* @__PURE__ */ getFallbacksAsync(value$1)])));
	if ("items" in schema) return Promise.all(schema.items.map(getFallbacksAsync));
	return /* @__PURE__ */ getFallback(schema);
}
/**
* Returns the metadata of a schema.
*
* If multiple metadata are defined, it shallowly merges them using depth-first
* search. If no metadata is defined, an empty object is returned.
*
* @param schema Schema to get the metadata from.
*
* @returns The metadata, if any.
*
* @beta
*/
/* @__NO_SIDE_EFFECTS__ */
function getMetadata(schema) {
	const result = {};
	function depthFirstMerge(schema$1) {
		if ("pipe" in schema$1) {
			for (const item of schema$1.pipe) if (item.kind === "schema" && "pipe" in item) depthFirstMerge(item);
			else if (item.kind === "metadata" && item.type === "metadata") Object.assign(result, item.metadata);
		}
	}
	depthFirstMerge(schema);
	return result;
}
/**
* Returns the title of the schema.
*
* If multiple titles are defined, the last one of the highest level is
* returned. If no title is defined, `undefined` is returned.
*
* @param schema The schema to get the title from.
*
* @returns The title, if any.
*
* @beta
*/
/* @__NO_SIDE_EFFECTS__ */
function getTitle(schema) {
	return /* @__PURE__ */ _getLastMetadata(schema, "title");
}
/**
* Checks if the input matches the schema. By using a type predicate, this
* function can be used as a type guard.
*
* @param schema The schema to be used.
* @param input The input to be tested.
*
* @returns Whether the input matches the schema.
*/
/* @__NO_SIDE_EFFECTS__ */
function is(schema, input) {
	return !schema["~run"]({ value: input }, ABORT_EARLY_CONFIG).issues;
}
/**
* Creates an any schema.
*
* Hint: This schema function exists only for completeness and is not
* recommended in practice. Instead, `unknown` should be used to accept
* unknown data.
*
* @returns An any schema.
*/
/* @__NO_SIDE_EFFECTS__ */
function any() {
	return {
		kind: "schema",
		type: "any",
		reference: any,
		expects: "any",
		async: false,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset) {
			dataset.typed = true;
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function array(item, message$1) {
	return {
		kind: "schema",
		type: "array",
		reference: array,
		expects: "Array",
		async: false,
		item,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (Array.isArray(input)) {
				dataset.typed = true;
				dataset.value = [];
				for (let key = 0; key < input.length; key++) {
					const value$1 = input[key];
					const itemDataset = this.item["~run"]({ value: value$1 }, config$1);
					if (itemDataset.issues) {
						const pathItem = {
							type: "array",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of itemDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = itemDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!itemDataset.typed) dataset.typed = false;
					dataset.value.push(itemDataset.value);
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function arrayAsync(item, message$1) {
	return {
		kind: "schema",
		type: "array",
		reference: arrayAsync,
		expects: "Array",
		async: true,
		item,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (Array.isArray(input)) {
				dataset.typed = true;
				dataset.value = [];
				const itemDatasets = await Promise.all(input.map((value$1) => this.item["~run"]({ value: value$1 }, config$1)));
				for (let key = 0; key < itemDatasets.length; key++) {
					const itemDataset = itemDatasets[key];
					if (itemDataset.issues) {
						const pathItem = {
							type: "array",
							origin: "value",
							input,
							key,
							value: input[key]
						};
						for (const issue of itemDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = itemDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!itemDataset.typed) dataset.typed = false;
					dataset.value.push(itemDataset.value);
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function bigint(message$1) {
	return {
		kind: "schema",
		type: "bigint",
		reference: bigint,
		expects: "bigint",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (typeof dataset.value === "bigint") dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function blob(message$1) {
	return {
		kind: "schema",
		type: "blob",
		reference: blob,
		expects: "Blob",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value instanceof Blob) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function boolean(message$1) {
	return {
		kind: "schema",
		type: "boolean",
		reference: boolean,
		expects: "boolean",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (typeof dataset.value === "boolean") dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function custom(check$1, message$1) {
	return {
		kind: "schema",
		type: "custom",
		reference: custom,
		expects: "unknown",
		async: false,
		check: check$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (this.check(dataset.value)) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function customAsync(check$1, message$1) {
	return {
		kind: "schema",
		type: "custom",
		reference: customAsync,
		expects: "unknown",
		async: true,
		check: check$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			if (await this.check(dataset.value)) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function date(message$1) {
	return {
		kind: "schema",
		type: "date",
		reference: date,
		expects: "Date",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value instanceof Date) if (!isNaN(dataset.value)) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1, { received: "\"Invalid Date\"" });
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function enum_(enum__, message$1) {
	const options = [];
	for (const key in enum__) if (`${+key}` !== key || typeof enum__[key] !== "string" || !Object.is(enum__[enum__[key]], +key)) options.push(enum__[key]);
	return {
		kind: "schema",
		type: "enum",
		reference: enum_,
		expects: /* @__PURE__ */ _joinExpects(options.map(_stringify), "|"),
		async: false,
		enum: enum__,
		options,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (this.options.includes(dataset.value)) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function exactOptional(wrapped, default_) {
	return {
		kind: "schema",
		type: "exact_optional",
		reference: exactOptional,
		expects: wrapped.expects,
		async: false,
		wrapped,
		default: default_,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			return this.wrapped["~run"](dataset, config$1);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function exactOptionalAsync(wrapped, default_) {
	return {
		kind: "schema",
		type: "exact_optional",
		reference: exactOptionalAsync,
		expects: wrapped.expects,
		async: true,
		wrapped,
		default: default_,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			return this.wrapped["~run"](dataset, config$1);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function file(message$1) {
	return {
		kind: "schema",
		type: "file",
		reference: file,
		expects: "File",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value instanceof File) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function function_(message$1) {
	return {
		kind: "schema",
		type: "function",
		reference: function_,
		expects: "Function",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (typeof dataset.value === "function") dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function instance(class_, message$1) {
	return {
		kind: "schema",
		type: "instance",
		reference: instance,
		expects: class_.name,
		async: false,
		class: class_,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value instanceof this.class) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/**
* Merges two values into one single output.
*
* @param value1 First value.
* @param value2 Second value.
*
* @returns The merge dataset.
*
* @internal
*/
/* @__NO_SIDE_EFFECTS__ */
function _merge(value1, value2) {
	if (typeof value1 === typeof value2) {
		if (value1 === value2 || value1 instanceof Date && value2 instanceof Date && +value1 === +value2) return { value: value1 };
		if (value1 && value2 && value1.constructor === Object && value2.constructor === Object) {
			const nextValue = { ...value1 };
			for (const key in value2) if (Object.prototype.hasOwnProperty.call(value1, key)) {
				const dataset = /* @__PURE__ */ _merge(value1[key], value2[key]);
				if (dataset.issue) return dataset;
				nextValue[key] = dataset.value;
			} else nextValue[key] = value2[key];
			return { value: nextValue };
		}
		if (Array.isArray(value1) && Array.isArray(value2)) {
			if (value1.length === value2.length) {
				const nextValue = [...value1];
				for (let index = 0; index < value1.length; index++) {
					const dataset = /* @__PURE__ */ _merge(value1[index], value2[index]);
					if (dataset.issue) return dataset;
					nextValue[index] = dataset.value;
				}
				return { value: nextValue };
			}
		}
	}
	return { issue: true };
}
/* @__NO_SIDE_EFFECTS__ */
function intersect(options, message$1) {
	return {
		kind: "schema",
		type: "intersect",
		reference: intersect,
		expects: /* @__PURE__ */ _joinExpects(options.map((option) => option.expects), "&"),
		async: false,
		options,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (this.options.length) {
				const input = dataset.value;
				let outputs;
				dataset.typed = true;
				for (const schema of this.options) {
					const optionDataset = schema["~run"]({ value: input }, config$1);
					if (optionDataset.issues) {
						if (dataset.issues) for (const issue of optionDataset.issues) dataset.issues.push(issue);
						else dataset.issues = optionDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!optionDataset.typed) dataset.typed = false;
					if (dataset.typed) if (outputs) outputs.push(optionDataset.value);
					else outputs = [optionDataset.value];
				}
				if (dataset.typed) {
					dataset.value = outputs[0];
					for (let index = 1; index < outputs.length; index++) {
						const mergeDataset = /* @__PURE__ */ _merge(dataset.value, outputs[index]);
						if (mergeDataset.issue) {
							_addIssue(this, "type", dataset, config$1, { received: "unknown" });
							break;
						}
						dataset.value = mergeDataset.value;
					}
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function intersectAsync(options, message$1) {
	return {
		kind: "schema",
		type: "intersect",
		reference: intersectAsync,
		expects: /* @__PURE__ */ _joinExpects(options.map((option) => option.expects), "&"),
		async: true,
		options,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			if (this.options.length) {
				const input = dataset.value;
				let outputs;
				dataset.typed = true;
				const optionDatasets = await Promise.all(this.options.map((schema) => schema["~run"]({ value: input }, config$1)));
				for (const optionDataset of optionDatasets) {
					if (optionDataset.issues) {
						if (dataset.issues) for (const issue of optionDataset.issues) dataset.issues.push(issue);
						else dataset.issues = optionDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!optionDataset.typed) dataset.typed = false;
					if (dataset.typed) if (outputs) outputs.push(optionDataset.value);
					else outputs = [optionDataset.value];
				}
				if (dataset.typed) {
					dataset.value = outputs[0];
					for (let index = 1; index < outputs.length; index++) {
						const mergeDataset = /* @__PURE__ */ _merge(dataset.value, outputs[index]);
						if (mergeDataset.issue) {
							_addIssue(this, "type", dataset, config$1, { received: "unknown" });
							break;
						}
						dataset.value = mergeDataset.value;
					}
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/**
* Creates a lazy schema.
*
* @param getter The schema getter.
*
* @returns A lazy schema.
*/
/* @__NO_SIDE_EFFECTS__ */
function lazy(getter) {
	return {
		kind: "schema",
		type: "lazy",
		reference: lazy,
		expects: "unknown",
		async: false,
		getter,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			return this.getter(dataset.value)["~run"](dataset, config$1);
		}
	};
}
/**
* Creates a lazy schema.
*
* @param getter The schema getter.
*
* @returns A lazy schema.
*/
/* @__NO_SIDE_EFFECTS__ */
function lazyAsync(getter) {
	return {
		kind: "schema",
		type: "lazy",
		reference: lazyAsync,
		expects: "unknown",
		async: true,
		getter,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			return (await this.getter(dataset.value))["~run"](dataset, config$1);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function literal(literal_, message$1) {
	return {
		kind: "schema",
		type: "literal",
		reference: literal,
		expects: /* @__PURE__ */ _stringify(literal_),
		async: false,
		literal: literal_,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value === this.literal) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function looseObject(entries$1, message$1) {
	return {
		kind: "schema",
		type: "loose_object",
		reference: looseObject,
		expects: "Object",
		async: false,
		entries: entries$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (input && typeof input === "object") {
				dataset.typed = true;
				dataset.value = {};
				for (const key in this.entries) {
					const valueSchema = this.entries[key];
					if (key in input || (valueSchema.type === "exact_optional" || valueSchema.type === "optional" || valueSchema.type === "nullish") && valueSchema.default !== void 0) {
						const value$1 = key in input ? input[key] : /* @__PURE__ */ getDefault(valueSchema);
						const valueDataset = valueSchema["~run"]({ value: value$1 }, config$1);
						if (valueDataset.issues) {
							const pathItem = {
								type: "object",
								origin: "value",
								input,
								key,
								value: value$1
							};
							for (const issue of valueDataset.issues) {
								if (issue.path) issue.path.unshift(pathItem);
								else issue.path = [pathItem];
								dataset.issues?.push(issue);
							}
							if (!dataset.issues) dataset.issues = valueDataset.issues;
							if (config$1.abortEarly) {
								dataset.typed = false;
								break;
							}
						}
						if (!valueDataset.typed) dataset.typed = false;
						dataset.value[key] = valueDataset.value;
					} else if (valueSchema.fallback !== void 0) dataset.value[key] = /* @__PURE__ */ getFallback(valueSchema);
					else if (valueSchema.type !== "exact_optional" && valueSchema.type !== "optional" && valueSchema.type !== "nullish") {
						_addIssue(this, "key", dataset, config$1, {
							input: void 0,
							expected: `"${key}"`,
							path: [{
								type: "object",
								origin: "key",
								input,
								key,
								value: input[key]
							}]
						});
						if (config$1.abortEarly) break;
					}
				}
				if (!dataset.issues || !config$1.abortEarly) {
					for (const key in input) if (/* @__PURE__ */ _isValidObjectKey(input, key) && !(key in this.entries)) dataset.value[key] = input[key];
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function looseObjectAsync(entries$1, message$1) {
	return {
		kind: "schema",
		type: "loose_object",
		reference: looseObjectAsync,
		expects: "Object",
		async: true,
		entries: entries$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (input && typeof input === "object") {
				dataset.typed = true;
				dataset.value = {};
				const valueDatasets = await Promise.all(Object.entries(this.entries).map(async ([key, valueSchema]) => {
					if (key in input || (valueSchema.type === "exact_optional" || valueSchema.type === "optional" || valueSchema.type === "nullish") && valueSchema.default !== void 0) {
						const value$1 = key in input ? input[key] : await /* @__PURE__ */ getDefault(valueSchema);
						return [
							key,
							value$1,
							valueSchema,
							await valueSchema["~run"]({ value: value$1 }, config$1)
						];
					}
					return [
						key,
						input[key],
						valueSchema,
						null
					];
				}));
				for (const [key, value$1, valueSchema, valueDataset] of valueDatasets) if (valueDataset) {
					if (valueDataset.issues) {
						const pathItem = {
							type: "object",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of valueDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = valueDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!valueDataset.typed) dataset.typed = false;
					dataset.value[key] = valueDataset.value;
				} else if (valueSchema.fallback !== void 0) dataset.value[key] = await /* @__PURE__ */ getFallback(valueSchema);
				else if (valueSchema.type !== "exact_optional" && valueSchema.type !== "optional" && valueSchema.type !== "nullish") {
					_addIssue(this, "key", dataset, config$1, {
						input: void 0,
						expected: `"${key}"`,
						path: [{
							type: "object",
							origin: "key",
							input,
							key,
							value: value$1
						}]
					});
					if (config$1.abortEarly) break;
				}
				if (!dataset.issues || !config$1.abortEarly) {
					for (const key in input) if (/* @__PURE__ */ _isValidObjectKey(input, key) && !(key in this.entries)) dataset.value[key] = input[key];
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function looseTuple(items, message$1) {
	return {
		kind: "schema",
		type: "loose_tuple",
		reference: looseTuple,
		expects: "Array",
		async: false,
		items,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (Array.isArray(input)) {
				dataset.typed = true;
				dataset.value = [];
				for (let key = 0; key < this.items.length; key++) {
					const value$1 = input[key];
					const itemDataset = this.items[key]["~run"]({ value: value$1 }, config$1);
					if (itemDataset.issues) {
						const pathItem = {
							type: "array",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of itemDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = itemDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!itemDataset.typed) dataset.typed = false;
					dataset.value.push(itemDataset.value);
				}
				if (!dataset.issues || !config$1.abortEarly) for (let key = this.items.length; key < input.length; key++) dataset.value.push(input[key]);
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function looseTupleAsync(items, message$1) {
	return {
		kind: "schema",
		type: "loose_tuple",
		reference: looseTupleAsync,
		expects: "Array",
		async: true,
		items,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (Array.isArray(input)) {
				dataset.typed = true;
				dataset.value = [];
				const itemDatasets = await Promise.all(this.items.map(async (item, key) => {
					const value$1 = input[key];
					return [
						key,
						value$1,
						await item["~run"]({ value: value$1 }, config$1)
					];
				}));
				for (const [key, value$1, itemDataset] of itemDatasets) {
					if (itemDataset.issues) {
						const pathItem = {
							type: "array",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of itemDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = itemDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!itemDataset.typed) dataset.typed = false;
					dataset.value.push(itemDataset.value);
				}
				if (!dataset.issues || !config$1.abortEarly) for (let key = this.items.length; key < input.length; key++) dataset.value.push(input[key]);
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function map(key, value$1, message$1) {
	return {
		kind: "schema",
		type: "map",
		reference: map,
		expects: "Map",
		async: false,
		key,
		value: value$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (input instanceof Map) {
				dataset.typed = true;
				dataset.value = /* @__PURE__ */ new Map();
				for (const [inputKey, inputValue] of input) {
					const keyDataset = this.key["~run"]({ value: inputKey }, config$1);
					if (keyDataset.issues) {
						const pathItem = {
							type: "map",
							origin: "key",
							input,
							key: inputKey,
							value: inputValue
						};
						for (const issue of keyDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = keyDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					const valueDataset = this.value["~run"]({ value: inputValue }, config$1);
					if (valueDataset.issues) {
						const pathItem = {
							type: "map",
							origin: "value",
							input,
							key: inputKey,
							value: inputValue
						};
						for (const issue of valueDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = valueDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!keyDataset.typed || !valueDataset.typed) dataset.typed = false;
					dataset.value.set(keyDataset.value, valueDataset.value);
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function mapAsync(key, value$1, message$1) {
	return {
		kind: "schema",
		type: "map",
		reference: mapAsync,
		expects: "Map",
		async: true,
		key,
		value: value$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (input instanceof Map) {
				dataset.typed = true;
				dataset.value = /* @__PURE__ */ new Map();
				const datasets = await Promise.all([...input].map(([inputKey, inputValue]) => Promise.all([
					inputKey,
					inputValue,
					this.key["~run"]({ value: inputKey }, config$1),
					this.value["~run"]({ value: inputValue }, config$1)
				])));
				for (const [inputKey, inputValue, keyDataset, valueDataset] of datasets) {
					if (keyDataset.issues) {
						const pathItem = {
							type: "map",
							origin: "key",
							input,
							key: inputKey,
							value: inputValue
						};
						for (const issue of keyDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = keyDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (valueDataset.issues) {
						const pathItem = {
							type: "map",
							origin: "value",
							input,
							key: inputKey,
							value: inputValue
						};
						for (const issue of valueDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = valueDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!keyDataset.typed || !valueDataset.typed) dataset.typed = false;
					dataset.value.set(keyDataset.value, valueDataset.value);
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nan(message$1) {
	return {
		kind: "schema",
		type: "nan",
		reference: nan,
		expects: "NaN",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (Number.isNaN(dataset.value)) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function never(message$1) {
	return {
		kind: "schema",
		type: "never",
		reference: never,
		expects: "never",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			_addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nonNullable(wrapped, message$1) {
	return {
		kind: "schema",
		type: "non_nullable",
		reference: nonNullable,
		expects: "!null",
		async: false,
		wrapped,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value !== null) dataset = this.wrapped["~run"](dataset, config$1);
			if (dataset.value === null) _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nonNullableAsync(wrapped, message$1) {
	return {
		kind: "schema",
		type: "non_nullable",
		reference: nonNullableAsync,
		expects: "!null",
		async: true,
		wrapped,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			if (dataset.value !== null) dataset = await this.wrapped["~run"](dataset, config$1);
			if (dataset.value === null) _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nonNullish(wrapped, message$1) {
	return {
		kind: "schema",
		type: "non_nullish",
		reference: nonNullish,
		expects: "(!null & !undefined)",
		async: false,
		wrapped,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (!(dataset.value === null || dataset.value === void 0)) dataset = this.wrapped["~run"](dataset, config$1);
			if (dataset.value === null || dataset.value === void 0) _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nonNullishAsync(wrapped, message$1) {
	return {
		kind: "schema",
		type: "non_nullish",
		reference: nonNullishAsync,
		expects: "(!null & !undefined)",
		async: true,
		wrapped,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			if (!(dataset.value === null || dataset.value === void 0)) dataset = await this.wrapped["~run"](dataset, config$1);
			if (dataset.value === null || dataset.value === void 0) _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nonOptional(wrapped, message$1) {
	return {
		kind: "schema",
		type: "non_optional",
		reference: nonOptional,
		expects: "!undefined",
		async: false,
		wrapped,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value !== void 0) dataset = this.wrapped["~run"](dataset, config$1);
			if (dataset.value === void 0) _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nonOptionalAsync(wrapped, message$1) {
	return {
		kind: "schema",
		type: "non_optional",
		reference: nonOptionalAsync,
		expects: "!undefined",
		async: true,
		wrapped,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			if (dataset.value !== void 0) dataset = await this.wrapped["~run"](dataset, config$1);
			if (dataset.value === void 0) _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function null_(message$1) {
	return {
		kind: "schema",
		type: "null",
		reference: null_,
		expects: "null",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value === null) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nullable(wrapped, default_) {
	return {
		kind: "schema",
		type: "nullable",
		reference: nullable,
		expects: `(${wrapped.expects} | null)`,
		async: false,
		wrapped,
		default: default_,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value === null) {
				if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
				if (dataset.value === null) {
					dataset.typed = true;
					return dataset;
				}
			}
			return this.wrapped["~run"](dataset, config$1);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nullableAsync(wrapped, default_) {
	return {
		kind: "schema",
		type: "nullable",
		reference: nullableAsync,
		expects: `(${wrapped.expects} | null)`,
		async: true,
		wrapped,
		default: default_,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			if (dataset.value === null) {
				if (this.default !== void 0) dataset.value = await /* @__PURE__ */ getDefault(this, dataset, config$1);
				if (dataset.value === null) {
					dataset.typed = true;
					return dataset;
				}
			}
			return this.wrapped["~run"](dataset, config$1);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nullish(wrapped, default_) {
	return {
		kind: "schema",
		type: "nullish",
		reference: nullish,
		expects: `(${wrapped.expects} | null | undefined)`,
		async: false,
		wrapped,
		default: default_,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value === null || dataset.value === void 0) {
				if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
				if (dataset.value === null || dataset.value === void 0) {
					dataset.typed = true;
					return dataset;
				}
			}
			return this.wrapped["~run"](dataset, config$1);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function nullishAsync(wrapped, default_) {
	return {
		kind: "schema",
		type: "nullish",
		reference: nullishAsync,
		expects: `(${wrapped.expects} | null | undefined)`,
		async: true,
		wrapped,
		default: default_,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			if (dataset.value === null || dataset.value === void 0) {
				if (this.default !== void 0) dataset.value = await /* @__PURE__ */ getDefault(this, dataset, config$1);
				if (dataset.value === null || dataset.value === void 0) {
					dataset.typed = true;
					return dataset;
				}
			}
			return this.wrapped["~run"](dataset, config$1);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function number(message$1) {
	return {
		kind: "schema",
		type: "number",
		reference: number,
		expects: "number",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (typeof dataset.value === "number" && !isNaN(dataset.value)) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function object(entries$1, message$1) {
	return {
		kind: "schema",
		type: "object",
		reference: object,
		expects: "Object",
		async: false,
		entries: entries$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (input && typeof input === "object") {
				dataset.typed = true;
				dataset.value = {};
				for (const key in this.entries) {
					const valueSchema = this.entries[key];
					if (key in input || (valueSchema.type === "exact_optional" || valueSchema.type === "optional" || valueSchema.type === "nullish") && valueSchema.default !== void 0) {
						const value$1 = key in input ? input[key] : /* @__PURE__ */ getDefault(valueSchema);
						const valueDataset = valueSchema["~run"]({ value: value$1 }, config$1);
						if (valueDataset.issues) {
							const pathItem = {
								type: "object",
								origin: "value",
								input,
								key,
								value: value$1
							};
							for (const issue of valueDataset.issues) {
								if (issue.path) issue.path.unshift(pathItem);
								else issue.path = [pathItem];
								dataset.issues?.push(issue);
							}
							if (!dataset.issues) dataset.issues = valueDataset.issues;
							if (config$1.abortEarly) {
								dataset.typed = false;
								break;
							}
						}
						if (!valueDataset.typed) dataset.typed = false;
						dataset.value[key] = valueDataset.value;
					} else if (valueSchema.fallback !== void 0) dataset.value[key] = /* @__PURE__ */ getFallback(valueSchema);
					else if (valueSchema.type !== "exact_optional" && valueSchema.type !== "optional" && valueSchema.type !== "nullish") {
						_addIssue(this, "key", dataset, config$1, {
							input: void 0,
							expected: `"${key}"`,
							path: [{
								type: "object",
								origin: "key",
								input,
								key,
								value: input[key]
							}]
						});
						if (config$1.abortEarly) break;
					}
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function objectAsync(entries$1, message$1) {
	return {
		kind: "schema",
		type: "object",
		reference: objectAsync,
		expects: "Object",
		async: true,
		entries: entries$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (input && typeof input === "object") {
				dataset.typed = true;
				dataset.value = {};
				const valueDatasets = await Promise.all(Object.entries(this.entries).map(async ([key, valueSchema]) => {
					if (key in input || (valueSchema.type === "exact_optional" || valueSchema.type === "optional" || valueSchema.type === "nullish") && valueSchema.default !== void 0) {
						const value$1 = key in input ? input[key] : await /* @__PURE__ */ getDefault(valueSchema);
						return [
							key,
							value$1,
							valueSchema,
							await valueSchema["~run"]({ value: value$1 }, config$1)
						];
					}
					return [
						key,
						input[key],
						valueSchema,
						null
					];
				}));
				for (const [key, value$1, valueSchema, valueDataset] of valueDatasets) if (valueDataset) {
					if (valueDataset.issues) {
						const pathItem = {
							type: "object",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of valueDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = valueDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!valueDataset.typed) dataset.typed = false;
					dataset.value[key] = valueDataset.value;
				} else if (valueSchema.fallback !== void 0) dataset.value[key] = await /* @__PURE__ */ getFallback(valueSchema);
				else if (valueSchema.type !== "exact_optional" && valueSchema.type !== "optional" && valueSchema.type !== "nullish") {
					_addIssue(this, "key", dataset, config$1, {
						input: void 0,
						expected: `"${key}"`,
						path: [{
							type: "object",
							origin: "key",
							input,
							key,
							value: value$1
						}]
					});
					if (config$1.abortEarly) break;
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function objectWithRest(entries$1, rest, message$1) {
	return {
		kind: "schema",
		type: "object_with_rest",
		reference: objectWithRest,
		expects: "Object",
		async: false,
		entries: entries$1,
		rest,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (input && typeof input === "object") {
				dataset.typed = true;
				dataset.value = {};
				for (const key in this.entries) {
					const valueSchema = this.entries[key];
					if (key in input || (valueSchema.type === "exact_optional" || valueSchema.type === "optional" || valueSchema.type === "nullish") && valueSchema.default !== void 0) {
						const value$1 = key in input ? input[key] : /* @__PURE__ */ getDefault(valueSchema);
						const valueDataset = valueSchema["~run"]({ value: value$1 }, config$1);
						if (valueDataset.issues) {
							const pathItem = {
								type: "object",
								origin: "value",
								input,
								key,
								value: value$1
							};
							for (const issue of valueDataset.issues) {
								if (issue.path) issue.path.unshift(pathItem);
								else issue.path = [pathItem];
								dataset.issues?.push(issue);
							}
							if (!dataset.issues) dataset.issues = valueDataset.issues;
							if (config$1.abortEarly) {
								dataset.typed = false;
								break;
							}
						}
						if (!valueDataset.typed) dataset.typed = false;
						dataset.value[key] = valueDataset.value;
					} else if (valueSchema.fallback !== void 0) dataset.value[key] = /* @__PURE__ */ getFallback(valueSchema);
					else if (valueSchema.type !== "exact_optional" && valueSchema.type !== "optional" && valueSchema.type !== "nullish") {
						_addIssue(this, "key", dataset, config$1, {
							input: void 0,
							expected: `"${key}"`,
							path: [{
								type: "object",
								origin: "key",
								input,
								key,
								value: input[key]
							}]
						});
						if (config$1.abortEarly) break;
					}
				}
				if (!dataset.issues || !config$1.abortEarly) {
					for (const key in input) if (/* @__PURE__ */ _isValidObjectKey(input, key) && !(key in this.entries)) {
						const valueDataset = this.rest["~run"]({ value: input[key] }, config$1);
						if (valueDataset.issues) {
							const pathItem = {
								type: "object",
								origin: "value",
								input,
								key,
								value: input[key]
							};
							for (const issue of valueDataset.issues) {
								if (issue.path) issue.path.unshift(pathItem);
								else issue.path = [pathItem];
								dataset.issues?.push(issue);
							}
							if (!dataset.issues) dataset.issues = valueDataset.issues;
							if (config$1.abortEarly) {
								dataset.typed = false;
								break;
							}
						}
						if (!valueDataset.typed) dataset.typed = false;
						dataset.value[key] = valueDataset.value;
					}
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function objectWithRestAsync(entries$1, rest, message$1) {
	return {
		kind: "schema",
		type: "object_with_rest",
		reference: objectWithRestAsync,
		expects: "Object",
		async: true,
		entries: entries$1,
		rest,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (input && typeof input === "object") {
				dataset.typed = true;
				dataset.value = {};
				const [normalDatasets, restDatasets] = await Promise.all([Promise.all(Object.entries(this.entries).map(async ([key, valueSchema]) => {
					if (key in input || (valueSchema.type === "exact_optional" || valueSchema.type === "optional" || valueSchema.type === "nullish") && valueSchema.default !== void 0) {
						const value$1 = key in input ? input[key] : await /* @__PURE__ */ getDefault(valueSchema);
						return [
							key,
							value$1,
							valueSchema,
							await valueSchema["~run"]({ value: value$1 }, config$1)
						];
					}
					return [
						key,
						input[key],
						valueSchema,
						null
					];
				})), Promise.all(Object.entries(input).filter(([key]) => /* @__PURE__ */ _isValidObjectKey(input, key) && !(key in this.entries)).map(async ([key, value$1]) => [
					key,
					value$1,
					await this.rest["~run"]({ value: value$1 }, config$1)
				]))]);
				for (const [key, value$1, valueSchema, valueDataset] of normalDatasets) if (valueDataset) {
					if (valueDataset.issues) {
						const pathItem = {
							type: "object",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of valueDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = valueDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!valueDataset.typed) dataset.typed = false;
					dataset.value[key] = valueDataset.value;
				} else if (valueSchema.fallback !== void 0) dataset.value[key] = await /* @__PURE__ */ getFallback(valueSchema);
				else if (valueSchema.type !== "exact_optional" && valueSchema.type !== "optional" && valueSchema.type !== "nullish") {
					_addIssue(this, "key", dataset, config$1, {
						input: void 0,
						expected: `"${key}"`,
						path: [{
							type: "object",
							origin: "key",
							input,
							key,
							value: value$1
						}]
					});
					if (config$1.abortEarly) break;
				}
				if (!dataset.issues || !config$1.abortEarly) for (const [key, value$1, valueDataset] of restDatasets) {
					if (valueDataset.issues) {
						const pathItem = {
							type: "object",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of valueDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = valueDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!valueDataset.typed) dataset.typed = false;
					dataset.value[key] = valueDataset.value;
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function optional(wrapped, default_) {
	return {
		kind: "schema",
		type: "optional",
		reference: optional,
		expects: `(${wrapped.expects} | undefined)`,
		async: false,
		wrapped,
		default: default_,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value === void 0) {
				if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
				if (dataset.value === void 0) {
					dataset.typed = true;
					return dataset;
				}
			}
			return this.wrapped["~run"](dataset, config$1);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function optionalAsync(wrapped, default_) {
	return {
		kind: "schema",
		type: "optional",
		reference: optionalAsync,
		expects: `(${wrapped.expects} | undefined)`,
		async: true,
		wrapped,
		default: default_,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			if (dataset.value === void 0) {
				if (this.default !== void 0) dataset.value = await /* @__PURE__ */ getDefault(this, dataset, config$1);
				if (dataset.value === void 0) {
					dataset.typed = true;
					return dataset;
				}
			}
			return this.wrapped["~run"](dataset, config$1);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function picklist(options, message$1) {
	return {
		kind: "schema",
		type: "picklist",
		reference: picklist,
		expects: /* @__PURE__ */ _joinExpects(options.map(_stringify), "|"),
		async: false,
		options,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (this.options.includes(dataset.value)) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function promise(message$1) {
	return {
		kind: "schema",
		type: "promise",
		reference: promise,
		expects: "Promise",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value instanceof Promise) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function record(key, value$1, message$1) {
	return {
		kind: "schema",
		type: "record",
		reference: record,
		expects: "Object",
		async: false,
		key,
		value: value$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (input && typeof input === "object") {
				dataset.typed = true;
				dataset.value = {};
				for (const entryKey in input) if (/* @__PURE__ */ _isValidObjectKey(input, entryKey)) {
					const entryValue = input[entryKey];
					const keyDataset = this.key["~run"]({ value: entryKey }, config$1);
					if (keyDataset.issues) {
						const pathItem = {
							type: "object",
							origin: "key",
							input,
							key: entryKey,
							value: entryValue
						};
						for (const issue of keyDataset.issues) {
							issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = keyDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					const valueDataset = this.value["~run"]({ value: entryValue }, config$1);
					if (valueDataset.issues) {
						const pathItem = {
							type: "object",
							origin: "value",
							input,
							key: entryKey,
							value: entryValue
						};
						for (const issue of valueDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = valueDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!keyDataset.typed || !valueDataset.typed) dataset.typed = false;
					if (keyDataset.typed) dataset.value[keyDataset.value] = valueDataset.value;
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function recordAsync(key, value$1, message$1) {
	return {
		kind: "schema",
		type: "record",
		reference: recordAsync,
		expects: "Object",
		async: true,
		key,
		value: value$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (input && typeof input === "object") {
				dataset.typed = true;
				dataset.value = {};
				const datasets = await Promise.all(Object.entries(input).filter(([key$1]) => /* @__PURE__ */ _isValidObjectKey(input, key$1)).map(([entryKey, entryValue]) => Promise.all([
					entryKey,
					entryValue,
					this.key["~run"]({ value: entryKey }, config$1),
					this.value["~run"]({ value: entryValue }, config$1)
				])));
				for (const [entryKey, entryValue, keyDataset, valueDataset] of datasets) {
					if (keyDataset.issues) {
						const pathItem = {
							type: "object",
							origin: "key",
							input,
							key: entryKey,
							value: entryValue
						};
						for (const issue of keyDataset.issues) {
							issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = keyDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (valueDataset.issues) {
						const pathItem = {
							type: "object",
							origin: "value",
							input,
							key: entryKey,
							value: entryValue
						};
						for (const issue of valueDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = valueDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!keyDataset.typed || !valueDataset.typed) dataset.typed = false;
					if (keyDataset.typed) dataset.value[keyDataset.value] = valueDataset.value;
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function set(value$1, message$1) {
	return {
		kind: "schema",
		type: "set",
		reference: set,
		expects: "Set",
		async: false,
		value: value$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (input instanceof Set) {
				dataset.typed = true;
				dataset.value = /* @__PURE__ */ new Set();
				for (const inputValue of input) {
					const valueDataset = this.value["~run"]({ value: inputValue }, config$1);
					if (valueDataset.issues) {
						const pathItem = {
							type: "set",
							origin: "value",
							input,
							key: null,
							value: inputValue
						};
						for (const issue of valueDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = valueDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!valueDataset.typed) dataset.typed = false;
					dataset.value.add(valueDataset.value);
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function setAsync(value$1, message$1) {
	return {
		kind: "schema",
		type: "set",
		reference: setAsync,
		expects: "Set",
		async: true,
		value: value$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (input instanceof Set) {
				dataset.typed = true;
				dataset.value = /* @__PURE__ */ new Set();
				const valueDatasets = await Promise.all([...input].map(async (inputValue) => [inputValue, await this.value["~run"]({ value: inputValue }, config$1)]));
				for (const [inputValue, valueDataset] of valueDatasets) {
					if (valueDataset.issues) {
						const pathItem = {
							type: "set",
							origin: "value",
							input,
							key: null,
							value: inputValue
						};
						for (const issue of valueDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = valueDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!valueDataset.typed) dataset.typed = false;
					dataset.value.add(valueDataset.value);
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function strictObject(entries$1, message$1) {
	return {
		kind: "schema",
		type: "strict_object",
		reference: strictObject,
		expects: "Object",
		async: false,
		entries: entries$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (input && typeof input === "object") {
				dataset.typed = true;
				dataset.value = {};
				for (const key in this.entries) {
					const valueSchema = this.entries[key];
					if (key in input || (valueSchema.type === "exact_optional" || valueSchema.type === "optional" || valueSchema.type === "nullish") && valueSchema.default !== void 0) {
						const value$1 = key in input ? input[key] : /* @__PURE__ */ getDefault(valueSchema);
						const valueDataset = valueSchema["~run"]({ value: value$1 }, config$1);
						if (valueDataset.issues) {
							const pathItem = {
								type: "object",
								origin: "value",
								input,
								key,
								value: value$1
							};
							for (const issue of valueDataset.issues) {
								if (issue.path) issue.path.unshift(pathItem);
								else issue.path = [pathItem];
								dataset.issues?.push(issue);
							}
							if (!dataset.issues) dataset.issues = valueDataset.issues;
							if (config$1.abortEarly) {
								dataset.typed = false;
								break;
							}
						}
						if (!valueDataset.typed) dataset.typed = false;
						dataset.value[key] = valueDataset.value;
					} else if (valueSchema.fallback !== void 0) dataset.value[key] = /* @__PURE__ */ getFallback(valueSchema);
					else if (valueSchema.type !== "exact_optional" && valueSchema.type !== "optional" && valueSchema.type !== "nullish") {
						_addIssue(this, "key", dataset, config$1, {
							input: void 0,
							expected: `"${key}"`,
							path: [{
								type: "object",
								origin: "key",
								input,
								key,
								value: input[key]
							}]
						});
						if (config$1.abortEarly) break;
					}
				}
				if (!dataset.issues || !config$1.abortEarly) {
					for (const key in input) if (!(key in this.entries)) {
						_addIssue(this, "key", dataset, config$1, {
							input: key,
							expected: "never",
							path: [{
								type: "object",
								origin: "key",
								input,
								key,
								value: input[key]
							}]
						});
						break;
					}
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function strictObjectAsync(entries$1, message$1) {
	return {
		kind: "schema",
		type: "strict_object",
		reference: strictObjectAsync,
		expects: "Object",
		async: true,
		entries: entries$1,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (input && typeof input === "object") {
				dataset.typed = true;
				dataset.value = {};
				const valueDatasets = await Promise.all(Object.entries(this.entries).map(async ([key, valueSchema]) => {
					if (key in input || (valueSchema.type === "exact_optional" || valueSchema.type === "optional" || valueSchema.type === "nullish") && valueSchema.default !== void 0) {
						const value$1 = key in input ? input[key] : await /* @__PURE__ */ getDefault(valueSchema);
						return [
							key,
							value$1,
							valueSchema,
							await valueSchema["~run"]({ value: value$1 }, config$1)
						];
					}
					return [
						key,
						input[key],
						valueSchema,
						null
					];
				}));
				for (const [key, value$1, valueSchema, valueDataset] of valueDatasets) if (valueDataset) {
					if (valueDataset.issues) {
						const pathItem = {
							type: "object",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of valueDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = valueDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!valueDataset.typed) dataset.typed = false;
					dataset.value[key] = valueDataset.value;
				} else if (valueSchema.fallback !== void 0) dataset.value[key] = await /* @__PURE__ */ getFallback(valueSchema);
				else if (valueSchema.type !== "exact_optional" && valueSchema.type !== "optional" && valueSchema.type !== "nullish") {
					_addIssue(this, "key", dataset, config$1, {
						input: void 0,
						expected: `"${key}"`,
						path: [{
							type: "object",
							origin: "key",
							input,
							key,
							value: value$1
						}]
					});
					if (config$1.abortEarly) break;
				}
				if (!dataset.issues || !config$1.abortEarly) {
					for (const key in input) if (!(key in this.entries)) {
						_addIssue(this, "key", dataset, config$1, {
							input: key,
							expected: "never",
							path: [{
								type: "object",
								origin: "key",
								input,
								key,
								value: input[key]
							}]
						});
						break;
					}
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function strictTuple(items, message$1) {
	return {
		kind: "schema",
		type: "strict_tuple",
		reference: strictTuple,
		expects: "Array",
		async: false,
		items,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (Array.isArray(input)) {
				dataset.typed = true;
				dataset.value = [];
				for (let key = 0; key < this.items.length; key++) {
					const value$1 = input[key];
					const itemDataset = this.items[key]["~run"]({ value: value$1 }, config$1);
					if (itemDataset.issues) {
						const pathItem = {
							type: "array",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of itemDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = itemDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!itemDataset.typed) dataset.typed = false;
					dataset.value.push(itemDataset.value);
				}
				if (!(dataset.issues && config$1.abortEarly) && this.items.length < input.length) _addIssue(this, "type", dataset, config$1, {
					input: input[this.items.length],
					expected: "never",
					path: [{
						type: "array",
						origin: "value",
						input,
						key: this.items.length,
						value: input[this.items.length]
					}]
				});
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function strictTupleAsync(items, message$1) {
	return {
		kind: "schema",
		type: "strict_tuple",
		reference: strictTupleAsync,
		expects: "Array",
		async: true,
		items,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (Array.isArray(input)) {
				dataset.typed = true;
				dataset.value = [];
				const itemDatasets = await Promise.all(this.items.map(async (item, key) => {
					const value$1 = input[key];
					return [
						key,
						value$1,
						await item["~run"]({ value: value$1 }, config$1)
					];
				}));
				for (const [key, value$1, itemDataset] of itemDatasets) {
					if (itemDataset.issues) {
						const pathItem = {
							type: "array",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of itemDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = itemDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!itemDataset.typed) dataset.typed = false;
					dataset.value.push(itemDataset.value);
				}
				if (!(dataset.issues && config$1.abortEarly) && this.items.length < input.length) _addIssue(this, "type", dataset, config$1, {
					input: input[this.items.length],
					expected: "never",
					path: [{
						type: "array",
						origin: "value",
						input,
						key: this.items.length,
						value: input[this.items.length]
					}]
				});
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function string(message$1) {
	return {
		kind: "schema",
		type: "string",
		reference: string,
		expects: "string",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (typeof dataset.value === "string") dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function symbol(message$1) {
	return {
		kind: "schema",
		type: "symbol",
		reference: symbol,
		expects: "symbol",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (typeof dataset.value === "symbol") dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function tuple(items, message$1) {
	return {
		kind: "schema",
		type: "tuple",
		reference: tuple,
		expects: "Array",
		async: false,
		items,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (Array.isArray(input)) {
				dataset.typed = true;
				dataset.value = [];
				for (let key = 0; key < this.items.length; key++) {
					const value$1 = input[key];
					const itemDataset = this.items[key]["~run"]({ value: value$1 }, config$1);
					if (itemDataset.issues) {
						const pathItem = {
							type: "array",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of itemDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = itemDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!itemDataset.typed) dataset.typed = false;
					dataset.value.push(itemDataset.value);
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function tupleAsync(items, message$1) {
	return {
		kind: "schema",
		type: "tuple",
		reference: tupleAsync,
		expects: "Array",
		async: true,
		items,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (Array.isArray(input)) {
				dataset.typed = true;
				dataset.value = [];
				const itemDatasets = await Promise.all(this.items.map(async (item, key) => {
					const value$1 = input[key];
					return [
						key,
						value$1,
						await item["~run"]({ value: value$1 }, config$1)
					];
				}));
				for (const [key, value$1, itemDataset] of itemDatasets) {
					if (itemDataset.issues) {
						const pathItem = {
							type: "array",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of itemDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = itemDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!itemDataset.typed) dataset.typed = false;
					dataset.value.push(itemDataset.value);
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function tupleWithRest(items, rest, message$1) {
	return {
		kind: "schema",
		type: "tuple_with_rest",
		reference: tupleWithRest,
		expects: "Array",
		async: false,
		items,
		rest,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (Array.isArray(input)) {
				dataset.typed = true;
				dataset.value = [];
				for (let key = 0; key < this.items.length; key++) {
					const value$1 = input[key];
					const itemDataset = this.items[key]["~run"]({ value: value$1 }, config$1);
					if (itemDataset.issues) {
						const pathItem = {
							type: "array",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of itemDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = itemDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!itemDataset.typed) dataset.typed = false;
					dataset.value.push(itemDataset.value);
				}
				if (!dataset.issues || !config$1.abortEarly) for (let key = this.items.length; key < input.length; key++) {
					const value$1 = input[key];
					const itemDataset = this.rest["~run"]({ value: value$1 }, config$1);
					if (itemDataset.issues) {
						const pathItem = {
							type: "array",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of itemDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = itemDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!itemDataset.typed) dataset.typed = false;
					dataset.value.push(itemDataset.value);
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function tupleWithRestAsync(items, rest, message$1) {
	return {
		kind: "schema",
		type: "tuple_with_rest",
		reference: tupleWithRestAsync,
		expects: "Array",
		async: true,
		items,
		rest,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (Array.isArray(input)) {
				dataset.typed = true;
				dataset.value = [];
				const [normalDatasets, restDatasets] = await Promise.all([Promise.all(this.items.map(async (item, key) => {
					const value$1 = input[key];
					return [
						key,
						value$1,
						await item["~run"]({ value: value$1 }, config$1)
					];
				})), Promise.all(input.slice(this.items.length).map(async (value$1, key) => {
					return [
						key + this.items.length,
						value$1,
						await this.rest["~run"]({ value: value$1 }, config$1)
					];
				}))]);
				for (const [key, value$1, itemDataset] of normalDatasets) {
					if (itemDataset.issues) {
						const pathItem = {
							type: "array",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of itemDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = itemDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!itemDataset.typed) dataset.typed = false;
					dataset.value.push(itemDataset.value);
				}
				if (!dataset.issues || !config$1.abortEarly) for (const [key, value$1, itemDataset] of restDatasets) {
					if (itemDataset.issues) {
						const pathItem = {
							type: "array",
							origin: "value",
							input,
							key,
							value: value$1
						};
						for (const issue of itemDataset.issues) {
							if (issue.path) issue.path.unshift(pathItem);
							else issue.path = [pathItem];
							dataset.issues?.push(issue);
						}
						if (!dataset.issues) dataset.issues = itemDataset.issues;
						if (config$1.abortEarly) {
							dataset.typed = false;
							break;
						}
					}
					if (!itemDataset.typed) dataset.typed = false;
					dataset.value.push(itemDataset.value);
				}
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function undefined_(message$1) {
	return {
		kind: "schema",
		type: "undefined",
		reference: undefined_,
		expects: "undefined",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value === void 0) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function undefinedable(wrapped, default_) {
	return {
		kind: "schema",
		type: "undefinedable",
		reference: undefinedable,
		expects: `(${wrapped.expects} | undefined)`,
		async: false,
		wrapped,
		default: default_,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value === void 0) {
				if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
				if (dataset.value === void 0) {
					dataset.typed = true;
					return dataset;
				}
			}
			return this.wrapped["~run"](dataset, config$1);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function undefinedableAsync(wrapped, default_) {
	return {
		kind: "schema",
		type: "undefinedable",
		reference: undefinedableAsync,
		expects: `(${wrapped.expects} | undefined)`,
		async: true,
		wrapped,
		default: default_,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			if (dataset.value === void 0) {
				if (this.default !== void 0) dataset.value = await /* @__PURE__ */ getDefault(this, dataset, config$1);
				if (dataset.value === void 0) {
					dataset.typed = true;
					return dataset;
				}
			}
			return this.wrapped["~run"](dataset, config$1);
		}
	};
}
/**
* Returns the sub issues of the provided datasets for the union issue.
*
* @param datasets The datasets.
*
* @returns The sub issues.
*
* @internal
*/
/* @__NO_SIDE_EFFECTS__ */
function _subIssues(datasets) {
	let issues;
	if (datasets) for (const dataset of datasets) if (issues) for (const issue of dataset.issues) issues.push(issue);
	else issues = dataset.issues;
	return issues;
}
/* @__NO_SIDE_EFFECTS__ */
function union(options, message$1) {
	return {
		kind: "schema",
		type: "union",
		reference: union,
		expects: /* @__PURE__ */ _joinExpects(options.map((option) => option.expects), "|"),
		async: false,
		options,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			let validDataset;
			let typedDatasets;
			let untypedDatasets;
			for (const schema of this.options) {
				const optionDataset = schema["~run"]({ value: dataset.value }, config$1);
				if (optionDataset.typed) if (optionDataset.issues) if (typedDatasets) typedDatasets.push(optionDataset);
				else typedDatasets = [optionDataset];
				else {
					validDataset = optionDataset;
					break;
				}
				else if (untypedDatasets) untypedDatasets.push(optionDataset);
				else untypedDatasets = [optionDataset];
			}
			if (validDataset) return validDataset;
			if (typedDatasets) {
				if (typedDatasets.length === 1) return typedDatasets[0];
				_addIssue(this, "type", dataset, config$1, { issues: /* @__PURE__ */ _subIssues(typedDatasets) });
				dataset.typed = true;
			} else if (untypedDatasets?.length === 1) return untypedDatasets[0];
			else _addIssue(this, "type", dataset, config$1, { issues: /* @__PURE__ */ _subIssues(untypedDatasets) });
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function unionAsync(options, message$1) {
	return {
		kind: "schema",
		type: "union",
		reference: unionAsync,
		expects: /* @__PURE__ */ _joinExpects(options.map((option) => option.expects), "|"),
		async: true,
		options,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			let validDataset;
			let typedDatasets;
			let untypedDatasets;
			for (const schema of this.options) {
				const optionDataset = await schema["~run"]({ value: dataset.value }, config$1);
				if (optionDataset.typed) if (optionDataset.issues) if (typedDatasets) typedDatasets.push(optionDataset);
				else typedDatasets = [optionDataset];
				else {
					validDataset = optionDataset;
					break;
				}
				else if (untypedDatasets) untypedDatasets.push(optionDataset);
				else untypedDatasets = [optionDataset];
			}
			if (validDataset) return validDataset;
			if (typedDatasets) {
				if (typedDatasets.length === 1) return typedDatasets[0];
				_addIssue(this, "type", dataset, config$1, { issues: /* @__PURE__ */ _subIssues(typedDatasets) });
				dataset.typed = true;
			} else if (untypedDatasets?.length === 1) return untypedDatasets[0];
			else _addIssue(this, "type", dataset, config$1, { issues: /* @__PURE__ */ _subIssues(untypedDatasets) });
			return dataset;
		}
	};
}
/**
* Creates a unknown schema.
*
* @returns A unknown schema.
*/
/* @__NO_SIDE_EFFECTS__ */
function unknown() {
	return {
		kind: "schema",
		type: "unknown",
		reference: unknown,
		expects: "unknown",
		async: false,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset) {
			dataset.typed = true;
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function variant(key, options, message$1) {
	return {
		kind: "schema",
		type: "variant",
		reference: variant,
		expects: "Object",
		async: false,
		key,
		options,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			const input = dataset.value;
			if (input && typeof input === "object") {
				let outputDataset;
				let maxDiscriminatorPriority = 0;
				let invalidDiscriminatorKey = this.key;
				let expectedDiscriminators = [];
				const parseOptions = (variant$1, allKeys) => {
					for (const schema of variant$1.options) {
						if (schema.type === "variant") parseOptions(schema, new Set(allKeys).add(schema.key));
						else {
							let keysAreValid = true;
							let currentPriority = 0;
							for (const currentKey of allKeys) {
								const discriminatorSchema = schema.entries[currentKey];
								if (currentKey in input ? discriminatorSchema["~run"]({
									typed: false,
									value: input[currentKey]
								}, ABORT_EARLY_CONFIG).issues : discriminatorSchema.type !== "exact_optional" && discriminatorSchema.type !== "optional" && discriminatorSchema.type !== "nullish") {
									keysAreValid = false;
									if (invalidDiscriminatorKey !== currentKey && (maxDiscriminatorPriority < currentPriority || maxDiscriminatorPriority === currentPriority && currentKey in input && !(invalidDiscriminatorKey in input))) {
										maxDiscriminatorPriority = currentPriority;
										invalidDiscriminatorKey = currentKey;
										expectedDiscriminators = [];
									}
									if (invalidDiscriminatorKey === currentKey) expectedDiscriminators.push(schema.entries[currentKey].expects);
									break;
								}
								currentPriority++;
							}
							if (keysAreValid) {
								const optionDataset = schema["~run"]({ value: input }, config$1);
								if (!outputDataset || !outputDataset.typed && optionDataset.typed) outputDataset = optionDataset;
							}
						}
						if (outputDataset && !outputDataset.issues) break;
					}
				};
				parseOptions(this, /* @__PURE__ */ new Set([this.key]));
				if (outputDataset) return outputDataset;
				_addIssue(this, "type", dataset, config$1, {
					input: input[invalidDiscriminatorKey],
					expected: /* @__PURE__ */ _joinExpects(expectedDiscriminators, "|"),
					path: [{
						type: "object",
						origin: "value",
						input,
						key: invalidDiscriminatorKey,
						value: input[invalidDiscriminatorKey]
					}]
				});
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function variantAsync(key, options, message$1) {
	return {
		kind: "schema",
		type: "variant",
		reference: variantAsync,
		expects: "Object",
		async: true,
		key,
		options,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			const input = dataset.value;
			if (input && typeof input === "object") {
				let outputDataset;
				let maxDiscriminatorPriority = 0;
				let invalidDiscriminatorKey = this.key;
				let expectedDiscriminators = [];
				const parseOptions = async (variant$1, allKeys) => {
					for (const schema of variant$1.options) {
						if (schema.type === "variant") await parseOptions(schema, new Set(allKeys).add(schema.key));
						else {
							let keysAreValid = true;
							let currentPriority = 0;
							for (const currentKey of allKeys) {
								const discriminatorSchema = schema.entries[currentKey];
								if (currentKey in input ? (await discriminatorSchema["~run"]({
									typed: false,
									value: input[currentKey]
								}, ABORT_EARLY_CONFIG)).issues : discriminatorSchema.type !== "exact_optional" && discriminatorSchema.type !== "optional" && discriminatorSchema.type !== "nullish") {
									keysAreValid = false;
									if (invalidDiscriminatorKey !== currentKey && (maxDiscriminatorPriority < currentPriority || maxDiscriminatorPriority === currentPriority && currentKey in input && !(invalidDiscriminatorKey in input))) {
										maxDiscriminatorPriority = currentPriority;
										invalidDiscriminatorKey = currentKey;
										expectedDiscriminators = [];
									}
									if (invalidDiscriminatorKey === currentKey) expectedDiscriminators.push(schema.entries[currentKey].expects);
									break;
								}
								currentPriority++;
							}
							if (keysAreValid) {
								const optionDataset = await schema["~run"]({ value: input }, config$1);
								if (!outputDataset || !outputDataset.typed && optionDataset.typed) outputDataset = optionDataset;
							}
						}
						if (outputDataset && !outputDataset.issues) break;
					}
				};
				await parseOptions(this, /* @__PURE__ */ new Set([this.key]));
				if (outputDataset) return outputDataset;
				_addIssue(this, "type", dataset, config$1, {
					input: input[invalidDiscriminatorKey],
					expected: /* @__PURE__ */ _joinExpects(expectedDiscriminators, "|"),
					path: [{
						type: "object",
						origin: "value",
						input,
						key: invalidDiscriminatorKey,
						value: input[invalidDiscriminatorKey]
					}]
				});
			} else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function void_(message$1) {
	return {
		kind: "schema",
		type: "void",
		reference: void_,
		expects: "void",
		async: false,
		message: message$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			if (dataset.value === void 0) dataset.typed = true;
			else _addIssue(this, "type", dataset, config$1);
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function keyof(schema, message$1) {
	return /* @__PURE__ */ picklist(Object.keys(schema.entries), message$1);
}
/**
* Changes the local message configuration of a schema.
*
* @param schema The schema to configure.
* @param message_ The error message.
*
* @returns The configured schema.
*/
/* @__NO_SIDE_EFFECTS__ */
function message(schema, message_) {
	return {
		...schema,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			return schema["~run"](dataset, {
				...config$1,
				message: message_
			});
		}
	};
}
/**
* Creates a modified copy of an object schema that does not contain the
* selected entries.
*
* @param schema The schema to omit from.
* @param keys The selected entries.
*
* @returns An object schema.
*/
/* @__NO_SIDE_EFFECTS__ */
function omit(schema, keys) {
	const entries$1 = { ...schema.entries };
	for (const key of keys) delete entries$1[key];
	return {
		...schema,
		entries: entries$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		}
	};
}
/**
* Parses an unknown input based on a schema.
*
* @param schema The schema to be used.
* @param input The input to be parsed.
* @param config The parse configuration.
*
* @returns The parsed input.
*/
function parse(schema, input, config$1) {
	const dataset = schema["~run"]({ value: input }, /* @__PURE__ */ getGlobalConfig(config$1));
	if (dataset.issues) throw new ValiError(dataset.issues);
	return dataset.value;
}
/**
* Parses an unknown input based on a schema.
*
* @param schema The schema to be used.
* @param input The input to be parsed.
* @param config The parse configuration.
*
* @returns The parsed input.
*/
async function parseAsync(schema, input, config$1) {
	const dataset = await schema["~run"]({ value: input }, /* @__PURE__ */ getGlobalConfig(config$1));
	if (dataset.issues) throw new ValiError(dataset.issues);
	return dataset.value;
}
/* @__NO_SIDE_EFFECTS__ */
function parser(schema, config$1) {
	const func = (input) => parse(schema, input, config$1);
	func.schema = schema;
	func.config = config$1;
	return func;
}
/* @__NO_SIDE_EFFECTS__ */
function parserAsync(schema, config$1) {
	const func = (input) => parseAsync(schema, input, config$1);
	func.schema = schema;
	func.config = config$1;
	return func;
}
/* @__NO_SIDE_EFFECTS__ */
function partial(schema, keys) {
	const entries$1 = {};
	for (const key in schema.entries) entries$1[key] = !keys || keys.includes(key) ? /* @__PURE__ */ optional(schema.entries[key]) : schema.entries[key];
	return {
		...schema,
		entries: entries$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function partialAsync(schema, keys) {
	const entries$1 = {};
	for (const key in schema.entries) entries$1[key] = !keys || keys.includes(key) ? /* @__PURE__ */ optionalAsync(schema.entries[key]) : schema.entries[key];
	return {
		...schema,
		entries: entries$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		}
	};
}
/**
* Creates a modified copy of an object schema that contains only the selected
* entries.
*
* @param schema The schema to pick from.
* @param keys The selected entries.
*
* @returns An object schema.
*/
/* @__NO_SIDE_EFFECTS__ */
function pick(schema, keys) {
	const entries$1 = {};
	for (const key of keys) entries$1[key] = schema.entries[key];
	return {
		...schema,
		entries: entries$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function pipe(...pipe$1) {
	return {
		...pipe$1[0],
		pipe: pipe$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		"~run"(dataset, config$1) {
			for (const item of pipe$1) if (item.kind !== "metadata") {
				if (dataset.issues && (item.kind === "schema" || item.kind === "transformation")) {
					dataset.typed = false;
					break;
				}
				if (!dataset.issues || !config$1.abortEarly && !config$1.abortPipeEarly) dataset = item["~run"](dataset, config$1);
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function pipeAsync(...pipe$1) {
	return {
		...pipe$1[0],
		pipe: pipe$1,
		async: true,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		},
		async "~run"(dataset, config$1) {
			for (const item of pipe$1) if (item.kind !== "metadata") {
				if (dataset.issues && (item.kind === "schema" || item.kind === "transformation")) {
					dataset.typed = false;
					break;
				}
				if (!dataset.issues || !config$1.abortEarly && !config$1.abortPipeEarly) dataset = await item["~run"](dataset, config$1);
			}
			return dataset;
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function required(schema, arg2, arg3) {
	const keys = Array.isArray(arg2) ? arg2 : void 0;
	const message$1 = Array.isArray(arg2) ? arg3 : arg2;
	const entries$1 = {};
	for (const key in schema.entries) entries$1[key] = !keys || keys.includes(key) ? /* @__PURE__ */ nonOptional(schema.entries[key], message$1) : schema.entries[key];
	return {
		...schema,
		entries: entries$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		}
	};
}
/* @__NO_SIDE_EFFECTS__ */
function requiredAsync(schema, arg2, arg3) {
	const keys = Array.isArray(arg2) ? arg2 : void 0;
	const message$1 = Array.isArray(arg2) ? arg3 : arg2;
	const entries$1 = {};
	for (const key in schema.entries) entries$1[key] = !keys || keys.includes(key) ? /* @__PURE__ */ nonOptionalAsync(schema.entries[key], message$1) : schema.entries[key];
	return {
		...schema,
		entries: entries$1,
		get "~standard"() {
			return /* @__PURE__ */ _getStandardProps(this);
		}
	};
}
/**
* Parses an unknown input based on a schema.
*
* @param schema The schema to be used.
* @param input The input to be parsed.
* @param config The parse configuration.
*
* @returns The parse result.
*/
/* @__NO_SIDE_EFFECTS__ */
function safeParse(schema, input, config$1) {
	const dataset = schema["~run"]({ value: input }, /* @__PURE__ */ getGlobalConfig(config$1));
	return {
		typed: dataset.typed,
		success: !dataset.issues,
		output: dataset.value,
		issues: dataset.issues
	};
}
/**
* Parses an unknown input based on a schema.
*
* @param schema The schema to be used.
* @param input The input to be parsed.
* @param config The parse configuration.
*
* @returns The parse result.
*/
/* @__NO_SIDE_EFFECTS__ */
async function safeParseAsync(schema, input, config$1) {
	const dataset = await schema["~run"]({ value: input }, /* @__PURE__ */ getGlobalConfig(config$1));
	return {
		typed: dataset.typed,
		success: !dataset.issues,
		output: dataset.value,
		issues: dataset.issues
	};
}
/* @__NO_SIDE_EFFECTS__ */
function safeParser(schema, config$1) {
	const func = (input) => /* @__PURE__ */ safeParse(schema, input, config$1);
	func.schema = schema;
	func.config = config$1;
	return func;
}
/* @__NO_SIDE_EFFECTS__ */
function safeParserAsync(schema, config$1) {
	const func = (input) => /* @__PURE__ */ safeParseAsync(schema, input, config$1);
	func.schema = schema;
	func.config = config$1;
	return func;
}
/**
* Summarize the error messages of issues in a pretty-printable multi-line string.
*
* @param issues The list of issues.
*
* @returns A summary of the issues.
*
* @beta
*/
/* @__NO_SIDE_EFFECTS__ */
function summarize(issues) {
	let summary = "";
	for (const issue of issues) {
		if (summary) summary += "\n";
		summary += `× ${issue.message}`;
		const dotPath = /* @__PURE__ */ getDotPath(issue);
		if (dotPath) summary += `\n  → at ${dotPath}`;
	}
	return summary;
}
/**
* Unwraps the wrapped schema.
*
* @param schema The schema to be unwrapped.
*
* @returns The unwrapped schema.
*/
/* @__NO_SIDE_EFFECTS__ */
function unwrap(schema) {
	return schema.wrapped;
}
//#endregion
export { BASE64_REGEX, BIC_REGEX, CUID2_REGEX, DECIMAL_REGEX, DIGITS_REGEX, DOMAIN_REGEX, EMAIL_REGEX, EMOJI_REGEX, HEXADECIMAL_REGEX, HEX_COLOR_REGEX, IMEI_REGEX, IPV4_REGEX, IPV6_REGEX, IP_REGEX, ISO_DATE_REGEX, ISO_DATE_TIME_REGEX, ISO_DATE_TIME_SECOND_REGEX, ISO_TIMESTAMP_REGEX, ISO_TIME_REGEX, ISO_TIME_SECOND_REGEX, ISO_WEEK_REGEX, ISRC_REGEX, JWS_COMPACT_REGEX, MAC48_REGEX, MAC64_REGEX, MAC_REGEX, NANO_ID_REGEX, OCTAL_REGEX, RFC_EMAIL_REGEX, SLUG_REGEX, ULID_REGEX, UUID_REGEX, ValiError, _addIssue, _cloneDataset, _formatCase, _getByteCount, _getGraphemeCount, _getLastMetadata, _getStandardProps, _getWordCount, _isLuhnAlgo, _isValidObjectKey, _joinExpects, _stringify, any, args, argsAsync, array, arrayAsync, assert, awaitAsync, base64, bic, bigint, blob, boolean, brand, bytes, cache, cacheAsync, check, checkAsync, checkItems, checkItemsAsync, config, creditCard, cuid2, custom, customAsync, date, decimal, deleteGlobalConfig, deleteGlobalMessage, deleteSchemaMessage, deleteSpecificMessage, description, digits, domain, email, emoji, empty, endsWith, entries, entriesFromList, entriesFromObjects, enum_ as enum, enum_, everyItem, exactOptional, exactOptionalAsync, examples, excludes, fallback, fallbackAsync, file, filterItems, findItem, finite, flatten, flavor, forward, forwardAsync, function_ as function, function_, getDefault, getDefaults, getDefaultsAsync, getDescription, getDotPath, getExamples, getFallback, getFallbacks, getFallbacksAsync, getGlobalConfig, getGlobalMessage, getMetadata, getSchemaMessage, getSpecificMessage, getTitle, graphemes, gtValue, guard, hash, hexColor, hexadecimal, imei, includes, instance, integer, intersect, intersectAsync, ip, ipv4, ipv6, is, isOfKind, isOfType, isValiError, isbn, isoDate, isoDateTime, isoDateTimeSecond, isoTime, isoTimeSecond, isoTimestamp, isoWeek, isrc, jwsCompact, keyof, lazy, lazyAsync, length, literal, looseObject, looseObjectAsync, looseTuple, looseTupleAsync, ltValue, mac, mac48, mac64, map, mapAsync, mapItems, maxBytes, maxEntries, maxGraphemes, maxLength, maxSize, maxValue, maxWords, message, metadata, mimeType, minBytes, minEntries, minGraphemes, minLength, minSize, minValue, minWords, multipleOf, nan, nanoid, never, nonEmpty, nonNullable, nonNullableAsync, nonNullish, nonNullishAsync, nonOptional, nonOptionalAsync, normalize, notBytes, notEntries, notGraphemes, notLength, notSize, notValue, notValues, notWords, null_ as null, null_, nullable, nullableAsync, nullish, nullishAsync, number, object, objectAsync, objectWithRest, objectWithRestAsync, octal, omit, optional, optionalAsync, parse, parseAsync, parseBoolean, parseJson, parser, parserAsync, partial, partialAsync, partialCheck, partialCheckAsync, pick, picklist, pipe, pipeAsync, promise, rawCheck, rawCheckAsync, rawTransform, rawTransformAsync, readonly, record, recordAsync, reduceItems, regex, required, requiredAsync, returns, returnsAsync, rfcEmail, safeInteger, safeParse, safeParseAsync, safeParser, safeParserAsync, set, setAsync, setGlobalConfig, setGlobalMessage, setSchemaMessage, setSpecificMessage, size, slug, someItem, sortItems, startsWith, strictObject, strictObjectAsync, strictTuple, strictTupleAsync, string, stringifyJson, summarize, symbol, title, toBigint, toBoolean, toCamelCase, toDate, toKebabCase, toLowerCase, toMaxValue, toMinValue, toNumber, toPascalCase, toSnakeCase, toString, toUpperCase, transform, transformAsync, trim, trimEnd, trimStart, tuple, tupleAsync, tupleWithRest, tupleWithRestAsync, ulid, undefined_ as undefined, undefined_, undefinedable, undefinedableAsync, union, unionAsync, unknown, unwrap, url, uuid, value, values, variant, variantAsync, void_ as void, void_, words };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWJvdC5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi8ucG5wbS92YWxpYm90QDEuNC4yX3R5cGVzY3JpcHRANi4wLjMvbm9kZV9tb2R1bGVzL3ZhbGlib3QvZGlzdC9pbmRleC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8jcmVnaW9uIHNyYy9zdG9yYWdlcy9nbG9iYWxDb25maWcvZ2xvYmFsQ29uZmlnLnRzXG5sZXQgc3RvcmUkNDtcbmNvbnN0IERFRkFVTFRfQ09ORklHID0ge1xuXHRsYW5nOiB2b2lkIDAsXG5cdG1lc3NhZ2U6IHZvaWQgMCxcblx0YWJvcnRFYXJseTogdm9pZCAwLFxuXHRhYm9ydFBpcGVFYXJseTogdm9pZCAwXG59O1xuLyoqXG4qIFNldHMgdGhlIGdsb2JhbCBjb25maWd1cmF0aW9uLlxuKlxuKiBAcGFyYW0gY29uZmlnIFRoZSBjb25maWd1cmF0aW9uLlxuKi9cbmZ1bmN0aW9uIHNldEdsb2JhbENvbmZpZyhjb25maWckMSkge1xuXHRzdG9yZSQ0ID0ge1xuXHRcdC4uLnN0b3JlJDQsXG5cdFx0Li4uY29uZmlnJDFcblx0fTtcbn1cbi8qKlxuKiBSZXR1cm5zIHRoZSBnbG9iYWwgY29uZmlndXJhdGlvbi5cbipcbiogQHBhcmFtIGNvbmZpZyBUaGUgY29uZmlnIHRvIG1lcmdlLlxuKlxuKiBAcmV0dXJucyBUaGUgY29uZmlndXJhdGlvbi5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gZ2V0R2xvYmFsQ29uZmlnKGNvbmZpZyQxKSB7XG5cdGlmICghY29uZmlnJDEgJiYgIXN0b3JlJDQpIHJldHVybiBERUZBVUxUX0NPTkZJRztcblx0cmV0dXJuIHtcblx0XHRsYW5nOiBjb25maWckMT8ubGFuZyA/PyBzdG9yZSQ0Py5sYW5nLFxuXHRcdG1lc3NhZ2U6IGNvbmZpZyQxPy5tZXNzYWdlLFxuXHRcdGFib3J0RWFybHk6IGNvbmZpZyQxPy5hYm9ydEVhcmx5ID8/IHN0b3JlJDQ/LmFib3J0RWFybHksXG5cdFx0YWJvcnRQaXBlRWFybHk6IGNvbmZpZyQxPy5hYm9ydFBpcGVFYXJseSA/PyBzdG9yZSQ0Py5hYm9ydFBpcGVFYXJseVxuXHR9O1xufVxuLyoqXG4qIERlbGV0ZXMgdGhlIGdsb2JhbCBjb25maWd1cmF0aW9uLlxuKi9cbmZ1bmN0aW9uIGRlbGV0ZUdsb2JhbENvbmZpZygpIHtcblx0c3RvcmUkNCA9IHZvaWQgMDtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3N0b3JhZ2VzL2dsb2JhbE1lc3NhZ2UvZ2xvYmFsTWVzc2FnZS50c1xubGV0IHN0b3JlJDM7XG4vKipcbiogU2V0cyBhIGdsb2JhbCBlcnJvciBtZXNzYWdlLlxuKlxuKiBAcGFyYW0gbWVzc2FnZSBUaGUgZXJyb3IgbWVzc2FnZS5cbiogQHBhcmFtIGxhbmcgVGhlIGxhbmd1YWdlIG9mIHRoZSBtZXNzYWdlLlxuKi9cbmZ1bmN0aW9uIHNldEdsb2JhbE1lc3NhZ2UobWVzc2FnZSQxLCBsYW5nKSB7XG5cdGlmICghc3RvcmUkMykgc3RvcmUkMyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdHN0b3JlJDMuc2V0KGxhbmcsIG1lc3NhZ2UkMSk7XG59XG4vKipcbiogUmV0dXJucyBhIGdsb2JhbCBlcnJvciBtZXNzYWdlLlxuKlxuKiBAcGFyYW0gbGFuZyBUaGUgbGFuZ3VhZ2Ugb2YgdGhlIG1lc3NhZ2UuXG4qXG4qIEByZXR1cm5zIFRoZSBlcnJvciBtZXNzYWdlLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBnZXRHbG9iYWxNZXNzYWdlKGxhbmcpIHtcblx0cmV0dXJuIHN0b3JlJDM/LmdldChsYW5nKTtcbn1cbi8qKlxuKiBEZWxldGVzIGEgZ2xvYmFsIGVycm9yIG1lc3NhZ2UuXG4qXG4qIEBwYXJhbSBsYW5nIFRoZSBsYW5ndWFnZSBvZiB0aGUgbWVzc2FnZS5cbiovXG5mdW5jdGlvbiBkZWxldGVHbG9iYWxNZXNzYWdlKGxhbmcpIHtcblx0c3RvcmUkMz8uZGVsZXRlKGxhbmcpO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc3RvcmFnZXMvc2NoZW1hTWVzc2FnZS9zY2hlbWFNZXNzYWdlLnRzXG5sZXQgc3RvcmUkMjtcbi8qKlxuKiBTZXRzIGEgc2NoZW1hIGVycm9yIG1lc3NhZ2UuXG4qXG4qIEBwYXJhbSBtZXNzYWdlIFRoZSBlcnJvciBtZXNzYWdlLlxuKiBAcGFyYW0gbGFuZyBUaGUgbGFuZ3VhZ2Ugb2YgdGhlIG1lc3NhZ2UuXG4qL1xuZnVuY3Rpb24gc2V0U2NoZW1hTWVzc2FnZShtZXNzYWdlJDEsIGxhbmcpIHtcblx0aWYgKCFzdG9yZSQyKSBzdG9yZSQyID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0c3RvcmUkMi5zZXQobGFuZywgbWVzc2FnZSQxKTtcbn1cbi8qKlxuKiBSZXR1cm5zIGEgc2NoZW1hIGVycm9yIG1lc3NhZ2UuXG4qXG4qIEBwYXJhbSBsYW5nIFRoZSBsYW5ndWFnZSBvZiB0aGUgbWVzc2FnZS5cbipcbiogQHJldHVybnMgVGhlIGVycm9yIG1lc3NhZ2UuXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGdldFNjaGVtYU1lc3NhZ2UobGFuZykge1xuXHRyZXR1cm4gc3RvcmUkMj8uZ2V0KGxhbmcpO1xufVxuLyoqXG4qIERlbGV0ZXMgYSBzY2hlbWEgZXJyb3IgbWVzc2FnZS5cbipcbiogQHBhcmFtIGxhbmcgVGhlIGxhbmd1YWdlIG9mIHRoZSBtZXNzYWdlLlxuKi9cbmZ1bmN0aW9uIGRlbGV0ZVNjaGVtYU1lc3NhZ2UobGFuZykge1xuXHRzdG9yZSQyPy5kZWxldGUobGFuZyk7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zdG9yYWdlcy9zcGVjaWZpY01lc3NhZ2Uvc3BlY2lmaWNNZXNzYWdlLnRzXG5sZXQgc3RvcmUkMTtcbi8qKlxuKiBTZXRzIGEgc3BlY2lmaWMgZXJyb3IgbWVzc2FnZS5cbipcbiogQHBhcmFtIHJlZmVyZW5jZSBUaGUgaWRlbnRpZmllciByZWZlcmVuY2UuXG4qIEBwYXJhbSBtZXNzYWdlIFRoZSBlcnJvciBtZXNzYWdlLlxuKiBAcGFyYW0gbGFuZyBUaGUgbGFuZ3VhZ2Ugb2YgdGhlIG1lc3NhZ2UuXG4qL1xuZnVuY3Rpb24gc2V0U3BlY2lmaWNNZXNzYWdlKHJlZmVyZW5jZSwgbWVzc2FnZSQxLCBsYW5nKSB7XG5cdGlmICghc3RvcmUkMSkgc3RvcmUkMSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGlmICghc3RvcmUkMS5nZXQocmVmZXJlbmNlKSkgc3RvcmUkMS5zZXQocmVmZXJlbmNlLCAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKTtcblx0c3RvcmUkMS5nZXQocmVmZXJlbmNlKS5zZXQobGFuZywgbWVzc2FnZSQxKTtcbn1cbi8qKlxuKiBSZXR1cm5zIGEgc3BlY2lmaWMgZXJyb3IgbWVzc2FnZS5cbipcbiogQHBhcmFtIHJlZmVyZW5jZSBUaGUgaWRlbnRpZmllciByZWZlcmVuY2UuXG4qIEBwYXJhbSBsYW5nIFRoZSBsYW5ndWFnZSBvZiB0aGUgbWVzc2FnZS5cbipcbiogQHJldHVybnMgVGhlIGVycm9yIG1lc3NhZ2UuXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGdldFNwZWNpZmljTWVzc2FnZShyZWZlcmVuY2UsIGxhbmcpIHtcblx0cmV0dXJuIHN0b3JlJDE/LmdldChyZWZlcmVuY2UpPy5nZXQobGFuZyk7XG59XG4vKipcbiogRGVsZXRlcyBhIHNwZWNpZmljIGVycm9yIG1lc3NhZ2UuXG4qXG4qIEBwYXJhbSByZWZlcmVuY2UgVGhlIGlkZW50aWZpZXIgcmVmZXJlbmNlLlxuKiBAcGFyYW0gbGFuZyBUaGUgbGFuZ3VhZ2Ugb2YgdGhlIG1lc3NhZ2UuXG4qL1xuZnVuY3Rpb24gZGVsZXRlU3BlY2lmaWNNZXNzYWdlKHJlZmVyZW5jZSwgbGFuZykge1xuXHRzdG9yZSQxPy5nZXQocmVmZXJlbmNlKT8uZGVsZXRlKGxhbmcpO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvX3N0cmluZ2lmeS9fc3RyaW5naWZ5LnRzXG4vKipcbiogU3RyaW5naWZpZXMgYW4gdW5rbm93biBpbnB1dCB0byBhIGxpdGVyYWwgb3IgdHlwZSBzdHJpbmcuXG4qXG4qIEBwYXJhbSBpbnB1dCBUaGUgdW5rbm93biBpbnB1dC5cbipcbiogQHJldHVybnMgQSBsaXRlcmFsIG9yIHR5cGUgc3RyaW5nLlxuKlxuKiBAaW50ZXJuYWxcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gX3N0cmluZ2lmeShpbnB1dCkge1xuXHRjb25zdCB0eXBlID0gdHlwZW9mIGlucHV0O1xuXHRpZiAodHlwZSA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIGBcIiR7aW5wdXR9XCJgO1xuXHRpZiAodHlwZSA9PT0gXCJudW1iZXJcIiB8fCB0eXBlID09PSBcImJpZ2ludFwiIHx8IHR5cGUgPT09IFwiYm9vbGVhblwiKSByZXR1cm4gYCR7aW5wdXR9YDtcblx0aWYgKHR5cGUgPT09IFwib2JqZWN0XCIgfHwgdHlwZSA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gKGlucHV0ICYmIE9iamVjdC5nZXRQcm90b3R5cGVPZihpbnB1dCk/LmNvbnN0cnVjdG9yPy5uYW1lKSA/PyBcIm51bGxcIjtcblx0cmV0dXJuIHR5cGU7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy9fYWRkSXNzdWUvX2FkZElzc3VlLnRzXG4vKipcbiogQWRkcyBhbiBpc3N1ZSB0byB0aGUgZGF0YXNldC5cbipcbiogQHBhcmFtIGNvbnRleHQgVGhlIGlzc3VlIGNvbnRleHQuXG4qIEBwYXJhbSBsYWJlbCBUaGUgaXNzdWUgbGFiZWwuXG4qIEBwYXJhbSBkYXRhc2V0IFRoZSBpbnB1dCBkYXRhc2V0LlxuKiBAcGFyYW0gY29uZmlnIFRoZSBjb25maWd1cmF0aW9uLlxuKiBAcGFyYW0gb3RoZXIgVGhlIG9wdGlvbmFsIHByb3BzLlxuKlxuKiBAaW50ZXJuYWxcbiovXG5mdW5jdGlvbiBfYWRkSXNzdWUoY29udGV4dCwgbGFiZWwsIGRhdGFzZXQsIGNvbmZpZyQxLCBvdGhlcikge1xuXHRjb25zdCBpbnB1dCA9IG90aGVyICYmIFwiaW5wdXRcIiBpbiBvdGhlciA/IG90aGVyLmlucHV0IDogZGF0YXNldC52YWx1ZTtcblx0Y29uc3QgZXhwZWN0ZWQgPSBvdGhlcj8uZXhwZWN0ZWQgPz8gY29udGV4dC5leHBlY3RzID8/IG51bGw7XG5cdGNvbnN0IHJlY2VpdmVkID0gb3RoZXI/LnJlY2VpdmVkID8/IC8qIEBfX1BVUkVfXyAqLyBfc3RyaW5naWZ5KGlucHV0KTtcblx0Y29uc3QgaXNzdWUgPSB7XG5cdFx0a2luZDogY29udGV4dC5raW5kLFxuXHRcdHR5cGU6IGNvbnRleHQudHlwZSxcblx0XHRpbnB1dCxcblx0XHRleHBlY3RlZCxcblx0XHRyZWNlaXZlZCxcblx0XHRtZXNzYWdlOiBgSW52YWxpZCAke2xhYmVsfTogJHtleHBlY3RlZCA/IGBFeHBlY3RlZCAke2V4cGVjdGVkfSBidXQgcmAgOiBcIlJcIn1lY2VpdmVkICR7cmVjZWl2ZWR9YCxcblx0XHRyZXF1aXJlbWVudDogY29udGV4dC5yZXF1aXJlbWVudCxcblx0XHRwYXRoOiBvdGhlcj8ucGF0aCxcblx0XHRpc3N1ZXM6IG90aGVyPy5pc3N1ZXMsXG5cdFx0bGFuZzogY29uZmlnJDEubGFuZyxcblx0XHRhYm9ydEVhcmx5OiBjb25maWckMS5hYm9ydEVhcmx5LFxuXHRcdGFib3J0UGlwZUVhcmx5OiBjb25maWckMS5hYm9ydFBpcGVFYXJseVxuXHR9O1xuXHRjb25zdCBpc1NjaGVtYSA9IGNvbnRleHQua2luZCA9PT0gXCJzY2hlbWFcIjtcblx0Y29uc3QgbWVzc2FnZSQxID0gb3RoZXI/Lm1lc3NhZ2UgPz8gY29udGV4dC5tZXNzYWdlID8/IC8qIEBfX1BVUkVfXyAqLyBnZXRTcGVjaWZpY01lc3NhZ2UoY29udGV4dC5yZWZlcmVuY2UsIGlzc3VlLmxhbmcpID8/IChpc1NjaGVtYSA/IC8qIEBfX1BVUkVfXyAqLyBnZXRTY2hlbWFNZXNzYWdlKGlzc3VlLmxhbmcpIDogbnVsbCkgPz8gY29uZmlnJDEubWVzc2FnZSA/PyAvKiBAX19QVVJFX18gKi8gZ2V0R2xvYmFsTWVzc2FnZShpc3N1ZS5sYW5nKTtcblx0aWYgKG1lc3NhZ2UkMSAhPT0gdm9pZCAwKSBpc3N1ZS5tZXNzYWdlID0gdHlwZW9mIG1lc3NhZ2UkMSA9PT0gXCJmdW5jdGlvblwiID8gbWVzc2FnZSQxKGlzc3VlKSA6IG1lc3NhZ2UkMTtcblx0aWYgKGlzU2NoZW1hKSBkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdGlmIChkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMucHVzaChpc3N1ZSk7XG5cdGVsc2UgZGF0YXNldC5pc3N1ZXMgPSBbaXNzdWVdO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvX2Nsb25lRGF0YXNldC9fY2xvbmVEYXRhc2V0LnRzXG4vKipcbiogQ3JlYXRlcyBhIHNoYWxsb3cgY29weSBvZiBhIGRhdGFzZXQuXG4qXG4qIEhpbnQ6IFRoZSBgdmFsdWVgIGlzIGNvcGllZCBieSByZWZlcmVuY2UsIGJ1dCB0aGUgYGlzc3Vlc2AgYXJyYXkgaXMgY2xvbmVkXG4qIHRvIGF2b2lkIHJldXNpbmcgbXV0YWJsZSBkYXRhc2V0IHN0YXRlIGFjcm9zcyBtdWx0aXBsZSBydW5zLiBNdXRhdGluZyBhXG4qIHJldHVybmVkIG9iamVjdCBvciBhcnJheSB2YWx1ZSBjYW4gdGhlcmVmb3JlIGFmZmVjdCBsYXRlciBjYWNoZSBoaXRzIHRoYXRcbiogcmV1c2UgdGhlIHNhbWUgY2FjaGVkIG91dHB1dC5cbipcbiogQHBhcmFtIGRhdGFzZXQgVGhlIG91dHB1dCBkYXRhc2V0LlxuKlxuKiBAcmV0dXJucyBUaGUgY29waWVkIG91dHB1dCBkYXRhc2V0LlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBfY2xvbmVEYXRhc2V0KGRhdGFzZXQpIHtcblx0cmV0dXJuIHtcblx0XHR0eXBlZDogZGF0YXNldC50eXBlZCxcblx0XHR2YWx1ZTogZGF0YXNldC52YWx1ZSxcblx0XHRpc3N1ZXM6IGRhdGFzZXQuaXNzdWVzICYmIFsuLi5kYXRhc2V0Lmlzc3Vlc11cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3V0aWxzL19mb3JtYXRDYXNlL19mb3JtYXRDYXNlLnRzXG4vKipcbiogU3BsaXRzIGEgc3RyaW5nIGludG8gbG93ZXJjYXNlIHdvcmRzIGFuZCByZWpvaW5zIHRoZW0gd2l0aCB0aGUgZ2l2ZW5cbiogc2VwYXJhdG9yIGFuZCBjYXBpdGFsaXphdGlvbiBydWxlcy5cbipcbiogV29yZHMgYXJlIHNlcGFyYXRlZCBieSBgX2AsIGAtYCBhbmQgQVNDSUkgd2hpdGVzcGFjZSwgYXMgd2VsbCBhcyBieSBjYXNlXG4qIGFuZCBhY3JvbnltIGJvdW5kYXJpZXMuIFdoZXRoZXIgdGhlIGZpcnN0IG9yIHN1YnNlcXVlbnQgd29yZHMgYXJlXG4qIGNhcGl0YWxpemVkIGlzIGNvbnRyb2xsZWQgYnkgYGNhcEZpcnN0YCBhbmQgYGNhcFJlc3RgLlxuKlxuKiBIaW50OiBJbXBsZW1lbnRlZCBpbiBhIHNpbmdsZSBwYXNzIHRoYXQgZW1pdHMgZGlyZWN0bHkgdG8gdGhlIHJlc3VsdFxuKiBzdHJpbmcgdG8gYXZvaWQgYW4gaW50ZXJtZWRpYXRlIGBzdHJpbmdbXWAgYWxsb2NhdGlvbi4gQVNDSUkgY2hhcnMgYXJlXG4qIGNsYXNzaWZpZWQgdmlhIGNoYXIgY29kZXMgdG8gc2tpcCBgLnRvTG93ZXJDYXNlKClgIGFuZCBgLnRvVXBwZXJDYXNlKClgXG4qIG1ldGhvZCBjYWxscyBpbiB0aGUgY29tbW9uIGNhc2UuXG4qXG4qIEhpbnQ6IERpZ2l0cyBhcmUgdHJlYXRlZCBhcyBhIHNlcGFyYXRlIGNoYXJhY3RlciBjbGFzcywgc28gYGl0ZW0yTmFtZWBcbiogeWllbGRzIGBpdGVtMmAgYW5kIGBuYW1lYCByYXRoZXIgdGhhbiBgaXRlbWAsIGAyYCBhbmQgYG5hbWVgLlxuKlxuKiBAcGFyYW0gaW5wdXQgVGhlIGlucHV0IHN0cmluZy5cbiogQHBhcmFtIHNlcGFyYXRvciBUaGUgc3RyaW5nIGluc2VydGVkIGJldHdlZW4gd29yZHMuXG4qIEBwYXJhbSBjYXBGaXJzdCBXaGV0aGVyIHRvIGNhcGl0YWxpemUgdGhlIGZpcnN0IHdvcmQuXG4qIEBwYXJhbSBjYXBSZXN0IFdoZXRoZXIgdG8gY2FwaXRhbGl6ZSBzdWJzZXF1ZW50IHdvcmRzLlxuKlxuKiBAcmV0dXJucyBUaGUgZm9ybWF0dGVkIHN0cmluZy5cbipcbiogQGludGVybmFsXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIF9mb3JtYXRDYXNlKGlucHV0LCBzZXBhcmF0b3IsIGNhcEZpcnN0LCBjYXBSZXN0KSB7XG5cdGxldCByZXN1bHQgPSBcIlwiO1xuXHRsZXQgZmlyc3RXb3JkID0gdHJ1ZTtcblx0bGV0IHN0YXJ0ID0gMDtcblx0bGV0IHByZXYgPSAwO1xuXHRsZXQgcHJldlByZXYgPSAwO1xuXHRjb25zdCBmbHVzaCA9IChlbmQpID0+IHtcblx0XHRpZiAoZW5kID4gc3RhcnQpIHtcblx0XHRcdGxldCB3b3JkID0gaW5wdXQuc2xpY2Uoc3RhcnQsIGVuZCkudG9Mb3dlckNhc2UoKTtcblx0XHRcdGlmIChmaXJzdFdvcmQgPyBjYXBGaXJzdCA6IGNhcFJlc3QpIHtcblx0XHRcdFx0Y29uc3QgZmlyc3RDb2RlID0gd29yZC5jaGFyQ29kZUF0KDApO1xuXHRcdFx0XHRpZiAoZmlyc3RDb2RlID49IDk3ICYmIGZpcnN0Q29kZSA8PSAxMjIpIHdvcmQgPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGZpcnN0Q29kZSAtIDMyKSArIHdvcmQuc2xpY2UoMSk7XG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdGNvbnN0IGNoYXJMZW4gPSBmaXJzdENvZGUgPj0gNTUyOTYgJiYgZmlyc3RDb2RlIDw9IDU2MzE5ID8gMiA6IDE7XG5cdFx0XHRcdFx0d29yZCA9IHdvcmQuc2xpY2UoMCwgY2hhckxlbikudG9VcHBlckNhc2UoKSArIHdvcmQuc2xpY2UoY2hhckxlbik7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJlc3VsdCArPSBmaXJzdFdvcmQgPyB3b3JkIDogc2VwYXJhdG9yICsgd29yZDtcblx0XHRcdGZpcnN0V29yZCA9IGZhbHNlO1xuXHRcdH1cblx0fTtcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGlucHV0Lmxlbmd0aDsgaW5kZXgrKykge1xuXHRcdGNvbnN0IGNvZGUgPSBpbnB1dC5jaGFyQ29kZUF0KGluZGV4KTtcblx0XHRsZXQgdHlwZTtcblx0XHRpZiAoY29kZSA9PT0gMzIgfHwgY29kZSA9PT0gOSB8fCBjb2RlID09PSAxMCB8fCBjb2RlID09PSAxMSB8fCBjb2RlID09PSAxMiB8fCBjb2RlID09PSAxMyB8fCBjb2RlID09PSA0NSB8fCBjb2RlID09PSA5NSkge1xuXHRcdFx0Zmx1c2goaW5kZXgpO1xuXHRcdFx0c3RhcnQgPSBpbmRleCArIDE7XG5cdFx0XHR0eXBlID0gMDtcblx0XHR9IGVsc2UgaWYgKGNvZGUgPCAxMjgpIHR5cGUgPSBjb2RlID49IDY1ICYmIGNvZGUgPD0gOTAgPyAxIDogY29kZSA+PSA5NyAmJiBjb2RlIDw9IDEyMiA/IDIgOiAzO1xuXHRcdGVsc2Uge1xuXHRcdFx0Y29uc3QgY2hhciA9IGlucHV0W2luZGV4XTtcblx0XHRcdGNvbnN0IGNoYXJMb3dlciA9IGNoYXIudG9Mb3dlckNhc2UoKTtcblx0XHRcdHR5cGUgPSBjaGFyTG93ZXIgPT09IGNoYXIudG9VcHBlckNhc2UoKSA/IDMgOiBjaGFyID09PSBjaGFyTG93ZXIgPyAyIDogMTtcblx0XHR9XG5cdFx0aWYgKHR5cGUgPT09IDEgJiYgKHByZXYgPT09IDIgfHwgcHJldiA9PT0gMykgJiYgaW5kZXggPiBzdGFydCkge1xuXHRcdFx0Zmx1c2goaW5kZXgpO1xuXHRcdFx0c3RhcnQgPSBpbmRleDtcblx0XHR9IGVsc2UgaWYgKHR5cGUgPT09IDIgJiYgcHJldiA9PT0gMSAmJiBwcmV2UHJldiA9PT0gMSAmJiBpbmRleCAtIDEgPiBzdGFydCkge1xuXHRcdFx0Zmx1c2goaW5kZXggLSAxKTtcblx0XHRcdHN0YXJ0ID0gaW5kZXggLSAxO1xuXHRcdH1cblx0XHRwcmV2UHJldiA9IHByZXY7XG5cdFx0cHJldiA9IHR5cGU7XG5cdH1cblx0Zmx1c2goaW5wdXQubGVuZ3RoKTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3V0aWxzL19nZXRCeXRlQ291bnQvX2dldEJ5dGVDb3VudC50c1xubGV0IHRleHRFbmNvZGVyO1xuLyoqXG4qIFJldHVybnMgdGhlIGJ5dGUgY291bnQgb2YgdGhlIGlucHV0LlxuKlxuKiBAcGFyYW0gaW5wdXQgVGhlIGlucHV0IHRvIGJlIG1lYXN1cmVkLlxuKlxuKiBAcmV0dXJucyBUaGUgYnl0ZSBjb3VudC5cbipcbiogQGludGVybmFsXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIF9nZXRCeXRlQ291bnQoaW5wdXQpIHtcblx0aWYgKCF0ZXh0RW5jb2RlcikgdGV4dEVuY29kZXIgPSBuZXcgVGV4dEVuY29kZXIoKTtcblx0cmV0dXJuIHRleHRFbmNvZGVyLmVuY29kZShpbnB1dCkubGVuZ3RoO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvX2dldEdyYXBoZW1lQ291bnQvX2dldEdyYXBoZW1lQ291bnQudHNcbmxldCBzZWdtZW50ZXI7XG4vKipcbiogUmV0dXJucyB0aGUgZ3JhcGhlbWUgY291bnQgb2YgdGhlIGlucHV0LlxuKlxuKiBAcGFyYW0gaW5wdXQgVGhlIGlucHV0IHRvIGJlIG1lYXN1cmVkLlxuKlxuKiBAcmV0dXJucyBUaGUgZ3JhcGhlbWUgY291bnQuXG4qXG4qIEBpbnRlcm5hbFxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBfZ2V0R3JhcGhlbWVDb3VudChpbnB1dCkge1xuXHRpZiAoIXNlZ21lbnRlcikgc2VnbWVudGVyID0gbmV3IEludGwuU2VnbWVudGVyKCk7XG5cdGNvbnN0IHNlZ21lbnRzID0gc2VnbWVudGVyLnNlZ21lbnQoaW5wdXQpO1xuXHRsZXQgY291bnQgPSAwO1xuXHRmb3IgKGNvbnN0IF8gb2Ygc2VnbWVudHMpIGNvdW50Kys7XG5cdHJldHVybiBjb3VudDtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3V0aWxzL19nZXRMYXN0TWV0YWRhdGEvX2dldExhc3RNZXRhZGF0YS50c1xuLyoqXG4qIFJldHVybnMgdGhlIGxhc3QgdG9wLWxldmVsIHZhbHVlIG9mIGEgZ2l2ZW4gbWV0YWRhdGEgdHlwZSBmcm9tIGEgc2NoZW1hXG4qIHVzaW5nIGEgYnJlYWR0aC1maXJzdCBzZWFyY2ggdGhhdCBzdGFydHMgd2l0aCB0aGUgbGFzdCBpdGVtIGluIHRoZSBwaXBlbGluZS5cbipcbiogQHBhcmFtIHNjaGVtYSBUaGUgc2NoZW1hIHRvIHNlYXJjaC5cbiogQHBhcmFtIHR5cGUgVGhlIG1ldGFkYXRhIHR5cGUuXG4qXG4qIEByZXR1cm5zIFRoZSB2YWx1ZSwgaWYgYW55LlxuKlxuKiBAaW50ZXJuYWxcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gX2dldExhc3RNZXRhZGF0YShzY2hlbWEsIHR5cGUpIHtcblx0aWYgKFwicGlwZVwiIGluIHNjaGVtYSkge1xuXHRcdGNvbnN0IG5lc3RlZFNjaGVtYXMgPSBbXTtcblx0XHRmb3IgKGxldCBpbmRleCA9IHNjaGVtYS5waXBlLmxlbmd0aCAtIDE7IGluZGV4ID49IDA7IGluZGV4LS0pIHtcblx0XHRcdGNvbnN0IGl0ZW0gPSBzY2hlbWEucGlwZVtpbmRleF07XG5cdFx0XHRpZiAoaXRlbS5raW5kID09PSBcInNjaGVtYVwiICYmIFwicGlwZVwiIGluIGl0ZW0pIG5lc3RlZFNjaGVtYXMucHVzaChpdGVtKTtcblx0XHRcdGVsc2UgaWYgKGl0ZW0ua2luZCA9PT0gXCJtZXRhZGF0YVwiICYmIGl0ZW0udHlwZSA9PT0gdHlwZSkgcmV0dXJuIGl0ZW1bdHlwZV07XG5cdFx0fVxuXHRcdGZvciAoY29uc3QgbmVzdGVkU2NoZW1hIG9mIG5lc3RlZFNjaGVtYXMpIHtcblx0XHRcdGNvbnN0IHJlc3VsdCA9IC8qIEBfX1BVUkVfXyAqLyBfZ2V0TGFzdE1ldGFkYXRhKG5lc3RlZFNjaGVtYSwgdHlwZSk7XG5cdFx0XHRpZiAocmVzdWx0ICE9PSB2b2lkIDApIHJldHVybiByZXN1bHQ7XG5cdFx0fVxuXHR9XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy9fZ2V0U3RhbmRhcmRQcm9wcy9fZ2V0U3RhbmRhcmRQcm9wcy50c1xuY29uc3QgX3N0YW5kYXJkQ2FjaGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbi8qKlxuKiBSZXR1cm5zIHRoZSBTdGFuZGFyZCBTY2hlbWEgcHJvcGVydGllcy5cbipcbiogQHBhcmFtIGNvbnRleHQgVGhlIHNjaGVtYSBjb250ZXh0LlxuKlxuKiBAcmV0dXJucyBUaGUgU3RhbmRhcmQgU2NoZW1hIHByb3BlcnRpZXMuXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIF9nZXRTdGFuZGFyZFByb3BzKGNvbnRleHQpIHtcblx0bGV0IGNhY2hlZCA9IF9zdGFuZGFyZENhY2hlLmdldChjb250ZXh0KTtcblx0aWYgKCFjYWNoZWQpIHtcblx0XHRjYWNoZWQgPSB7XG5cdFx0XHR2ZXJzaW9uOiAxLFxuXHRcdFx0dmVuZG9yOiBcInZhbGlib3RcIixcblx0XHRcdHZhbGlkYXRlKHZhbHVlJDEpIHtcblx0XHRcdFx0cmV0dXJuIGNvbnRleHRbXCJ+cnVuXCJdKHsgdmFsdWU6IHZhbHVlJDEgfSwgLyogQF9fUFVSRV9fICovIGdldEdsb2JhbENvbmZpZygpKTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdF9zdGFuZGFyZENhY2hlLnNldChjb250ZXh0LCBjYWNoZWQpO1xuXHR9XG5cdHJldHVybiBjYWNoZWQ7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy9fZ2V0V29yZENvdW50L19nZXRXb3JkQ291bnQudHNcbmxldCBzdG9yZTtcbi8qKlxuKiBSZXR1cm5zIHRoZSB3b3JkIGNvdW50IG9mIHRoZSBpbnB1dC5cbipcbiogQHBhcmFtIGxvY2FsZXMgVGhlIGxvY2FsZXMgdG8gYmUgdXNlZC5cbiogQHBhcmFtIGlucHV0IFRoZSBpbnB1dCB0byBiZSBtZWFzdXJlZC5cbipcbiogQHJldHVybnMgVGhlIHdvcmQgY291bnQuXG4qXG4qIEBpbnRlcm5hbFxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBfZ2V0V29yZENvdW50KGxvY2FsZXMsIGlucHV0KSB7XG5cdGlmICghc3RvcmUpIHN0b3JlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0Y29uc3Qga2V5ID0gU3RyaW5nKGxvY2FsZXMpO1xuXHRsZXQgc2VnbWVudGVyJDEgPSBzdG9yZS5nZXQoa2V5KTtcblx0aWYgKCFzZWdtZW50ZXIkMSkge1xuXHRcdHNlZ21lbnRlciQxID0gbmV3IEludGwuU2VnbWVudGVyKGxvY2FsZXMsIHsgZ3JhbnVsYXJpdHk6IFwid29yZFwiIH0pO1xuXHRcdHN0b3JlLnNldChrZXksIHNlZ21lbnRlciQxKTtcblx0fVxuXHRjb25zdCBzZWdtZW50cyA9IHNlZ21lbnRlciQxLnNlZ21lbnQoaW5wdXQpO1xuXHRsZXQgY291bnQgPSAwO1xuXHRmb3IgKGNvbnN0IHNlZ21lbnQgb2Ygc2VnbWVudHMpIGlmIChzZWdtZW50LmlzV29yZExpa2UpIGNvdW50Kys7XG5cdHJldHVybiBjb3VudDtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3V0aWxzL19pc0x1aG5BbGdvL19pc0x1aG5BbGdvLnRzXG4vKipcbiogTm9uLWRpZ2l0IHJlZ2V4LlxuKi9cbmNvbnN0IE5PTl9ESUdJVF9SRUdFWCA9IC9cXEQvZ3U7XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBzdHJpbmcgd2l0aCBudW1iZXJzIGNvcnJlc3BvbmRzIHRvIHRoZSBsdWhuIGFsZ29yaXRobS5cbipcbiogQHBhcmFtIGlucHV0IFRoZSBpbnB1dCB0byBiZSBjaGVja2VkLlxuKlxuKiBAcmV0dXJucyBXaGV0aGVyIGlucHV0IGlzIHZhbGlkLlxuKlxuKiBAaW50ZXJuYWxcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gX2lzTHVobkFsZ28oaW5wdXQpIHtcblx0Y29uc3QgbnVtYmVyJDEgPSBpbnB1dC5yZXBsYWNlKE5PTl9ESUdJVF9SRUdFWCwgXCJcIik7XG5cdGxldCBsZW5ndGgkMSA9IG51bWJlciQxLmxlbmd0aDtcblx0bGV0IGJpdCA9IDE7XG5cdGxldCBzdW0gPSAwO1xuXHR3aGlsZSAobGVuZ3RoJDEpIHtcblx0XHRjb25zdCB2YWx1ZSQxID0gK251bWJlciQxWy0tbGVuZ3RoJDFdO1xuXHRcdGJpdCBePSAxO1xuXHRcdHN1bSArPSBiaXQgPyBbXG5cdFx0XHQwLFxuXHRcdFx0Mixcblx0XHRcdDQsXG5cdFx0XHQ2LFxuXHRcdFx0OCxcblx0XHRcdDEsXG5cdFx0XHQzLFxuXHRcdFx0NSxcblx0XHRcdDcsXG5cdFx0XHQ5XG5cdFx0XVt2YWx1ZSQxXSA6IHZhbHVlJDE7XG5cdH1cblx0cmV0dXJuIHN1bSAlIDEwID09PSAwO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvX2lzVmFsaWRPYmplY3RLZXkvX2lzVmFsaWRPYmplY3RLZXkudHNcbi8qKlxuKiBEaXNhbGxvd3MgaW5oZXJpdGVkIG9iamVjdCBwcm9wZXJ0aWVzIGFuZCBwcmV2ZW50cyBvYmplY3QgcHJvdG90eXBlXG4qIHBvbGx1dGlvbiBieSBkaXNhbGxvd2luZyBjZXJ0YWluIGtleXMuXG4qXG4qIEBwYXJhbSBvYmplY3QgVGhlIG9iamVjdCB0byBjaGVjay5cbiogQHBhcmFtIGtleSBUaGUga2V5IHRvIGNoZWNrLlxuKlxuKiBAcmV0dXJucyBXaGV0aGVyIHRoZSBrZXkgaXMgYWxsb3dlZC5cbipcbiogQGludGVybmFsXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIF9pc1ZhbGlkT2JqZWN0S2V5KG9iamVjdCQxLCBrZXkpIHtcblx0cmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QkMSwga2V5KSAmJiBrZXkgIT09IFwiX19wcm90b19fXCIgJiYga2V5ICE9PSBcInByb3RvdHlwZVwiICYmIGtleSAhPT0gXCJjb25zdHJ1Y3RvclwiO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvX2pvaW5FeHBlY3RzL19qb2luRXhwZWN0cy50c1xuLyoqXG4qIEpvaW5zIG11bHRpcGxlIGBleHBlY3RzYCB2YWx1ZXMgd2l0aCB0aGUgZ2l2ZW4gc2VwYXJhdG9yLlxuKlxuKiBAcGFyYW0gdmFsdWVzIFRoZSBgZXhwZWN0c2AgdmFsdWVzLlxuKiBAcGFyYW0gc2VwYXJhdG9yIFRoZSBzZXBhcmF0b3IuXG4qXG4qIEByZXR1cm5zIFRoZSBqb2luZWQgYGV4cGVjdHNgIHByb3BlcnR5LlxuKlxuKiBAaW50ZXJuYWxcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gX2pvaW5FeHBlY3RzKHZhbHVlcyQxLCBzZXBhcmF0b3IpIHtcblx0Y29uc3QgbGlzdCA9IFsuLi5uZXcgU2V0KHZhbHVlcyQxKV07XG5cdGlmIChsaXN0Lmxlbmd0aCA+IDEpIHJldHVybiBgKCR7bGlzdC5qb2luKGAgJHtzZXBhcmF0b3J9IGApfSlgO1xuXHRyZXR1cm4gbGlzdFswXSA/PyBcIm5ldmVyXCI7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy9lbnRyaWVzRnJvbUxpc3QvZW50cmllc0Zyb21MaXN0LnRzXG4vKipcbiogQ3JlYXRlcyBhbiBvYmplY3QgZW50cmllcyBkZWZpbml0aW9uIGZyb20gYSBsaXN0IG9mIGtleXMgYW5kIGEgc2NoZW1hLlxuKlxuKiBAcGFyYW0gbGlzdCBBIGxpc3Qgb2Yga2V5cy5cbiogQHBhcmFtIHNjaGVtYSBUaGUgc2NoZW1hIG9mIHRoZSBrZXlzLlxuKlxuKiBAcmV0dXJucyBUaGUgb2JqZWN0IGVudHJpZXMuXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGVudHJpZXNGcm9tTGlzdChsaXN0LCBzY2hlbWEpIHtcblx0Y29uc3QgZW50cmllcyQxID0ge307XG5cdGZvciAoY29uc3Qga2V5IG9mIGxpc3QpIGVudHJpZXMkMVtrZXldID0gc2NoZW1hO1xuXHRyZXR1cm4gZW50cmllcyQxO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvZW50cmllc0Zyb21PYmplY3RzL2VudHJpZXNGcm9tT2JqZWN0cy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGVudHJpZXNGcm9tT2JqZWN0cyhzY2hlbWFzKSB7XG5cdGNvbnN0IGVudHJpZXMkMSA9IHt9O1xuXHRmb3IgKGNvbnN0IHNjaGVtYSBvZiBzY2hlbWFzKSBPYmplY3QuYXNzaWduKGVudHJpZXMkMSwgc2NoZW1hLmVudHJpZXMpO1xuXHRyZXR1cm4gZW50cmllcyQxO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvZ2V0RG90UGF0aC9nZXREb3RQYXRoLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gZ2V0RG90UGF0aChpc3N1ZSkge1xuXHRpZiAoaXNzdWUucGF0aCkge1xuXHRcdGxldCBrZXkgPSBcIlwiO1xuXHRcdGZvciAoY29uc3QgaXRlbSBvZiBpc3N1ZS5wYXRoKSBpZiAodHlwZW9mIGl0ZW0ua2V5ID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiBpdGVtLmtleSA9PT0gXCJudW1iZXJcIikgaWYgKGtleSkga2V5ICs9IGAuJHtpdGVtLmtleX1gO1xuXHRcdGVsc2Uga2V5ICs9IGl0ZW0ua2V5O1xuXHRcdGVsc2UgcmV0dXJuIG51bGw7XG5cdFx0cmV0dXJuIGtleTtcblx0fVxuXHRyZXR1cm4gbnVsbDtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3V0aWxzL2lzT2ZLaW5kL2lzT2ZLaW5kLnRzXG4vKipcbiogQSBnZW5lcmljIHR5cGUgZ3VhcmQgdG8gY2hlY2sgdGhlIGtpbmQgb2YgYW4gb2JqZWN0LlxuKlxuKiBAcGFyYW0ga2luZCBUaGUga2luZCB0byBjaGVjayBmb3IuXG4qIEBwYXJhbSBvYmplY3QgVGhlIG9iamVjdCB0byBjaGVjay5cbipcbiogQHJldHVybnMgV2hldGhlciBpdCBtYXRjaGVzLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBpc09mS2luZChraW5kLCBvYmplY3QkMSkge1xuXHRyZXR1cm4gb2JqZWN0JDEua2luZCA9PT0ga2luZDtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3V0aWxzL2lzT2ZUeXBlL2lzT2ZUeXBlLnRzXG4vKipcbiogQSBnZW5lcmljIHR5cGUgZ3VhcmQgdG8gY2hlY2sgdGhlIHR5cGUgb2YgYW4gb2JqZWN0LlxuKlxuKiBAcGFyYW0gdHlwZSBUaGUgdHlwZSB0byBjaGVjayBmb3IuXG4qIEBwYXJhbSBvYmplY3QgVGhlIG9iamVjdCB0byBjaGVjay5cbipcbiogQHJldHVybnMgV2hldGhlciBpdCBtYXRjaGVzLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBpc09mVHlwZSh0eXBlLCBvYmplY3QkMSkge1xuXHRyZXR1cm4gb2JqZWN0JDEudHlwZSA9PT0gdHlwZTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3V0aWxzL2lzVmFsaUVycm9yL2lzVmFsaUVycm9yLnRzXG4vKipcbiogQSB0eXBlIGd1YXJkIHRvIGNoZWNrIGlmIGFuIGVycm9yIGlzIGEgVmFsaUVycm9yLlxuKlxuKiBAcGFyYW0gZXJyb3IgVGhlIGVycm9yIHRvIGNoZWNrLlxuKlxuKiBAcmV0dXJucyBXaGV0aGVyIGl0cyBhIFZhbGlFcnJvci5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gaXNWYWxpRXJyb3IoZXJyb3IpIHtcblx0cmV0dXJuIGVycm9yIGluc3RhbmNlb2YgVmFsaUVycm9yO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvVmFsaUVycm9yL1ZhbGlFcnJvci50c1xuLyoqXG4qIEEgVmFsaWJvdCBlcnJvciB3aXRoIHVzZWZ1bCBpbmZvcm1hdGlvbi5cbiovXG52YXIgVmFsaUVycm9yID0gY2xhc3MgZXh0ZW5kcyBFcnJvciB7XG5cdC8qKlxuXHQqIENyZWF0ZXMgYSBWYWxpYm90IGVycm9yIHdpdGggdXNlZnVsIGluZm9ybWF0aW9uLlxuXHQqXG5cdCogQHBhcmFtIGlzc3VlcyBUaGUgZXJyb3IgaXNzdWVzLlxuXHQqL1xuXHRjb25zdHJ1Y3Rvcihpc3N1ZXMpIHtcblx0XHRzdXBlcihpc3N1ZXNbMF0ubWVzc2FnZSk7XG5cdFx0dGhpcy5uYW1lID0gXCJWYWxpRXJyb3JcIjtcblx0XHR0aGlzLmlzc3VlcyA9IGlzc3Vlcztcblx0fVxufTtcblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvYXJncy9hcmdzLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gYXJncyhzY2hlbWEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInRyYW5zZm9ybWF0aW9uXCIsXG5cdFx0dHlwZTogXCJhcmdzXCIsXG5cdFx0cmVmZXJlbmNlOiBhcmdzLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRzY2hlbWEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGNvbnN0IGZ1bmMgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0ZGF0YXNldC52YWx1ZSA9ICguLi5hcmdzXykgPT4ge1xuXHRcdFx0XHRjb25zdCBhcmdzRGF0YXNldCA9IHRoaXMuc2NoZW1hW1wifnJ1blwiXSh7IHZhbHVlOiBhcmdzXyB9LCBjb25maWckMSk7XG5cdFx0XHRcdGlmIChhcmdzRGF0YXNldC5pc3N1ZXMpIHRocm93IG5ldyBWYWxpRXJyb3IoYXJnc0RhdGFzZXQuaXNzdWVzKTtcblx0XHRcdFx0cmV0dXJuIGZ1bmMoLi4uYXJnc0RhdGFzZXQudmFsdWUpO1xuXHRcdFx0fTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvYXJncy9hcmdzQXN5bmMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBhcmdzQXN5bmMoc2NoZW1hKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwiYXJnc1wiLFxuXHRcdHJlZmVyZW5jZTogYXJnc0FzeW5jLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRzY2hlbWEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGNvbnN0IGZ1bmMgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0ZGF0YXNldC52YWx1ZSA9IGFzeW5jICguLi5hcmdzJDEpID0+IHtcblx0XHRcdFx0Y29uc3QgYXJnc0RhdGFzZXQgPSBhd2FpdCBzY2hlbWFbXCJ+cnVuXCJdKHsgdmFsdWU6IGFyZ3MkMSB9LCBjb25maWckMSk7XG5cdFx0XHRcdGlmIChhcmdzRGF0YXNldC5pc3N1ZXMpIHRocm93IG5ldyBWYWxpRXJyb3IoYXJnc0RhdGFzZXQuaXNzdWVzKTtcblx0XHRcdFx0cmV0dXJuIGZ1bmMoLi4uYXJnc0RhdGFzZXQudmFsdWUpO1xuXHRcdFx0fTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvYXdhaXQvYXdhaXRBc3luYy50c1xuLyoqXG4qIENyZWF0ZXMgYW4gYXdhaXQgdHJhbnNmb3JtYXRpb24gYWN0aW9uLlxuKlxuKiBAcmV0dXJucyBBbiBhd2FpdCBhY3Rpb24uXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGF3YWl0QXN5bmMoKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwiYXdhaXRcIixcblx0XHRyZWZlcmVuY2U6IGF3YWl0QXN5bmMsXG5cdFx0YXN5bmM6IHRydWUsXG5cdFx0YXN5bmMgXCJ+cnVuXCIoZGF0YXNldCkge1xuXHRcdFx0ZGF0YXNldC52YWx1ZSA9IGF3YWl0IGRhdGFzZXQudmFsdWU7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9yZWdleC50c1xuLyoqXG4qIFtCYXNlNjRdKGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0Jhc2U2NCkgcmVnZXguXG4qL1xuY29uc3QgQkFTRTY0X1JFR0VYID0gL14oPzpbXFxkYS16Ky9dezR9KSooPzpbXFxkYS16Ky9dezJ9PT18W1xcZGEteisvXXszfT0pPyQvaXU7XG4vKipcbiogW0JJQ10oaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvSVNPXzkzNjIpIHJlZ2V4LlxuKi9cbmNvbnN0IEJJQ19SRUdFWCA9IC9eW0EtWl17Nn0oPyEwMClbXFxkQS1aXXsyfSg/OltcXGRBLVpdezN9KT8kL3U7XG4vKipcbiogW0N1aWQyXShodHRwczovL2dpdGh1Yi5jb20vcGFyYWxsZWxkcml2ZS9jdWlkMikgcmVnZXguXG4qL1xuY29uc3QgQ1VJRDJfUkVHRVggPSAvXlthLXpdW1xcZGEtel0qJC91O1xuLyoqXG4qIFtEZWNpbWFsXShodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9EZWNpbWFsKSByZWdleC5cbiovXG5jb25zdCBERUNJTUFMX1JFR0VYID0gL15bKy1dPyg/OlxcZCpcXC4pP1xcZCskL3U7XG4vKipcbiogW0RpZ2l0c10oaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvTnVtZXJpY2FsX2RpZ2l0KSByZWdleC5cbiovXG5jb25zdCBESUdJVFNfUkVHRVggPSAvXlxcZCskL3U7XG4vKipcbiogW0RvbWFpbiBuYW1lXShodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9Eb21haW5fbmFtZSkgcmVnZXguXG4qXG4qIEhpbnQ6IFdlIGRlY2lkZWQgYWdhaW5zdCB0aGUgYGlgIGZsYWcgZm9yIGJldHRlciBKU09OIFNjaGVtYSBjb21wYXRpYmlsaXR5LlxuKiBBU0NJSS1vbmx5IHZhbGlkYXRpb24uIEludGVybmF0aW9uYWxpemVkIGRvbWFpbiBuYW1lcyAoSUROcykgYXJlIG5vdFxuKiBzdXBwb3J0ZWQsIGluY2x1ZGluZyBQdW55Y29kZS1lbmNvZGVkIGxhYmVscy5cbiovXG5jb25zdCBET01BSU5fUkVHRVggPSAvXig/PS57MSwyNTN9JCkoPzooPyFbWHhdW05uXS0tKVtBLVphLXowLTldKD86W0EtWmEtejAtOS1dezAsNjF9W0EtWmEtejAtOV0pP1xcLikrW0EtWmEtel17Miw2M30kL3U7XG4vKipcbiogW0VtYWlsIGFkZHJlc3NdKGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0VtYWlsX2FkZHJlc3MpIHJlZ2V4LlxuKi9cbmNvbnN0IEVNQUlMX1JFR0VYID0gL15bXFx3Ky1dKyg/OlxcLltcXHcrLV0rKSpAW1xcZGEtel0rKD86Wy4tXVtcXGRhLXpdKykqXFwuW2Etel17Mix9JC9pdTtcbi8qKlxuKiBFbW9qaSByZWdleCBmcm9tIFtlbW9qaS1yZWdleC14c10oaHR0cHM6Ly9naXRodWIuY29tL3NsZXZpdGhhbi9lbW9qaS1yZWdleC14cykgdjEuMC4wIChNSVQgbGljZW5zZSkuXG4qXG4qIEhpbnQ6IFdlIGRlY2lkZWQgYWdhaW5zdCB0aGUgbmV3ZXIgYC9eXFxwe1JHSV9FbW9qaX0rJC92YCByZWdleCBiZWNhdXNlIGl0IGlzXG4qIG5vdCBzdXBwb3J0ZWQgaW4gb2xkZXIgcnVudGltZXMgYW5kIGRvZXMgbm90IG1hdGNoIGFsbCBlbW9qaS5cbiovXG5jb25zdCBFTU9KSV9SRUdFWCA9IC9eKD86W1xcdXsxRjFFNn0tXFx1ezFGMUZGfV17Mn18XFx1ezFGM0Y0fVtcXHV7RTAwNjF9LVxcdXtFMDA3QX1dezJ9W1xcdXtFMDAzMH0tXFx1e0UwMDM5fVxcdXtFMDA2MX0tXFx1e0UwMDdBfV17MSwzfVxcdXtFMDA3Rn18KD86XFxwe0Vtb2ppfVxcdUZFMEZcXHUyMEUzP3xcXHB7RW1vamlfTW9kaWZpZXJfQmFzZX1cXHB7RW1vamlfTW9kaWZpZXJ9P3woPyFbXFxwe0Vtb2ppX01vZGlmaWVyX0Jhc2V9XFx1ezFGMUU2fS1cXHV7MUYxRkZ9XSlcXHB7RW1vamlfUHJlc2VudGF0aW9ufSkoPzpcXHUyMDBEKD86XFxwe0Vtb2ppfVxcdUZFMEZcXHUyMEUzP3xcXHB7RW1vamlfTW9kaWZpZXJfQmFzZX1cXHB7RW1vamlfTW9kaWZpZXJ9P3woPyFbXFxwe0Vtb2ppX01vZGlmaWVyX0Jhc2V9XFx1ezFGMUU2fS1cXHV7MUYxRkZ9XSlcXHB7RW1vamlfUHJlc2VudGF0aW9ufSkpKikrJC91O1xuLyoqXG4qIFtIZXhhZGVjaW1hbF0oaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvSGV4YWRlY2ltYWwpIHJlZ2V4LlxuKlxuKiBIaW50OiBXZSBkZWNpZGVkIGFnYWluc3QgdGhlIGBpYCBmbGFnIGZvciBiZXR0ZXIgSlNPTiBTY2hlbWEgY29tcGF0aWJpbGl0eS5cbiovXG5jb25zdCBIRVhBREVDSU1BTF9SRUdFWCA9IC9eKD86MFtoeF0pP1tcXGRhLWZBLUZdKyQvdTtcbi8qKlxuKiBbSGV4IGNvbG9yXShodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9XZWJfY29sb3JzI0hleF90cmlwbGV0KSByZWdleC5cbipcbiogSGludDogV2UgZGVjaWRlZCBhZ2FpbnN0IHRoZSBgaWAgZmxhZyBmb3IgYmV0dGVyIEpTT04gU2NoZW1hIGNvbXBhdGliaWxpdHkuXG4qL1xuY29uc3QgSEVYX0NPTE9SX1JFR0VYID0gL14jKD86W1xcZGEtZkEtRl17Myw0fXxbXFxkYS1mQS1GXXs2fXxbXFxkYS1mQS1GXXs4fSkkL3U7XG4vKipcbiogW0lNRUldKGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0ludGVybmF0aW9uYWxfTW9iaWxlX0VxdWlwbWVudF9JZGVudGl0eSkgcmVnZXguXG4qL1xuY29uc3QgSU1FSV9SRUdFWCA9IC9eXFxkezE1fSR8XlxcZHsyfS1cXGR7Nn0tXFxkezZ9LVxcZCQvdTtcbi8qKlxuKiBbSVB2NF0oaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvSVB2NCkgcmVnZXguXG4qL1xuY29uc3QgSVBWNF9SRUdFWCA9IC9eKD86KD86WzEtOV18MVxcZHwyWzAtNF0pP1xcZHwyNVswLTVdKSg/OlxcLig/Oig/OlsxLTldfDFcXGR8MlswLTRdKT9cXGR8MjVbMC01XSkpezN9JC91O1xuLyoqXG4qIFtJUHY2XShodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9JUHY2KSByZWdleC5cbiovXG5jb25zdCBJUFY2X1JFR0VYID0gL14oPzooPzpbXFxkYS1mXXsxLDR9Oil7N31bXFxkYS1mXXsxLDR9fCg/OltcXGRhLWZdezEsNH06KXsxLDd9OnwoPzpbXFxkYS1mXXsxLDR9Oil7MSw2fTpbXFxkYS1mXXsxLDR9fCg/OltcXGRhLWZdezEsNH06KXsxLDV9KD86OltcXGRhLWZdezEsNH0pezEsMn18KD86W1xcZGEtZl17MSw0fTopezEsNH0oPzo6W1xcZGEtZl17MSw0fSl7MSwzfXwoPzpbXFxkYS1mXXsxLDR9Oil7MSwzfSg/OjpbXFxkYS1mXXsxLDR9KXsxLDR9fCg/OltcXGRhLWZdezEsNH06KXsxLDJ9KD86OltcXGRhLWZdezEsNH0pezEsNX18W1xcZGEtZl17MSw0fTooPzo6W1xcZGEtZl17MSw0fSl7MSw2fXw6KD86KD86OltcXGRhLWZdezEsNH0pezEsN318Oil8ZmU4MDooPzo6W1xcZGEtZl17MCw0fSl7MCw0fSVbXFxkYS16XSt8OjooPzpmezR9KD86OjB7MSw0fSk/Oik/KD86KD86MjVbMC01XXwoPzoyWzAtNF18MT9cXGQpP1xcZClcXC4pezN9KD86MjVbMC01XXwoPzoyWzAtNF18MT9cXGQpP1xcZCl8KD86W1xcZGEtZl17MSw0fTopezEsNH06KD86KD86MjVbMC01XXwoPzoyWzAtNF18MT9cXGQpP1xcZClcXC4pezN9KD86MjVbMC01XXwoPzoyWzAtNF18MT9cXGQpP1xcZCkpJC9pdTtcbi8qKlxuKiBbSVBdKGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0lQX2FkZHJlc3MpIHJlZ2V4LlxuKi9cbmNvbnN0IElQX1JFR0VYID0gL14oPzooPzpbMS05XXwxXFxkfDJbMC00XSk/XFxkfDI1WzAtNV0pKD86XFwuKD86KD86WzEtOV18MVxcZHwyWzAtNF0pP1xcZHwyNVswLTVdKSl7M30kfF4oPzooPzpbXFxkYS1mXXsxLDR9Oil7N31bXFxkYS1mXXsxLDR9fCg/OltcXGRhLWZdezEsNH06KXsxLDd9OnwoPzpbXFxkYS1mXXsxLDR9Oil7MSw2fTpbXFxkYS1mXXsxLDR9fCg/OltcXGRhLWZdezEsNH06KXsxLDV9KD86OltcXGRhLWZdezEsNH0pezEsMn18KD86W1xcZGEtZl17MSw0fTopezEsNH0oPzo6W1xcZGEtZl17MSw0fSl7MSwzfXwoPzpbXFxkYS1mXXsxLDR9Oil7MSwzfSg/OjpbXFxkYS1mXXsxLDR9KXsxLDR9fCg/OltcXGRhLWZdezEsNH06KXsxLDJ9KD86OltcXGRhLWZdezEsNH0pezEsNX18W1xcZGEtZl17MSw0fTooPzo6W1xcZGEtZl17MSw0fSl7MSw2fXw6KD86KD86OltcXGRhLWZdezEsNH0pezEsN318Oil8ZmU4MDooPzo6W1xcZGEtZl17MCw0fSl7MCw0fSVbXFxkYS16XSt8OjooPzpmezR9KD86OjB7MSw0fSk/Oik/KD86KD86MjVbMC01XXwoPzoyWzAtNF18MT9cXGQpP1xcZClcXC4pezN9KD86MjVbMC01XXwoPzoyWzAtNF18MT9cXGQpP1xcZCl8KD86W1xcZGEtZl17MSw0fTopezEsNH06KD86KD86MjVbMC01XXwoPzoyWzAtNF18MT9cXGQpP1xcZClcXC4pezN9KD86MjVbMC01XXwoPzoyWzAtNF18MT9cXGQpP1xcZCkpJC9pdTtcbi8qKlxuKiBbSVNPIDg2MDFdKGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0lTT184NjAxKSBkYXRlIHJlZ2V4LlxuKi9cbmNvbnN0IElTT19EQVRFX1JFR0VYID0gL15cXGR7NH0tKD86MFsxLTldfDFbMC0yXSktKD86WzEyXVxcZHwwWzEtOV18M1swMV0pJC91O1xuLyoqXG4qIFtJU08gODYwMV0oaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvSVNPXzg2MDEpIGRhdGUtdGltZSByZWdleC5cbiovXG5jb25zdCBJU09fREFURV9USU1FX1JFR0VYID0gL15cXGR7NH0tKD86MFsxLTldfDFbMC0yXSktKD86WzEyXVxcZHwwWzEtOV18M1swMV0pW1QgXSg/OjBcXGR8MVxcZHwyWzAtM10pOlswLTVdXFxkJC91O1xuLyoqXG4qIFtJU08gODYwMV0oaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvSVNPXzg2MDEpIGRhdGUtdGltZSB3aXRoIHNlY29uZHMgcmVnZXguXG4qL1xuY29uc3QgSVNPX0RBVEVfVElNRV9TRUNPTkRfUkVHRVggPSAvXlxcZHs0fS0oPzowWzEtOV18MVswLTJdKS0oPzpbMTJdXFxkfDBbMS05XXwzWzAxXSlbVCBdKD86MFxcZHwxXFxkfDJbMC0zXSkoPzo6WzAtNV1cXGQpezJ9JC91O1xuLyoqXG4qIFtJU08gODYwMV0oaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvSVNPXzg2MDEpIHRpbWUgcmVnZXguXG4qL1xuY29uc3QgSVNPX1RJTUVfUkVHRVggPSAvXig/OjBcXGR8MVxcZHwyWzAtM10pOlswLTVdXFxkJC91O1xuLyoqXG4qIFtJU08gODYwMV0oaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvSVNPXzg2MDEpIHRpbWUgd2l0aCBzZWNvbmRzIHJlZ2V4LlxuKi9cbmNvbnN0IElTT19USU1FX1NFQ09ORF9SRUdFWCA9IC9eKD86MFxcZHwxXFxkfDJbMC0zXSkoPzo6WzAtNV1cXGQpezJ9JC91O1xuLyoqXG4qIFtJU08gODYwMV0oaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvSVNPXzg2MDEpIHRpbWVzdGFtcCByZWdleC4gQWxsb3dzIGFcbiogc3BhY2UgYXMgYSBkYXRlL3RpbWUgc2VwYXJhdG9yIGFuZCBhbiBvcHRpb25hbCBzcGFjZSBiZWZvcmUgdGhlIFVUQyBvZmZzZXQuXG4qL1xuY29uc3QgSVNPX1RJTUVTVEFNUF9SRUdFWCA9IC9eXFxkezR9LSg/OjBbMS05XXwxWzAtMl0pLSg/OlsxMl1cXGR8MFsxLTldfDNbMDFdKVtUIF0oPzowXFxkfDFcXGR8MlswLTNdKSg/OjpbMC01XVxcZCl7Mn0oPzpcXC5cXGR7MSw5fSk/KD86WnwgP1srLV0oPzowXFxkfDFcXGR8MlswLTNdKSg/Ojo/WzAtNV1cXGQpPykkL3U7XG4vKipcbiogW0lTTyA4NjAxXShodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9JU09fODYwMSkgd2VlayByZWdleC5cbiovXG5jb25zdCBJU09fV0VFS19SRUdFWCA9IC9eXFxkezR9LVcoPzowWzEtOV18WzEtNF1cXGR8NVswLTNdKSQvdTtcbi8qKlxuKiBbSldTIGNvbXBhY3Qgc2VyaWFsaXphdGlvbl0oaHR0cHM6Ly9kYXRhdHJhY2tlci5pZXRmLm9yZy9kb2MvaHRtbC9yZmM3NTE1I3NlY3Rpb24tMy4xKVxuKiByZWdleC5cbipcbiogSGludDogRW1wdHkgcGF5bG9hZCBhbmQgc2lnbmF0dXJlIHNlZ21lbnRzIGFyZSBhbGxvd2VkIGJlY2F1c2UgdGhlXG4qIEJhc2U2NFVSTC1lbmNvZGVkIHJlcHJlc2VudGF0aW9uIG9mIGFuIGVtcHR5IG9jdGV0IHNlcXVlbmNlIGlzIGFuIGVtcHR5XG4qIHN0cmluZy5cbiovXG5jb25zdCBKV1NfQ09NUEFDVF9SRUdFWCA9IC9eKD86W1xcdy1dezIsM318KD86W1xcdy1dezR9KSsoPzpbXFx3LV17MiwzfSk/KVxcLig/OltcXHctXXsyLDN9fCg/OltcXHctXXs0fSkrKD86W1xcdy1dezIsM30pPyk/XFwuKD86W1xcdy1dezIsM318KD86W1xcdy1dezR9KSsoPzpbXFx3LV17MiwzfSk/KT8kL3U7XG4vKipcbiogW0lTUkNdKGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0ludGVybmF0aW9uYWxfU3RhbmRhcmRfUmVjb3JkaW5nX0NvZGUpIHJlZ2V4LlxuKi9cbmNvbnN0IElTUkNfUkVHRVggPSAvXig/OltBLVpdezJ9W0EtWlxcZF17M31cXGR7N318W0EtWl17Mn0tW0EtWlxcZF17M30tXFxkezJ9LVxcZHs1fSkkL3U7XG4vKipcbiogW01BQ10oaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvTUFDX2FkZHJlc3MpIDQ4IGJpdCByZWdleC5cbipcbiogSGludDogV2UgZGVjaWRlZCBhZ2FpbnN0IHRoZSBgaWAgZmxhZyBmb3IgYmV0dGVyIEpTT04gU2NoZW1hIGNvbXBhdGliaWxpdHkuXG4qL1xuY29uc3QgTUFDNDhfUkVHRVggPSAvXig/OltcXGRhLWZBLUZdezJ9Oil7NX1bXFxkYS1mQS1GXXsyfSR8Xig/OltcXGRhLWZBLUZdezJ9LSl7NX1bXFxkYS1mQS1GXXsyfSR8Xig/OltcXGRhLWZBLUZdezR9XFwuKXsyfVtcXGRhLWZBLUZdezR9JC91O1xuLyoqXG4qIFtNQUNdKGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL01BQ19hZGRyZXNzKSA2NCBiaXQgcmVnZXguXG4qXG4qIEhpbnQ6IFdlIGRlY2lkZWQgYWdhaW5zdCB0aGUgYGlgIGZsYWcgZm9yIGJldHRlciBKU09OIFNjaGVtYSBjb21wYXRpYmlsaXR5LlxuKi9cbmNvbnN0IE1BQzY0X1JFR0VYID0gL14oPzpbXFxkYS1mQS1GXXsyfTopezd9W1xcZGEtZkEtRl17Mn0kfF4oPzpbXFxkYS1mQS1GXXsyfS0pezd9W1xcZGEtZkEtRl17Mn0kfF4oPzpbXFxkYS1mQS1GXXs0fVxcLil7M31bXFxkYS1mQS1GXXs0fSR8Xig/OltcXGRhLWZBLUZdezR9Oil7M31bXFxkYS1mQS1GXXs0fSQvdTtcbi8qKlxuKiBbTUFDXShodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9NQUNfYWRkcmVzcykgcmVnZXguXG4qXG4qIEhpbnQ6IFdlIGRlY2lkZWQgYWdhaW5zdCB0aGUgYGlgIGZsYWcgZm9yIGJldHRlciBKU09OIFNjaGVtYSBjb21wYXRpYmlsaXR5LlxuKi9cbmNvbnN0IE1BQ19SRUdFWCA9IC9eKD86W1xcZGEtZkEtRl17Mn06KXs1fVtcXGRhLWZBLUZdezJ9JHxeKD86W1xcZGEtZkEtRl17Mn0tKXs1fVtcXGRhLWZBLUZdezJ9JHxeKD86W1xcZGEtZkEtRl17NH1cXC4pezJ9W1xcZGEtZkEtRl17NH0kfF4oPzpbXFxkYS1mQS1GXXsyfTopezd9W1xcZGEtZkEtRl17Mn0kfF4oPzpbXFxkYS1mQS1GXXsyfS0pezd9W1xcZGEtZkEtRl17Mn0kfF4oPzpbXFxkYS1mQS1GXXs0fVxcLil7M31bXFxkYS1mQS1GXXs0fSR8Xig/OltcXGRhLWZBLUZdezR9Oil7M31bXFxkYS1mQS1GXXs0fSQvdTtcbi8qKlxuKiBbTmFubyBJRF0oaHR0cHM6Ly9naXRodWIuY29tL2FpL25hbm9pZCkgcmVnZXguXG4qL1xuY29uc3QgTkFOT19JRF9SRUdFWCA9IC9eW1xcdy1dKyQvdTtcbi8qKlxuKiBbT2N0YWxdKGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL09jdGFsKSByZWdleC5cbiovXG5jb25zdCBPQ1RBTF9SRUdFWCA9IC9eKD86MG8pP1swLTddKyQvdTtcbi8qKlxuKiBbUkZDIDUzMjIgZW1haWwgYWRkcmVzc10oaHR0cHM6Ly9kYXRhdHJhY2tlci5pZXRmLm9yZy9kb2MvaHRtbC9yZmM1MzIyI3NlY3Rpb24tMy40LjEpIHJlZ2V4LlxuKlxuKiBIaW50OiBUaGlzIHJlZ2V4IHdhcyB0YWtlbiBmcm9tIHRoZSBbSFRNTCBMaXZpbmcgU3RhbmRhcmQgU3BlY2lmaWNhdGlvbl0oaHR0cHM6Ly9odG1sLnNwZWMud2hhdHdnLm9yZy9tdWx0aXBhZ2UvaW5wdXQuaHRtbCN2YWxpZC1lLW1haWwtYWRkcmVzcykgYW5kIGRvZXMgbm90IHBlcmZlY3RseSByZXByZXNlbnQgUkZDIDUzMjIuXG4qL1xuY29uc3QgUkZDX0VNQUlMX1JFR0VYID0gL15bYS16QS1aMC05LiEjJCUmJyorXFwvPT9eX2B7fH1+LV0rQFthLXpBLVowLTldKD86W2EtekEtWjAtOS1dezAsNjF9W2EtekEtWjAtOV0pPyg/OlxcLlthLXpBLVowLTldKD86W2EtekEtWjAtOS1dezAsNjF9W2EtekEtWjAtOV0pPykqJC87XG4vKipcbiogW1NsdWddKGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0NsZWFuX1VSTCNTbHVnKSByZWdleC5cbiovXG5jb25zdCBTTFVHX1JFR0VYID0gL15bXFxkYS16XSsoPzpbLV9dW1xcZGEtel0rKSokL3U7XG4vKipcbiogW1VMSURdKGh0dHBzOi8vZ2l0aHViLmNvbS91bGlkL3NwZWMpIHJlZ2V4LlxuKlxuKiBIaW50OiBXZSBkZWNpZGVkIGFnYWluc3QgdGhlIGBpYCBmbGFnIGZvciBiZXR0ZXIgSlNPTiBTY2hlbWEgY29tcGF0aWJpbGl0eS5cbiovXG5jb25zdCBVTElEX1JFR0VYID0gL15bXFxkYS1oamttbnAtdHYtekEtSEpLTU5QLVRWLVpdezI2fSQvdTtcbi8qKlxuKiBbVVVJRF0oaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvVW5pdmVyc2FsbHlfdW5pcXVlX2lkZW50aWZpZXIpIHJlZ2V4LlxuKi9cbmNvbnN0IFVVSURfUkVHRVggPSAvXltcXGRhLWZdezh9KD86LVtcXGRhLWZdezR9KXszfS1bXFxkYS1mXXsxMn0kL2l1O1xuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9iYXNlNjQvYmFzZTY0LnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gYmFzZTY0KG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiYmFzZTY0XCIsXG5cdFx0cmVmZXJlbmNlOiBiYXNlNjQsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IEJBU0U2NF9SRUdFWCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50LnRlc3QoZGF0YXNldC52YWx1ZSkpIF9hZGRJc3N1ZSh0aGlzLCBcIkJhc2U2NFwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2JpYy9iaWMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBiaWMobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJiaWNcIixcblx0XHRyZWZlcmVuY2U6IGJpYyxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRyZXF1aXJlbWVudDogQklDX1JFR0VYLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIXRoaXMucmVxdWlyZW1lbnQudGVzdChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwiQklDXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvYnJhbmQvYnJhbmQudHNcbi8qKlxuKiBDcmVhdGVzIGEgYnJhbmQgdHJhbnNmb3JtYXRpb24gYWN0aW9uLlxuKlxuKiBAcGFyYW0gbmFtZSBUaGUgYnJhbmQgbmFtZS5cbipcbiogQHJldHVybnMgQSBicmFuZCBhY3Rpb24uXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGJyYW5kKG5hbWUpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInRyYW5zZm9ybWF0aW9uXCIsXG5cdFx0dHlwZTogXCJicmFuZFwiLFxuXHRcdHJlZmVyZW5jZTogYnJhbmQsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdG5hbWUsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCkge1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9ieXRlcy9ieXRlcy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGJ5dGVzKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImJ5dGVzXCIsXG5cdFx0cmVmZXJlbmNlOiBieXRlcyxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogYCR7cmVxdWlyZW1lbnR9YCxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkKSB7XG5cdFx0XHRcdGNvbnN0IGxlbmd0aCQxID0gLyogQF9fUFVSRV9fICovIF9nZXRCeXRlQ291bnQoZGF0YXNldC52YWx1ZSk7XG5cdFx0XHRcdGlmIChsZW5ndGgkMSAhPT0gdGhpcy5yZXF1aXJlbWVudCkgX2FkZElzc3VlKHRoaXMsIFwiYnl0ZXNcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGAke2xlbmd0aCQxfWAgfSk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2NoZWNrL2NoZWNrLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gY2hlY2socmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiY2hlY2tcIixcblx0XHRyZWZlcmVuY2U6IGNoZWNrLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIXRoaXMucmVxdWlyZW1lbnQoZGF0YXNldC52YWx1ZSkpIF9hZGRJc3N1ZSh0aGlzLCBcImlucHV0XCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvY2hlY2svY2hlY2tBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGNoZWNrQXN5bmMocmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiY2hlY2tcIixcblx0XHRyZWZlcmVuY2U6IGNoZWNrQXN5bmMsXG5cdFx0YXN5bmM6IHRydWUsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0YXN5bmMgXCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICFhd2FpdCB0aGlzLnJlcXVpcmVtZW50KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJpbnB1dFwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2NoZWNrSXRlbXMvY2hlY2tJdGVtcy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGNoZWNrSXRlbXMocmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiY2hlY2tfaXRlbXNcIixcblx0XHRyZWZlcmVuY2U6IGNoZWNrSXRlbXMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCkgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGRhdGFzZXQudmFsdWUubGVuZ3RoOyBpbmRleCsrKSB7XG5cdFx0XHRcdGNvbnN0IGl0ZW0gPSBkYXRhc2V0LnZhbHVlW2luZGV4XTtcblx0XHRcdFx0aWYgKCF0aGlzLnJlcXVpcmVtZW50KGl0ZW0sIGluZGV4LCBkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwiaXRlbVwiLCBkYXRhc2V0LCBjb25maWckMSwge1xuXHRcdFx0XHRcdGlucHV0OiBpdGVtLFxuXHRcdFx0XHRcdHBhdGg6IFt7XG5cdFx0XHRcdFx0XHR0eXBlOiBcImFycmF5XCIsXG5cdFx0XHRcdFx0XHRvcmlnaW46IFwidmFsdWVcIixcblx0XHRcdFx0XHRcdGlucHV0OiBkYXRhc2V0LnZhbHVlLFxuXHRcdFx0XHRcdFx0a2V5OiBpbmRleCxcblx0XHRcdFx0XHRcdHZhbHVlOiBpdGVtXG5cdFx0XHRcdFx0fV1cblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2NoZWNrSXRlbXMvY2hlY2tJdGVtc0FzeW5jLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gY2hlY2tJdGVtc0FzeW5jKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImNoZWNrX2l0ZW1zXCIsXG5cdFx0cmVmZXJlbmNlOiBjaGVja0l0ZW1zQXN5bmMsXG5cdFx0YXN5bmM6IHRydWUsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0YXN5bmMgXCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkKSB7XG5cdFx0XHRcdGNvbnN0IHJlcXVpcmVtZW50UmVzdWx0cyA9IGF3YWl0IFByb21pc2UuYWxsKGRhdGFzZXQudmFsdWUubWFwKHRoaXMucmVxdWlyZW1lbnQpKTtcblx0XHRcdFx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGRhdGFzZXQudmFsdWUubGVuZ3RoOyBpbmRleCsrKSBpZiAoIXJlcXVpcmVtZW50UmVzdWx0c1tpbmRleF0pIHtcblx0XHRcdFx0XHRjb25zdCBpdGVtID0gZGF0YXNldC52YWx1ZVtpbmRleF07XG5cdFx0XHRcdFx0X2FkZElzc3VlKHRoaXMsIFwiaXRlbVwiLCBkYXRhc2V0LCBjb25maWckMSwge1xuXHRcdFx0XHRcdFx0aW5wdXQ6IGl0ZW0sXG5cdFx0XHRcdFx0XHRwYXRoOiBbe1xuXHRcdFx0XHRcdFx0XHR0eXBlOiBcImFycmF5XCIsXG5cdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0XHRpbnB1dDogZGF0YXNldC52YWx1ZSxcblx0XHRcdFx0XHRcdFx0a2V5OiBpbmRleCxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IGl0ZW1cblx0XHRcdFx0XHRcdH1dXG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvY3JlZGl0Q2FyZC9jcmVkaXRDYXJkLnRzXG4vKipcbiogQ3JlZGl0IGNhcmQgcmVnZXguXG4qL1xuY29uc3QgQ1JFRElUX0NBUkRfUkVHRVggPSAvXig/OlxcZHsxMywxOX18XFxkezR9KD86IFxcZHszLDZ9KXsyLDR9fFxcZHs0fSg/Oi1cXGR7Myw2fSl7Miw0fSkkL3U7XG4vKipcbiogU2FuaXRpemUgcmVnZXguXG4qL1xuY29uc3QgU0FOSVRJWkVfUkVHRVggPSAvWy0gXS9ndTtcbi8qKlxuKiBQcm92aWRlciByZWdleCBsaXN0LlxuKi9cbmNvbnN0IFBST1ZJREVSX1JFR0VYX0xJU1QgPSBbXG5cdC9eM1s0N11cXGR7MTN9JC91LFxuXHQvXjMoPzowWzAtNV18WzY4XVxcZClcXGR7MTEsMTN9JC91LFxuXHQvXjYoPzowMTF8NVxcZHsyfSlcXGR7MTIsMTV9JC91LFxuXHQvXig/OjIxMzF8MTgwMHwzNVxcZHszfSlcXGR7MTF9JC91LFxuXHQvXig/OjVbMS01XVxcZHsyfXwyMjJcXGR8MjJbMy05XVxcZHwyWzMtNl1cXGR7Mn18MjdbMDFdXFxkfDI3MjApXFxkezEyfSQvdSxcblx0L14oPzo2WzI3XVxcZHsxNCwxN318ODFcXGR7MTQsMTd9KSQvdSxcblx0L140XFxkezEyfSg/OlxcZHszLDZ9KT8kL3Vcbl07XG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gY3JlZGl0Q2FyZChtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImNyZWRpdF9jYXJkXCIsXG5cdFx0cmVmZXJlbmNlOiBjcmVkaXRDYXJkLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50KGlucHV0KSB7XG5cdFx0XHRsZXQgc2FuaXRpemVkO1xuXHRcdFx0cmV0dXJuIENSRURJVF9DQVJEX1JFR0VYLnRlc3QoaW5wdXQpICYmIChzYW5pdGl6ZWQgPSBpbnB1dC5yZXBsYWNlKFNBTklUSVpFX1JFR0VYLCBcIlwiKSkgJiYgUFJPVklERVJfUkVHRVhfTElTVC5zb21lKChyZWdleCQxKSA9PiByZWdleCQxLnRlc3Qoc2FuaXRpemVkKSkgJiYgLyogQF9fUFVSRV9fICovIF9pc0x1aG5BbGdvKHNhbml0aXplZCk7XG5cdFx0fSxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJjcmVkaXQgY2FyZFwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2N1aWQyL2N1aWQyLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gY3VpZDIobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJjdWlkMlwiLFxuXHRcdHJlZmVyZW5jZTogY3VpZDIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IENVSUQyX1JFR0VYLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIXRoaXMucmVxdWlyZW1lbnQudGVzdChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwiQ3VpZDJcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9kZWNpbWFsL2RlY2ltYWwudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBkZWNpbWFsKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiZGVjaW1hbFwiLFxuXHRcdHJlZmVyZW5jZTogZGVjaW1hbCxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRyZXF1aXJlbWVudDogREVDSU1BTF9SRUdFWCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50LnRlc3QoZGF0YXNldC52YWx1ZSkpIF9hZGRJc3N1ZSh0aGlzLCBcImRlY2ltYWxcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9kZXNjcmlwdGlvbi9kZXNjcmlwdGlvbi50c1xuLyoqXG4qIENyZWF0ZXMgYSBkZXNjcmlwdGlvbiBtZXRhZGF0YSBhY3Rpb24uXG4qXG4qIEBwYXJhbSBkZXNjcmlwdGlvbl8gVGhlIGRlc2NyaXB0aW9uIHRleHQuXG4qXG4qIEByZXR1cm5zIEEgZGVzY3JpcHRpb24gYWN0aW9uLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBkZXNjcmlwdGlvbihkZXNjcmlwdGlvbl8pIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcIm1ldGFkYXRhXCIsXG5cdFx0dHlwZTogXCJkZXNjcmlwdGlvblwiLFxuXHRcdHJlZmVyZW5jZTogZGVzY3JpcHRpb24sXG5cdFx0ZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uX1xuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9kaWdpdHMvZGlnaXRzLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gZGlnaXRzKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiZGlnaXRzXCIsXG5cdFx0cmVmZXJlbmNlOiBkaWdpdHMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IERJR0lUU19SRUdFWCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50LnRlc3QoZGF0YXNldC52YWx1ZSkpIF9hZGRJc3N1ZSh0aGlzLCBcImRpZ2l0c1wiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2RvbWFpbi9kb21haW4udHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBkb21haW4obWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJkb21haW5cIixcblx0XHRyZWZlcmVuY2U6IGRvbWFpbixcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRyZXF1aXJlbWVudDogRE9NQUlOX1JFR0VYLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIXRoaXMucmVxdWlyZW1lbnQudGVzdChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwiZG9tYWluXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvZW1haWwvZW1haWwudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBlbWFpbChtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImVtYWlsXCIsXG5cdFx0cmVmZXJlbmNlOiBlbWFpbCxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRyZXF1aXJlbWVudDogRU1BSUxfUkVHRVgsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJlbWFpbFwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2Vtb2ppL2Vtb2ppLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gZW1vamkobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJlbW9qaVwiLFxuXHRcdHJlZmVyZW5jZTogZW1vamksXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IEVNT0pJX1JFR0VYLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIXRoaXMucmVxdWlyZW1lbnQudGVzdChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwiZW1vamlcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9lbXB0eS9lbXB0eS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGVtcHR5KG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiZW1wdHlcIixcblx0XHRyZWZlcmVuY2U6IGVtcHR5LFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBcIjBcIixcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmIGRhdGFzZXQudmFsdWUubGVuZ3RoID4gMCkgX2FkZElzc3VlKHRoaXMsIFwibGVuZ3RoXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBgJHtkYXRhc2V0LnZhbHVlLmxlbmd0aH1gIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9lbmRzV2l0aC9lbmRzV2l0aC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGVuZHNXaXRoKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImVuZHNfd2l0aFwiLFxuXHRcdHJlZmVyZW5jZTogZW5kc1dpdGgsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGBcIiR7cmVxdWlyZW1lbnR9XCJgLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIWRhdGFzZXQudmFsdWUuZW5kc1dpdGgodGhpcy5yZXF1aXJlbWVudCkpIF9hZGRJc3N1ZSh0aGlzLCBcImVuZFwiLCBkYXRhc2V0LCBjb25maWckMSwgeyByZWNlaXZlZDogYFwiJHtkYXRhc2V0LnZhbHVlLnNsaWNlKC10aGlzLnJlcXVpcmVtZW50Lmxlbmd0aCl9XCJgIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9lbnRyaWVzL2VudHJpZXMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBlbnRyaWVzKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImVudHJpZXNcIixcblx0XHRyZWZlcmVuY2U6IGVudHJpZXMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGAke3JlcXVpcmVtZW50fWAsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoIWRhdGFzZXQudHlwZWQpIHJldHVybiBkYXRhc2V0O1xuXHRcdFx0Y29uc3QgY291bnQgPSBPYmplY3Qua2V5cyhkYXRhc2V0LnZhbHVlKS5sZW5ndGg7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiBjb3VudCAhPT0gdGhpcy5yZXF1aXJlbWVudCkgX2FkZElzc3VlKHRoaXMsIFwiZW50cmllc1wiLCBkYXRhc2V0LCBjb25maWckMSwgeyByZWNlaXZlZDogYCR7Y291bnR9YCB9KTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvZXZlcnlJdGVtL2V2ZXJ5SXRlbS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGV2ZXJ5SXRlbShyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJldmVyeV9pdGVtXCIsXG5cdFx0cmVmZXJlbmNlOiBldmVyeUl0ZW0sXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhZGF0YXNldC52YWx1ZS5ldmVyeSh0aGlzLnJlcXVpcmVtZW50KSkgX2FkZElzc3VlKHRoaXMsIFwiaXRlbVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2V4YW1wbGVzL2V4YW1wbGVzLnRzXG4vKipcbiogQ3JlYXRlcyBhbiBleGFtcGxlcyBtZXRhZGF0YSBhY3Rpb24uXG4qXG4qIEBwYXJhbSBleGFtcGxlc18gVGhlIGV4YW1wbGVzLlxuKlxuKiBAcmV0dXJucyBBbiBleGFtcGxlcyBhY3Rpb24uXG4qXG4qIEBiZXRhXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGV4YW1wbGVzKGV4YW1wbGVzXykge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwibWV0YWRhdGFcIixcblx0XHR0eXBlOiBcImV4YW1wbGVzXCIsXG5cdFx0cmVmZXJlbmNlOiBleGFtcGxlcyxcblx0XHRleGFtcGxlczogZXhhbXBsZXNfXG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2V4Y2x1ZGVzL2V4Y2x1ZGVzLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gZXhjbHVkZXMocmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRjb25zdCByZWNlaXZlZCA9IC8qIEBfX1BVUkVfXyAqLyBfc3RyaW5naWZ5KHJlcXVpcmVtZW50KTtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImV4Y2x1ZGVzXCIsXG5cdFx0cmVmZXJlbmNlOiBleGNsdWRlcyxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogYCEke3JlY2VpdmVkfWAsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiBkYXRhc2V0LnZhbHVlLmluY2x1ZGVzKHRoaXMucmVxdWlyZW1lbnQpKSBfYWRkSXNzdWUodGhpcywgXCJjb250ZW50XCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9maWx0ZXJJdGVtcy9maWx0ZXJJdGVtcy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGZpbHRlckl0ZW1zKG9wZXJhdGlvbikge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcImZpbHRlcl9pdGVtc1wiLFxuXHRcdHJlZmVyZW5jZTogZmlsdGVySXRlbXMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdG9wZXJhdGlvbixcblx0XHRcIn5ydW5cIihkYXRhc2V0KSB7XG5cdFx0XHRkYXRhc2V0LnZhbHVlID0gZGF0YXNldC52YWx1ZS5maWx0ZXIodGhpcy5vcGVyYXRpb24pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9maW5kSXRlbS9maW5kSXRlbS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGZpbmRJdGVtKG9wZXJhdGlvbikge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcImZpbmRfaXRlbVwiLFxuXHRcdHJlZmVyZW5jZTogZmluZEl0ZW0sXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdG9wZXJhdGlvbixcblx0XHRcIn5ydW5cIihkYXRhc2V0KSB7XG5cdFx0XHRkYXRhc2V0LnZhbHVlID0gZGF0YXNldC52YWx1ZS5maW5kKHRoaXMub3BlcmF0aW9uKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvZmluaXRlL2Zpbml0ZS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGZpbml0ZShtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImZpbml0ZVwiLFxuXHRcdHJlZmVyZW5jZTogZmluaXRlLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50OiBOdW1iZXIuaXNGaW5pdGUsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwiZmluaXRlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvZmxhdm9yL2ZsYXZvci50c1xuLyoqXG4qIENyZWF0ZXMgYSBmbGF2b3IgdHJhbnNmb3JtYXRpb24gYWN0aW9uLlxuKlxuKiBAcGFyYW0gbmFtZSBUaGUgZmxhdm9yIG5hbWUuXG4qXG4qIEByZXR1cm5zIEEgZmxhdm9yIGFjdGlvbi5cbipcbiogQGJldGFcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gZmxhdm9yKG5hbWUpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInRyYW5zZm9ybWF0aW9uXCIsXG5cdFx0dHlwZTogXCJmbGF2b3JcIixcblx0XHRyZWZlcmVuY2U6IGZsYXZvcixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bmFtZSxcblx0XHRcIn5ydW5cIihkYXRhc2V0KSB7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2dyYXBoZW1lcy9ncmFwaGVtZXMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBncmFwaGVtZXMocmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiZ3JhcGhlbWVzXCIsXG5cdFx0cmVmZXJlbmNlOiBncmFwaGVtZXMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGAke3JlcXVpcmVtZW50fWAsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCkge1xuXHRcdFx0XHRjb25zdCBjb3VudCA9IC8qIEBfX1BVUkVfXyAqLyBfZ2V0R3JhcGhlbWVDb3VudChkYXRhc2V0LnZhbHVlKTtcblx0XHRcdFx0aWYgKGNvdW50ICE9PSB0aGlzLnJlcXVpcmVtZW50KSBfYWRkSXNzdWUodGhpcywgXCJncmFwaGVtZXNcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGAke2NvdW50fWAgfSk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2d0VmFsdWUvZ3RWYWx1ZS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGd0VmFsdWUocmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiZ3RfdmFsdWVcIixcblx0XHRyZWZlcmVuY2U6IGd0VmFsdWUsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGA+JHtyZXF1aXJlbWVudCBpbnN0YW5jZW9mIERhdGUgPyByZXF1aXJlbWVudC50b0pTT04oKSA6IC8qIEBfX1BVUkVfXyAqLyBfc3RyaW5naWZ5KHJlcXVpcmVtZW50KX1gLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIShkYXRhc2V0LnZhbHVlID4gdGhpcy5yZXF1aXJlbWVudCkpIF9hZGRJc3N1ZSh0aGlzLCBcInZhbHVlXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBkYXRhc2V0LnZhbHVlIGluc3RhbmNlb2YgRGF0ZSA/IGRhdGFzZXQudmFsdWUudG9KU09OKCkgOiAvKiBAX19QVVJFX18gKi8gX3N0cmluZ2lmeShkYXRhc2V0LnZhbHVlKSB9KTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvZ3VhcmQvZ3VhcmQudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBndWFyZChyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwiZ3VhcmRcIixcblx0XHRyZWZlcmVuY2U6IGd1YXJkLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50KGRhdGFzZXQudmFsdWUpKSB7XG5cdFx0XHRcdF9hZGRJc3N1ZSh0aGlzLCBcImlucHV0XCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9oYXNoL2hhc2gudHNcbi8qKlxuKiBIYXNoIGxlbmd0aHMgb2JqZWN0LlxuKi9cbmNvbnN0IEhBU0hfTEVOR1RIUyA9IHtcblx0bWQ0OiAzMixcblx0bWQ1OiAzMixcblx0c2hhMTogNDAsXG5cdHNoYTI1NjogNjQsXG5cdHNoYTM4NDogOTYsXG5cdHNoYTUxMjogMTI4LFxuXHRyaXBlbWQxMjg6IDMyLFxuXHRyaXBlbWQxNjA6IDQwLFxuXHR0aWdlcjEyODogMzIsXG5cdHRpZ2VyMTYwOiA0MCxcblx0dGlnZXIxOTI6IDQ4LFxuXHRjcmMzMjogOCxcblx0Y3JjMzJiOiA4LFxuXHRhZGxlcjMyOiA4XG59O1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGhhc2godHlwZXMsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiaGFzaFwiLFxuXHRcdHJlZmVyZW5jZTogaGFzaCxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRyZXF1aXJlbWVudDogUmVnRXhwKHR5cGVzLm1hcCgodHlwZSkgPT4gYF5bYS1mQS1GMC05XXske0hBU0hfTEVOR1RIU1t0eXBlXX19JGApLmpvaW4oXCJ8XCIpLCBcInVcIiksXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJoYXNoXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvaGV4YWRlY2ltYWwvaGV4YWRlY2ltYWwudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBoZXhhZGVjaW1hbChtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImhleGFkZWNpbWFsXCIsXG5cdFx0cmVmZXJlbmNlOiBoZXhhZGVjaW1hbCxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRyZXF1aXJlbWVudDogSEVYQURFQ0lNQUxfUkVHRVgsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJoZXhhZGVjaW1hbFwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2hleENvbG9yL2hleENvbG9yLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gaGV4Q29sb3IobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJoZXhfY29sb3JcIixcblx0XHRyZWZlcmVuY2U6IGhleENvbG9yLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50OiBIRVhfQ09MT1JfUkVHRVgsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJoZXggY29sb3JcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9pbWVpL2ltZWkudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBpbWVpKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiaW1laVwiLFxuXHRcdHJlZmVyZW5jZTogaW1laSxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRyZXF1aXJlbWVudChpbnB1dCkge1xuXHRcdFx0cmV0dXJuIElNRUlfUkVHRVgudGVzdChpbnB1dCkgJiYgLyogQF9fUFVSRV9fICovIF9pc0x1aG5BbGdvKGlucHV0KTtcblx0XHR9LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIXRoaXMucmVxdWlyZW1lbnQoZGF0YXNldC52YWx1ZSkpIF9hZGRJc3N1ZSh0aGlzLCBcIklNRUlcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9pbmNsdWRlcy9pbmNsdWRlcy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGluY2x1ZGVzKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0Y29uc3QgZXhwZWN0cyA9IC8qIEBfX1BVUkVfXyAqLyBfc3RyaW5naWZ5KHJlcXVpcmVtZW50KTtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImluY2x1ZGVzXCIsXG5cdFx0cmVmZXJlbmNlOiBpbmNsdWRlcyxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0cyxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICFkYXRhc2V0LnZhbHVlLmluY2x1ZGVzKHRoaXMucmVxdWlyZW1lbnQpKSBfYWRkSXNzdWUodGhpcywgXCJjb250ZW50XCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBgISR7ZXhwZWN0c31gIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9pbnRlZ2VyL2ludGVnZXIudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBpbnRlZ2VyKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiaW50ZWdlclwiLFxuXHRcdHJlZmVyZW5jZTogaW50ZWdlcixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRyZXF1aXJlbWVudDogTnVtYmVyLmlzSW50ZWdlcixcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJpbnRlZ2VyXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvaXAvaXAudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBpcChtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImlwXCIsXG5cdFx0cmVmZXJlbmNlOiBpcCxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRyZXF1aXJlbWVudDogSVBfUkVHRVgsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJJUFwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2lwdjQvaXB2NC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGlwdjQobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJpcHY0XCIsXG5cdFx0cmVmZXJlbmNlOiBpcHY0LFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50OiBJUFY0X1JFR0VYLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIXRoaXMucmVxdWlyZW1lbnQudGVzdChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwiSVB2NFwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2lwdjYvaXB2Ni50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGlwdjYobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJpcHY2XCIsXG5cdFx0cmVmZXJlbmNlOiBpcHY2LFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50OiBJUFY2X1JFR0VYLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIXRoaXMucmVxdWlyZW1lbnQudGVzdChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwiSVB2NlwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2lzYm4vdXRpbHMvX2lzSXNibjEwLnRzXG4vKipcbiogW1ZhbGlkYXRlcyBhbiBJU0JOLTEwXShodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9JU0JOI0lTQk4tMTBfY2hlY2tfZGlnaXRzKS5cbipcbiogQHBhcmFtIGlucHV0IFRoZSBpbnB1dCB2YWx1ZS5cbipcbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBpbnB1dCBpcyBhIHZhbGlkIElTQk4tMTAsIGBmYWxzZWAgb3RoZXJ3aXNlLlxuKlxuKiBAaW50ZXJuYWxcbiovXG5mdW5jdGlvbiBfaXNJc2JuMTAoaW5wdXQpIHtcblx0Y29uc3QgZGlnaXRzJDEgPSBpbnB1dC5zcGxpdChcIlwiKS5tYXAoKGMpID0+IGMgPT09IFwiWFwiID8gMTAgOiBwYXJzZUludChjKSk7XG5cdGxldCBzdW0gPSAwO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IDEwOyBpKyspIHN1bSArPSBkaWdpdHMkMVtpXSAqICgxMCAtIGkpO1xuXHRyZXR1cm4gc3VtICUgMTEgPT09IDA7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2lzYm4vdXRpbHMvX2lzSXNibjEzLnRzXG4vKipcbiogW1ZhbGlkYXRlcyBhbiBJU0JOLTEzXShodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9JU0JOI0lTQk4tMTNfY2hlY2tfZGlnaXRfY2FsY3VsYXRpb24pLlxuKlxuKiBAcGFyYW0gaW5wdXQgVGhlIGlucHV0IHZhbHVlLlxuKlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIGlucHV0IGlzIGEgdmFsaWQgSVNCTi0xMywgYGZhbHNlYCBvdGhlcndpc2UuXG4qXG4qIEBpbnRlcm5hbFxuKi9cbmZ1bmN0aW9uIF9pc0lzYm4xMyhpbnB1dCkge1xuXHRjb25zdCBkaWdpdHMkMSA9IGlucHV0LnNwbGl0KFwiXCIpLm1hcCgoYykgPT4gcGFyc2VJbnQoYykpO1xuXHRsZXQgc3VtID0gMDtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCAxMzsgaSsrKSBzdW0gKz0gZGlnaXRzJDFbaV0gKiAoaSAlIDIgPT09IDAgPyAxIDogMyk7XG5cdHJldHVybiBzdW0gJSAxMCA9PT0gMDtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvaXNibi9pc2JuLnRzXG4vKipcbiogSVNCTiBzZXBhcmF0b3IgcmVnZXguXG4qL1xuY29uc3QgSVNCTl9TRVBBUkFUT1JfUkVHRVggPSAvWy0gXS9ndTtcbi8qKlxuKiBJU0JOLTEwIGRldGVjdGlvbiByZWdleC5cbiovXG5jb25zdCBJU0JOXzEwX0RFVEVDVElPTl9SRUdFWCA9IC9eXFxkezl9W1xcZFhdJC91O1xuLyoqXG4qIElTQk4tMTMgZGV0ZWN0aW9uIHJlZ2V4LlxuKi9cbmNvbnN0IElTQk5fMTNfREVURUNUSU9OX1JFR0VYID0gL15cXGR7MTN9JC91O1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGlzYm4obWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJpc2JuXCIsXG5cdFx0cmVmZXJlbmNlOiBpc2JuLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50KGlucHV0KSB7XG5cdFx0XHRjb25zdCByZXBsYWNlZElucHV0ID0gaW5wdXQucmVwbGFjZShJU0JOX1NFUEFSQVRPUl9SRUdFWCwgXCJcIik7XG5cdFx0XHRpZiAoSVNCTl8xMF9ERVRFQ1RJT05fUkVHRVgudGVzdChyZXBsYWNlZElucHV0KSkgcmV0dXJuIF9pc0lzYm4xMChyZXBsYWNlZElucHV0KTtcblx0XHRcdGVsc2UgaWYgKElTQk5fMTNfREVURUNUSU9OX1JFR0VYLnRlc3QocmVwbGFjZWRJbnB1dCkpIHJldHVybiBfaXNJc2JuMTMocmVwbGFjZWRJbnB1dCk7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fSxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJJU0JOXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvaXNyYy9pc3JjLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gaXNyYyhtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImlzcmNcIixcblx0XHRyZWZlcmVuY2U6IGlzcmMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IElTUkNfUkVHRVgsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJJU1JDXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvaXNvRGF0ZS9pc29EYXRlLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gaXNvRGF0ZShtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImlzb19kYXRlXCIsXG5cdFx0cmVmZXJlbmNlOiBpc29EYXRlLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50OiBJU09fREFURV9SRUdFWCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50LnRlc3QoZGF0YXNldC52YWx1ZSkpIF9hZGRJc3N1ZSh0aGlzLCBcImRhdGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9pc29EYXRlVGltZS9pc29EYXRlVGltZS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGlzb0RhdGVUaW1lKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiaXNvX2RhdGVfdGltZVwiLFxuXHRcdHJlZmVyZW5jZTogaXNvRGF0ZVRpbWUsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IElTT19EQVRFX1RJTUVfUkVHRVgsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJkYXRlLXRpbWVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9pc29EYXRlVGltZVNlY29uZC9pc29EYXRlVGltZVNlY29uZC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGlzb0RhdGVUaW1lU2Vjb25kKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiaXNvX2RhdGVfdGltZV9zZWNvbmRcIixcblx0XHRyZWZlcmVuY2U6IGlzb0RhdGVUaW1lU2Vjb25kLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50OiBJU09fREFURV9USU1FX1NFQ09ORF9SRUdFWCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50LnRlc3QoZGF0YXNldC52YWx1ZSkpIF9hZGRJc3N1ZSh0aGlzLCBcImRhdGUtdGltZS1zZWNvbmRcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9pc29UaW1lL2lzb1RpbWUudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBpc29UaW1lKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwiaXNvX3RpbWVcIixcblx0XHRyZWZlcmVuY2U6IGlzb1RpbWUsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IElTT19USU1FX1JFR0VYLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIXRoaXMucmVxdWlyZW1lbnQudGVzdChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwidGltZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2lzb1RpbWVTZWNvbmQvaXNvVGltZVNlY29uZC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGlzb1RpbWVTZWNvbmQobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJpc29fdGltZV9zZWNvbmRcIixcblx0XHRyZWZlcmVuY2U6IGlzb1RpbWVTZWNvbmQsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IElTT19USU1FX1NFQ09ORF9SRUdFWCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50LnRlc3QoZGF0YXNldC52YWx1ZSkpIF9hZGRJc3N1ZSh0aGlzLCBcInRpbWUtc2Vjb25kXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvaXNvVGltZXN0YW1wL2lzb1RpbWVzdGFtcC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGlzb1RpbWVzdGFtcChtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImlzb190aW1lc3RhbXBcIixcblx0XHRyZWZlcmVuY2U6IGlzb1RpbWVzdGFtcCxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRyZXF1aXJlbWVudDogSVNPX1RJTUVTVEFNUF9SRUdFWCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50LnRlc3QoZGF0YXNldC52YWx1ZSkpIF9hZGRJc3N1ZSh0aGlzLCBcInRpbWVzdGFtcFwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2lzb1dlZWsvaXNvV2Vlay50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGlzb1dlZWsobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJpc29fd2Vla1wiLFxuXHRcdHJlZmVyZW5jZTogaXNvV2Vlayxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRyZXF1aXJlbWVudDogSVNPX1dFRUtfUkVHRVgsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJ3ZWVrXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvandzQ29tcGFjdC9qd3NDb21wYWN0LnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gandzQ29tcGFjdChtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcImp3c19jb21wYWN0XCIsXG5cdFx0cmVmZXJlbmNlOiBqd3NDb21wYWN0LFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50OiBKV1NfQ09NUEFDVF9SRUdFWCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50LnRlc3QoZGF0YXNldC52YWx1ZSkpIF9hZGRJc3N1ZSh0aGlzLCBcIkpXUyBjb21wYWN0XCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbGVuZ3RoL2xlbmd0aC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGxlbmd0aChyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJsZW5ndGhcIixcblx0XHRyZWZlcmVuY2U6IGxlbmd0aCxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogYCR7cmVxdWlyZW1lbnR9YCxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmIGRhdGFzZXQudmFsdWUubGVuZ3RoICE9PSB0aGlzLnJlcXVpcmVtZW50KSBfYWRkSXNzdWUodGhpcywgXCJsZW5ndGhcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGAke2RhdGFzZXQudmFsdWUubGVuZ3RofWAgfSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL2x0VmFsdWUvbHRWYWx1ZS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGx0VmFsdWUocmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwibHRfdmFsdWVcIixcblx0XHRyZWZlcmVuY2U6IGx0VmFsdWUsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGA8JHtyZXF1aXJlbWVudCBpbnN0YW5jZW9mIERhdGUgPyByZXF1aXJlbWVudC50b0pTT04oKSA6IC8qIEBfX1BVUkVfXyAqLyBfc3RyaW5naWZ5KHJlcXVpcmVtZW50KX1gLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIShkYXRhc2V0LnZhbHVlIDwgdGhpcy5yZXF1aXJlbWVudCkpIF9hZGRJc3N1ZSh0aGlzLCBcInZhbHVlXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBkYXRhc2V0LnZhbHVlIGluc3RhbmNlb2YgRGF0ZSA/IGRhdGFzZXQudmFsdWUudG9KU09OKCkgOiAvKiBAX19QVVJFX18gKi8gX3N0cmluZ2lmeShkYXRhc2V0LnZhbHVlKSB9KTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbWFjL21hYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG1hYyhtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcIm1hY1wiLFxuXHRcdHJlZmVyZW5jZTogbWFjLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50OiBNQUNfUkVHRVgsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJNQUNcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9tYWM0OC9tYWM0OC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG1hYzQ4KG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwibWFjNDhcIixcblx0XHRyZWZlcmVuY2U6IG1hYzQ4LFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50OiBNQUM0OF9SRUdFWCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50LnRlc3QoZGF0YXNldC52YWx1ZSkpIF9hZGRJc3N1ZSh0aGlzLCBcIjQ4LWJpdCBNQUNcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9tYWM2NC9tYWM2NC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG1hYzY0KG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwibWFjNjRcIixcblx0XHRyZWZlcmVuY2U6IG1hYzY0LFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50OiBNQUM2NF9SRUdFWCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50LnRlc3QoZGF0YXNldC52YWx1ZSkpIF9hZGRJc3N1ZSh0aGlzLCBcIjY0LWJpdCBNQUNcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9tYXBJdGVtcy9tYXBJdGVtcy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG1hcEl0ZW1zKG9wZXJhdGlvbikge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcIm1hcF9pdGVtc1wiLFxuXHRcdHJlZmVyZW5jZTogbWFwSXRlbXMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdG9wZXJhdGlvbixcblx0XHRcIn5ydW5cIihkYXRhc2V0KSB7XG5cdFx0XHRkYXRhc2V0LnZhbHVlID0gZGF0YXNldC52YWx1ZS5tYXAodGhpcy5vcGVyYXRpb24pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9tYXhCeXRlcy9tYXhCeXRlcy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG1heEJ5dGVzKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcIm1heF9ieXRlc1wiLFxuXHRcdHJlZmVyZW5jZTogbWF4Qnl0ZXMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGA8PSR7cmVxdWlyZW1lbnR9YCxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkKSB7XG5cdFx0XHRcdGNvbnN0IGxlbmd0aCQxID0gLyogQF9fUFVSRV9fICovIF9nZXRCeXRlQ291bnQoZGF0YXNldC52YWx1ZSk7XG5cdFx0XHRcdGlmIChsZW5ndGgkMSA+IHRoaXMucmVxdWlyZW1lbnQpIF9hZGRJc3N1ZSh0aGlzLCBcImJ5dGVzXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBgJHtsZW5ndGgkMX1gIH0pO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9tYXhFbnRyaWVzL21heEVudHJpZXMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBtYXhFbnRyaWVzKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcIm1heF9lbnRyaWVzXCIsXG5cdFx0cmVmZXJlbmNlOiBtYXhFbnRyaWVzLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBgPD0ke3JlcXVpcmVtZW50fWAsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoIWRhdGFzZXQudHlwZWQpIHJldHVybiBkYXRhc2V0O1xuXHRcdFx0Y29uc3QgY291bnQgPSBPYmplY3Qua2V5cyhkYXRhc2V0LnZhbHVlKS5sZW5ndGg7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiBjb3VudCA+IHRoaXMucmVxdWlyZW1lbnQpIF9hZGRJc3N1ZSh0aGlzLCBcImVudHJpZXNcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGAke2NvdW50fWAgfSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL21heEdyYXBoZW1lcy9tYXhHcmFwaGVtZXMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBtYXhHcmFwaGVtZXMocmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwibWF4X2dyYXBoZW1lc1wiLFxuXHRcdHJlZmVyZW5jZTogbWF4R3JhcGhlbWVzLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBgPD0ke3JlcXVpcmVtZW50fWAsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCkge1xuXHRcdFx0XHRjb25zdCBjb3VudCA9IC8qIEBfX1BVUkVfXyAqLyBfZ2V0R3JhcGhlbWVDb3VudChkYXRhc2V0LnZhbHVlKTtcblx0XHRcdFx0aWYgKGNvdW50ID4gdGhpcy5yZXF1aXJlbWVudCkgX2FkZElzc3VlKHRoaXMsIFwiZ3JhcGhlbWVzXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBgJHtjb3VudH1gIH0pO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9tYXhMZW5ndGgvbWF4TGVuZ3RoLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbWF4TGVuZ3RoKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcIm1heF9sZW5ndGhcIixcblx0XHRyZWZlcmVuY2U6IG1heExlbmd0aCxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogYDw9JHtyZXF1aXJlbWVudH1gLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgZGF0YXNldC52YWx1ZS5sZW5ndGggPiB0aGlzLnJlcXVpcmVtZW50KSBfYWRkSXNzdWUodGhpcywgXCJsZW5ndGhcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGAke2RhdGFzZXQudmFsdWUubGVuZ3RofWAgfSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL21heFNpemUvbWF4U2l6ZS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG1heFNpemUocmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwibWF4X3NpemVcIixcblx0XHRyZWZlcmVuY2U6IG1heFNpemUsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGA8PSR7cmVxdWlyZW1lbnR9YCxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmIGRhdGFzZXQudmFsdWUuc2l6ZSA+IHRoaXMucmVxdWlyZW1lbnQpIF9hZGRJc3N1ZSh0aGlzLCBcInNpemVcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGAke2RhdGFzZXQudmFsdWUuc2l6ZX1gIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9tYXhWYWx1ZS9tYXhWYWx1ZS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG1heFZhbHVlKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcIm1heF92YWx1ZVwiLFxuXHRcdHJlZmVyZW5jZTogbWF4VmFsdWUsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGA8PSR7cmVxdWlyZW1lbnQgaW5zdGFuY2VvZiBEYXRlID8gcmVxdWlyZW1lbnQudG9KU09OKCkgOiAvKiBAX19QVVJFX18gKi8gX3N0cmluZ2lmeShyZXF1aXJlbWVudCl9YCxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICEoZGF0YXNldC52YWx1ZSA8PSB0aGlzLnJlcXVpcmVtZW50KSkgX2FkZElzc3VlKHRoaXMsIFwidmFsdWVcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGRhdGFzZXQudmFsdWUgaW5zdGFuY2VvZiBEYXRlID8gZGF0YXNldC52YWx1ZS50b0pTT04oKSA6IC8qIEBfX1BVUkVfXyAqLyBfc3RyaW5naWZ5KGRhdGFzZXQudmFsdWUpIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9tYXhXb3Jkcy9tYXhXb3Jkcy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG1heFdvcmRzKGxvY2FsZXMsIHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcIm1heF93b3Jkc1wiLFxuXHRcdHJlZmVyZW5jZTogbWF4V29yZHMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGA8PSR7cmVxdWlyZW1lbnR9YCxcblx0XHRsb2NhbGVzLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQpIHtcblx0XHRcdFx0Y29uc3QgY291bnQgPSAvKiBAX19QVVJFX18gKi8gX2dldFdvcmRDb3VudCh0aGlzLmxvY2FsZXMsIGRhdGFzZXQudmFsdWUpO1xuXHRcdFx0XHRpZiAoY291bnQgPiB0aGlzLnJlcXVpcmVtZW50KSBfYWRkSXNzdWUodGhpcywgXCJ3b3Jkc1wiLCBkYXRhc2V0LCBjb25maWckMSwgeyByZWNlaXZlZDogYCR7Y291bnR9YCB9KTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbWV0YWRhdGEvbWV0YWRhdGEudHNcbi8qKlxuKiBDcmVhdGVzIGEgY3VzdG9tIG1ldGFkYXRhIGFjdGlvbi5cbipcbiogQHBhcmFtIG1ldGFkYXRhXyBUaGUgbWV0YWRhdGEgb2JqZWN0LlxuKlxuKiBAcmV0dXJucyBBIG1ldGFkYXRhIGFjdGlvbi5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbWV0YWRhdGEobWV0YWRhdGFfKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJtZXRhZGF0YVwiLFxuXHRcdHR5cGU6IFwibWV0YWRhdGFcIixcblx0XHRyZWZlcmVuY2U6IG1ldGFkYXRhLFxuXHRcdG1ldGFkYXRhOiBtZXRhZGF0YV9cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbWltZVR5cGUvbWltZVR5cGUudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBtaW1lVHlwZShyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJtaW1lX3R5cGVcIixcblx0XHRyZWZlcmVuY2U6IG1pbWVUeXBlLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiAvKiBAX19QVVJFX18gKi8gX2pvaW5FeHBlY3RzKHJlcXVpcmVtZW50Lm1hcCgob3B0aW9uKSA9PiBgXCIke29wdGlvbn1cImApLCBcInxcIiksXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC5pbmNsdWRlcyhkYXRhc2V0LnZhbHVlLnR5cGUpKSBfYWRkSXNzdWUodGhpcywgXCJNSU1FIHR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGBcIiR7ZGF0YXNldC52YWx1ZS50eXBlfVwiYCB9KTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbWluQnl0ZXMvbWluQnl0ZXMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBtaW5CeXRlcyhyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJtaW5fYnl0ZXNcIixcblx0XHRyZWZlcmVuY2U6IG1pbkJ5dGVzLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBgPj0ke3JlcXVpcmVtZW50fWAsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCkge1xuXHRcdFx0XHRjb25zdCBsZW5ndGgkMSA9IC8qIEBfX1BVUkVfXyAqLyBfZ2V0Qnl0ZUNvdW50KGRhdGFzZXQudmFsdWUpO1xuXHRcdFx0XHRpZiAobGVuZ3RoJDEgPCB0aGlzLnJlcXVpcmVtZW50KSBfYWRkSXNzdWUodGhpcywgXCJieXRlc1wiLCBkYXRhc2V0LCBjb25maWckMSwgeyByZWNlaXZlZDogYCR7bGVuZ3RoJDF9YCB9KTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbWluRW50cmllcy9taW5FbnRyaWVzLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbWluRW50cmllcyhyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJtaW5fZW50cmllc1wiLFxuXHRcdHJlZmVyZW5jZTogbWluRW50cmllcyxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogYD49JHtyZXF1aXJlbWVudH1gLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKCFkYXRhc2V0LnR5cGVkKSByZXR1cm4gZGF0YXNldDtcblx0XHRcdGNvbnN0IGNvdW50ID0gT2JqZWN0LmtleXMoZGF0YXNldC52YWx1ZSkubGVuZ3RoO1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgY291bnQgPCB0aGlzLnJlcXVpcmVtZW50KSBfYWRkSXNzdWUodGhpcywgXCJlbnRyaWVzXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBgJHtjb3VudH1gIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9taW5HcmFwaGVtZXMvbWluR3JhcGhlbWVzLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbWluR3JhcGhlbWVzKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcIm1pbl9ncmFwaGVtZXNcIixcblx0XHRyZWZlcmVuY2U6IG1pbkdyYXBoZW1lcyxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogYD49JHtyZXF1aXJlbWVudH1gLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQpIHtcblx0XHRcdFx0Y29uc3QgY291bnQgPSAvKiBAX19QVVJFX18gKi8gX2dldEdyYXBoZW1lQ291bnQoZGF0YXNldC52YWx1ZSk7XG5cdFx0XHRcdGlmIChjb3VudCA8IHRoaXMucmVxdWlyZW1lbnQpIF9hZGRJc3N1ZSh0aGlzLCBcImdyYXBoZW1lc1wiLCBkYXRhc2V0LCBjb25maWckMSwgeyByZWNlaXZlZDogYCR7Y291bnR9YCB9KTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbWluTGVuZ3RoL21pbkxlbmd0aC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG1pbkxlbmd0aChyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJtaW5fbGVuZ3RoXCIsXG5cdFx0cmVmZXJlbmNlOiBtaW5MZW5ndGgsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGA+PSR7cmVxdWlyZW1lbnR9YCxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmIGRhdGFzZXQudmFsdWUubGVuZ3RoIDwgdGhpcy5yZXF1aXJlbWVudCkgX2FkZElzc3VlKHRoaXMsIFwibGVuZ3RoXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBgJHtkYXRhc2V0LnZhbHVlLmxlbmd0aH1gIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9taW5TaXplL21pblNpemUudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBtaW5TaXplKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcIm1pbl9zaXplXCIsXG5cdFx0cmVmZXJlbmNlOiBtaW5TaXplLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBgPj0ke3JlcXVpcmVtZW50fWAsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiBkYXRhc2V0LnZhbHVlLnNpemUgPCB0aGlzLnJlcXVpcmVtZW50KSBfYWRkSXNzdWUodGhpcywgXCJzaXplXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBgJHtkYXRhc2V0LnZhbHVlLnNpemV9YCB9KTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbWluVmFsdWUvbWluVmFsdWUudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBtaW5WYWx1ZShyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJtaW5fdmFsdWVcIixcblx0XHRyZWZlcmVuY2U6IG1pblZhbHVlLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBgPj0ke3JlcXVpcmVtZW50IGluc3RhbmNlb2YgRGF0ZSA/IHJlcXVpcmVtZW50LnRvSlNPTigpIDogLyogQF9fUFVSRV9fICovIF9zdHJpbmdpZnkocmVxdWlyZW1lbnQpfWAsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhKGRhdGFzZXQudmFsdWUgPj0gdGhpcy5yZXF1aXJlbWVudCkpIF9hZGRJc3N1ZSh0aGlzLCBcInZhbHVlXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBkYXRhc2V0LnZhbHVlIGluc3RhbmNlb2YgRGF0ZSA/IGRhdGFzZXQudmFsdWUudG9KU09OKCkgOiAvKiBAX19QVVJFX18gKi8gX3N0cmluZ2lmeShkYXRhc2V0LnZhbHVlKSB9KTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbWluV29yZHMvbWluV29yZHMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBtaW5Xb3Jkcyhsb2NhbGVzLCByZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJtaW5fd29yZHNcIixcblx0XHRyZWZlcmVuY2U6IG1pbldvcmRzLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBgPj0ke3JlcXVpcmVtZW50fWAsXG5cdFx0bG9jYWxlcyxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkKSB7XG5cdFx0XHRcdGNvbnN0IGNvdW50ID0gLyogQF9fUFVSRV9fICovIF9nZXRXb3JkQ291bnQodGhpcy5sb2NhbGVzLCBkYXRhc2V0LnZhbHVlKTtcblx0XHRcdFx0aWYgKGNvdW50IDwgdGhpcy5yZXF1aXJlbWVudCkgX2FkZElzc3VlKHRoaXMsIFwid29yZHNcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGAke2NvdW50fWAgfSk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL211bHRpcGxlT2YvbXVsdGlwbGVPZi50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG11bHRpcGxlT2YocmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwibXVsdGlwbGVfb2ZcIixcblx0XHRyZWZlcmVuY2U6IG11bHRpcGxlT2YsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGAlJHtyZXF1aXJlbWVudH1gLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgZGF0YXNldC52YWx1ZSAlIHRoaXMucmVxdWlyZW1lbnQgIT0gMCkgX2FkZElzc3VlKHRoaXMsIFwibXVsdGlwbGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9uYW5vaWQvbmFub2lkLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbmFub2lkKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwibmFub2lkXCIsXG5cdFx0cmVmZXJlbmNlOiBuYW5vaWQsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IE5BTk9fSURfUkVHRVgsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJOYW5vIElEXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbm9uRW1wdHkvbm9uRW1wdHkudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBub25FbXB0eShtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcIm5vbl9lbXB0eVwiLFxuXHRcdHJlZmVyZW5jZTogbm9uRW1wdHksXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IFwiITBcIixcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmIGRhdGFzZXQudmFsdWUubGVuZ3RoID09PSAwKSBfYWRkSXNzdWUodGhpcywgXCJsZW5ndGhcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IFwiMFwiIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9ub3JtYWxpemUvbm9ybWFsaXplLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbm9ybWFsaXplKGZvcm0pIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInRyYW5zZm9ybWF0aW9uXCIsXG5cdFx0dHlwZTogXCJub3JtYWxpemVcIixcblx0XHRyZWZlcmVuY2U6IG5vcm1hbGl6ZSxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0Zm9ybSxcblx0XHRcIn5ydW5cIihkYXRhc2V0KSB7XG5cdFx0XHRkYXRhc2V0LnZhbHVlID0gZGF0YXNldC52YWx1ZS5ub3JtYWxpemUodGhpcy5mb3JtKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbm90Qnl0ZXMvbm90Qnl0ZXMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBub3RCeXRlcyhyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJub3RfYnl0ZXNcIixcblx0XHRyZWZlcmVuY2U6IG5vdEJ5dGVzLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBgISR7cmVxdWlyZW1lbnR9YCxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkKSB7XG5cdFx0XHRcdGNvbnN0IGxlbmd0aCQxID0gLyogQF9fUFVSRV9fICovIF9nZXRCeXRlQ291bnQoZGF0YXNldC52YWx1ZSk7XG5cdFx0XHRcdGlmIChsZW5ndGgkMSA9PT0gdGhpcy5yZXF1aXJlbWVudCkgX2FkZElzc3VlKHRoaXMsIFwiYnl0ZXNcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGAke2xlbmd0aCQxfWAgfSk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL25vdEVudHJpZXMvbm90RW50cmllcy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG5vdEVudHJpZXMocmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwibm90X2VudHJpZXNcIixcblx0XHRyZWZlcmVuY2U6IG5vdEVudHJpZXMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGAhJHtyZXF1aXJlbWVudH1gLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKCFkYXRhc2V0LnR5cGVkKSByZXR1cm4gZGF0YXNldDtcblx0XHRcdGNvbnN0IGNvdW50ID0gT2JqZWN0LmtleXMoZGF0YXNldC52YWx1ZSkubGVuZ3RoO1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgY291bnQgPT09IHRoaXMucmVxdWlyZW1lbnQpIF9hZGRJc3N1ZSh0aGlzLCBcImVudHJpZXNcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGAke2NvdW50fWAgfSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL25vdEdyYXBoZW1lcy9ub3RHcmFwaGVtZXMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBub3RHcmFwaGVtZXMocmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwibm90X2dyYXBoZW1lc1wiLFxuXHRcdHJlZmVyZW5jZTogbm90R3JhcGhlbWVzLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBgISR7cmVxdWlyZW1lbnR9YCxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkKSB7XG5cdFx0XHRcdGNvbnN0IGNvdW50ID0gLyogQF9fUFVSRV9fICovIF9nZXRHcmFwaGVtZUNvdW50KGRhdGFzZXQudmFsdWUpO1xuXHRcdFx0XHRpZiAoY291bnQgPT09IHRoaXMucmVxdWlyZW1lbnQpIF9hZGRJc3N1ZSh0aGlzLCBcImdyYXBoZW1lc1wiLCBkYXRhc2V0LCBjb25maWckMSwgeyByZWNlaXZlZDogYCR7Y291bnR9YCB9KTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbm90TGVuZ3RoL25vdExlbmd0aC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG5vdExlbmd0aChyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJub3RfbGVuZ3RoXCIsXG5cdFx0cmVmZXJlbmNlOiBub3RMZW5ndGgsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGAhJHtyZXF1aXJlbWVudH1gLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgZGF0YXNldC52YWx1ZS5sZW5ndGggPT09IHRoaXMucmVxdWlyZW1lbnQpIF9hZGRJc3N1ZSh0aGlzLCBcImxlbmd0aFwiLCBkYXRhc2V0LCBjb25maWckMSwgeyByZWNlaXZlZDogYCR7ZGF0YXNldC52YWx1ZS5sZW5ndGh9YCB9KTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvbm90U2l6ZS9ub3RTaXplLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbm90U2l6ZShyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJub3Rfc2l6ZVwiLFxuXHRcdHJlZmVyZW5jZTogbm90U2l6ZSxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogYCEke3JlcXVpcmVtZW50fWAsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiBkYXRhc2V0LnZhbHVlLnNpemUgPT09IHRoaXMucmVxdWlyZW1lbnQpIF9hZGRJc3N1ZSh0aGlzLCBcInNpemVcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGAke2RhdGFzZXQudmFsdWUuc2l6ZX1gIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9ub3RWYWx1ZS9ub3RWYWx1ZS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG5vdFZhbHVlKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcIm5vdF92YWx1ZVwiLFxuXHRcdHJlZmVyZW5jZTogbm90VmFsdWUsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IHJlcXVpcmVtZW50IGluc3RhbmNlb2YgRGF0ZSA/IGAhJHtyZXF1aXJlbWVudC50b0pTT04oKX1gIDogYCEkey8qIEBfX1BVUkVfXyAqLyBfc3RyaW5naWZ5KHJlcXVpcmVtZW50KX1gLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgdGhpcy5yZXF1aXJlbWVudCA8PSBkYXRhc2V0LnZhbHVlICYmIHRoaXMucmVxdWlyZW1lbnQgPj0gZGF0YXNldC52YWx1ZSkgX2FkZElzc3VlKHRoaXMsIFwidmFsdWVcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGRhdGFzZXQudmFsdWUgaW5zdGFuY2VvZiBEYXRlID8gZGF0YXNldC52YWx1ZS50b0pTT04oKSA6IC8qIEBfX1BVUkVfXyAqLyBfc3RyaW5naWZ5KGRhdGFzZXQudmFsdWUpIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9ub3RWYWx1ZXMvbm90VmFsdWVzLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbm90VmFsdWVzKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcIm5vdF92YWx1ZXNcIixcblx0XHRyZWZlcmVuY2U6IG5vdFZhbHVlcyxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogYCEkey8qIEBfX1BVUkVfXyAqLyBfam9pbkV4cGVjdHMocmVxdWlyZW1lbnQubWFwKCh2YWx1ZSQxKSA9PiB2YWx1ZSQxIGluc3RhbmNlb2YgRGF0ZSA/IHZhbHVlJDEudG9KU09OKCkgOiAvKiBAX19QVVJFX18gKi8gX3N0cmluZ2lmeSh2YWx1ZSQxKSksIFwifFwiKX1gLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgdGhpcy5yZXF1aXJlbWVudC5zb21lKCh2YWx1ZSQxKSA9PiB2YWx1ZSQxIDw9IGRhdGFzZXQudmFsdWUgJiYgdmFsdWUkMSA+PSBkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwidmFsdWVcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGRhdGFzZXQudmFsdWUgaW5zdGFuY2VvZiBEYXRlID8gZGF0YXNldC52YWx1ZS50b0pTT04oKSA6IC8qIEBfX1BVUkVfXyAqLyBfc3RyaW5naWZ5KGRhdGFzZXQudmFsdWUpIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9ub3RXb3Jkcy9ub3RXb3Jkcy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG5vdFdvcmRzKGxvY2FsZXMsIHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcIm5vdF93b3Jkc1wiLFxuXHRcdHJlZmVyZW5jZTogbm90V29yZHMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGAhJHtyZXF1aXJlbWVudH1gLFxuXHRcdGxvY2FsZXMsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCkge1xuXHRcdFx0XHRjb25zdCBjb3VudCA9IC8qIEBfX1BVUkVfXyAqLyBfZ2V0V29yZENvdW50KHRoaXMubG9jYWxlcywgZGF0YXNldC52YWx1ZSk7XG5cdFx0XHRcdGlmIChjb3VudCA9PT0gdGhpcy5yZXF1aXJlbWVudCkgX2FkZElzc3VlKHRoaXMsIFwid29yZHNcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGAke2NvdW50fWAgfSk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL29jdGFsL29jdGFsLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gb2N0YWwobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJvY3RhbFwiLFxuXHRcdHJlZmVyZW5jZTogb2N0YWwsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IE9DVEFMX1JFR0VYLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIXRoaXMucmVxdWlyZW1lbnQudGVzdChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwib2N0YWxcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9wYXJzZUJvb2xlYW4vcGFyc2VCb29sZWFuLnRzXG5jb25zdCBUUlVUSFkgPSBbXG5cdHRydWUsXG5cdDEsXG5cdFwidHJ1ZVwiLFxuXHRcIjFcIixcblx0XCJ5ZXNcIixcblx0XCJ5XCIsXG5cdFwib25cIixcblx0XCJlbmFibGVkXCJcbl07XG5jb25zdCBGQUxTWSA9IFtcblx0ZmFsc2UsXG5cdDAsXG5cdFwiZmFsc2VcIixcblx0XCIwXCIsXG5cdFwibm9cIixcblx0XCJuXCIsXG5cdFwib2ZmXCIsXG5cdFwiZGlzYWJsZWRcIlxuXTtcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBwYXJzZUJvb2xlYW4oY29uZmlnJDEsIG1lc3NhZ2UkMSkge1xuXHRjb25zdCBub3JtYWxpemUkMSA9ICh2KSA9PiB0eXBlb2YgdiA9PT0gXCJzdHJpbmdcIiA/IHYudG9Mb3dlckNhc2UoKSA6IHY7XG5cdGNvbnN0IHRydXRoeVJhdyA9IGNvbmZpZyQxPy50cnV0aHkgPz8gVFJVVEhZO1xuXHRjb25zdCBmYWxzeVJhdyA9IGNvbmZpZyQxPy5mYWxzeSA/PyBGQUxTWTtcblx0Y29uc3QgdHJ1dGh5ID0gY29uZmlnJDE/LnRydXRoeSA/IGNvbmZpZyQxLnRydXRoeS5tYXAobm9ybWFsaXplJDEpIDogVFJVVEhZO1xuXHRjb25zdCBmYWxzeSA9IGNvbmZpZyQxPy5mYWxzeSA/IGNvbmZpZyQxLmZhbHN5Lm1hcChub3JtYWxpemUkMSkgOiBGQUxTWTtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInRyYW5zZm9ybWF0aW9uXCIsXG5cdFx0dHlwZTogXCJwYXJzZV9ib29sZWFuXCIsXG5cdFx0cmVmZXJlbmNlOiBwYXJzZUJvb2xlYW4sXG5cdFx0ZXhwZWN0czogLyogQF9fUFVSRV9fICovIF9qb2luRXhwZWN0cyhbLi4udHJ1dGh5UmF3LCAuLi5mYWxzeVJhd10ubWFwKF9zdHJpbmdpZnkpLCBcInxcIiksXG5cdFx0Y29uZmlnOiBjb25maWckMSxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQyKSB7XG5cdFx0XHRjb25zdCBpbnB1dCA9IG5vcm1hbGl6ZSQxKGRhdGFzZXQudmFsdWUpO1xuXHRcdFx0aWYgKHRydXRoeS5pbmNsdWRlcyhpbnB1dCkpIGRhdGFzZXQudmFsdWUgPSB0cnVlO1xuXHRcdFx0ZWxzZSBpZiAoZmFsc3kuaW5jbHVkZXMoaW5wdXQpKSBkYXRhc2V0LnZhbHVlID0gZmFsc2U7XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0X2FkZElzc3VlKHRoaXMsIFwiYm9vbGVhblwiLCBkYXRhc2V0LCBjb25maWckMik7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvcGFyc2VKc29uL3BhcnNlSnNvbi50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHBhcnNlSnNvbihjb25maWckMSwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwicGFyc2VfanNvblwiLFxuXHRcdHJlZmVyZW5jZTogcGFyc2VKc29uLFxuXHRcdGNvbmZpZzogY29uZmlnJDEsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMikge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0ZGF0YXNldC52YWx1ZSA9IEpTT04ucGFyc2UoZGF0YXNldC52YWx1ZSwgdGhpcy5jb25maWc/LnJldml2ZXIpO1xuXHRcdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdFx0aWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcblx0XHRcdFx0XHRfYWRkSXNzdWUodGhpcywgXCJKU09OXCIsIGRhdGFzZXQsIGNvbmZpZyQyLCB7IHJlY2VpdmVkOiBgXCIke2Vycm9yLm1lc3NhZ2V9XCJgIH0pO1xuXHRcdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0fSBlbHNlIHRocm93IGVycm9yO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9wYXJ0aWFsQ2hlY2svdXRpbHMvX2lzUGFydGlhbGx5VHlwZWQvX2lzUGFydGlhbGx5VHlwZWQudHNcbi8qKlxuKiBDaGVja3MgaWYgYSBkYXRhc2V0IGlzIHBhcnRpYWxseSB0eXBlZC5cbipcbiogQHBhcmFtIGRhdGFzZXQgVGhlIGRhdGFzZXQgdG8gY2hlY2suXG4qIEBwYXJhbSBwYXRocyBUaGUgcGF0aHMgdG8gY2hlY2suXG4qXG4qIEByZXR1cm5zIFdoZXRoZXIgaXQgaXMgcGFydGlhbGx5IHR5cGVkLlxuKlxuKiBAaW50ZXJuYWxcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gX2lzUGFydGlhbGx5VHlwZWQoZGF0YXNldCwgcGF0aHMpIHtcblx0aWYgKGRhdGFzZXQuaXNzdWVzKSBmb3IgKGNvbnN0IHBhdGggb2YgcGF0aHMpIGZvciAoY29uc3QgaXNzdWUgb2YgZGF0YXNldC5pc3N1ZXMpIHtcblx0XHRsZXQgdHlwZWQgPSBmYWxzZTtcblx0XHRjb25zdCBib3VuZCA9IE1hdGgubWluKHBhdGgubGVuZ3RoLCBpc3N1ZS5wYXRoPy5sZW5ndGggPz8gMCk7XG5cdFx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGJvdW5kOyBpbmRleCsrKSBpZiAocGF0aFtpbmRleF0gIT09IGlzc3VlLnBhdGhbaW5kZXhdLmtleSAmJiAocGF0aFtpbmRleF0gIT09IFwiJFwiIHx8IGlzc3VlLnBhdGhbaW5kZXhdLnR5cGUgIT09IFwiYXJyYXlcIikpIHtcblx0XHRcdHR5cGVkID0gdHJ1ZTtcblx0XHRcdGJyZWFrO1xuXHRcdH1cblx0XHRpZiAoIXR5cGVkKSByZXR1cm4gZmFsc2U7XG5cdH1cblx0cmV0dXJuIHRydWU7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3BhcnRpYWxDaGVjay9wYXJ0aWFsQ2hlY2sudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBwYXJ0aWFsQ2hlY2socGF0aHMsIHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcInBhcnRpYWxfY2hlY2tcIixcblx0XHRyZWZlcmVuY2U6IHBhcnRpYWxDaGVjayxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRwYXRocyxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmICgoZGF0YXNldC50eXBlZCB8fCAvKiBAX19QVVJFX18gKi8gX2lzUGFydGlhbGx5VHlwZWQoZGF0YXNldCwgcGF0aHMpKSAmJiAhdGhpcy5yZXF1aXJlbWVudChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwiaW5wdXRcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9wYXJ0aWFsQ2hlY2svcGFydGlhbENoZWNrQXN5bmMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBwYXJ0aWFsQ2hlY2tBc3luYyhwYXRocywgcmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwicGFydGlhbF9jaGVja1wiLFxuXHRcdHJlZmVyZW5jZTogcGFydGlhbENoZWNrQXN5bmMsXG5cdFx0YXN5bmM6IHRydWUsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRwYXRocyxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0YXN5bmMgXCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmICgoZGF0YXNldC50eXBlZCB8fCAvKiBAX19QVVJFX18gKi8gX2lzUGFydGlhbGx5VHlwZWQoZGF0YXNldCwgcGF0aHMpKSAmJiAhYXdhaXQgdGhpcy5yZXF1aXJlbWVudChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwiaW5wdXRcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9yYXdDaGVjay9yYXdDaGVjay50c1xuLyoqXG4qIENyZWF0ZXMgYSByYXcgY2hlY2sgdmFsaWRhdGlvbiBhY3Rpb24uXG4qXG4qIEBwYXJhbSBhY3Rpb24gVGhlIHZhbGlkYXRpb24gYWN0aW9uLlxuKlxuKiBAcmV0dXJucyBBIHJhdyBjaGVjayBhY3Rpb24uXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHJhd0NoZWNrKGFjdGlvbikge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwicmF3X2NoZWNrXCIsXG5cdFx0cmVmZXJlbmNlOiByYXdDaGVjayxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0YWN0aW9uKHtcblx0XHRcdFx0ZGF0YXNldCxcblx0XHRcdFx0Y29uZmlnOiBjb25maWckMSxcblx0XHRcdFx0YWRkSXNzdWU6IChpbmZvKSA9PiBfYWRkSXNzdWUodGhpcywgaW5mbz8ubGFiZWwgPz8gXCJpbnB1dFwiLCBkYXRhc2V0LCBjb25maWckMSwgaW5mbylcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9yYXdDaGVjay9yYXdDaGVja0FzeW5jLnRzXG4vKipcbiogQ3JlYXRlcyBhIHJhdyBjaGVjayB2YWxpZGF0aW9uIGFjdGlvbi5cbipcbiogQHBhcmFtIGFjdGlvbiBUaGUgdmFsaWRhdGlvbiBhY3Rpb24uXG4qXG4qIEByZXR1cm5zIEEgcmF3IGNoZWNrIGFjdGlvbi5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gcmF3Q2hlY2tBc3luYyhhY3Rpb24pIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcInJhd19jaGVja1wiLFxuXHRcdHJlZmVyZW5jZTogcmF3Q2hlY2tBc3luYyxcblx0XHRhc3luYzogdHJ1ZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdGFzeW5jIFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRhd2FpdCBhY3Rpb24oe1xuXHRcdFx0XHRkYXRhc2V0LFxuXHRcdFx0XHRjb25maWc6IGNvbmZpZyQxLFxuXHRcdFx0XHRhZGRJc3N1ZTogKGluZm8pID0+IF9hZGRJc3N1ZSh0aGlzLCBpbmZvPy5sYWJlbCA/PyBcImlucHV0XCIsIGRhdGFzZXQsIGNvbmZpZyQxLCBpbmZvKVxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3Jhd1RyYW5zZm9ybS9yYXdUcmFuc2Zvcm0udHNcbi8qKlxuKiBDcmVhdGVzIGEgcmF3IHRyYW5zZm9ybWF0aW9uIGFjdGlvbi5cbipcbiogQHBhcmFtIGFjdGlvbiBUaGUgdHJhbnNmb3JtYXRpb24gYWN0aW9uLlxuKlxuKiBAcmV0dXJucyBBIHJhdyB0cmFuc2Zvcm0gYWN0aW9uLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiByYXdUcmFuc2Zvcm0oYWN0aW9uKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwicmF3X3RyYW5zZm9ybVwiLFxuXHRcdHJlZmVyZW5jZTogcmF3VHJhbnNmb3JtLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3Qgb3V0cHV0ID0gYWN0aW9uKHtcblx0XHRcdFx0ZGF0YXNldCxcblx0XHRcdFx0Y29uZmlnOiBjb25maWckMSxcblx0XHRcdFx0YWRkSXNzdWU6IChpbmZvKSA9PiBfYWRkSXNzdWUodGhpcywgaW5mbz8ubGFiZWwgPz8gXCJpbnB1dFwiLCBkYXRhc2V0LCBjb25maWckMSwgaW5mbyksXG5cdFx0XHRcdE5FVkVSOiBudWxsXG5cdFx0XHR9KTtcblx0XHRcdGlmIChkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0ZWxzZSBkYXRhc2V0LnZhbHVlID0gb3V0cHV0O1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9yYXdUcmFuc2Zvcm0vcmF3VHJhbnNmb3JtQXN5bmMudHNcbi8qKlxuKiBDcmVhdGVzIGEgcmF3IHRyYW5zZm9ybWF0aW9uIGFjdGlvbi5cbipcbiogQHBhcmFtIGFjdGlvbiBUaGUgdHJhbnNmb3JtYXRpb24gYWN0aW9uLlxuKlxuKiBAcmV0dXJucyBBIHJhdyB0cmFuc2Zvcm0gYWN0aW9uLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiByYXdUcmFuc2Zvcm1Bc3luYyhhY3Rpb24pIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInRyYW5zZm9ybWF0aW9uXCIsXG5cdFx0dHlwZTogXCJyYXdfdHJhbnNmb3JtXCIsXG5cdFx0cmVmZXJlbmNlOiByYXdUcmFuc2Zvcm1Bc3luYyxcblx0XHRhc3luYzogdHJ1ZSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3Qgb3V0cHV0ID0gYXdhaXQgYWN0aW9uKHtcblx0XHRcdFx0ZGF0YXNldCxcblx0XHRcdFx0Y29uZmlnOiBjb25maWckMSxcblx0XHRcdFx0YWRkSXNzdWU6IChpbmZvKSA9PiBfYWRkSXNzdWUodGhpcywgaW5mbz8ubGFiZWwgPz8gXCJpbnB1dFwiLCBkYXRhc2V0LCBjb25maWckMSwgaW5mbyksXG5cdFx0XHRcdE5FVkVSOiBudWxsXG5cdFx0XHR9KTtcblx0XHRcdGlmIChkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0ZWxzZSBkYXRhc2V0LnZhbHVlID0gb3V0cHV0O1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9yZWFkb25seS9yZWFkb25seS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHJlYWRvbmx5KCkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcInJlYWRvbmx5XCIsXG5cdFx0cmVmZXJlbmNlOiByZWFkb25seSxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCkge1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9yZWR1Y2VJdGVtcy9yZWR1Y2VJdGVtcy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHJlZHVjZUl0ZW1zKG9wZXJhdGlvbiwgaW5pdGlhbCkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcInJlZHVjZV9pdGVtc1wiLFxuXHRcdHJlZmVyZW5jZTogcmVkdWNlSXRlbXMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdG9wZXJhdGlvbixcblx0XHRpbml0aWFsLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQpIHtcblx0XHRcdGRhdGFzZXQudmFsdWUgPSBkYXRhc2V0LnZhbHVlLnJlZHVjZSh0aGlzLm9wZXJhdGlvbiwgdGhpcy5pbml0aWFsKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvcmVnZXgvcmVnZXgudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiByZWdleChyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJyZWdleFwiLFxuXHRcdHJlZmVyZW5jZTogcmVnZXgsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGAke3JlcXVpcmVtZW50fWAsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJmb3JtYXRcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9yZXR1cm5zL3JldHVybnMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiByZXR1cm5zKHNjaGVtYSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcInJldHVybnNcIixcblx0XHRyZWZlcmVuY2U6IHJldHVybnMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdHNjaGVtYSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgZnVuYyA9IGRhdGFzZXQudmFsdWU7XG5cdFx0XHRkYXRhc2V0LnZhbHVlID0gKC4uLmFyZ3NfKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHJldHVybnNEYXRhc2V0ID0gdGhpcy5zY2hlbWFbXCJ+cnVuXCJdKHsgdmFsdWU6IGZ1bmMoLi4uYXJnc18pIH0sIGNvbmZpZyQxKTtcblx0XHRcdFx0aWYgKHJldHVybnNEYXRhc2V0Lmlzc3VlcykgdGhyb3cgbmV3IFZhbGlFcnJvcihyZXR1cm5zRGF0YXNldC5pc3N1ZXMpO1xuXHRcdFx0XHRyZXR1cm4gcmV0dXJuc0RhdGFzZXQudmFsdWU7XG5cdFx0XHR9O1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9yZXR1cm5zL3JldHVybnNBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHJldHVybnNBc3luYyhzY2hlbWEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInRyYW5zZm9ybWF0aW9uXCIsXG5cdFx0dHlwZTogXCJyZXR1cm5zXCIsXG5cdFx0cmVmZXJlbmNlOiByZXR1cm5zQXN5bmMsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdHNjaGVtYSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgZnVuYyA9IGRhdGFzZXQudmFsdWU7XG5cdFx0XHRkYXRhc2V0LnZhbHVlID0gYXN5bmMgKC4uLmFyZ3NfKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHJldHVybnNEYXRhc2V0ID0gYXdhaXQgdGhpcy5zY2hlbWFbXCJ+cnVuXCJdKHsgdmFsdWU6IGF3YWl0IGZ1bmMoLi4uYXJnc18pIH0sIGNvbmZpZyQxKTtcblx0XHRcdFx0aWYgKHJldHVybnNEYXRhc2V0Lmlzc3VlcykgdGhyb3cgbmV3IFZhbGlFcnJvcihyZXR1cm5zRGF0YXNldC5pc3N1ZXMpO1xuXHRcdFx0XHRyZXR1cm4gcmV0dXJuc0RhdGFzZXQudmFsdWU7XG5cdFx0XHR9O1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9yZmNFbWFpbC9yZmNFbWFpbC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHJmY0VtYWlsKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwicmZjX2VtYWlsXCIsXG5cdFx0cmVmZXJlbmNlOiByZmNFbWFpbCxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRyZXF1aXJlbWVudDogUkZDX0VNQUlMX1JFR0VYLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIXRoaXMucmVxdWlyZW1lbnQudGVzdChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwiZW1haWxcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9zYWZlSW50ZWdlci9zYWZlSW50ZWdlci50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHNhZmVJbnRlZ2VyKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwic2FmZV9pbnRlZ2VyXCIsXG5cdFx0cmVmZXJlbmNlOiBzYWZlSW50ZWdlcixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZXhwZWN0czogbnVsbCxcblx0XHRyZXF1aXJlbWVudDogTnVtYmVyLmlzU2FmZUludGVnZXIsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwic2FmZSBpbnRlZ2VyXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvc2l6ZS9zaXplLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gc2l6ZShyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJzaXplXCIsXG5cdFx0cmVmZXJlbmNlOiBzaXplLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBgJHtyZXF1aXJlbWVudH1gLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgZGF0YXNldC52YWx1ZS5zaXplICE9PSB0aGlzLnJlcXVpcmVtZW50KSBfYWRkSXNzdWUodGhpcywgXCJzaXplXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBgJHtkYXRhc2V0LnZhbHVlLnNpemV9YCB9KTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvc2x1Zy9zbHVnLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gc2x1ZyhtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcInNsdWdcIixcblx0XHRyZWZlcmVuY2U6IHNsdWcsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IFNMVUdfUkVHRVgsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJzbHVnXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvc29tZUl0ZW0vc29tZUl0ZW0udHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBzb21lSXRlbShyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJzb21lX2l0ZW1cIixcblx0XHRyZWZlcmVuY2U6IHNvbWVJdGVtLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIWRhdGFzZXQudmFsdWUuc29tZSh0aGlzLnJlcXVpcmVtZW50KSkgX2FkZElzc3VlKHRoaXMsIFwiaXRlbVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3NvcnRJdGVtcy9zb3J0SXRlbXMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBzb3J0SXRlbXMob3BlcmF0aW9uKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwic29ydF9pdGVtc1wiLFxuXHRcdHJlZmVyZW5jZTogc29ydEl0ZW1zLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRvcGVyYXRpb24sXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCkge1xuXHRcdFx0ZGF0YXNldC52YWx1ZSA9IGRhdGFzZXQudmFsdWUuc29ydCh0aGlzLm9wZXJhdGlvbik7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3N0YXJ0c1dpdGgvc3RhcnRzV2l0aC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHN0YXJ0c1dpdGgocmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwic3RhcnRzX3dpdGhcIixcblx0XHRyZWZlcmVuY2U6IHN0YXJ0c1dpdGgsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IGBcIiR7cmVxdWlyZW1lbnR9XCJgLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgIWRhdGFzZXQudmFsdWUuc3RhcnRzV2l0aCh0aGlzLnJlcXVpcmVtZW50KSkgX2FkZElzc3VlKHRoaXMsIFwic3RhcnRcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGBcIiR7ZGF0YXNldC52YWx1ZS5zbGljZSgwLCB0aGlzLnJlcXVpcmVtZW50Lmxlbmd0aCl9XCJgIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy9zdHJpbmdpZnlKc29uL3N0cmluZ2lmeUpzb24udHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBzdHJpbmdpZnlKc29uKGNvbmZpZyQxLCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInRyYW5zZm9ybWF0aW9uXCIsXG5cdFx0dHlwZTogXCJzdHJpbmdpZnlfanNvblwiLFxuXHRcdHJlZmVyZW5jZTogc3RyaW5naWZ5SnNvbixcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Y29uZmlnOiBjb25maWckMSxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDIpIHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IG91dHB1dCA9IEpTT04uc3RyaW5naWZ5KGRhdGFzZXQudmFsdWUsIHRoaXMuY29uZmlnPy5yZXBsYWNlciwgdGhpcy5jb25maWc/LnNwYWNlKTtcblx0XHRcdFx0aWYgKG91dHB1dCA9PT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0X2FkZElzc3VlKHRoaXMsIFwiSlNPTlwiLCBkYXRhc2V0LCBjb25maWckMik7XG5cdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGRhdGFzZXQudmFsdWUgPSBvdXRwdXQ7XG5cdFx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0XHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikge1xuXHRcdFx0XHRcdF9hZGRJc3N1ZSh0aGlzLCBcIkpTT05cIiwgZGF0YXNldCwgY29uZmlnJDIsIHsgcmVjZWl2ZWQ6IGBcIiR7ZXJyb3IubWVzc2FnZX1cImAgfSk7XG5cdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHR9IGVsc2UgdGhyb3cgZXJyb3I7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3RpdGxlL3RpdGxlLnRzXG4vKipcbiogQ3JlYXRlcyBhIHRpdGxlIG1ldGFkYXRhIGFjdGlvbi5cbipcbiogQHBhcmFtIHRpdGxlXyBUaGUgdGl0bGUgdGV4dC5cbipcbiogQHJldHVybnMgQSB0aXRsZSBhY3Rpb24uXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHRpdGxlKHRpdGxlXykge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwibWV0YWRhdGFcIixcblx0XHR0eXBlOiBcInRpdGxlXCIsXG5cdFx0cmVmZXJlbmNlOiB0aXRsZSxcblx0XHR0aXRsZTogdGl0bGVfXG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3RvQmlnaW50L3RvQmlnaW50LnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdG9CaWdpbnQobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwidG9fYmlnaW50XCIsXG5cdFx0cmVmZXJlbmNlOiB0b0JpZ2ludCxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gQmlnSW50KGRhdGFzZXQudmFsdWUpO1xuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdF9hZGRJc3N1ZSh0aGlzLCBcImJpZ2ludFwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvdG9Cb29sZWFuL3RvQm9vbGVhbi50c1xuLyoqXG4qIENyZWF0ZXMgYSB0byBib29sZWFuIHRyYW5zZm9ybWF0aW9uIGFjdGlvbi5cbipcbiogQHJldHVybnMgQSB0byBib29sZWFuIGFjdGlvbi5cbipcbiogQGJldGFcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdG9Cb29sZWFuKCkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcInRvX2Jvb2xlYW5cIixcblx0XHRyZWZlcmVuY2U6IHRvQm9vbGVhbixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCkge1xuXHRcdFx0ZGF0YXNldC52YWx1ZSA9IEJvb2xlYW4oZGF0YXNldC52YWx1ZSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3RvQ2FtZWxDYXNlL3RvQ2FtZWxDYXNlLnRzXG4vKipcbiogQ3JlYXRlcyBhIHRvIGNhbWVsIGNhc2UgdHJhbnNmb3JtYXRpb24gYWN0aW9uLlxuKlxuKiBXb3JkcyBhcmUgc2VwYXJhdGVkIGJ5IGBfYCwgYC1gIGFuZCBBU0NJSSB3aGl0ZXNwYWNlLCBhcyB3ZWxsIGFzIGJ5IGNhc2VcbiogYW5kIGFjcm9ueW0gYm91bmRhcmllcy5cbipcbiogSGludDogQWNyb255bSBydW5zIGFyZSBub3JtYWxpemVkIHRvIGxvd2VyY2FzZSAoZS5nLiBgcGFyc2VVUkxWYWx1ZWAg4oaSXG4qIGBwYXJzZVVybFZhbHVlYCkgYW5kIGRpZ2l0cyBzdGF5IGF0dGFjaGVkIHRvIHRoZSBwcmVjZWRpbmcgdG9rZW4gKGUuZy5cbiogYGl0ZW0yTmFtZWAg4oaSIGBpdGVtMk5hbWVgKS5cbipcbiogQHJldHVybnMgQSB0byBjYW1lbCBjYXNlIGFjdGlvbi5cbipcbiogQGJldGFcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdG9DYW1lbENhc2UoKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwidG9fY2FtZWxfY2FzZVwiLFxuXHRcdHJlZmVyZW5jZTogdG9DYW1lbENhc2UsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQpIHtcblx0XHRcdGRhdGFzZXQudmFsdWUgPSAvKiBAX19QVVJFX18gKi8gX2Zvcm1hdENhc2UoZGF0YXNldC52YWx1ZSwgXCJcIiwgZmFsc2UsIHRydWUpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy90b0RhdGUvdG9EYXRlLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdG9EYXRlKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcInRvX2RhdGVcIixcblx0XHRyZWZlcmVuY2U6IHRvRGF0ZSxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gbmV3IERhdGUoZGF0YXNldC52YWx1ZSk7XG5cdFx0XHRcdGlmIChpc05hTihkYXRhc2V0LnZhbHVlKSkge1xuXHRcdFx0XHRcdF9hZGRJc3N1ZSh0aGlzLCBcImRhdGVcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IFwiXFxcIkludmFsaWQgRGF0ZVxcXCJcIiB9KTtcblx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdH1cblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRfYWRkSXNzdWUodGhpcywgXCJkYXRlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy90b0tlYmFiQ2FzZS90b0tlYmFiQ2FzZS50c1xuLyoqXG4qIENyZWF0ZXMgYSB0byBrZWJhYiBjYXNlIHRyYW5zZm9ybWF0aW9uIGFjdGlvbi5cbipcbiogV29yZHMgYXJlIHNlcGFyYXRlZCBieSBgX2AsIGAtYCBhbmQgQVNDSUkgd2hpdGVzcGFjZSwgYXMgd2VsbCBhcyBieSBjYXNlXG4qIGFuZCBhY3JvbnltIGJvdW5kYXJpZXMuXG4qXG4qIEhpbnQ6IEFjcm9ueW0gcnVucyBhcmUgbm9ybWFsaXplZCB0byBsb3dlcmNhc2UgKGUuZy4gYHBhcnNlVVJMVmFsdWVgIOKGklxuKiBgcGFyc2UtdXJsLXZhbHVlYCkgYW5kIGRpZ2l0cyBzdGF5IGF0dGFjaGVkIHRvIHRoZSBwcmVjZWRpbmcgdG9rZW4gKGUuZy5cbiogYGl0ZW0yTmFtZWAg4oaSIGBpdGVtMi1uYW1lYCkuXG4qXG4qIEByZXR1cm5zIEEgdG8ga2ViYWIgY2FzZSBhY3Rpb24uXG4qXG4qIEBiZXRhXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHRvS2ViYWJDYXNlKCkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcInRvX2tlYmFiX2Nhc2VcIixcblx0XHRyZWZlcmVuY2U6IHRvS2ViYWJDYXNlLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRcIn5ydW5cIihkYXRhc2V0KSB7XG5cdFx0XHRkYXRhc2V0LnZhbHVlID0gLyogQF9fUFVSRV9fICovIF9mb3JtYXRDYXNlKGRhdGFzZXQudmFsdWUsIFwiLVwiLCBmYWxzZSwgZmFsc2UpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy90b0xvd2VyQ2FzZS90b0xvd2VyQ2FzZS50c1xuLyoqXG4qIENyZWF0ZXMgYSB0byBsb3dlciBjYXNlIHRyYW5zZm9ybWF0aW9uIGFjdGlvbi5cbipcbiogQHJldHVybnMgQSB0byBsb3dlciBjYXNlIGFjdGlvbi5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdG9Mb3dlckNhc2UoKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwidG9fbG93ZXJfY2FzZVwiLFxuXHRcdHJlZmVyZW5jZTogdG9Mb3dlckNhc2UsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQpIHtcblx0XHRcdGRhdGFzZXQudmFsdWUgPSBkYXRhc2V0LnZhbHVlLnRvTG93ZXJDYXNlKCk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3RvTWF4VmFsdWUvdG9NYXhWYWx1ZS50c1xuLyoqXG4qIENyZWF0ZXMgYSB0byBtYXggdmFsdWUgdHJhbnNmb3JtYXRpb24gYWN0aW9uLlxuKlxuKiBAcGFyYW0gcmVxdWlyZW1lbnQgVGhlIG1heGltdW0gdmFsdWUuXG4qXG4qIEByZXR1cm5zIEEgdG8gbWF4IHZhbHVlIGFjdGlvbi5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdG9NYXhWYWx1ZShyZXF1aXJlbWVudCkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcInRvX21heF92YWx1ZVwiLFxuXHRcdHJlZmVyZW5jZTogdG9NYXhWYWx1ZSxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCkge1xuXHRcdFx0ZGF0YXNldC52YWx1ZSA9IGRhdGFzZXQudmFsdWUgPiB0aGlzLnJlcXVpcmVtZW50ID8gdGhpcy5yZXF1aXJlbWVudCA6IGRhdGFzZXQudmFsdWU7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3RvTWluVmFsdWUvdG9NaW5WYWx1ZS50c1xuLyoqXG4qIENyZWF0ZXMgYSB0byBtaW4gdmFsdWUgdHJhbnNmb3JtYXRpb24gYWN0aW9uLlxuKlxuKiBAcGFyYW0gcmVxdWlyZW1lbnQgVGhlIG1pbmltdW0gdmFsdWUuXG4qXG4qIEByZXR1cm5zIEEgdG8gbWluIHZhbHVlIGFjdGlvbi5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdG9NaW5WYWx1ZShyZXF1aXJlbWVudCkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcInRvX21pbl92YWx1ZVwiLFxuXHRcdHJlZmVyZW5jZTogdG9NaW5WYWx1ZSxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCkge1xuXHRcdFx0ZGF0YXNldC52YWx1ZSA9IGRhdGFzZXQudmFsdWUgPCB0aGlzLnJlcXVpcmVtZW50ID8gdGhpcy5yZXF1aXJlbWVudCA6IGRhdGFzZXQudmFsdWU7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3RvTnVtYmVyL3RvTnVtYmVyLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdG9OdW1iZXIobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwidG9fbnVtYmVyXCIsXG5cdFx0cmVmZXJlbmNlOiB0b051bWJlcixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gTnVtYmVyKGRhdGFzZXQudmFsdWUpO1xuXHRcdFx0XHRpZiAoaXNOYU4oZGF0YXNldC52YWx1ZSkpIHtcblx0XHRcdFx0XHRfYWRkSXNzdWUodGhpcywgXCJudW1iZXJcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdF9hZGRJc3N1ZSh0aGlzLCBcIm51bWJlclwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvdG9QYXNjYWxDYXNlL3RvUGFzY2FsQ2FzZS50c1xuLyoqXG4qIENyZWF0ZXMgYSB0byBwYXNjYWwgY2FzZSB0cmFuc2Zvcm1hdGlvbiBhY3Rpb24uXG4qXG4qIFdvcmRzIGFyZSBzZXBhcmF0ZWQgYnkgYF9gLCBgLWAgYW5kIEFTQ0lJIHdoaXRlc3BhY2UsIGFzIHdlbGwgYXMgYnkgY2FzZVxuKiBhbmQgYWNyb255bSBib3VuZGFyaWVzLlxuKlxuKiBIaW50OiBBY3JvbnltIHJ1bnMgYXJlIG5vcm1hbGl6ZWQgdG8gbG93ZXJjYXNlIChlLmcuIGBwYXJzZVVSTFZhbHVlYCDihpJcbiogYFBhcnNlVXJsVmFsdWVgKSBhbmQgZGlnaXRzIHN0YXkgYXR0YWNoZWQgdG8gdGhlIHByZWNlZGluZyB0b2tlbiAoZS5nLlxuKiBgaXRlbTJOYW1lYCDihpIgYEl0ZW0yTmFtZWApLlxuKlxuKiBAcmV0dXJucyBBIHRvIHBhc2NhbCBjYXNlIGFjdGlvbi5cbipcbiogQGJldGFcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdG9QYXNjYWxDYXNlKCkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcInRvX3Bhc2NhbF9jYXNlXCIsXG5cdFx0cmVmZXJlbmNlOiB0b1Bhc2NhbENhc2UsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQpIHtcblx0XHRcdGRhdGFzZXQudmFsdWUgPSAvKiBAX19QVVJFX18gKi8gX2Zvcm1hdENhc2UoZGF0YXNldC52YWx1ZSwgXCJcIiwgdHJ1ZSwgdHJ1ZSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3RvU25ha2VDYXNlL3RvU25ha2VDYXNlLnRzXG4vKipcbiogQ3JlYXRlcyBhIHRvIHNuYWtlIGNhc2UgdHJhbnNmb3JtYXRpb24gYWN0aW9uLlxuKlxuKiBXb3JkcyBhcmUgc2VwYXJhdGVkIGJ5IGBfYCwgYC1gIGFuZCBBU0NJSSB3aGl0ZXNwYWNlLCBhcyB3ZWxsIGFzIGJ5IGNhc2VcbiogYW5kIGFjcm9ueW0gYm91bmRhcmllcy5cbipcbiogSGludDogQWNyb255bSBydW5zIGFyZSBub3JtYWxpemVkIHRvIGxvd2VyY2FzZSAoZS5nLiBgcGFyc2VVUkxWYWx1ZWAg4oaSXG4qIGBwYXJzZV91cmxfdmFsdWVgKSBhbmQgZGlnaXRzIHN0YXkgYXR0YWNoZWQgdG8gdGhlIHByZWNlZGluZyB0b2tlbiAoZS5nLlxuKiBgaXRlbTJOYW1lYCDihpIgYGl0ZW0yX25hbWVgKS5cbipcbiogQHJldHVybnMgQSB0byBzbmFrZSBjYXNlIGFjdGlvbi5cbipcbiogQGJldGFcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdG9TbmFrZUNhc2UoKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwidG9fc25ha2VfY2FzZVwiLFxuXHRcdHJlZmVyZW5jZTogdG9TbmFrZUNhc2UsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQpIHtcblx0XHRcdGRhdGFzZXQudmFsdWUgPSAvKiBAX19QVVJFX18gKi8gX2Zvcm1hdENhc2UoZGF0YXNldC52YWx1ZSwgXCJfXCIsIGZhbHNlLCBmYWxzZSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3RvU3RyaW5nL3RvU3RyaW5nLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdG9TdHJpbmcobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwidG9fc3RyaW5nXCIsXG5cdFx0cmVmZXJlbmNlOiB0b1N0cmluZyxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gU3RyaW5nKGRhdGFzZXQudmFsdWUpO1xuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdF9hZGRJc3N1ZSh0aGlzLCBcInN0cmluZ1wiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvdG9VcHBlckNhc2UvdG9VcHBlckNhc2UudHNcbi8qKlxuKiBDcmVhdGVzIGEgdG8gdXBwZXIgY2FzZSB0cmFuc2Zvcm1hdGlvbiBhY3Rpb24uXG4qXG4qIEByZXR1cm5zIEEgdG8gdXBwZXIgY2FzZSBhY3Rpb24uXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHRvVXBwZXJDYXNlKCkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidHJhbnNmb3JtYXRpb25cIixcblx0XHR0eXBlOiBcInRvX3VwcGVyX2Nhc2VcIixcblx0XHRyZWZlcmVuY2U6IHRvVXBwZXJDYXNlLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRcIn5ydW5cIihkYXRhc2V0KSB7XG5cdFx0XHRkYXRhc2V0LnZhbHVlID0gZGF0YXNldC52YWx1ZS50b1VwcGVyQ2FzZSgpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy90cmFuc2Zvcm0vdHJhbnNmb3JtLnRzXG4vKipcbiogQ3JlYXRlcyBhIGN1c3RvbSB0cmFuc2Zvcm1hdGlvbiBhY3Rpb24uXG4qXG4qIEBwYXJhbSBvcGVyYXRpb24gVGhlIHRyYW5zZm9ybWF0aW9uIG9wZXJhdGlvbi5cbipcbiogQHJldHVybnMgQSB0cmFuc2Zvcm0gYWN0aW9uLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiB0cmFuc2Zvcm0ob3BlcmF0aW9uKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwidHJhbnNmb3JtXCIsXG5cdFx0cmVmZXJlbmNlOiB0cmFuc2Zvcm0sXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdG9wZXJhdGlvbixcblx0XHRcIn5ydW5cIihkYXRhc2V0KSB7XG5cdFx0XHRkYXRhc2V0LnZhbHVlID0gdGhpcy5vcGVyYXRpb24oZGF0YXNldC52YWx1ZSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3RyYW5zZm9ybS90cmFuc2Zvcm1Bc3luYy50c1xuLyoqXG4qIENyZWF0ZXMgYSBjdXN0b20gdHJhbnNmb3JtYXRpb24gYWN0aW9uLlxuKlxuKiBAcGFyYW0gb3BlcmF0aW9uIFRoZSB0cmFuc2Zvcm1hdGlvbiBvcGVyYXRpb24uXG4qXG4qIEByZXR1cm5zIEEgdHJhbnNmb3JtIGFjdGlvbi5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdHJhbnNmb3JtQXN5bmMob3BlcmF0aW9uKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwidHJhbnNmb3JtXCIsXG5cdFx0cmVmZXJlbmNlOiB0cmFuc2Zvcm1Bc3luYyxcblx0XHRhc3luYzogdHJ1ZSxcblx0XHRvcGVyYXRpb24sXG5cdFx0YXN5bmMgXCJ+cnVuXCIoZGF0YXNldCkge1xuXHRcdFx0ZGF0YXNldC52YWx1ZSA9IGF3YWl0IHRoaXMub3BlcmF0aW9uKGRhdGFzZXQudmFsdWUpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy90cmltL3RyaW0udHNcbi8qKlxuKiBDcmVhdGVzIGEgdHJpbSB0cmFuc2Zvcm1hdGlvbiBhY3Rpb24uXG4qXG4qIEByZXR1cm5zIEEgdHJpbSBhY3Rpb24uXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHRyaW0oKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwidHJpbVwiLFxuXHRcdHJlZmVyZW5jZTogdHJpbSxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCkge1xuXHRcdFx0ZGF0YXNldC52YWx1ZSA9IGRhdGFzZXQudmFsdWUudHJpbSgpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy90cmltRW5kL3RyaW1FbmQudHNcbi8qKlxuKiBDcmVhdGVzIGEgdHJpbSBlbmQgdHJhbnNmb3JtYXRpb24gYWN0aW9uLlxuKlxuKiBAcmV0dXJucyBBIHRyaW0gZW5kIGFjdGlvbi5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdHJpbUVuZCgpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInRyYW5zZm9ybWF0aW9uXCIsXG5cdFx0dHlwZTogXCJ0cmltX2VuZFwiLFxuXHRcdHJlZmVyZW5jZTogdHJpbUVuZCxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCkge1xuXHRcdFx0ZGF0YXNldC52YWx1ZSA9IGRhdGFzZXQudmFsdWUudHJpbUVuZCgpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy90cmltU3RhcnQvdHJpbVN0YXJ0LnRzXG4vKipcbiogQ3JlYXRlcyBhIHRyaW0gc3RhcnQgdHJhbnNmb3JtYXRpb24gYWN0aW9uLlxuKlxuKiBAcmV0dXJucyBBIHRyaW0gc3RhcnQgYWN0aW9uLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiB0cmltU3RhcnQoKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ0cmFuc2Zvcm1hdGlvblwiLFxuXHRcdHR5cGU6IFwidHJpbV9zdGFydFwiLFxuXHRcdHJlZmVyZW5jZTogdHJpbVN0YXJ0LFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRcIn5ydW5cIihkYXRhc2V0KSB7XG5cdFx0XHRkYXRhc2V0LnZhbHVlID0gZGF0YXNldC52YWx1ZS50cmltU3RhcnQoKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvdWxpZC91bGlkLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdWxpZChtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcInVsaWRcIixcblx0XHRyZWZlcmVuY2U6IHVsaWQsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IFVMSURfUkVHRVgsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJVTElEXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvdXJsL3VybC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHVybChtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcInVybFwiLFxuXHRcdHJlZmVyZW5jZTogdXJsLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBudWxsLFxuXHRcdHJlcXVpcmVtZW50KGlucHV0KSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRuZXcgVVJMKGlucHV0KTtcblx0XHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdFx0fVxuXHRcdH0sXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudChkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwiVVJMXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvdXVpZC91dWlkLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdXVpZChtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcInV1aWRcIixcblx0XHRyZWZlcmVuY2U6IHV1aWQsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IG51bGwsXG5cdFx0cmVxdWlyZW1lbnQ6IFVVSURfUkVHRVgsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCAmJiAhdGhpcy5yZXF1aXJlbWVudC50ZXN0KGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJVVUlEXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FjdGlvbnMvdmFsdWUvdmFsdWUudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiB2YWx1ZShyZXF1aXJlbWVudCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJ2YWxpZGF0aW9uXCIsXG5cdFx0dHlwZTogXCJ2YWx1ZVwiLFxuXHRcdHJlZmVyZW5jZTogdmFsdWUsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGV4cGVjdHM6IHJlcXVpcmVtZW50IGluc3RhbmNlb2YgRGF0ZSA/IHJlcXVpcmVtZW50LnRvSlNPTigpIDogLyogQF9fUFVSRV9fICovIF9zdHJpbmdpZnkocmVxdWlyZW1lbnQpLFxuXHRcdHJlcXVpcmVtZW50LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudHlwZWQgJiYgISh0aGlzLnJlcXVpcmVtZW50IDw9IGRhdGFzZXQudmFsdWUgJiYgdGhpcy5yZXF1aXJlbWVudCA+PSBkYXRhc2V0LnZhbHVlKSkgX2FkZElzc3VlKHRoaXMsIFwidmFsdWVcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGRhdGFzZXQudmFsdWUgaW5zdGFuY2VvZiBEYXRlID8gZGF0YXNldC52YWx1ZS50b0pTT04oKSA6IC8qIEBfX1BVUkVfXyAqLyBfc3RyaW5naWZ5KGRhdGFzZXQudmFsdWUpIH0pO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9ucy92YWx1ZXMvdmFsdWVzLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdmFsdWVzKHJlcXVpcmVtZW50LCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInZhbGlkYXRpb25cIixcblx0XHR0eXBlOiBcInZhbHVlc1wiLFxuXHRcdHJlZmVyZW5jZTogdmFsdWVzLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBgJHsvKiBAX19QVVJFX18gKi8gX2pvaW5FeHBlY3RzKHJlcXVpcmVtZW50Lm1hcCgodmFsdWUkMSkgPT4gdmFsdWUkMSBpbnN0YW5jZW9mIERhdGUgPyB2YWx1ZSQxLnRvSlNPTigpIDogLyogQF9fUFVSRV9fICovIF9zdHJpbmdpZnkodmFsdWUkMSkpLCBcInxcIil9YCxcblx0XHRyZXF1aXJlbWVudCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnR5cGVkICYmICF0aGlzLnJlcXVpcmVtZW50LnNvbWUoKHZhbHVlJDEpID0+IHZhbHVlJDEgPD0gZGF0YXNldC52YWx1ZSAmJiB2YWx1ZSQxID49IGRhdGFzZXQudmFsdWUpKSBfYWRkSXNzdWUodGhpcywgXCJ2YWx1ZVwiLCBkYXRhc2V0LCBjb25maWckMSwgeyByZWNlaXZlZDogZGF0YXNldC52YWx1ZSBpbnN0YW5jZW9mIERhdGUgPyBkYXRhc2V0LnZhbHVlLnRvSlNPTigpIDogLyogQF9fUFVSRV9fICovIF9zdHJpbmdpZnkoZGF0YXNldC52YWx1ZSkgfSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hY3Rpb25zL3dvcmRzL3dvcmRzLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gd29yZHMobG9jYWxlcywgcmVxdWlyZW1lbnQsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwidmFsaWRhdGlvblwiLFxuXHRcdHR5cGU6IFwid29yZHNcIixcblx0XHRyZWZlcmVuY2U6IHdvcmRzLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRleHBlY3RzOiBgJHtyZXF1aXJlbWVudH1gLFxuXHRcdGxvY2FsZXMsXG5cdFx0cmVxdWlyZW1lbnQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC50eXBlZCkge1xuXHRcdFx0XHRjb25zdCBjb3VudCA9IC8qIEBfX1BVUkVfXyAqLyBfZ2V0V29yZENvdW50KHRoaXMubG9jYWxlcywgZGF0YXNldC52YWx1ZSk7XG5cdFx0XHRcdGlmIChjb3VudCAhPT0gdGhpcy5yZXF1aXJlbWVudCkgX2FkZElzc3VlKHRoaXMsIFwid29yZHNcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IGAke2NvdW50fWAgfSk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb25zdC50c1xuY29uc3QgQUJPUlRfRUFSTFlfQ09ORklHID0geyBhYm9ydEVhcmx5OiB0cnVlIH07XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXRob2RzL2Fzc2VydC9hc3NlcnQudHNcbi8qKlxuKiBDaGVja3MgaWYgdGhlIGlucHV0IG1hdGNoZXMgdGhlIHNjaGVtYS4gQXMgdGhpcyBpcyBhbiBhc3NlcnRpb24gZnVuY3Rpb24sIGl0XG4qIGNhbiBiZSB1c2VkIGFzIGEgdHlwZSBndWFyZC5cbipcbiogQHBhcmFtIHNjaGVtYSBUaGUgc2NoZW1hIHRvIGJlIHVzZWQuXG4qIEBwYXJhbSBpbnB1dCBUaGUgaW5wdXQgdG8gYmUgdGVzdGVkLlxuKi9cbmZ1bmN0aW9uIGFzc2VydChzY2hlbWEsIGlucHV0KSB7XG5cdGNvbnN0IGlzc3VlcyA9IHNjaGVtYVtcIn5ydW5cIl0oeyB2YWx1ZTogaW5wdXQgfSwgQUJPUlRfRUFSTFlfQ09ORklHKS5pc3N1ZXM7XG5cdGlmIChpc3N1ZXMpIHRocm93IG5ldyBWYWxpRXJyb3IoaXNzdWVzKTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvY2FjaGUvX0xydUNhY2hlLnRzXG4vKipcbiogRWZmaWNpZW50IExSVSBjYWNoZSB1c2luZyBNYXAgaXRlcmF0aW9uIG9yZGVyLlxuKi9cbnZhciBfTHJ1Q2FjaGUgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKGNvbmZpZyQxKSB7XG5cdFx0dGhpcy5yZWZDb3VudCA9IDA7XG5cdFx0dGhpcy5tYXhTaXplID0gY29uZmlnJDE/Lm1heFNpemUgPz8gMWUzO1xuXHRcdHRoaXMubWF4QWdlID0gY29uZmlnJDE/Lm1heEFnZSA/PyBJbmZpbml0eTtcblx0XHR0aGlzLmhhc01heEFnZSA9IGlzRmluaXRlKHRoaXMubWF4QWdlKTtcblx0fVxuXHQvKipcblx0KiBTdHJpbmdpZmllcyBhbiB1bmtub3duIGlucHV0IHRvIGEgY2FjaGUga2V5IGNvbXBvbmVudC5cblx0KlxuXHQqIEBwYXJhbSBpbnB1dCBUaGUgdW5rbm93biBpbnB1dC5cblx0KlxuXHQqIEByZXR1cm5zIEEgY2FjaGUga2V5IGNvbXBvbmVudC5cblx0Ki9cblx0c3RyaW5naWZ5KGlucHV0KSB7XG5cdFx0Y29uc3QgdHlwZSA9IHR5cGVvZiBpbnB1dDtcblx0XHRpZiAodHlwZSA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIGBcIiR7aW5wdXR9XCJgO1xuXHRcdGlmICh0eXBlID09PSBcIm51bWJlclwiIHx8IHR5cGUgPT09IFwiYm9vbGVhblwiKSByZXR1cm4gYCR7aW5wdXR9YDtcblx0XHRpZiAodHlwZSA9PT0gXCJiaWdpbnRcIikgcmV0dXJuIGAke2lucHV0fW5gO1xuXHRcdGlmICh0eXBlID09PSBcIm9iamVjdFwiIHx8IHR5cGUgPT09IFwiZnVuY3Rpb25cIikge1xuXHRcdFx0aWYgKGlucHV0KSB7XG5cdFx0XHRcdHRoaXMucmVmSWRzID8/ICh0aGlzLnJlZklkcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpKTtcblx0XHRcdFx0bGV0IGlkID0gdGhpcy5yZWZJZHMuZ2V0KGlucHV0KTtcblx0XHRcdFx0aWYgKCFpZCkge1xuXHRcdFx0XHRcdGlkID0gKyt0aGlzLnJlZkNvdW50O1xuXHRcdFx0XHRcdHRoaXMucmVmSWRzLnNldChpbnB1dCwgaWQpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBgIyR7aWR9YDtcblx0XHRcdH1cblx0XHRcdHJldHVybiBcIm51bGxcIjtcblx0XHR9XG5cdFx0cmV0dXJuIHR5cGU7XG5cdH1cblx0LyoqXG5cdCogQ3JlYXRlcyBhIGNhY2hlIGtleSBmcm9tIGlucHV0IGFuZCBjb25maWcuXG5cdCpcblx0KiBAcGFyYW0gaW5wdXQgVGhlIGlucHV0IHZhbHVlLlxuXHQqIEBwYXJhbSBjb25maWcgVGhlIHBhcnNlIGNvbmZpZ3VyYXRpb24uXG5cdCpcblx0KiBAcmV0dXJucyBUaGUgY2FjaGUga2V5LlxuXHQqL1xuXHRrZXkoaW5wdXQsIGNvbmZpZyQxID0ge30pIHtcblx0XHRyZXR1cm4gYCR7dGhpcy5zdHJpbmdpZnkoaW5wdXQpfXwke3RoaXMuc3RyaW5naWZ5KGNvbmZpZyQxLmxhbmcpfXwke3RoaXMuc3RyaW5naWZ5KGNvbmZpZyQxLm1lc3NhZ2UpfXwke3RoaXMuc3RyaW5naWZ5KGNvbmZpZyQxLmFib3J0RWFybHkpfXwke3RoaXMuc3RyaW5naWZ5KGNvbmZpZyQxLmFib3J0UGlwZUVhcmx5KX1gO1xuXHR9XG5cdC8qKlxuXHQqIEdldHMgYSB2YWx1ZSBmcm9tIHRoZSBjYWNoZSBieSBrZXkuXG5cdCpcblx0KiBAcGFyYW0ga2V5IFRoZSBjYWNoZSBrZXkuXG5cdCpcblx0KiBAcmV0dXJucyBUaGUgY2FjaGVkIHZhbHVlLlxuXHQqL1xuXHRnZXQoa2V5KSB7XG5cdFx0aWYgKCF0aGlzLnN0b3JlKSByZXR1cm4gdm9pZCAwO1xuXHRcdGNvbnN0IGVudHJ5ID0gdGhpcy5zdG9yZS5nZXQoa2V5KTtcblx0XHRpZiAoIWVudHJ5KSByZXR1cm4gdm9pZCAwO1xuXHRcdGlmICh0aGlzLmhhc01heEFnZSAmJiBEYXRlLm5vdygpIC0gZW50cnlbMV0gPiB0aGlzLm1heEFnZSkge1xuXHRcdFx0dGhpcy5zdG9yZS5kZWxldGUoa2V5KTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0dGhpcy5zdG9yZS5kZWxldGUoa2V5KTtcblx0XHR0aGlzLnN0b3JlLnNldChrZXksIGVudHJ5KTtcblx0XHRyZXR1cm4gZW50cnlbMF07XG5cdH1cblx0LyoqXG5cdCogU2V0cyBhIHZhbHVlIGluIHRoZSBjYWNoZSBieSBrZXkuXG5cdCpcblx0KiBAcGFyYW0ga2V5IFRoZSBjYWNoZSBrZXkuXG5cdCogQHBhcmFtIHZhbHVlIFRoZSBjYWNoZWQgdmFsdWUuXG5cdCovXG5cdHNldChrZXksIHZhbHVlJDEpIHtcblx0XHR0aGlzLnN0b3JlID8/ICh0aGlzLnN0b3JlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSk7XG5cdFx0dGhpcy5zdG9yZS5kZWxldGUoa2V5KTtcblx0XHRjb25zdCB0aW1lc3RhbXAgPSB0aGlzLmhhc01heEFnZSA/IERhdGUubm93KCkgOiAwO1xuXHRcdHRoaXMuc3RvcmUuc2V0KGtleSwgW3ZhbHVlJDEsIHRpbWVzdGFtcF0pO1xuXHRcdGlmICh0aGlzLnN0b3JlLnNpemUgPiB0aGlzLm1heFNpemUpIHRoaXMuc3RvcmUuZGVsZXRlKHRoaXMuc3RvcmUua2V5cygpLm5leHQoKS52YWx1ZSk7XG5cdH1cblx0LyoqXG5cdCogQ2xlYXJzIGFsbCBlbnRyaWVzIGZyb20gdGhlIGNhY2hlLlxuXHQqL1xuXHRjbGVhcigpIHtcblx0XHR0aGlzLnN0b3JlPy5jbGVhcigpO1xuXHR9XG59O1xuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9jYWNoZS9jYWNoZS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGNhY2hlKHNjaGVtYSwgY29uZmlnJDEpIHtcblx0cmV0dXJuIHtcblx0XHQuLi5zY2hlbWEsXG5cdFx0Y2FjaGVDb25maWc6IGNvbmZpZyQxLFxuXHRcdGNhY2hlOiBuZXcgX0xydUNhY2hlKGNvbmZpZyQxKSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBydW5Db25maWcpIHtcblx0XHRcdGNvbnN0IGtleSA9IHRoaXMuY2FjaGUua2V5KGRhdGFzZXQudmFsdWUsIHJ1bkNvbmZpZyk7XG5cdFx0XHRsZXQgb3V0cHV0RGF0YXNldCA9IHRoaXMuY2FjaGUuZ2V0KGtleSk7XG5cdFx0XHRpZiAoIW91dHB1dERhdGFzZXQpIHRoaXMuY2FjaGUuc2V0KGtleSwgb3V0cHV0RGF0YXNldCA9IHNjaGVtYVtcIn5ydW5cIl0oZGF0YXNldCwgcnVuQ29uZmlnKSk7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9jbG9uZURhdGFzZXQob3V0cHV0RGF0YXNldCk7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9jYWNoZS9jYWNoZUFzeW5jLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gY2FjaGVBc3luYyhzY2hlbWEsIGNvbmZpZyQxKSB7XG5cdGxldCBhY3RpdmVSdW5zO1xuXHRyZXR1cm4ge1xuXHRcdC4uLnNjaGVtYSxcblx0XHRhc3luYzogdHJ1ZSxcblx0XHRjYWNoZUNvbmZpZzogY29uZmlnJDEsXG5cdFx0Y2FjaGU6IG5ldyBfTHJ1Q2FjaGUoY29uZmlnJDEpLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdGFzeW5jIFwifnJ1blwiKGRhdGFzZXQsIHJ1bkNvbmZpZykge1xuXHRcdFx0Y29uc3Qga2V5ID0gdGhpcy5jYWNoZS5rZXkoZGF0YXNldC52YWx1ZSwgcnVuQ29uZmlnKTtcblx0XHRcdGNvbnN0IGNhY2hlZCA9IHRoaXMuY2FjaGUuZ2V0KGtleSk7XG5cdFx0XHRpZiAoY2FjaGVkKSByZXR1cm4gLyogQF9fUFVSRV9fICovIF9jbG9uZURhdGFzZXQoY2FjaGVkKTtcblx0XHRcdGxldCBwcm9taXNlJDEgPSBhY3RpdmVSdW5zPy5nZXQoa2V5KTtcblx0XHRcdGlmICghcHJvbWlzZSQxKSB7XG5cdFx0XHRcdGFjdGl2ZVJ1bnMgPz8gKGFjdGl2ZVJ1bnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKTtcblx0XHRcdFx0cHJvbWlzZSQxID0gUHJvbWlzZS5yZXNvbHZlKHNjaGVtYVtcIn5ydW5cIl0oZGF0YXNldCwgcnVuQ29uZmlnKSk7XG5cdFx0XHRcdGFjdGl2ZVJ1bnMuc2V0KGtleSwgcHJvbWlzZSQxKTtcblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IG91dHB1dERhdGFzZXQgPSBhd2FpdCBwcm9taXNlJDE7XG5cdFx0XHRcdHRoaXMuY2FjaGUuc2V0KGtleSwgb3V0cHV0RGF0YXNldCk7XG5cdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2Nsb25lRGF0YXNldChvdXRwdXREYXRhc2V0KTtcblx0XHRcdH0gZmluYWxseSB7XG5cdFx0XHRcdGFjdGl2ZVJ1bnM/LmRlbGV0ZShrZXkpO1xuXHRcdFx0fVxuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvY29uZmlnL2NvbmZpZy50c1xuLyoqXG4qIENoYW5nZXMgdGhlIGxvY2FsIGNvbmZpZ3VyYXRpb24gb2YgYSBzY2hlbWEuXG4qXG4qIEBwYXJhbSBzY2hlbWEgVGhlIHNjaGVtYSB0byBjb25maWd1cmUuXG4qIEBwYXJhbSBjb25maWcgVGhlIHBhcnNlIGNvbmZpZ3VyYXRpb24uXG4qXG4qIEByZXR1cm5zIFRoZSBjb25maWd1cmVkIHNjaGVtYS5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gY29uZmlnKHNjaGVtYSwgY29uZmlnJDEpIHtcblx0cmV0dXJuIHtcblx0XHQuLi5zY2hlbWEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnXykge1xuXHRcdFx0cmV0dXJuIHNjaGVtYVtcIn5ydW5cIl0oZGF0YXNldCwge1xuXHRcdFx0XHQuLi5jb25maWdfLFxuXHRcdFx0XHQuLi5jb25maWckMVxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9nZXRGYWxsYmFjay9nZXRGYWxsYmFjay50c1xuLyoqXG4qIFJldHVybnMgdGhlIGZhbGxiYWNrIHZhbHVlIG9mIHRoZSBzY2hlbWEuXG4qXG4qIEBwYXJhbSBzY2hlbWEgVGhlIHNjaGVtYSB0byBnZXQgaXQgZnJvbS5cbiogQHBhcmFtIGRhdGFzZXQgVGhlIG91dHB1dCBkYXRhc2V0IGlmIGF2YWlsYWJsZS5cbiogQHBhcmFtIGNvbmZpZyBUaGUgY29uZmlnIGlmIGF2YWlsYWJsZS5cbipcbiogQHJldHVybnMgVGhlIGZhbGxiYWNrIHZhbHVlLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBnZXRGYWxsYmFjayhzY2hlbWEsIGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdHJldHVybiB0eXBlb2Ygc2NoZW1hLmZhbGxiYWNrID09PSBcImZ1bmN0aW9uXCIgPyBzY2hlbWEuZmFsbGJhY2soZGF0YXNldCwgY29uZmlnJDEpIDogc2NoZW1hLmZhbGxiYWNrO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9mYWxsYmFjay9mYWxsYmFjay50c1xuLyoqXG4qIFJldHVybnMgYSBmYWxsYmFjayB2YWx1ZSBhcyBvdXRwdXQgaWYgdGhlIGlucHV0IGRvZXMgbm90IG1hdGNoIHRoZSBzY2hlbWEuXG4qXG4qIEBwYXJhbSBzY2hlbWEgVGhlIHNjaGVtYSB0byBjYXRjaC5cbiogQHBhcmFtIGZhbGxiYWNrIFRoZSBmYWxsYmFjayB2YWx1ZS5cbipcbiogQHJldHVybnMgVGhlIHBhc3NlZCBzY2hlbWEuXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGZhbGxiYWNrKHNjaGVtYSwgZmFsbGJhY2skMSkge1xuXHRyZXR1cm4ge1xuXHRcdC4uLnNjaGVtYSxcblx0XHRmYWxsYmFjazogZmFsbGJhY2skMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3Qgb3V0cHV0RGF0YXNldCA9IHNjaGVtYVtcIn5ydW5cIl0oZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIG91dHB1dERhdGFzZXQuaXNzdWVzID8ge1xuXHRcdFx0XHR0eXBlZDogdHJ1ZSxcblx0XHRcdFx0dmFsdWU6IC8qIEBfX1BVUkVfXyAqLyBnZXRGYWxsYmFjayh0aGlzLCBvdXRwdXREYXRhc2V0LCBjb25maWckMSlcblx0XHRcdH0gOiBvdXRwdXREYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvZmFsbGJhY2svZmFsbGJhY2tBc3luYy50c1xuLyoqXG4qIFJldHVybnMgYSBmYWxsYmFjayB2YWx1ZSBhcyBvdXRwdXQgaWYgdGhlIGlucHV0IGRvZXMgbm90IG1hdGNoIHRoZSBzY2hlbWEuXG4qXG4qIEBwYXJhbSBzY2hlbWEgVGhlIHNjaGVtYSB0byBjYXRjaC5cbiogQHBhcmFtIGZhbGxiYWNrIFRoZSBmYWxsYmFjayB2YWx1ZS5cbipcbiogQHJldHVybnMgVGhlIHBhc3NlZCBzY2hlbWEuXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGZhbGxiYWNrQXN5bmMoc2NoZW1hLCBmYWxsYmFjayQxKSB7XG5cdHJldHVybiB7XG5cdFx0Li4uc2NoZW1hLFxuXHRcdGZhbGxiYWNrOiBmYWxsYmFjayQxLFxuXHRcdGFzeW5jOiB0cnVlLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdGFzeW5jIFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRjb25zdCBvdXRwdXREYXRhc2V0ID0gYXdhaXQgc2NoZW1hW1wifnJ1blwiXShkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gb3V0cHV0RGF0YXNldC5pc3N1ZXMgPyB7XG5cdFx0XHRcdHR5cGVkOiB0cnVlLFxuXHRcdFx0XHR2YWx1ZTogYXdhaXQgLyogQF9fUFVSRV9fICovIGdldEZhbGxiYWNrKHRoaXMsIG91dHB1dERhdGFzZXQsIGNvbmZpZyQxKVxuXHRcdFx0fSA6IG91dHB1dERhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9mbGF0dGVuL2ZsYXR0ZW4udHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBmbGF0dGVuKGlzc3Vlcykge1xuXHRjb25zdCBmbGF0RXJyb3JzID0ge307XG5cdGZvciAoY29uc3QgaXNzdWUgb2YgaXNzdWVzKSBpZiAoaXNzdWUucGF0aCkge1xuXHRcdGNvbnN0IGRvdFBhdGggPSAvKiBAX19QVVJFX18gKi8gZ2V0RG90UGF0aChpc3N1ZSk7XG5cdFx0aWYgKGRvdFBhdGgpIHtcblx0XHRcdGlmICghZmxhdEVycm9ycy5uZXN0ZWQpIGZsYXRFcnJvcnMubmVzdGVkID0ge307XG5cdFx0XHRpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGZsYXRFcnJvcnMubmVzdGVkLCBkb3RQYXRoKSkgZmxhdEVycm9ycy5uZXN0ZWRbZG90UGF0aF0ucHVzaChpc3N1ZS5tZXNzYWdlKTtcblx0XHRcdGVsc2UgZmxhdEVycm9ycy5uZXN0ZWRbZG90UGF0aF0gPSBbaXNzdWUubWVzc2FnZV07XG5cdFx0fSBlbHNlIGlmIChmbGF0RXJyb3JzLm90aGVyKSBmbGF0RXJyb3JzLm90aGVyLnB1c2goaXNzdWUubWVzc2FnZSk7XG5cdFx0ZWxzZSBmbGF0RXJyb3JzLm90aGVyID0gW2lzc3VlLm1lc3NhZ2VdO1xuXHR9IGVsc2UgaWYgKGZsYXRFcnJvcnMucm9vdCkgZmxhdEVycm9ycy5yb290LnB1c2goaXNzdWUubWVzc2FnZSk7XG5cdGVsc2UgZmxhdEVycm9ycy5yb290ID0gW2lzc3VlLm1lc3NhZ2VdO1xuXHRyZXR1cm4gZmxhdEVycm9ycztcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvZm9yd2FyZC9mb3J3YXJkLnRzXG4vKipcbiogRm9yd2FyZHMgdGhlIGlzc3VlcyBvZiB0aGUgcGFzc2VkIHZhbGlkYXRpb24gYWN0aW9uLlxuKlxuKiBAcGFyYW0gYWN0aW9uIFRoZSB2YWxpZGF0aW9uIGFjdGlvbi5cbiogQHBhcmFtIHBhdGggVGhlIHBhdGggdG8gZm9yd2FyZCB0aGUgaXNzdWVzIHRvLlxuKlxuKiBAcmV0dXJucyBUaGUgbW9kaWZpZWQgYWN0aW9uLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBmb3J3YXJkKGFjdGlvbiwgcGF0aCkge1xuXHRyZXR1cm4ge1xuXHRcdC4uLmFjdGlvbixcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgcHJldklzc3VlcyA9IGRhdGFzZXQuaXNzdWVzICYmIFsuLi5kYXRhc2V0Lmlzc3Vlc107XG5cdFx0XHRkYXRhc2V0ID0gYWN0aW9uW1wifnJ1blwiXShkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRpZiAoZGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0Zm9yIChjb25zdCBpc3N1ZSBvZiBkYXRhc2V0Lmlzc3VlcykgaWYgKCFwcmV2SXNzdWVzPy5pbmNsdWRlcyhpc3N1ZSkpIHtcblx0XHRcdFx0XHRsZXQgcGF0aElucHV0ID0gZGF0YXNldC52YWx1ZTtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGtleSBvZiBwYXRoKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoVmFsdWUgPSBwYXRoSW5wdXRba2V5XTtcblx0XHRcdFx0XHRcdGNvbnN0IHBhdGhJdGVtID0ge1xuXHRcdFx0XHRcdFx0XHR0eXBlOiBcInVua25vd25cIixcblx0XHRcdFx0XHRcdFx0b3JpZ2luOiBcInZhbHVlXCIsXG5cdFx0XHRcdFx0XHRcdGlucHV0OiBwYXRoSW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IHBhdGhWYWx1ZVxuXHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRcdGlmIChpc3N1ZS5wYXRoKSBpc3N1ZS5wYXRoLnB1c2gocGF0aEl0ZW0pO1xuXHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdGlmICghcGF0aFZhbHVlKSBicmVhaztcblx0XHRcdFx0XHRcdHBhdGhJbnB1dCA9IHBhdGhWYWx1ZTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvZm9yd2FyZC9mb3J3YXJkQXN5bmMudHNcbi8qKlxuKiBGb3J3YXJkcyB0aGUgaXNzdWVzIG9mIHRoZSBwYXNzZWQgdmFsaWRhdGlvbiBhY3Rpb24uXG4qXG4qIEBwYXJhbSBhY3Rpb24gVGhlIHZhbGlkYXRpb24gYWN0aW9uLlxuKiBAcGFyYW0gcGF0aCBUaGUgcGF0aCB0byBmb3J3YXJkIHRoZSBpc3N1ZXMgdG8uXG4qXG4qIEByZXR1cm5zIFRoZSBtb2RpZmllZCBhY3Rpb24uXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGZvcndhcmRBc3luYyhhY3Rpb24sIHBhdGgpIHtcblx0cmV0dXJuIHtcblx0XHQuLi5hY3Rpb24sXG5cdFx0YXN5bmM6IHRydWUsXG5cdFx0YXN5bmMgXCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGNvbnN0IHByZXZJc3N1ZXMgPSBkYXRhc2V0Lmlzc3VlcyAmJiBbLi4uZGF0YXNldC5pc3N1ZXNdO1xuXHRcdFx0ZGF0YXNldCA9IGF3YWl0IGFjdGlvbltcIn5ydW5cIl0oZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0aWYgKGRhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdGZvciAoY29uc3QgaXNzdWUgb2YgZGF0YXNldC5pc3N1ZXMpIGlmICghcHJldklzc3Vlcz8uaW5jbHVkZXMoaXNzdWUpKSB7XG5cdFx0XHRcdFx0bGV0IHBhdGhJbnB1dCA9IGRhdGFzZXQudmFsdWU7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBrZXkgb2YgcGF0aCkge1xuXHRcdFx0XHRcdFx0Y29uc3QgcGF0aFZhbHVlID0gcGF0aElucHV0W2tleV07XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJ1bmtub3duXCIsXG5cdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0XHRpbnB1dDogcGF0aElucHV0LFxuXHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBwYXRoVmFsdWVcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC5wdXNoKHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdGVsc2UgaXNzdWUucGF0aCA9IFtwYXRoSXRlbV07XG5cdFx0XHRcdFx0XHRpZiAoIXBhdGhWYWx1ZSkgYnJlYWs7XG5cdFx0XHRcdFx0XHRwYXRoSW5wdXQgPSBwYXRoVmFsdWU7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXRob2RzL2dldERlZmF1bHQvZ2V0RGVmYXVsdC50c1xuLyoqXG4qIFJldHVybnMgdGhlIGRlZmF1bHQgdmFsdWUgb2YgdGhlIHNjaGVtYS5cbipcbiogQHBhcmFtIHNjaGVtYSBUaGUgc2NoZW1hIHRvIGdldCBpdCBmcm9tLlxuKiBAcGFyYW0gZGF0YXNldCBUaGUgaW5wdXQgZGF0YXNldCBpZiBhdmFpbGFibGUuXG4qIEBwYXJhbSBjb25maWcgVGhlIGNvbmZpZyBpZiBhdmFpbGFibGUuXG4qXG4qIEByZXR1cm5zIFRoZSBkZWZhdWx0IHZhbHVlLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBnZXREZWZhdWx0KHNjaGVtYSwgZGF0YXNldCwgY29uZmlnJDEpIHtcblx0cmV0dXJuIHR5cGVvZiBzY2hlbWEuZGVmYXVsdCA9PT0gXCJmdW5jdGlvblwiID8gc2NoZW1hLmRlZmF1bHQoZGF0YXNldCwgY29uZmlnJDEpIDogc2NoZW1hLmRlZmF1bHQ7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXRob2RzL2dldERlZmF1bHRzL2dldERlZmF1bHRzLnRzXG4vKipcbiogUmV0dXJucyB0aGUgZGVmYXVsdCB2YWx1ZXMgb2YgdGhlIHNjaGVtYS5cbipcbiogSGludDogVGhlIGRpZmZlcmVuY2UgdG8gYGdldERlZmF1bHRgIGlzIHRoYXQgZm9yIG9iamVjdCBhbmQgdHVwbGUgc2NoZW1hc1xuKiB0aGlzIGZ1bmN0aW9uIHJlY3Vyc2l2ZWx5IHJldHVybnMgdGhlIGRlZmF1bHQgdmFsdWVzIG9mIHRoZSBzdWJzY2hlbWFzXG4qIGluc3RlYWQgb2YgYHVuZGVmaW5lZGAuXG4qXG4qIEBwYXJhbSBzY2hlbWEgVGhlIHNjaGVtYSB0byBnZXQgdGhlbSBmcm9tLlxuKlxuKiBAcmV0dXJucyBUaGUgZGVmYXVsdCB2YWx1ZXMuXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGdldERlZmF1bHRzKHNjaGVtYSkge1xuXHRpZiAoXCJlbnRyaWVzXCIgaW4gc2NoZW1hKSB7XG5cdFx0Y29uc3Qgb2JqZWN0JDEgPSB7fTtcblx0XHRmb3IgKGNvbnN0IGtleSBpbiBzY2hlbWEuZW50cmllcykgb2JqZWN0JDFba2V5XSA9IC8qIEBfX1BVUkVfXyAqLyBnZXREZWZhdWx0cyhzY2hlbWEuZW50cmllc1trZXldKTtcblx0XHRyZXR1cm4gb2JqZWN0JDE7XG5cdH1cblx0aWYgKFwiaXRlbXNcIiBpbiBzY2hlbWEpIHJldHVybiBzY2hlbWEuaXRlbXMubWFwKGdldERlZmF1bHRzKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBnZXREZWZhdWx0KHNjaGVtYSk7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXRob2RzL2dldERlZmF1bHRzL2dldERlZmF1bHRzQXN5bmMudHNcbi8qKlxuKiBSZXR1cm5zIHRoZSBkZWZhdWx0IHZhbHVlcyBvZiB0aGUgc2NoZW1hLlxuKlxuKiBIaW50OiBUaGUgZGlmZmVyZW5jZSB0byBgZ2V0RGVmYXVsdGAgaXMgdGhhdCBmb3Igb2JqZWN0IGFuZCB0dXBsZSBzY2hlbWFzXG4qIHRoaXMgZnVuY3Rpb24gcmVjdXJzaXZlbHkgcmV0dXJucyB0aGUgZGVmYXVsdCB2YWx1ZXMgb2YgdGhlIHN1YnNjaGVtYXNcbiogaW5zdGVhZCBvZiBgdW5kZWZpbmVkYC5cbipcbiogQHBhcmFtIHNjaGVtYSBUaGUgc2NoZW1hIHRvIGdldCB0aGVtIGZyb20uXG4qXG4qIEByZXR1cm5zIFRoZSBkZWZhdWx0IHZhbHVlcy5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuYXN5bmMgZnVuY3Rpb24gZ2V0RGVmYXVsdHNBc3luYyhzY2hlbWEpIHtcblx0aWYgKFwiZW50cmllc1wiIGluIHNjaGVtYSkgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhhd2FpdCBQcm9taXNlLmFsbChPYmplY3QuZW50cmllcyhzY2hlbWEuZW50cmllcykubWFwKGFzeW5jIChba2V5LCB2YWx1ZSQxXSkgPT4gW2tleSwgYXdhaXQgLyogQF9fUFVSRV9fICovIGdldERlZmF1bHRzQXN5bmModmFsdWUkMSldKSkpO1xuXHRpZiAoXCJpdGVtc1wiIGluIHNjaGVtYSkgcmV0dXJuIFByb21pc2UuYWxsKHNjaGVtYS5pdGVtcy5tYXAoZ2V0RGVmYXVsdHNBc3luYykpO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGdldERlZmF1bHQoc2NoZW1hKTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvZ2V0RGVzY3JpcHRpb24vZ2V0RGVzY3JpcHRpb24udHNcbi8qKlxuKiBSZXR1cm5zIHRoZSBkZXNjcmlwdGlvbiBvZiB0aGUgc2NoZW1hLlxuKlxuKiBJZiBtdWx0aXBsZSBkZXNjcmlwdGlvbnMgYXJlIGRlZmluZWQsIHRoZSBsYXN0IG9uZSBvZiB0aGUgaGlnaGVzdCBsZXZlbCBpc1xuKiByZXR1cm5lZC4gSWYgbm8gZGVzY3JpcHRpb24gaXMgZGVmaW5lZCwgYHVuZGVmaW5lZGAgaXMgcmV0dXJuZWQuXG4qXG4qIEBwYXJhbSBzY2hlbWEgVGhlIHNjaGVtYSB0byBnZXQgdGhlIGRlc2NyaXB0aW9uIGZyb20uXG4qXG4qIEByZXR1cm5zIFRoZSBkZXNjcmlwdGlvbiwgaWYgYW55LlxuKlxuKiBAYmV0YVxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBnZXREZXNjcmlwdGlvbihzY2hlbWEpIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0TGFzdE1ldGFkYXRhKHNjaGVtYSwgXCJkZXNjcmlwdGlvblwiKTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvZ2V0RXhhbXBsZXMvZ2V0RXhhbXBsZXMudHNcbi8qKlxuKiBSZXR1cm5zIHRoZSBleGFtcGxlcyBvZiBhIHNjaGVtYS5cbipcbiogSWYgbXVsdGlwbGUgZXhhbXBsZXMgYXJlIGRlZmluZWQsIGl0IGNvbmNhdGVuYXRlcyB0aGVtIHVzaW5nIGRlcHRoLWZpcnN0XG4qIHNlYXJjaC4gSWYgbm8gZXhhbXBsZXMgYXJlIGRlZmluZWQsIGFuIGVtcHR5IGFycmF5IGlzIHJldHVybmVkLlxuKlxuKiBAcGFyYW0gc2NoZW1hIFRoZSBzY2hlbWEgdG8gZ2V0IHRoZSBleGFtcGxlcyBmcm9tLlxuKlxuKiBAcmV0dXJucyBUaGUgZXhhbXBsZXMsIGlmIGFueS5cbipcbiogQGJldGFcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gZ2V0RXhhbXBsZXMoc2NoZW1hKSB7XG5cdGNvbnN0IGV4YW1wbGVzJDEgPSBbXTtcblx0ZnVuY3Rpb24gZGVwdGhGaXJzdENvbGxlY3Qoc2NoZW1hJDEpIHtcblx0XHRpZiAoXCJwaXBlXCIgaW4gc2NoZW1hJDEpIHtcblx0XHRcdGZvciAoY29uc3QgaXRlbSBvZiBzY2hlbWEkMS5waXBlKSBpZiAoaXRlbS5raW5kID09PSBcInNjaGVtYVwiICYmIFwicGlwZVwiIGluIGl0ZW0pIGRlcHRoRmlyc3RDb2xsZWN0KGl0ZW0pO1xuXHRcdFx0ZWxzZSBpZiAoaXRlbS5raW5kID09PSBcIm1ldGFkYXRhXCIgJiYgaXRlbS50eXBlID09PSBcImV4YW1wbGVzXCIpIGZvciAoY29uc3QgZXhhbXBsZSBvZiBpdGVtLmV4YW1wbGVzKSBleGFtcGxlcyQxLnB1c2goZXhhbXBsZSk7XG5cdFx0fVxuXHR9XG5cdGRlcHRoRmlyc3RDb2xsZWN0KHNjaGVtYSk7XG5cdHJldHVybiBleGFtcGxlcyQxO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9nZXRGYWxsYmFja3MvZ2V0RmFsbGJhY2tzLnRzXG4vKipcbiogUmV0dXJucyB0aGUgZmFsbGJhY2sgdmFsdWVzIG9mIHRoZSBzY2hlbWEuXG4qXG4qIEhpbnQ6IFRoZSBkaWZmZXJlbmNlIHRvIGBnZXRGYWxsYmFja2AgaXMgdGhhdCBmb3Igb2JqZWN0IGFuZCB0dXBsZSBzY2hlbWFzXG4qIHRoaXMgZnVuY3Rpb24gcmVjdXJzaXZlbHkgcmV0dXJucyB0aGUgZmFsbGJhY2sgdmFsdWVzIG9mIHRoZSBzdWJzY2hlbWFzXG4qIGluc3RlYWQgb2YgYHVuZGVmaW5lZGAuXG4qXG4qIEBwYXJhbSBzY2hlbWEgVGhlIHNjaGVtYSB0byBnZXQgdGhlbSBmcm9tLlxuKlxuKiBAcmV0dXJucyBUaGUgZmFsbGJhY2sgdmFsdWVzLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBnZXRGYWxsYmFja3Moc2NoZW1hKSB7XG5cdGlmIChcImVudHJpZXNcIiBpbiBzY2hlbWEpIHtcblx0XHRjb25zdCBvYmplY3QkMSA9IHt9O1xuXHRcdGZvciAoY29uc3Qga2V5IGluIHNjaGVtYS5lbnRyaWVzKSBvYmplY3QkMVtrZXldID0gLyogQF9fUFVSRV9fICovIGdldEZhbGxiYWNrcyhzY2hlbWEuZW50cmllc1trZXldKTtcblx0XHRyZXR1cm4gb2JqZWN0JDE7XG5cdH1cblx0aWYgKFwiaXRlbXNcIiBpbiBzY2hlbWEpIHJldHVybiBzY2hlbWEuaXRlbXMubWFwKGdldEZhbGxiYWNrcyk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gZ2V0RmFsbGJhY2soc2NoZW1hKTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvZ2V0RmFsbGJhY2tzL2dldEZhbGxiYWNrc0FzeW5jLnRzXG4vKipcbiogUmV0dXJucyB0aGUgZmFsbGJhY2sgdmFsdWVzIG9mIHRoZSBzY2hlbWEuXG4qXG4qIEhpbnQ6IFRoZSBkaWZmZXJlbmNlIHRvIGBnZXRGYWxsYmFja2AgaXMgdGhhdCBmb3Igb2JqZWN0IGFuZCB0dXBsZSBzY2hlbWFzXG4qIHRoaXMgZnVuY3Rpb24gcmVjdXJzaXZlbHkgcmV0dXJucyB0aGUgZmFsbGJhY2sgdmFsdWVzIG9mIHRoZSBzdWJzY2hlbWFzXG4qIGluc3RlYWQgb2YgYHVuZGVmaW5lZGAuXG4qXG4qIEBwYXJhbSBzY2hlbWEgVGhlIHNjaGVtYSB0byBnZXQgdGhlbSBmcm9tLlxuKlxuKiBAcmV0dXJucyBUaGUgZmFsbGJhY2sgdmFsdWVzLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5hc3luYyBmdW5jdGlvbiBnZXRGYWxsYmFja3NBc3luYyhzY2hlbWEpIHtcblx0aWYgKFwiZW50cmllc1wiIGluIHNjaGVtYSkgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhhd2FpdCBQcm9taXNlLmFsbChPYmplY3QuZW50cmllcyhzY2hlbWEuZW50cmllcykubWFwKGFzeW5jIChba2V5LCB2YWx1ZSQxXSkgPT4gW2tleSwgYXdhaXQgLyogQF9fUFVSRV9fICovIGdldEZhbGxiYWNrc0FzeW5jKHZhbHVlJDEpXSkpKTtcblx0aWYgKFwiaXRlbXNcIiBpbiBzY2hlbWEpIHJldHVybiBQcm9taXNlLmFsbChzY2hlbWEuaXRlbXMubWFwKGdldEZhbGxiYWNrc0FzeW5jKSk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gZ2V0RmFsbGJhY2soc2NoZW1hKTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvZ2V0TWV0YWRhdGEvZ2V0TWV0YWRhdGEudHNcbi8qKlxuKiBSZXR1cm5zIHRoZSBtZXRhZGF0YSBvZiBhIHNjaGVtYS5cbipcbiogSWYgbXVsdGlwbGUgbWV0YWRhdGEgYXJlIGRlZmluZWQsIGl0IHNoYWxsb3dseSBtZXJnZXMgdGhlbSB1c2luZyBkZXB0aC1maXJzdFxuKiBzZWFyY2guIElmIG5vIG1ldGFkYXRhIGlzIGRlZmluZWQsIGFuIGVtcHR5IG9iamVjdCBpcyByZXR1cm5lZC5cbipcbiogQHBhcmFtIHNjaGVtYSBTY2hlbWEgdG8gZ2V0IHRoZSBtZXRhZGF0YSBmcm9tLlxuKlxuKiBAcmV0dXJucyBUaGUgbWV0YWRhdGEsIGlmIGFueS5cbipcbiogQGJldGFcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gZ2V0TWV0YWRhdGEoc2NoZW1hKSB7XG5cdGNvbnN0IHJlc3VsdCA9IHt9O1xuXHRmdW5jdGlvbiBkZXB0aEZpcnN0TWVyZ2Uoc2NoZW1hJDEpIHtcblx0XHRpZiAoXCJwaXBlXCIgaW4gc2NoZW1hJDEpIHtcblx0XHRcdGZvciAoY29uc3QgaXRlbSBvZiBzY2hlbWEkMS5waXBlKSBpZiAoaXRlbS5raW5kID09PSBcInNjaGVtYVwiICYmIFwicGlwZVwiIGluIGl0ZW0pIGRlcHRoRmlyc3RNZXJnZShpdGVtKTtcblx0XHRcdGVsc2UgaWYgKGl0ZW0ua2luZCA9PT0gXCJtZXRhZGF0YVwiICYmIGl0ZW0udHlwZSA9PT0gXCJtZXRhZGF0YVwiKSBPYmplY3QuYXNzaWduKHJlc3VsdCwgaXRlbS5tZXRhZGF0YSk7XG5cdFx0fVxuXHR9XG5cdGRlcHRoRmlyc3RNZXJnZShzY2hlbWEpO1xuXHRyZXR1cm4gcmVzdWx0O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9nZXRUaXRsZS9nZXRUaXRsZS50c1xuLyoqXG4qIFJldHVybnMgdGhlIHRpdGxlIG9mIHRoZSBzY2hlbWEuXG4qXG4qIElmIG11bHRpcGxlIHRpdGxlcyBhcmUgZGVmaW5lZCwgdGhlIGxhc3Qgb25lIG9mIHRoZSBoaWdoZXN0IGxldmVsIGlzXG4qIHJldHVybmVkLiBJZiBubyB0aXRsZSBpcyBkZWZpbmVkLCBgdW5kZWZpbmVkYCBpcyByZXR1cm5lZC5cbipcbiogQHBhcmFtIHNjaGVtYSBUaGUgc2NoZW1hIHRvIGdldCB0aGUgdGl0bGUgZnJvbS5cbipcbiogQHJldHVybnMgVGhlIHRpdGxlLCBpZiBhbnkuXG4qXG4qIEBiZXRhXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGdldFRpdGxlKHNjaGVtYSkge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRMYXN0TWV0YWRhdGEoc2NoZW1hLCBcInRpdGxlXCIpO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9pcy9pcy50c1xuLyoqXG4qIENoZWNrcyBpZiB0aGUgaW5wdXQgbWF0Y2hlcyB0aGUgc2NoZW1hLiBCeSB1c2luZyBhIHR5cGUgcHJlZGljYXRlLCB0aGlzXG4qIGZ1bmN0aW9uIGNhbiBiZSB1c2VkIGFzIGEgdHlwZSBndWFyZC5cbipcbiogQHBhcmFtIHNjaGVtYSBUaGUgc2NoZW1hIHRvIGJlIHVzZWQuXG4qIEBwYXJhbSBpbnB1dCBUaGUgaW5wdXQgdG8gYmUgdGVzdGVkLlxuKlxuKiBAcmV0dXJucyBXaGV0aGVyIHRoZSBpbnB1dCBtYXRjaGVzIHRoZSBzY2hlbWEuXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGlzKHNjaGVtYSwgaW5wdXQpIHtcblx0cmV0dXJuICFzY2hlbWFbXCJ+cnVuXCJdKHsgdmFsdWU6IGlucHV0IH0sIEFCT1JUX0VBUkxZX0NPTkZJRykuaXNzdWVzO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9hbnkvYW55LnRzXG4vKipcbiogQ3JlYXRlcyBhbiBhbnkgc2NoZW1hLlxuKlxuKiBIaW50OiBUaGlzIHNjaGVtYSBmdW5jdGlvbiBleGlzdHMgb25seSBmb3IgY29tcGxldGVuZXNzIGFuZCBpcyBub3RcbiogcmVjb21tZW5kZWQgaW4gcHJhY3RpY2UuIEluc3RlYWQsIGB1bmtub3duYCBzaG91bGQgYmUgdXNlZCB0byBhY2NlcHRcbiogdW5rbm93biBkYXRhLlxuKlxuKiBAcmV0dXJucyBBbiBhbnkgc2NoZW1hLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBhbnkoKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcImFueVwiLFxuXHRcdHJlZmVyZW5jZTogYW55LFxuXHRcdGV4cGVjdHM6IFwiYW55XCIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdFwifnJ1blwiKGRhdGFzZXQpIHtcblx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9hcnJheS9hcnJheS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGFycmF5KGl0ZW0sIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJhcnJheVwiLFxuXHRcdHJlZmVyZW5jZTogYXJyYXksXG5cdFx0ZXhwZWN0czogXCJBcnJheVwiLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRpdGVtLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkoaW5wdXQpKSB7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gW107XG5cdFx0XHRcdGZvciAobGV0IGtleSA9IDA7IGtleSA8IGlucHV0Lmxlbmd0aDsga2V5KyspIHtcblx0XHRcdFx0XHRjb25zdCB2YWx1ZSQxID0gaW5wdXRba2V5XTtcblx0XHRcdFx0XHRjb25zdCBpdGVtRGF0YXNldCA9IHRoaXMuaXRlbVtcIn5ydW5cIl0oeyB2YWx1ZTogdmFsdWUkMSB9LCBjb25maWckMSk7XG5cdFx0XHRcdFx0aWYgKGl0ZW1EYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0Y29uc3QgcGF0aEl0ZW0gPSB7XG5cdFx0XHRcdFx0XHRcdHR5cGU6IFwiYXJyYXlcIixcblx0XHRcdFx0XHRcdFx0b3JpZ2luOiBcInZhbHVlXCIsXG5cdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiB2YWx1ZSQxXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0Zm9yIChjb25zdCBpc3N1ZSBvZiBpdGVtRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdFx0aWYgKGlzc3VlLnBhdGgpIGlzc3VlLnBhdGgudW5zaGlmdChwYXRoSXRlbSk7XG5cdFx0XHRcdFx0XHRcdGVsc2UgaXNzdWUucGF0aCA9IFtwYXRoSXRlbV07XG5cdFx0XHRcdFx0XHRcdGRhdGFzZXQuaXNzdWVzPy5wdXNoKGlzc3VlKTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmICghZGF0YXNldC5pc3N1ZXMpIGRhdGFzZXQuaXNzdWVzID0gaXRlbURhdGFzZXQuaXNzdWVzO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIHtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCFpdGVtRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdGRhdGFzZXQudmFsdWUucHVzaChpdGVtRGF0YXNldC52YWx1ZSk7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvYXJyYXkvYXJyYXlBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGFycmF5QXN5bmMoaXRlbSwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcImFycmF5XCIsXG5cdFx0cmVmZXJlbmNlOiBhcnJheUFzeW5jLFxuXHRcdGV4cGVjdHM6IFwiQXJyYXlcIixcblx0XHRhc3luYzogdHJ1ZSxcblx0XHRpdGVtLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkoaW5wdXQpKSB7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gW107XG5cdFx0XHRcdGNvbnN0IGl0ZW1EYXRhc2V0cyA9IGF3YWl0IFByb21pc2UuYWxsKGlucHV0Lm1hcCgodmFsdWUkMSkgPT4gdGhpcy5pdGVtW1wifnJ1blwiXSh7IHZhbHVlOiB2YWx1ZSQxIH0sIGNvbmZpZyQxKSkpO1xuXHRcdFx0XHRmb3IgKGxldCBrZXkgPSAwOyBrZXkgPCBpdGVtRGF0YXNldHMubGVuZ3RoOyBrZXkrKykge1xuXHRcdFx0XHRcdGNvbnN0IGl0ZW1EYXRhc2V0ID0gaXRlbURhdGFzZXRzW2tleV07XG5cdFx0XHRcdFx0aWYgKGl0ZW1EYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0Y29uc3QgcGF0aEl0ZW0gPSB7XG5cdFx0XHRcdFx0XHRcdHR5cGU6IFwiYXJyYXlcIixcblx0XHRcdFx0XHRcdFx0b3JpZ2luOiBcInZhbHVlXCIsXG5cdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBpbnB1dFtrZXldXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0Zm9yIChjb25zdCBpc3N1ZSBvZiBpdGVtRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdFx0aWYgKGlzc3VlLnBhdGgpIGlzc3VlLnBhdGgudW5zaGlmdChwYXRoSXRlbSk7XG5cdFx0XHRcdFx0XHRcdGVsc2UgaXNzdWUucGF0aCA9IFtwYXRoSXRlbV07XG5cdFx0XHRcdFx0XHRcdGRhdGFzZXQuaXNzdWVzPy5wdXNoKGlzc3VlKTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmICghZGF0YXNldC5pc3N1ZXMpIGRhdGFzZXQuaXNzdWVzID0gaXRlbURhdGFzZXQuaXNzdWVzO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIHtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCFpdGVtRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdGRhdGFzZXQudmFsdWUucHVzaChpdGVtRGF0YXNldC52YWx1ZSk7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvYmlnaW50L2JpZ2ludC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGJpZ2ludChtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwiYmlnaW50XCIsXG5cdFx0cmVmZXJlbmNlOiBiaWdpbnQsXG5cdFx0ZXhwZWN0czogXCJiaWdpbnRcIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAodHlwZW9mIGRhdGFzZXQudmFsdWUgPT09IFwiYmlnaW50XCIpIGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0ZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvYmxvYi9ibG9iLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gYmxvYihtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwiYmxvYlwiLFxuXHRcdHJlZmVyZW5jZTogYmxvYixcblx0XHRleHBlY3RzOiBcIkJsb2JcIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC52YWx1ZSBpbnN0YW5jZW9mIEJsb2IpIGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0ZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvYm9vbGVhbi9ib29sZWFuLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gYm9vbGVhbihtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwiYm9vbGVhblwiLFxuXHRcdHJlZmVyZW5jZTogYm9vbGVhbixcblx0XHRleHBlY3RzOiBcImJvb2xlYW5cIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAodHlwZW9mIGRhdGFzZXQudmFsdWUgPT09IFwiYm9vbGVhblwiKSBkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL2N1c3RvbS9jdXN0b20udHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBjdXN0b20oY2hlY2skMSwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcImN1c3RvbVwiLFxuXHRcdHJlZmVyZW5jZTogY3VzdG9tLFxuXHRcdGV4cGVjdHM6IFwidW5rbm93blwiLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRjaGVjazogY2hlY2skMSxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmICh0aGlzLmNoZWNrKGRhdGFzZXQudmFsdWUpKSBkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL2N1c3RvbS9jdXN0b21Bc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGN1c3RvbUFzeW5jKGNoZWNrJDEsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJjdXN0b21cIixcblx0XHRyZWZlcmVuY2U6IGN1c3RvbUFzeW5jLFxuXHRcdGV4cGVjdHM6IFwidW5rbm93blwiLFxuXHRcdGFzeW5jOiB0cnVlLFxuXHRcdGNoZWNrOiBjaGVjayQxLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGF3YWl0IHRoaXMuY2hlY2soZGF0YXNldC52YWx1ZSkpIGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0ZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvZGF0ZS9kYXRlLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gZGF0ZShtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwiZGF0ZVwiLFxuXHRcdHJlZmVyZW5jZTogZGF0ZSxcblx0XHRleHBlY3RzOiBcIkRhdGVcIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC52YWx1ZSBpbnN0YW5jZW9mIERhdGUpIGlmICghaXNOYU4oZGF0YXNldC52YWx1ZSkpIGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0ZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBcIlxcXCJJbnZhbGlkIERhdGVcXFwiXCIgfSk7XG5cdFx0XHRlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9lbnVtL2VudW0udHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBlbnVtXyhlbnVtX18sIG1lc3NhZ2UkMSkge1xuXHRjb25zdCBvcHRpb25zID0gW107XG5cdGZvciAoY29uc3Qga2V5IGluIGVudW1fXykgaWYgKGAkeytrZXl9YCAhPT0ga2V5IHx8IHR5cGVvZiBlbnVtX19ba2V5XSAhPT0gXCJzdHJpbmdcIiB8fCAhT2JqZWN0LmlzKGVudW1fX1tlbnVtX19ba2V5XV0sICtrZXkpKSBvcHRpb25zLnB1c2goZW51bV9fW2tleV0pO1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJlbnVtXCIsXG5cdFx0cmVmZXJlbmNlOiBlbnVtXyxcblx0XHRleHBlY3RzOiAvKiBAX19QVVJFX18gKi8gX2pvaW5FeHBlY3RzKG9wdGlvbnMubWFwKF9zdHJpbmdpZnkpLCBcInxcIiksXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGVudW06IGVudW1fXyxcblx0XHRvcHRpb25zLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKHRoaXMub3B0aW9ucy5pbmNsdWRlcyhkYXRhc2V0LnZhbHVlKSkgZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9leGFjdE9wdGlvbmFsL2V4YWN0T3B0aW9uYWwudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBleGFjdE9wdGlvbmFsKHdyYXBwZWQsIGRlZmF1bHRfKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcImV4YWN0X29wdGlvbmFsXCIsXG5cdFx0cmVmZXJlbmNlOiBleGFjdE9wdGlvbmFsLFxuXHRcdGV4cGVjdHM6IHdyYXBwZWQuZXhwZWN0cyxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0d3JhcHBlZCxcblx0XHRkZWZhdWx0OiBkZWZhdWx0Xyxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0cmV0dXJuIHRoaXMud3JhcHBlZFtcIn5ydW5cIl0oZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvZXhhY3RPcHRpb25hbC9leGFjdE9wdGlvbmFsQXN5bmMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBleGFjdE9wdGlvbmFsQXN5bmMod3JhcHBlZCwgZGVmYXVsdF8pIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwiZXhhY3Rfb3B0aW9uYWxcIixcblx0XHRyZWZlcmVuY2U6IGV4YWN0T3B0aW9uYWxBc3luYyxcblx0XHRleHBlY3RzOiB3cmFwcGVkLmV4cGVjdHMsXG5cdFx0YXN5bmM6IHRydWUsXG5cdFx0d3JhcHBlZCxcblx0XHRkZWZhdWx0OiBkZWZhdWx0Xyxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0cmV0dXJuIHRoaXMud3JhcHBlZFtcIn5ydW5cIl0oZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvZmlsZS9maWxlLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gZmlsZShtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwiZmlsZVwiLFxuXHRcdHJlZmVyZW5jZTogZmlsZSxcblx0XHRleHBlY3RzOiBcIkZpbGVcIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC52YWx1ZSBpbnN0YW5jZW9mIEZpbGUpIGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0ZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvZnVuY3Rpb24vZnVuY3Rpb24udHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBmdW5jdGlvbl8obWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcImZ1bmN0aW9uXCIsXG5cdFx0cmVmZXJlbmNlOiBmdW5jdGlvbl8sXG5cdFx0ZXhwZWN0czogXCJGdW5jdGlvblwiLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmICh0eXBlb2YgZGF0YXNldC52YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSBkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL2luc3RhbmNlL2luc3RhbmNlLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gaW5zdGFuY2UoY2xhc3NfLCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwiaW5zdGFuY2VcIixcblx0XHRyZWZlcmVuY2U6IGluc3RhbmNlLFxuXHRcdGV4cGVjdHM6IGNsYXNzXy5uYW1lLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRjbGFzczogY2xhc3NfLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgaW5zdGFuY2VvZiB0aGlzLmNsYXNzKSBkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL2ludGVyc2VjdC91dGlscy9fbWVyZ2UvX21lcmdlLnRzXG4vKipcbiogTWVyZ2VzIHR3byB2YWx1ZXMgaW50byBvbmUgc2luZ2xlIG91dHB1dC5cbipcbiogQHBhcmFtIHZhbHVlMSBGaXJzdCB2YWx1ZS5cbiogQHBhcmFtIHZhbHVlMiBTZWNvbmQgdmFsdWUuXG4qXG4qIEByZXR1cm5zIFRoZSBtZXJnZSBkYXRhc2V0LlxuKlxuKiBAaW50ZXJuYWxcbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gX21lcmdlKHZhbHVlMSwgdmFsdWUyKSB7XG5cdGlmICh0eXBlb2YgdmFsdWUxID09PSB0eXBlb2YgdmFsdWUyKSB7XG5cdFx0aWYgKHZhbHVlMSA9PT0gdmFsdWUyIHx8IHZhbHVlMSBpbnN0YW5jZW9mIERhdGUgJiYgdmFsdWUyIGluc3RhbmNlb2YgRGF0ZSAmJiArdmFsdWUxID09PSArdmFsdWUyKSByZXR1cm4geyB2YWx1ZTogdmFsdWUxIH07XG5cdFx0aWYgKHZhbHVlMSAmJiB2YWx1ZTIgJiYgdmFsdWUxLmNvbnN0cnVjdG9yID09PSBPYmplY3QgJiYgdmFsdWUyLmNvbnN0cnVjdG9yID09PSBPYmplY3QpIHtcblx0XHRcdGNvbnN0IG5leHRWYWx1ZSA9IHsgLi4udmFsdWUxIH07XG5cdFx0XHRmb3IgKGNvbnN0IGtleSBpbiB2YWx1ZTIpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwodmFsdWUxLCBrZXkpKSB7XG5cdFx0XHRcdGNvbnN0IGRhdGFzZXQgPSAvKiBAX19QVVJFX18gKi8gX21lcmdlKHZhbHVlMVtrZXldLCB2YWx1ZTJba2V5XSk7XG5cdFx0XHRcdGlmIChkYXRhc2V0Lmlzc3VlKSByZXR1cm4gZGF0YXNldDtcblx0XHRcdFx0bmV4dFZhbHVlW2tleV0gPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0fSBlbHNlIG5leHRWYWx1ZVtrZXldID0gdmFsdWUyW2tleV07XG5cdFx0XHRyZXR1cm4geyB2YWx1ZTogbmV4dFZhbHVlIH07XG5cdFx0fVxuXHRcdGlmIChBcnJheS5pc0FycmF5KHZhbHVlMSkgJiYgQXJyYXkuaXNBcnJheSh2YWx1ZTIpKSB7XG5cdFx0XHRpZiAodmFsdWUxLmxlbmd0aCA9PT0gdmFsdWUyLmxlbmd0aCkge1xuXHRcdFx0XHRjb25zdCBuZXh0VmFsdWUgPSBbLi4udmFsdWUxXTtcblx0XHRcdFx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IHZhbHVlMS5sZW5ndGg7IGluZGV4KyspIHtcblx0XHRcdFx0XHRjb25zdCBkYXRhc2V0ID0gLyogQF9fUFVSRV9fICovIF9tZXJnZSh2YWx1ZTFbaW5kZXhdLCB2YWx1ZTJbaW5kZXhdKTtcblx0XHRcdFx0XHRpZiAoZGF0YXNldC5pc3N1ZSkgcmV0dXJuIGRhdGFzZXQ7XG5cdFx0XHRcdFx0bmV4dFZhbHVlW2luZGV4XSA9IGRhdGFzZXQudmFsdWU7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIHsgdmFsdWU6IG5leHRWYWx1ZSB9O1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRyZXR1cm4geyBpc3N1ZTogdHJ1ZSB9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9pbnRlcnNlY3QvaW50ZXJzZWN0LnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gaW50ZXJzZWN0KG9wdGlvbnMsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJpbnRlcnNlY3RcIixcblx0XHRyZWZlcmVuY2U6IGludGVyc2VjdCxcblx0XHRleHBlY3RzOiAvKiBAX19QVVJFX18gKi8gX2pvaW5FeHBlY3RzKG9wdGlvbnMubWFwKChvcHRpb24pID0+IG9wdGlvbi5leHBlY3RzKSwgXCImXCIpLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRvcHRpb25zLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKHRoaXMub3B0aW9ucy5sZW5ndGgpIHtcblx0XHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0XHRsZXQgb3V0cHV0cztcblx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRcdGZvciAoY29uc3Qgc2NoZW1hIG9mIHRoaXMub3B0aW9ucykge1xuXHRcdFx0XHRcdGNvbnN0IG9wdGlvbkRhdGFzZXQgPSBzY2hlbWFbXCJ+cnVuXCJdKHsgdmFsdWU6IGlucHV0IH0sIGNvbmZpZyQxKTtcblx0XHRcdFx0XHRpZiAob3B0aW9uRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdGlmIChkYXRhc2V0Lmlzc3VlcykgZm9yIChjb25zdCBpc3N1ZSBvZiBvcHRpb25EYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMucHVzaChpc3N1ZSk7XG5cdFx0XHRcdFx0XHRlbHNlIGRhdGFzZXQuaXNzdWVzID0gb3B0aW9uRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIW9wdGlvbkRhdGFzZXQudHlwZWQpIGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRpZiAoZGF0YXNldC50eXBlZCkgaWYgKG91dHB1dHMpIG91dHB1dHMucHVzaChvcHRpb25EYXRhc2V0LnZhbHVlKTtcblx0XHRcdFx0XHRlbHNlIG91dHB1dHMgPSBbb3B0aW9uRGF0YXNldC52YWx1ZV07XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKGRhdGFzZXQudHlwZWQpIHtcblx0XHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gb3V0cHV0c1swXTtcblx0XHRcdFx0XHRmb3IgKGxldCBpbmRleCA9IDE7IGluZGV4IDwgb3V0cHV0cy5sZW5ndGg7IGluZGV4KyspIHtcblx0XHRcdFx0XHRcdGNvbnN0IG1lcmdlRGF0YXNldCA9IC8qIEBfX1BVUkVfXyAqLyBfbWVyZ2UoZGF0YXNldC52YWx1ZSwgb3V0cHV0c1tpbmRleF0pO1xuXHRcdFx0XHRcdFx0aWYgKG1lcmdlRGF0YXNldC5pc3N1ZSkge1xuXHRcdFx0XHRcdFx0XHRfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IHJlY2VpdmVkOiBcInVua25vd25cIiB9KTtcblx0XHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gbWVyZ2VEYXRhc2V0LnZhbHVlO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9pbnRlcnNlY3QvaW50ZXJzZWN0QXN5bmMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBpbnRlcnNlY3RBc3luYyhvcHRpb25zLCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwiaW50ZXJzZWN0XCIsXG5cdFx0cmVmZXJlbmNlOiBpbnRlcnNlY3RBc3luYyxcblx0XHRleHBlY3RzOiAvKiBAX19QVVJFX18gKi8gX2pvaW5FeHBlY3RzKG9wdGlvbnMubWFwKChvcHRpb24pID0+IG9wdGlvbi5leHBlY3RzKSwgXCImXCIpLFxuXHRcdGFzeW5jOiB0cnVlLFxuXHRcdG9wdGlvbnMsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdGFzeW5jIFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAodGhpcy5vcHRpb25zLmxlbmd0aCkge1xuXHRcdFx0XHRjb25zdCBpbnB1dCA9IGRhdGFzZXQudmFsdWU7XG5cdFx0XHRcdGxldCBvdXRwdXRzO1xuXHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0Y29uc3Qgb3B0aW9uRGF0YXNldHMgPSBhd2FpdCBQcm9taXNlLmFsbCh0aGlzLm9wdGlvbnMubWFwKChzY2hlbWEpID0+IHNjaGVtYVtcIn5ydW5cIl0oeyB2YWx1ZTogaW5wdXQgfSwgY29uZmlnJDEpKSk7XG5cdFx0XHRcdGZvciAoY29uc3Qgb3B0aW9uRGF0YXNldCBvZiBvcHRpb25EYXRhc2V0cykge1xuXHRcdFx0XHRcdGlmIChvcHRpb25EYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0aWYgKGRhdGFzZXQuaXNzdWVzKSBmb3IgKGNvbnN0IGlzc3VlIG9mIG9wdGlvbkRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3Vlcy5wdXNoKGlzc3VlKTtcblx0XHRcdFx0XHRcdGVsc2UgZGF0YXNldC5pc3N1ZXMgPSBvcHRpb25EYXRhc2V0Lmlzc3Vlcztcblx0XHRcdFx0XHRcdGlmIChjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmICghb3B0aW9uRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdGlmIChkYXRhc2V0LnR5cGVkKSBpZiAob3V0cHV0cykgb3V0cHV0cy5wdXNoKG9wdGlvbkRhdGFzZXQudmFsdWUpO1xuXHRcdFx0XHRcdGVsc2Ugb3V0cHV0cyA9IFtvcHRpb25EYXRhc2V0LnZhbHVlXTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoZGF0YXNldC50eXBlZCkge1xuXHRcdFx0XHRcdGRhdGFzZXQudmFsdWUgPSBvdXRwdXRzWzBdO1xuXHRcdFx0XHRcdGZvciAobGV0IGluZGV4ID0gMTsgaW5kZXggPCBvdXRwdXRzLmxlbmd0aDsgaW5kZXgrKykge1xuXHRcdFx0XHRcdFx0Y29uc3QgbWVyZ2VEYXRhc2V0ID0gLyogQF9fUFVSRV9fICovIF9tZXJnZShkYXRhc2V0LnZhbHVlLCBvdXRwdXRzW2luZGV4XSk7XG5cdFx0XHRcdFx0XHRpZiAobWVyZ2VEYXRhc2V0Lmlzc3VlKSB7XG5cdFx0XHRcdFx0XHRcdF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgcmVjZWl2ZWQ6IFwidW5rbm93blwiIH0pO1xuXHRcdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGRhdGFzZXQudmFsdWUgPSBtZXJnZURhdGFzZXQudmFsdWU7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL2xhenkvbGF6eS50c1xuLyoqXG4qIENyZWF0ZXMgYSBsYXp5IHNjaGVtYS5cbipcbiogQHBhcmFtIGdldHRlciBUaGUgc2NoZW1hIGdldHRlci5cbipcbiogQHJldHVybnMgQSBsYXp5IHNjaGVtYS5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbGF6eShnZXR0ZXIpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwibGF6eVwiLFxuXHRcdHJlZmVyZW5jZTogbGF6eSxcblx0XHRleHBlY3RzOiBcInVua25vd25cIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0Z2V0dGVyLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRyZXR1cm4gdGhpcy5nZXR0ZXIoZGF0YXNldC52YWx1ZSlbXCJ+cnVuXCJdKGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL2xhenkvbGF6eUFzeW5jLnRzXG4vKipcbiogQ3JlYXRlcyBhIGxhenkgc2NoZW1hLlxuKlxuKiBAcGFyYW0gZ2V0dGVyIFRoZSBzY2hlbWEgZ2V0dGVyLlxuKlxuKiBAcmV0dXJucyBBIGxhenkgc2NoZW1hLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBsYXp5QXN5bmMoZ2V0dGVyKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcImxhenlcIixcblx0XHRyZWZlcmVuY2U6IGxhenlBc3luYyxcblx0XHRleHBlY3RzOiBcInVua25vd25cIixcblx0XHRhc3luYzogdHJ1ZSxcblx0XHRnZXR0ZXIsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0YXN5bmMgXCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdHJldHVybiAoYXdhaXQgdGhpcy5nZXR0ZXIoZGF0YXNldC52YWx1ZSkpW1wifnJ1blwiXShkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9saXRlcmFsL2xpdGVyYWwudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBsaXRlcmFsKGxpdGVyYWxfLCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwibGl0ZXJhbFwiLFxuXHRcdHJlZmVyZW5jZTogbGl0ZXJhbCxcblx0XHRleHBlY3RzOiAvKiBAX19QVVJFX18gKi8gX3N0cmluZ2lmeShsaXRlcmFsXyksXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGxpdGVyYWw6IGxpdGVyYWxfLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgPT09IHRoaXMubGl0ZXJhbCkgZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9sb29zZU9iamVjdC9sb29zZU9iamVjdC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGxvb3NlT2JqZWN0KGVudHJpZXMkMSwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcImxvb3NlX29iamVjdFwiLFxuXHRcdHJlZmVyZW5jZTogbG9vc2VPYmplY3QsXG5cdFx0ZXhwZWN0czogXCJPYmplY3RcIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZW50cmllczogZW50cmllcyQxLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKGlucHV0ICYmIHR5cGVvZiBpbnB1dCA9PT0gXCJvYmplY3RcIikge1xuXHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0ZGF0YXNldC52YWx1ZSA9IHt9O1xuXHRcdFx0XHRmb3IgKGNvbnN0IGtleSBpbiB0aGlzLmVudHJpZXMpIHtcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVNjaGVtYSA9IHRoaXMuZW50cmllc1trZXldO1xuXHRcdFx0XHRcdGlmIChrZXkgaW4gaW5wdXQgfHwgKHZhbHVlU2NoZW1hLnR5cGUgPT09IFwiZXhhY3Rfb3B0aW9uYWxcIiB8fCB2YWx1ZVNjaGVtYS50eXBlID09PSBcIm9wdGlvbmFsXCIgfHwgdmFsdWVTY2hlbWEudHlwZSA9PT0gXCJudWxsaXNoXCIpICYmIHZhbHVlU2NoZW1hLmRlZmF1bHQgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdFx0Y29uc3QgdmFsdWUkMSA9IGtleSBpbiBpbnB1dCA/IGlucHV0W2tleV0gOiAvKiBAX19QVVJFX18gKi8gZ2V0RGVmYXVsdCh2YWx1ZVNjaGVtYSk7XG5cdFx0XHRcdFx0XHRjb25zdCB2YWx1ZURhdGFzZXQgPSB2YWx1ZVNjaGVtYVtcIn5ydW5cIl0oeyB2YWx1ZTogdmFsdWUkMSB9LCBjb25maWckMSk7XG5cdFx0XHRcdFx0XHRpZiAodmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0XHR2YWx1ZTogdmFsdWUkMVxuXHRcdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIHZhbHVlRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0XHRlbHNlIGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRcdGRhdGFzZXQuaXNzdWVzPy5wdXNoKGlzc3VlKTtcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IHZhbHVlRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRcdGlmIChjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIXZhbHVlRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0ZGF0YXNldC52YWx1ZVtrZXldID0gdmFsdWVEYXRhc2V0LnZhbHVlO1xuXHRcdFx0XHRcdH0gZWxzZSBpZiAodmFsdWVTY2hlbWEuZmFsbGJhY2sgIT09IHZvaWQgMCkgZGF0YXNldC52YWx1ZVtrZXldID0gLyogQF9fUFVSRV9fICovIGdldEZhbGxiYWNrKHZhbHVlU2NoZW1hKTtcblx0XHRcdFx0XHRlbHNlIGlmICh2YWx1ZVNjaGVtYS50eXBlICE9PSBcImV4YWN0X29wdGlvbmFsXCIgJiYgdmFsdWVTY2hlbWEudHlwZSAhPT0gXCJvcHRpb25hbFwiICYmIHZhbHVlU2NoZW1hLnR5cGUgIT09IFwibnVsbGlzaFwiKSB7XG5cdFx0XHRcdFx0XHRfYWRkSXNzdWUodGhpcywgXCJrZXlcIiwgZGF0YXNldCwgY29uZmlnJDEsIHtcblx0XHRcdFx0XHRcdFx0aW5wdXQ6IHZvaWQgMCxcblx0XHRcdFx0XHRcdFx0ZXhwZWN0ZWQ6IGBcIiR7a2V5fVwiYCxcblx0XHRcdFx0XHRcdFx0cGF0aDogW3tcblx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJrZXlcIixcblx0XHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdFx0dmFsdWU6IGlucHV0W2tleV1cblx0XHRcdFx0XHRcdFx0fV1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIGJyZWFrO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzIHx8ICFjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBrZXkgaW4gaW5wdXQpIGlmICgvKiBAX19QVVJFX18gKi8gX2lzVmFsaWRPYmplY3RLZXkoaW5wdXQsIGtleSkgJiYgIShrZXkgaW4gdGhpcy5lbnRyaWVzKSkgZGF0YXNldC52YWx1ZVtrZXldID0gaW5wdXRba2V5XTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9sb29zZU9iamVjdC9sb29zZU9iamVjdEFzeW5jLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbG9vc2VPYmplY3RBc3luYyhlbnRyaWVzJDEsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJsb29zZV9vYmplY3RcIixcblx0XHRyZWZlcmVuY2U6IGxvb3NlT2JqZWN0QXN5bmMsXG5cdFx0ZXhwZWN0czogXCJPYmplY3RcIixcblx0XHRhc3luYzogdHJ1ZSxcblx0XHRlbnRyaWVzOiBlbnRyaWVzJDEsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdGFzeW5jIFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRjb25zdCBpbnB1dCA9IGRhdGFzZXQudmFsdWU7XG5cdFx0XHRpZiAoaW5wdXQgJiYgdHlwZW9mIGlucHV0ID09PSBcIm9iamVjdFwiKSB7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0ge307XG5cdFx0XHRcdGNvbnN0IHZhbHVlRGF0YXNldHMgPSBhd2FpdCBQcm9taXNlLmFsbChPYmplY3QuZW50cmllcyh0aGlzLmVudHJpZXMpLm1hcChhc3luYyAoW2tleSwgdmFsdWVTY2hlbWFdKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGtleSBpbiBpbnB1dCB8fCAodmFsdWVTY2hlbWEudHlwZSA9PT0gXCJleGFjdF9vcHRpb25hbFwiIHx8IHZhbHVlU2NoZW1hLnR5cGUgPT09IFwib3B0aW9uYWxcIiB8fCB2YWx1ZVNjaGVtYS50eXBlID09PSBcIm51bGxpc2hcIikgJiYgdmFsdWVTY2hlbWEuZGVmYXVsdCAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0XHRjb25zdCB2YWx1ZSQxID0ga2V5IGluIGlucHV0ID8gaW5wdXRba2V5XSA6IGF3YWl0IC8qIEBfX1BVUkVfXyAqLyBnZXREZWZhdWx0KHZhbHVlU2NoZW1hKTtcblx0XHRcdFx0XHRcdHJldHVybiBbXG5cdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWUkMSxcblx0XHRcdFx0XHRcdFx0dmFsdWVTY2hlbWEsXG5cdFx0XHRcdFx0XHRcdGF3YWl0IHZhbHVlU2NoZW1hW1wifnJ1blwiXSh7IHZhbHVlOiB2YWx1ZSQxIH0sIGNvbmZpZyQxKVxuXHRcdFx0XHRcdFx0XTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0cmV0dXJuIFtcblx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdGlucHV0W2tleV0sXG5cdFx0XHRcdFx0XHR2YWx1ZVNjaGVtYSxcblx0XHRcdFx0XHRcdG51bGxcblx0XHRcdFx0XHRdO1xuXHRcdFx0XHR9KSk7XG5cdFx0XHRcdGZvciAoY29uc3QgW2tleSwgdmFsdWUkMSwgdmFsdWVTY2hlbWEsIHZhbHVlRGF0YXNldF0gb2YgdmFsdWVEYXRhc2V0cykgaWYgKHZhbHVlRGF0YXNldCkge1xuXHRcdFx0XHRcdGlmICh2YWx1ZURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJvYmplY3RcIixcblx0XHRcdFx0XHRcdFx0b3JpZ2luOiBcInZhbHVlXCIsXG5cdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiB2YWx1ZSQxXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0Zm9yIChjb25zdCBpc3N1ZSBvZiB2YWx1ZURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChpc3N1ZS5wYXRoKSBpc3N1ZS5wYXRoLnVuc2hpZnQocGF0aEl0ZW0pO1xuXHRcdFx0XHRcdFx0XHRlbHNlIGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0Lmlzc3Vlcz8ucHVzaChpc3N1ZSk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IHZhbHVlRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIXZhbHVlRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdGRhdGFzZXQudmFsdWVba2V5XSA9IHZhbHVlRGF0YXNldC52YWx1ZTtcblx0XHRcdFx0fSBlbHNlIGlmICh2YWx1ZVNjaGVtYS5mYWxsYmFjayAhPT0gdm9pZCAwKSBkYXRhc2V0LnZhbHVlW2tleV0gPSBhd2FpdCAvKiBAX19QVVJFX18gKi8gZ2V0RmFsbGJhY2sodmFsdWVTY2hlbWEpO1xuXHRcdFx0XHRlbHNlIGlmICh2YWx1ZVNjaGVtYS50eXBlICE9PSBcImV4YWN0X29wdGlvbmFsXCIgJiYgdmFsdWVTY2hlbWEudHlwZSAhPT0gXCJvcHRpb25hbFwiICYmIHZhbHVlU2NoZW1hLnR5cGUgIT09IFwibnVsbGlzaFwiKSB7XG5cdFx0XHRcdFx0X2FkZElzc3VlKHRoaXMsIFwia2V5XCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7XG5cdFx0XHRcdFx0XHRpbnB1dDogdm9pZCAwLFxuXHRcdFx0XHRcdFx0ZXhwZWN0ZWQ6IGBcIiR7a2V5fVwiYCxcblx0XHRcdFx0XHRcdHBhdGg6IFt7XG5cdFx0XHRcdFx0XHRcdHR5cGU6IFwib2JqZWN0XCIsXG5cdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJrZXlcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IHZhbHVlJDFcblx0XHRcdFx0XHRcdH1dXG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIGJyZWFrO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmICghZGF0YXNldC5pc3N1ZXMgfHwgIWNvbmZpZyQxLmFib3J0RWFybHkpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGtleSBpbiBpbnB1dCkgaWYgKC8qIEBfX1BVUkVfXyAqLyBfaXNWYWxpZE9iamVjdEtleShpbnB1dCwga2V5KSAmJiAhKGtleSBpbiB0aGlzLmVudHJpZXMpKSBkYXRhc2V0LnZhbHVlW2tleV0gPSBpbnB1dFtrZXldO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL2xvb3NlVHVwbGUvbG9vc2VUdXBsZS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGxvb3NlVHVwbGUoaXRlbXMsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJsb29zZV90dXBsZVwiLFxuXHRcdHJlZmVyZW5jZTogbG9vc2VUdXBsZSxcblx0XHRleHBlY3RzOiBcIkFycmF5XCIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGl0ZW1zLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkoaW5wdXQpKSB7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gW107XG5cdFx0XHRcdGZvciAobGV0IGtleSA9IDA7IGtleSA8IHRoaXMuaXRlbXMubGVuZ3RoOyBrZXkrKykge1xuXHRcdFx0XHRcdGNvbnN0IHZhbHVlJDEgPSBpbnB1dFtrZXldO1xuXHRcdFx0XHRcdGNvbnN0IGl0ZW1EYXRhc2V0ID0gdGhpcy5pdGVtc1trZXldW1wifnJ1blwiXSh7IHZhbHVlOiB2YWx1ZSQxIH0sIGNvbmZpZyQxKTtcblx0XHRcdFx0XHRpZiAoaXRlbURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJhcnJheVwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwidmFsdWVcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IHZhbHVlJDFcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIGl0ZW1EYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMgPSBpdGVtRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIWl0ZW1EYXRhc2V0LnR5cGVkKSBkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0ZGF0YXNldC52YWx1ZS5wdXNoKGl0ZW1EYXRhc2V0LnZhbHVlKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzIHx8ICFjb25maWckMS5hYm9ydEVhcmx5KSBmb3IgKGxldCBrZXkgPSB0aGlzLml0ZW1zLmxlbmd0aDsga2V5IDwgaW5wdXQubGVuZ3RoOyBrZXkrKykgZGF0YXNldC52YWx1ZS5wdXNoKGlucHV0W2tleV0pO1xuXHRcdFx0fSBlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9sb29zZVR1cGxlL2xvb3NlVHVwbGVBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGxvb3NlVHVwbGVBc3luYyhpdGVtcywgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcImxvb3NlX3R1cGxlXCIsXG5cdFx0cmVmZXJlbmNlOiBsb29zZVR1cGxlQXN5bmMsXG5cdFx0ZXhwZWN0czogXCJBcnJheVwiLFxuXHRcdGFzeW5jOiB0cnVlLFxuXHRcdGl0ZW1zLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkoaW5wdXQpKSB7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gW107XG5cdFx0XHRcdGNvbnN0IGl0ZW1EYXRhc2V0cyA9IGF3YWl0IFByb21pc2UuYWxsKHRoaXMuaXRlbXMubWFwKGFzeW5jIChpdGVtLCBrZXkpID0+IHtcblx0XHRcdFx0XHRjb25zdCB2YWx1ZSQxID0gaW5wdXRba2V5XTtcblx0XHRcdFx0XHRyZXR1cm4gW1xuXHRcdFx0XHRcdFx0a2V5LFxuXHRcdFx0XHRcdFx0dmFsdWUkMSxcblx0XHRcdFx0XHRcdGF3YWl0IGl0ZW1bXCJ+cnVuXCJdKHsgdmFsdWU6IHZhbHVlJDEgfSwgY29uZmlnJDEpXG5cdFx0XHRcdFx0XTtcblx0XHRcdFx0fSkpO1xuXHRcdFx0XHRmb3IgKGNvbnN0IFtrZXksIHZhbHVlJDEsIGl0ZW1EYXRhc2V0XSBvZiBpdGVtRGF0YXNldHMpIHtcblx0XHRcdFx0XHRpZiAoaXRlbURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJhcnJheVwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwidmFsdWVcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IHZhbHVlJDFcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIGl0ZW1EYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMgPSBpdGVtRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIWl0ZW1EYXRhc2V0LnR5cGVkKSBkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0ZGF0YXNldC52YWx1ZS5wdXNoKGl0ZW1EYXRhc2V0LnZhbHVlKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzIHx8ICFjb25maWckMS5hYm9ydEVhcmx5KSBmb3IgKGxldCBrZXkgPSB0aGlzLml0ZW1zLmxlbmd0aDsga2V5IDwgaW5wdXQubGVuZ3RoOyBrZXkrKykgZGF0YXNldC52YWx1ZS5wdXNoKGlucHV0W2tleV0pO1xuXHRcdFx0fSBlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9tYXAvbWFwLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbWFwKGtleSwgdmFsdWUkMSwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm1hcFwiLFxuXHRcdHJlZmVyZW5jZTogbWFwLFxuXHRcdGV4cGVjdHM6IFwiTWFwXCIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGtleSxcblx0XHR2YWx1ZTogdmFsdWUkMSxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGNvbnN0IGlucHV0ID0gZGF0YXNldC52YWx1ZTtcblx0XHRcdGlmIChpbnB1dCBpbnN0YW5jZW9mIE1hcCkge1xuXHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0ZGF0YXNldC52YWx1ZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0XHRcdGZvciAoY29uc3QgW2lucHV0S2V5LCBpbnB1dFZhbHVlXSBvZiBpbnB1dCkge1xuXHRcdFx0XHRcdGNvbnN0IGtleURhdGFzZXQgPSB0aGlzLmtleVtcIn5ydW5cIl0oeyB2YWx1ZTogaW5wdXRLZXkgfSwgY29uZmlnJDEpO1xuXHRcdFx0XHRcdGlmIChrZXlEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0Y29uc3QgcGF0aEl0ZW0gPSB7XG5cdFx0XHRcdFx0XHRcdHR5cGU6IFwibWFwXCIsXG5cdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJrZXlcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleTogaW5wdXRLZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBpbnB1dFZhbHVlXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0Zm9yIChjb25zdCBpc3N1ZSBvZiBrZXlEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMgPSBrZXlEYXRhc2V0Lmlzc3Vlcztcblx0XHRcdFx0XHRcdGlmIChjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlRGF0YXNldCA9IHRoaXMudmFsdWVbXCJ+cnVuXCJdKHsgdmFsdWU6IGlucHV0VmFsdWUgfSwgY29uZmlnJDEpO1xuXHRcdFx0XHRcdGlmICh2YWx1ZURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJtYXBcIixcblx0XHRcdFx0XHRcdFx0b3JpZ2luOiBcInZhbHVlXCIsXG5cdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRrZXk6IGlucHV0S2V5LFxuXHRcdFx0XHRcdFx0XHR2YWx1ZTogaW5wdXRWYWx1ZVxuXHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRcdGZvciAoY29uc3QgaXNzdWUgb2YgdmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMgPSB2YWx1ZURhdGFzZXQuaXNzdWVzO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIHtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCFrZXlEYXRhc2V0LnR5cGVkIHx8ICF2YWx1ZURhdGFzZXQudHlwZWQpIGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRkYXRhc2V0LnZhbHVlLnNldChrZXlEYXRhc2V0LnZhbHVlLCB2YWx1ZURhdGFzZXQudmFsdWUpO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL21hcC9tYXBBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG1hcEFzeW5jKGtleSwgdmFsdWUkMSwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm1hcFwiLFxuXHRcdHJlZmVyZW5jZTogbWFwQXN5bmMsXG5cdFx0ZXhwZWN0czogXCJNYXBcIixcblx0XHRhc3luYzogdHJ1ZSxcblx0XHRrZXksXG5cdFx0dmFsdWU6IHZhbHVlJDEsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdGFzeW5jIFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRjb25zdCBpbnB1dCA9IGRhdGFzZXQudmFsdWU7XG5cdFx0XHRpZiAoaW5wdXQgaW5zdGFuY2VvZiBNYXApIHtcblx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRcdGRhdGFzZXQudmFsdWUgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdFx0XHRjb25zdCBkYXRhc2V0cyA9IGF3YWl0IFByb21pc2UuYWxsKFsuLi5pbnB1dF0ubWFwKChbaW5wdXRLZXksIGlucHV0VmFsdWVdKSA9PiBQcm9taXNlLmFsbChbXG5cdFx0XHRcdFx0aW5wdXRLZXksXG5cdFx0XHRcdFx0aW5wdXRWYWx1ZSxcblx0XHRcdFx0XHR0aGlzLmtleVtcIn5ydW5cIl0oeyB2YWx1ZTogaW5wdXRLZXkgfSwgY29uZmlnJDEpLFxuXHRcdFx0XHRcdHRoaXMudmFsdWVbXCJ+cnVuXCJdKHsgdmFsdWU6IGlucHV0VmFsdWUgfSwgY29uZmlnJDEpXG5cdFx0XHRcdF0pKSk7XG5cdFx0XHRcdGZvciAoY29uc3QgW2lucHV0S2V5LCBpbnB1dFZhbHVlLCBrZXlEYXRhc2V0LCB2YWx1ZURhdGFzZXRdIG9mIGRhdGFzZXRzKSB7XG5cdFx0XHRcdFx0aWYgKGtleURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJtYXBcIixcblx0XHRcdFx0XHRcdFx0b3JpZ2luOiBcImtleVwiLFxuXHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0a2V5OiBpbnB1dEtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IGlucHV0VmFsdWVcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIGtleURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChpc3N1ZS5wYXRoKSBpc3N1ZS5wYXRoLnVuc2hpZnQocGF0aEl0ZW0pO1xuXHRcdFx0XHRcdFx0XHRlbHNlIGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0Lmlzc3Vlcz8ucHVzaChpc3N1ZSk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IGtleURhdGFzZXQuaXNzdWVzO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIHtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKHZhbHVlRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdGNvbnN0IHBhdGhJdGVtID0ge1xuXHRcdFx0XHRcdFx0XHR0eXBlOiBcIm1hcFwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwidmFsdWVcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleTogaW5wdXRLZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBpbnB1dFZhbHVlXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0Zm9yIChjb25zdCBpc3N1ZSBvZiB2YWx1ZURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChpc3N1ZS5wYXRoKSBpc3N1ZS5wYXRoLnVuc2hpZnQocGF0aEl0ZW0pO1xuXHRcdFx0XHRcdFx0XHRlbHNlIGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0Lmlzc3Vlcz8ucHVzaChpc3N1ZSk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IHZhbHVlRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIWtleURhdGFzZXQudHlwZWQgfHwgIXZhbHVlRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdGRhdGFzZXQudmFsdWUuc2V0KGtleURhdGFzZXQudmFsdWUsIHZhbHVlRGF0YXNldC52YWx1ZSk7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvbmFuL25hbi50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG5hbihtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwibmFuXCIsXG5cdFx0cmVmZXJlbmNlOiBuYW4sXG5cdFx0ZXhwZWN0czogXCJOYU5cIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoTnVtYmVyLmlzTmFOKGRhdGFzZXQudmFsdWUpKSBkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL25ldmVyL25ldmVyLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbmV2ZXIobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm5ldmVyXCIsXG5cdFx0cmVmZXJlbmNlOiBuZXZlcixcblx0XHRleHBlY3RzOiBcIm5ldmVyXCIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0X2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL25vbk51bGxhYmxlL25vbk51bGxhYmxlLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbm9uTnVsbGFibGUod3JhcHBlZCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm5vbl9udWxsYWJsZVwiLFxuXHRcdHJlZmVyZW5jZTogbm9uTnVsbGFibGUsXG5cdFx0ZXhwZWN0czogXCIhbnVsbFwiLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHR3cmFwcGVkLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgIT09IG51bGwpIGRhdGFzZXQgPSB0aGlzLndyYXBwZWRbXCJ+cnVuXCJdKGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdGlmIChkYXRhc2V0LnZhbHVlID09PSBudWxsKSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvbm9uTnVsbGFibGUvbm9uTnVsbGFibGVBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG5vbk51bGxhYmxlQXN5bmMod3JhcHBlZCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm5vbl9udWxsYWJsZVwiLFxuXHRcdHJlZmVyZW5jZTogbm9uTnVsbGFibGVBc3luYyxcblx0XHRleHBlY3RzOiBcIiFudWxsXCIsXG5cdFx0YXN5bmM6IHRydWUsXG5cdFx0d3JhcHBlZCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0YXN5bmMgXCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnZhbHVlICE9PSBudWxsKSBkYXRhc2V0ID0gYXdhaXQgdGhpcy53cmFwcGVkW1wifnJ1blwiXShkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRpZiAoZGF0YXNldC52YWx1ZSA9PT0gbnVsbCkgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL25vbk51bGxpc2gvbm9uTnVsbGlzaC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG5vbk51bGxpc2god3JhcHBlZCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm5vbl9udWxsaXNoXCIsXG5cdFx0cmVmZXJlbmNlOiBub25OdWxsaXNoLFxuXHRcdGV4cGVjdHM6IFwiKCFudWxsICYgIXVuZGVmaW5lZClcIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0d3JhcHBlZCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmICghKGRhdGFzZXQudmFsdWUgPT09IG51bGwgfHwgZGF0YXNldC52YWx1ZSA9PT0gdm9pZCAwKSkgZGF0YXNldCA9IHRoaXMud3JhcHBlZFtcIn5ydW5cIl0oZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgPT09IG51bGwgfHwgZGF0YXNldC52YWx1ZSA9PT0gdm9pZCAwKSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvbm9uTnVsbGlzaC9ub25OdWxsaXNoQXN5bmMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBub25OdWxsaXNoQXN5bmMod3JhcHBlZCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm5vbl9udWxsaXNoXCIsXG5cdFx0cmVmZXJlbmNlOiBub25OdWxsaXNoQXN5bmMsXG5cdFx0ZXhwZWN0czogXCIoIW51bGwgJiAhdW5kZWZpbmVkKVwiLFxuXHRcdGFzeW5jOiB0cnVlLFxuXHRcdHdyYXBwZWQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdGFzeW5jIFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoIShkYXRhc2V0LnZhbHVlID09PSBudWxsIHx8IGRhdGFzZXQudmFsdWUgPT09IHZvaWQgMCkpIGRhdGFzZXQgPSBhd2FpdCB0aGlzLndyYXBwZWRbXCJ+cnVuXCJdKGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdGlmIChkYXRhc2V0LnZhbHVlID09PSBudWxsIHx8IGRhdGFzZXQudmFsdWUgPT09IHZvaWQgMCkgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL25vbk9wdGlvbmFsL25vbk9wdGlvbmFsLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbm9uT3B0aW9uYWwod3JhcHBlZCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm5vbl9vcHRpb25hbFwiLFxuXHRcdHJlZmVyZW5jZTogbm9uT3B0aW9uYWwsXG5cdFx0ZXhwZWN0czogXCIhdW5kZWZpbmVkXCIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdHdyYXBwZWQsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC52YWx1ZSAhPT0gdm9pZCAwKSBkYXRhc2V0ID0gdGhpcy53cmFwcGVkW1wifnJ1blwiXShkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRpZiAoZGF0YXNldC52YWx1ZSA9PT0gdm9pZCAwKSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvbm9uT3B0aW9uYWwvbm9uT3B0aW9uYWxBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG5vbk9wdGlvbmFsQXN5bmMod3JhcHBlZCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm5vbl9vcHRpb25hbFwiLFxuXHRcdHJlZmVyZW5jZTogbm9uT3B0aW9uYWxBc3luYyxcblx0XHRleHBlY3RzOiBcIiF1bmRlZmluZWRcIixcblx0XHRhc3luYzogdHJ1ZSxcblx0XHR3cmFwcGVkLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgIT09IHZvaWQgMCkgZGF0YXNldCA9IGF3YWl0IHRoaXMud3JhcHBlZFtcIn5ydW5cIl0oZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgPT09IHZvaWQgMCkgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL251bGwvbnVsbC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG51bGxfKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJudWxsXCIsXG5cdFx0cmVmZXJlbmNlOiBudWxsXyxcblx0XHRleHBlY3RzOiBcIm51bGxcIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC52YWx1ZSA9PT0gbnVsbCkgZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9udWxsYWJsZS9udWxsYWJsZS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG51bGxhYmxlKHdyYXBwZWQsIGRlZmF1bHRfKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm51bGxhYmxlXCIsXG5cdFx0cmVmZXJlbmNlOiBudWxsYWJsZSxcblx0XHRleHBlY3RzOiBgKCR7d3JhcHBlZC5leHBlY3RzfSB8IG51bGwpYCxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0d3JhcHBlZCxcblx0XHRkZWZhdWx0OiBkZWZhdWx0Xyxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgPT09IG51bGwpIHtcblx0XHRcdFx0aWYgKHRoaXMuZGVmYXVsdCAhPT0gdm9pZCAwKSBkYXRhc2V0LnZhbHVlID0gLyogQF9fUFVSRV9fICovIGdldERlZmF1bHQodGhpcywgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0XHRpZiAoZGF0YXNldC52YWx1ZSA9PT0gbnVsbCkge1xuXHRcdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gdGhpcy53cmFwcGVkW1wifnJ1blwiXShkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9udWxsYWJsZS9udWxsYWJsZUFzeW5jLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbnVsbGFibGVBc3luYyh3cmFwcGVkLCBkZWZhdWx0Xykge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJudWxsYWJsZVwiLFxuXHRcdHJlZmVyZW5jZTogbnVsbGFibGVBc3luYyxcblx0XHRleHBlY3RzOiBgKCR7d3JhcHBlZC5leHBlY3RzfSB8IG51bGwpYCxcblx0XHRhc3luYzogdHJ1ZSxcblx0XHR3cmFwcGVkLFxuXHRcdGRlZmF1bHQ6IGRlZmF1bHRfLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdGFzeW5jIFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC52YWx1ZSA9PT0gbnVsbCkge1xuXHRcdFx0XHRpZiAodGhpcy5kZWZhdWx0ICE9PSB2b2lkIDApIGRhdGFzZXQudmFsdWUgPSBhd2FpdCAvKiBAX19QVVJFX18gKi8gZ2V0RGVmYXVsdCh0aGlzLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRcdGlmIChkYXRhc2V0LnZhbHVlID09PSBudWxsKSB7XG5cdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJldHVybiB0aGlzLndyYXBwZWRbXCJ+cnVuXCJdKGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL251bGxpc2gvbnVsbGlzaC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG51bGxpc2god3JhcHBlZCwgZGVmYXVsdF8pIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwibnVsbGlzaFwiLFxuXHRcdHJlZmVyZW5jZTogbnVsbGlzaCxcblx0XHRleHBlY3RzOiBgKCR7d3JhcHBlZC5leHBlY3RzfSB8IG51bGwgfCB1bmRlZmluZWQpYCxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0d3JhcHBlZCxcblx0XHRkZWZhdWx0OiBkZWZhdWx0Xyxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgPT09IG51bGwgfHwgZGF0YXNldC52YWx1ZSA9PT0gdm9pZCAwKSB7XG5cdFx0XHRcdGlmICh0aGlzLmRlZmF1bHQgIT09IHZvaWQgMCkgZGF0YXNldC52YWx1ZSA9IC8qIEBfX1BVUkVfXyAqLyBnZXREZWZhdWx0KHRoaXMsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgPT09IG51bGwgfHwgZGF0YXNldC52YWx1ZSA9PT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJldHVybiB0aGlzLndyYXBwZWRbXCJ+cnVuXCJdKGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL251bGxpc2gvbnVsbGlzaEFzeW5jLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbnVsbGlzaEFzeW5jKHdyYXBwZWQsIGRlZmF1bHRfKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm51bGxpc2hcIixcblx0XHRyZWZlcmVuY2U6IG51bGxpc2hBc3luYyxcblx0XHRleHBlY3RzOiBgKCR7d3JhcHBlZC5leHBlY3RzfSB8IG51bGwgfCB1bmRlZmluZWQpYCxcblx0XHRhc3luYzogdHJ1ZSxcblx0XHR3cmFwcGVkLFxuXHRcdGRlZmF1bHQ6IGRlZmF1bHRfLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdGFzeW5jIFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC52YWx1ZSA9PT0gbnVsbCB8fCBkYXRhc2V0LnZhbHVlID09PSB2b2lkIDApIHtcblx0XHRcdFx0aWYgKHRoaXMuZGVmYXVsdCAhPT0gdm9pZCAwKSBkYXRhc2V0LnZhbHVlID0gYXdhaXQgLyogQF9fUFVSRV9fICovIGdldERlZmF1bHQodGhpcywgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0XHRpZiAoZGF0YXNldC52YWx1ZSA9PT0gbnVsbCB8fCBkYXRhc2V0LnZhbHVlID09PSB2b2lkIDApIHtcblx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHRoaXMud3JhcHBlZFtcIn5ydW5cIl0oZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvbnVtYmVyL251bWJlci50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG51bWJlcihtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwibnVtYmVyXCIsXG5cdFx0cmVmZXJlbmNlOiBudW1iZXIsXG5cdFx0ZXhwZWN0czogXCJudW1iZXJcIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAodHlwZW9mIGRhdGFzZXQudmFsdWUgPT09IFwibnVtYmVyXCIgJiYgIWlzTmFOKGRhdGFzZXQudmFsdWUpKSBkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL29iamVjdC9vYmplY3QudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBvYmplY3QoZW50cmllcyQxLCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwib2JqZWN0XCIsXG5cdFx0cmVmZXJlbmNlOiBvYmplY3QsXG5cdFx0ZXhwZWN0czogXCJPYmplY3RcIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZW50cmllczogZW50cmllcyQxLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKGlucHV0ICYmIHR5cGVvZiBpbnB1dCA9PT0gXCJvYmplY3RcIikge1xuXHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0ZGF0YXNldC52YWx1ZSA9IHt9O1xuXHRcdFx0XHRmb3IgKGNvbnN0IGtleSBpbiB0aGlzLmVudHJpZXMpIHtcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVNjaGVtYSA9IHRoaXMuZW50cmllc1trZXldO1xuXHRcdFx0XHRcdGlmIChrZXkgaW4gaW5wdXQgfHwgKHZhbHVlU2NoZW1hLnR5cGUgPT09IFwiZXhhY3Rfb3B0aW9uYWxcIiB8fCB2YWx1ZVNjaGVtYS50eXBlID09PSBcIm9wdGlvbmFsXCIgfHwgdmFsdWVTY2hlbWEudHlwZSA9PT0gXCJudWxsaXNoXCIpICYmIHZhbHVlU2NoZW1hLmRlZmF1bHQgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdFx0Y29uc3QgdmFsdWUkMSA9IGtleSBpbiBpbnB1dCA/IGlucHV0W2tleV0gOiAvKiBAX19QVVJFX18gKi8gZ2V0RGVmYXVsdCh2YWx1ZVNjaGVtYSk7XG5cdFx0XHRcdFx0XHRjb25zdCB2YWx1ZURhdGFzZXQgPSB2YWx1ZVNjaGVtYVtcIn5ydW5cIl0oeyB2YWx1ZTogdmFsdWUkMSB9LCBjb25maWckMSk7XG5cdFx0XHRcdFx0XHRpZiAodmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0XHR2YWx1ZTogdmFsdWUkMVxuXHRcdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIHZhbHVlRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0XHRlbHNlIGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRcdGRhdGFzZXQuaXNzdWVzPy5wdXNoKGlzc3VlKTtcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IHZhbHVlRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRcdGlmIChjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIXZhbHVlRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0ZGF0YXNldC52YWx1ZVtrZXldID0gdmFsdWVEYXRhc2V0LnZhbHVlO1xuXHRcdFx0XHRcdH0gZWxzZSBpZiAodmFsdWVTY2hlbWEuZmFsbGJhY2sgIT09IHZvaWQgMCkgZGF0YXNldC52YWx1ZVtrZXldID0gLyogQF9fUFVSRV9fICovIGdldEZhbGxiYWNrKHZhbHVlU2NoZW1hKTtcblx0XHRcdFx0XHRlbHNlIGlmICh2YWx1ZVNjaGVtYS50eXBlICE9PSBcImV4YWN0X29wdGlvbmFsXCIgJiYgdmFsdWVTY2hlbWEudHlwZSAhPT0gXCJvcHRpb25hbFwiICYmIHZhbHVlU2NoZW1hLnR5cGUgIT09IFwibnVsbGlzaFwiKSB7XG5cdFx0XHRcdFx0XHRfYWRkSXNzdWUodGhpcywgXCJrZXlcIiwgZGF0YXNldCwgY29uZmlnJDEsIHtcblx0XHRcdFx0XHRcdFx0aW5wdXQ6IHZvaWQgMCxcblx0XHRcdFx0XHRcdFx0ZXhwZWN0ZWQ6IGBcIiR7a2V5fVwiYCxcblx0XHRcdFx0XHRcdFx0cGF0aDogW3tcblx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJrZXlcIixcblx0XHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdFx0dmFsdWU6IGlucHV0W2tleV1cblx0XHRcdFx0XHRcdFx0fV1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIGJyZWFrO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9vYmplY3Qvb2JqZWN0QXN5bmMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBvYmplY3RBc3luYyhlbnRyaWVzJDEsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJvYmplY3RcIixcblx0XHRyZWZlcmVuY2U6IG9iamVjdEFzeW5jLFxuXHRcdGV4cGVjdHM6IFwiT2JqZWN0XCIsXG5cdFx0YXN5bmM6IHRydWUsXG5cdFx0ZW50cmllczogZW50cmllcyQxLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKGlucHV0ICYmIHR5cGVvZiBpbnB1dCA9PT0gXCJvYmplY3RcIikge1xuXHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0ZGF0YXNldC52YWx1ZSA9IHt9O1xuXHRcdFx0XHRjb25zdCB2YWx1ZURhdGFzZXRzID0gYXdhaXQgUHJvbWlzZS5hbGwoT2JqZWN0LmVudHJpZXModGhpcy5lbnRyaWVzKS5tYXAoYXN5bmMgKFtrZXksIHZhbHVlU2NoZW1hXSkgPT4ge1xuXHRcdFx0XHRcdGlmIChrZXkgaW4gaW5wdXQgfHwgKHZhbHVlU2NoZW1hLnR5cGUgPT09IFwiZXhhY3Rfb3B0aW9uYWxcIiB8fCB2YWx1ZVNjaGVtYS50eXBlID09PSBcIm9wdGlvbmFsXCIgfHwgdmFsdWVTY2hlbWEudHlwZSA9PT0gXCJudWxsaXNoXCIpICYmIHZhbHVlU2NoZW1hLmRlZmF1bHQgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdFx0Y29uc3QgdmFsdWUkMSA9IGtleSBpbiBpbnB1dCA/IGlucHV0W2tleV0gOiBhd2FpdCAvKiBAX19QVVJFX18gKi8gZ2V0RGVmYXVsdCh2YWx1ZVNjaGVtYSk7XG5cdFx0XHRcdFx0XHRyZXR1cm4gW1xuXHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlJDEsXG5cdFx0XHRcdFx0XHRcdHZhbHVlU2NoZW1hLFxuXHRcdFx0XHRcdFx0XHRhd2FpdCB2YWx1ZVNjaGVtYVtcIn5ydW5cIl0oeyB2YWx1ZTogdmFsdWUkMSB9LCBjb25maWckMSlcblx0XHRcdFx0XHRcdF07XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHJldHVybiBbXG5cdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRpbnB1dFtrZXldLFxuXHRcdFx0XHRcdFx0dmFsdWVTY2hlbWEsXG5cdFx0XHRcdFx0XHRudWxsXG5cdFx0XHRcdFx0XTtcblx0XHRcdFx0fSkpO1xuXHRcdFx0XHRmb3IgKGNvbnN0IFtrZXksIHZhbHVlJDEsIHZhbHVlU2NoZW1hLCB2YWx1ZURhdGFzZXRdIG9mIHZhbHVlRGF0YXNldHMpIGlmICh2YWx1ZURhdGFzZXQpIHtcblx0XHRcdFx0XHRpZiAodmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0Y29uc3QgcGF0aEl0ZW0gPSB7XG5cdFx0XHRcdFx0XHRcdHR5cGU6IFwib2JqZWN0XCIsXG5cdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0a2V5LFxuXHRcdFx0XHRcdFx0XHR2YWx1ZTogdmFsdWUkMVxuXHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRcdGZvciAoY29uc3QgaXNzdWUgb2YgdmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMgPSB2YWx1ZURhdGFzZXQuaXNzdWVzO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIHtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCF2YWx1ZURhdGFzZXQudHlwZWQpIGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRkYXRhc2V0LnZhbHVlW2tleV0gPSB2YWx1ZURhdGFzZXQudmFsdWU7XG5cdFx0XHRcdH0gZWxzZSBpZiAodmFsdWVTY2hlbWEuZmFsbGJhY2sgIT09IHZvaWQgMCkgZGF0YXNldC52YWx1ZVtrZXldID0gYXdhaXQgLyogQF9fUFVSRV9fICovIGdldEZhbGxiYWNrKHZhbHVlU2NoZW1hKTtcblx0XHRcdFx0ZWxzZSBpZiAodmFsdWVTY2hlbWEudHlwZSAhPT0gXCJleGFjdF9vcHRpb25hbFwiICYmIHZhbHVlU2NoZW1hLnR5cGUgIT09IFwib3B0aW9uYWxcIiAmJiB2YWx1ZVNjaGVtYS50eXBlICE9PSBcIm51bGxpc2hcIikge1xuXHRcdFx0XHRcdF9hZGRJc3N1ZSh0aGlzLCBcImtleVwiLCBkYXRhc2V0LCBjb25maWckMSwge1xuXHRcdFx0XHRcdFx0aW5wdXQ6IHZvaWQgMCxcblx0XHRcdFx0XHRcdGV4cGVjdGVkOiBgXCIke2tleX1cImAsXG5cdFx0XHRcdFx0XHRwYXRoOiBbe1xuXHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwia2V5XCIsXG5cdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiB2YWx1ZSQxXG5cdFx0XHRcdFx0XHR9XVxuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdGlmIChjb25maWckMS5hYm9ydEVhcmx5KSBicmVhaztcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9vYmplY3RXaXRoUmVzdC9vYmplY3RXaXRoUmVzdC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG9iamVjdFdpdGhSZXN0KGVudHJpZXMkMSwgcmVzdCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm9iamVjdF93aXRoX3Jlc3RcIixcblx0XHRyZWZlcmVuY2U6IG9iamVjdFdpdGhSZXN0LFxuXHRcdGV4cGVjdHM6IFwiT2JqZWN0XCIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGVudHJpZXM6IGVudHJpZXMkMSxcblx0XHRyZXN0LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKGlucHV0ICYmIHR5cGVvZiBpbnB1dCA9PT0gXCJvYmplY3RcIikge1xuXHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0ZGF0YXNldC52YWx1ZSA9IHt9O1xuXHRcdFx0XHRmb3IgKGNvbnN0IGtleSBpbiB0aGlzLmVudHJpZXMpIHtcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVNjaGVtYSA9IHRoaXMuZW50cmllc1trZXldO1xuXHRcdFx0XHRcdGlmIChrZXkgaW4gaW5wdXQgfHwgKHZhbHVlU2NoZW1hLnR5cGUgPT09IFwiZXhhY3Rfb3B0aW9uYWxcIiB8fCB2YWx1ZVNjaGVtYS50eXBlID09PSBcIm9wdGlvbmFsXCIgfHwgdmFsdWVTY2hlbWEudHlwZSA9PT0gXCJudWxsaXNoXCIpICYmIHZhbHVlU2NoZW1hLmRlZmF1bHQgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdFx0Y29uc3QgdmFsdWUkMSA9IGtleSBpbiBpbnB1dCA/IGlucHV0W2tleV0gOiAvKiBAX19QVVJFX18gKi8gZ2V0RGVmYXVsdCh2YWx1ZVNjaGVtYSk7XG5cdFx0XHRcdFx0XHRjb25zdCB2YWx1ZURhdGFzZXQgPSB2YWx1ZVNjaGVtYVtcIn5ydW5cIl0oeyB2YWx1ZTogdmFsdWUkMSB9LCBjb25maWckMSk7XG5cdFx0XHRcdFx0XHRpZiAodmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0XHR2YWx1ZTogdmFsdWUkMVxuXHRcdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIHZhbHVlRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0XHRlbHNlIGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRcdGRhdGFzZXQuaXNzdWVzPy5wdXNoKGlzc3VlKTtcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IHZhbHVlRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRcdGlmIChjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIXZhbHVlRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0ZGF0YXNldC52YWx1ZVtrZXldID0gdmFsdWVEYXRhc2V0LnZhbHVlO1xuXHRcdFx0XHRcdH0gZWxzZSBpZiAodmFsdWVTY2hlbWEuZmFsbGJhY2sgIT09IHZvaWQgMCkgZGF0YXNldC52YWx1ZVtrZXldID0gLyogQF9fUFVSRV9fICovIGdldEZhbGxiYWNrKHZhbHVlU2NoZW1hKTtcblx0XHRcdFx0XHRlbHNlIGlmICh2YWx1ZVNjaGVtYS50eXBlICE9PSBcImV4YWN0X29wdGlvbmFsXCIgJiYgdmFsdWVTY2hlbWEudHlwZSAhPT0gXCJvcHRpb25hbFwiICYmIHZhbHVlU2NoZW1hLnR5cGUgIT09IFwibnVsbGlzaFwiKSB7XG5cdFx0XHRcdFx0XHRfYWRkSXNzdWUodGhpcywgXCJrZXlcIiwgZGF0YXNldCwgY29uZmlnJDEsIHtcblx0XHRcdFx0XHRcdFx0aW5wdXQ6IHZvaWQgMCxcblx0XHRcdFx0XHRcdFx0ZXhwZWN0ZWQ6IGBcIiR7a2V5fVwiYCxcblx0XHRcdFx0XHRcdFx0cGF0aDogW3tcblx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJrZXlcIixcblx0XHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdFx0dmFsdWU6IGlucHV0W2tleV1cblx0XHRcdFx0XHRcdFx0fV1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIGJyZWFrO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzIHx8ICFjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBrZXkgaW4gaW5wdXQpIGlmICgvKiBAX19QVVJFX18gKi8gX2lzVmFsaWRPYmplY3RLZXkoaW5wdXQsIGtleSkgJiYgIShrZXkgaW4gdGhpcy5lbnRyaWVzKSkge1xuXHRcdFx0XHRcdFx0Y29uc3QgdmFsdWVEYXRhc2V0ID0gdGhpcy5yZXN0W1wifnJ1blwiXSh7IHZhbHVlOiBpbnB1dFtrZXldIH0sIGNvbmZpZyQxKTtcblx0XHRcdFx0XHRcdGlmICh2YWx1ZURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRcdGNvbnN0IHBhdGhJdGVtID0ge1xuXHRcdFx0XHRcdFx0XHRcdHR5cGU6IFwib2JqZWN0XCIsXG5cdFx0XHRcdFx0XHRcdFx0b3JpZ2luOiBcInZhbHVlXCIsXG5cdFx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdFx0a2V5LFxuXHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBpbnB1dFtrZXldXG5cdFx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRcdGZvciAoY29uc3QgaXNzdWUgb2YgdmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRcdGlmIChpc3N1ZS5wYXRoKSBpc3N1ZS5wYXRoLnVuc2hpZnQocGF0aEl0ZW0pO1xuXHRcdFx0XHRcdFx0XHRcdGVsc2UgaXNzdWUucGF0aCA9IFtwYXRoSXRlbV07XG5cdFx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRcdGlmICghZGF0YXNldC5pc3N1ZXMpIGRhdGFzZXQuaXNzdWVzID0gdmFsdWVEYXRhc2V0Lmlzc3Vlcztcblx0XHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIHtcblx0XHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmICghdmFsdWVEYXRhc2V0LnR5cGVkKSBkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRkYXRhc2V0LnZhbHVlW2tleV0gPSB2YWx1ZURhdGFzZXQudmFsdWU7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL29iamVjdFdpdGhSZXN0L29iamVjdFdpdGhSZXN0QXN5bmMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBvYmplY3RXaXRoUmVzdEFzeW5jKGVudHJpZXMkMSwgcmVzdCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcIm9iamVjdF93aXRoX3Jlc3RcIixcblx0XHRyZWZlcmVuY2U6IG9iamVjdFdpdGhSZXN0QXN5bmMsXG5cdFx0ZXhwZWN0czogXCJPYmplY3RcIixcblx0XHRhc3luYzogdHJ1ZSxcblx0XHRlbnRyaWVzOiBlbnRyaWVzJDEsXG5cdFx0cmVzdCxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0YXN5bmMgXCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGNvbnN0IGlucHV0ID0gZGF0YXNldC52YWx1ZTtcblx0XHRcdGlmIChpbnB1dCAmJiB0eXBlb2YgaW5wdXQgPT09IFwib2JqZWN0XCIpIHtcblx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRcdGRhdGFzZXQudmFsdWUgPSB7fTtcblx0XHRcdFx0Y29uc3QgW25vcm1hbERhdGFzZXRzLCByZXN0RGF0YXNldHNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1Byb21pc2UuYWxsKE9iamVjdC5lbnRyaWVzKHRoaXMuZW50cmllcykubWFwKGFzeW5jIChba2V5LCB2YWx1ZVNjaGVtYV0pID0+IHtcblx0XHRcdFx0XHRpZiAoa2V5IGluIGlucHV0IHx8ICh2YWx1ZVNjaGVtYS50eXBlID09PSBcImV4YWN0X29wdGlvbmFsXCIgfHwgdmFsdWVTY2hlbWEudHlwZSA9PT0gXCJvcHRpb25hbFwiIHx8IHZhbHVlU2NoZW1hLnR5cGUgPT09IFwibnVsbGlzaFwiKSAmJiB2YWx1ZVNjaGVtYS5kZWZhdWx0ICE9PSB2b2lkIDApIHtcblx0XHRcdFx0XHRcdGNvbnN0IHZhbHVlJDEgPSBrZXkgaW4gaW5wdXQgPyBpbnB1dFtrZXldIDogYXdhaXQgLyogQF9fUFVSRV9fICovIGdldERlZmF1bHQodmFsdWVTY2hlbWEpO1xuXHRcdFx0XHRcdFx0cmV0dXJuIFtcblx0XHRcdFx0XHRcdFx0a2V5LFxuXHRcdFx0XHRcdFx0XHR2YWx1ZSQxLFxuXHRcdFx0XHRcdFx0XHR2YWx1ZVNjaGVtYSxcblx0XHRcdFx0XHRcdFx0YXdhaXQgdmFsdWVTY2hlbWFbXCJ+cnVuXCJdKHsgdmFsdWU6IHZhbHVlJDEgfSwgY29uZmlnJDEpXG5cdFx0XHRcdFx0XHRdO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRyZXR1cm4gW1xuXHRcdFx0XHRcdFx0a2V5LFxuXHRcdFx0XHRcdFx0aW5wdXRba2V5XSxcblx0XHRcdFx0XHRcdHZhbHVlU2NoZW1hLFxuXHRcdFx0XHRcdFx0bnVsbFxuXHRcdFx0XHRcdF07XG5cdFx0XHRcdH0pKSwgUHJvbWlzZS5hbGwoT2JqZWN0LmVudHJpZXMoaW5wdXQpLmZpbHRlcigoW2tleV0pID0+IC8qIEBfX1BVUkVfXyAqLyBfaXNWYWxpZE9iamVjdEtleShpbnB1dCwga2V5KSAmJiAhKGtleSBpbiB0aGlzLmVudHJpZXMpKS5tYXAoYXN5bmMgKFtrZXksIHZhbHVlJDFdKSA9PiBbXG5cdFx0XHRcdFx0a2V5LFxuXHRcdFx0XHRcdHZhbHVlJDEsXG5cdFx0XHRcdFx0YXdhaXQgdGhpcy5yZXN0W1wifnJ1blwiXSh7IHZhbHVlOiB2YWx1ZSQxIH0sIGNvbmZpZyQxKVxuXHRcdFx0XHRdKSldKTtcblx0XHRcdFx0Zm9yIChjb25zdCBba2V5LCB2YWx1ZSQxLCB2YWx1ZVNjaGVtYSwgdmFsdWVEYXRhc2V0XSBvZiBub3JtYWxEYXRhc2V0cykgaWYgKHZhbHVlRGF0YXNldCkge1xuXHRcdFx0XHRcdGlmICh2YWx1ZURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJvYmplY3RcIixcblx0XHRcdFx0XHRcdFx0b3JpZ2luOiBcInZhbHVlXCIsXG5cdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiB2YWx1ZSQxXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0Zm9yIChjb25zdCBpc3N1ZSBvZiB2YWx1ZURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChpc3N1ZS5wYXRoKSBpc3N1ZS5wYXRoLnVuc2hpZnQocGF0aEl0ZW0pO1xuXHRcdFx0XHRcdFx0XHRlbHNlIGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0Lmlzc3Vlcz8ucHVzaChpc3N1ZSk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IHZhbHVlRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIXZhbHVlRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdGRhdGFzZXQudmFsdWVba2V5XSA9IHZhbHVlRGF0YXNldC52YWx1ZTtcblx0XHRcdFx0fSBlbHNlIGlmICh2YWx1ZVNjaGVtYS5mYWxsYmFjayAhPT0gdm9pZCAwKSBkYXRhc2V0LnZhbHVlW2tleV0gPSBhd2FpdCAvKiBAX19QVVJFX18gKi8gZ2V0RmFsbGJhY2sodmFsdWVTY2hlbWEpO1xuXHRcdFx0XHRlbHNlIGlmICh2YWx1ZVNjaGVtYS50eXBlICE9PSBcImV4YWN0X29wdGlvbmFsXCIgJiYgdmFsdWVTY2hlbWEudHlwZSAhPT0gXCJvcHRpb25hbFwiICYmIHZhbHVlU2NoZW1hLnR5cGUgIT09IFwibnVsbGlzaFwiKSB7XG5cdFx0XHRcdFx0X2FkZElzc3VlKHRoaXMsIFwia2V5XCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7XG5cdFx0XHRcdFx0XHRpbnB1dDogdm9pZCAwLFxuXHRcdFx0XHRcdFx0ZXhwZWN0ZWQ6IGBcIiR7a2V5fVwiYCxcblx0XHRcdFx0XHRcdHBhdGg6IFt7XG5cdFx0XHRcdFx0XHRcdHR5cGU6IFwib2JqZWN0XCIsXG5cdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJrZXlcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IHZhbHVlJDFcblx0XHRcdFx0XHRcdH1dXG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIGJyZWFrO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmICghZGF0YXNldC5pc3N1ZXMgfHwgIWNvbmZpZyQxLmFib3J0RWFybHkpIGZvciAoY29uc3QgW2tleSwgdmFsdWUkMSwgdmFsdWVEYXRhc2V0XSBvZiByZXN0RGF0YXNldHMpIHtcblx0XHRcdFx0XHRpZiAodmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0Y29uc3QgcGF0aEl0ZW0gPSB7XG5cdFx0XHRcdFx0XHRcdHR5cGU6IFwib2JqZWN0XCIsXG5cdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0a2V5LFxuXHRcdFx0XHRcdFx0XHR2YWx1ZTogdmFsdWUkMVxuXHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRcdGZvciAoY29uc3QgaXNzdWUgb2YgdmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMgPSB2YWx1ZURhdGFzZXQuaXNzdWVzO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIHtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCF2YWx1ZURhdGFzZXQudHlwZWQpIGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRkYXRhc2V0LnZhbHVlW2tleV0gPSB2YWx1ZURhdGFzZXQudmFsdWU7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvb3B0aW9uYWwvb3B0aW9uYWwudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBvcHRpb25hbCh3cmFwcGVkLCBkZWZhdWx0Xykge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJvcHRpb25hbFwiLFxuXHRcdHJlZmVyZW5jZTogb3B0aW9uYWwsXG5cdFx0ZXhwZWN0czogYCgke3dyYXBwZWQuZXhwZWN0c30gfCB1bmRlZmluZWQpYCxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0d3JhcHBlZCxcblx0XHRkZWZhdWx0OiBkZWZhdWx0Xyxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgPT09IHZvaWQgMCkge1xuXHRcdFx0XHRpZiAodGhpcy5kZWZhdWx0ICE9PSB2b2lkIDApIGRhdGFzZXQudmFsdWUgPSAvKiBAX19QVVJFX18gKi8gZ2V0RGVmYXVsdCh0aGlzLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRcdGlmIChkYXRhc2V0LnZhbHVlID09PSB2b2lkIDApIHtcblx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHRoaXMud3JhcHBlZFtcIn5ydW5cIl0oZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvb3B0aW9uYWwvb3B0aW9uYWxBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIG9wdGlvbmFsQXN5bmMod3JhcHBlZCwgZGVmYXVsdF8pIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwib3B0aW9uYWxcIixcblx0XHRyZWZlcmVuY2U6IG9wdGlvbmFsQXN5bmMsXG5cdFx0ZXhwZWN0czogYCgke3dyYXBwZWQuZXhwZWN0c30gfCB1bmRlZmluZWQpYCxcblx0XHRhc3luYzogdHJ1ZSxcblx0XHR3cmFwcGVkLFxuXHRcdGRlZmF1bHQ6IGRlZmF1bHRfLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdGFzeW5jIFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRpZiAoZGF0YXNldC52YWx1ZSA9PT0gdm9pZCAwKSB7XG5cdFx0XHRcdGlmICh0aGlzLmRlZmF1bHQgIT09IHZvaWQgMCkgZGF0YXNldC52YWx1ZSA9IGF3YWl0IC8qIEBfX1BVUkVfXyAqLyBnZXREZWZhdWx0KHRoaXMsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgPT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gdGhpcy53cmFwcGVkW1wifnJ1blwiXShkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9waWNrbGlzdC9waWNrbGlzdC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHBpY2tsaXN0KG9wdGlvbnMsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJwaWNrbGlzdFwiLFxuXHRcdHJlZmVyZW5jZTogcGlja2xpc3QsXG5cdFx0ZXhwZWN0czogLyogQF9fUFVSRV9fICovIF9qb2luRXhwZWN0cyhvcHRpb25zLm1hcChfc3RyaW5naWZ5KSwgXCJ8XCIpLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRvcHRpb25zLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKHRoaXMub3B0aW9ucy5pbmNsdWRlcyhkYXRhc2V0LnZhbHVlKSkgZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9wcm9taXNlL3Byb21pc2UudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBwcm9taXNlKG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJwcm9taXNlXCIsXG5cdFx0cmVmZXJlbmNlOiBwcm9taXNlLFxuXHRcdGV4cGVjdHM6IFwiUHJvbWlzZVwiLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGlmIChkYXRhc2V0LnZhbHVlIGluc3RhbmNlb2YgUHJvbWlzZSkgZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9yZWNvcmQvcmVjb3JkLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gcmVjb3JkKGtleSwgdmFsdWUkMSwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcInJlY29yZFwiLFxuXHRcdHJlZmVyZW5jZTogcmVjb3JkLFxuXHRcdGV4cGVjdHM6IFwiT2JqZWN0XCIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdGtleSxcblx0XHR2YWx1ZTogdmFsdWUkMSxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGNvbnN0IGlucHV0ID0gZGF0YXNldC52YWx1ZTtcblx0XHRcdGlmIChpbnB1dCAmJiB0eXBlb2YgaW5wdXQgPT09IFwib2JqZWN0XCIpIHtcblx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRcdGRhdGFzZXQudmFsdWUgPSB7fTtcblx0XHRcdFx0Zm9yIChjb25zdCBlbnRyeUtleSBpbiBpbnB1dCkgaWYgKC8qIEBfX1BVUkVfXyAqLyBfaXNWYWxpZE9iamVjdEtleShpbnB1dCwgZW50cnlLZXkpKSB7XG5cdFx0XHRcdFx0Y29uc3QgZW50cnlWYWx1ZSA9IGlucHV0W2VudHJ5S2V5XTtcblx0XHRcdFx0XHRjb25zdCBrZXlEYXRhc2V0ID0gdGhpcy5rZXlbXCJ+cnVuXCJdKHsgdmFsdWU6IGVudHJ5S2V5IH0sIGNvbmZpZyQxKTtcblx0XHRcdFx0XHRpZiAoa2V5RGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdGNvbnN0IHBhdGhJdGVtID0ge1xuXHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwia2V5XCIsXG5cdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRrZXk6IGVudHJ5S2V5LFxuXHRcdFx0XHRcdFx0XHR2YWx1ZTogZW50cnlWYWx1ZVxuXHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRcdGZvciAoY29uc3QgaXNzdWUgb2Yga2V5RGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdFx0aXNzdWUucGF0aCA9IFtwYXRoSXRlbV07XG5cdFx0XHRcdFx0XHRcdGRhdGFzZXQuaXNzdWVzPy5wdXNoKGlzc3VlKTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmICghZGF0YXNldC5pc3N1ZXMpIGRhdGFzZXQuaXNzdWVzID0ga2V5RGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRjb25zdCB2YWx1ZURhdGFzZXQgPSB0aGlzLnZhbHVlW1wifnJ1blwiXSh7IHZhbHVlOiBlbnRyeVZhbHVlIH0sIGNvbmZpZyQxKTtcblx0XHRcdFx0XHRpZiAodmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0Y29uc3QgcGF0aEl0ZW0gPSB7XG5cdFx0XHRcdFx0XHRcdHR5cGU6IFwib2JqZWN0XCIsXG5cdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0a2V5OiBlbnRyeUtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IGVudHJ5VmFsdWVcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIHZhbHVlRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdFx0aWYgKGlzc3VlLnBhdGgpIGlzc3VlLnBhdGgudW5zaGlmdChwYXRoSXRlbSk7XG5cdFx0XHRcdFx0XHRcdGVsc2UgaXNzdWUucGF0aCA9IFtwYXRoSXRlbV07XG5cdFx0XHRcdFx0XHRcdGRhdGFzZXQuaXNzdWVzPy5wdXNoKGlzc3VlKTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmICghZGF0YXNldC5pc3N1ZXMpIGRhdGFzZXQuaXNzdWVzID0gdmFsdWVEYXRhc2V0Lmlzc3Vlcztcblx0XHRcdFx0XHRcdGlmIChjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmICgha2V5RGF0YXNldC50eXBlZCB8fCAhdmFsdWVEYXRhc2V0LnR5cGVkKSBkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0aWYgKGtleURhdGFzZXQudHlwZWQpIGRhdGFzZXQudmFsdWVba2V5RGF0YXNldC52YWx1ZV0gPSB2YWx1ZURhdGFzZXQudmFsdWU7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvcmVjb3JkL3JlY29yZEFzeW5jLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gcmVjb3JkQXN5bmMoa2V5LCB2YWx1ZSQxLCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwicmVjb3JkXCIsXG5cdFx0cmVmZXJlbmNlOiByZWNvcmRBc3luYyxcblx0XHRleHBlY3RzOiBcIk9iamVjdFwiLFxuXHRcdGFzeW5jOiB0cnVlLFxuXHRcdGtleSxcblx0XHR2YWx1ZTogdmFsdWUkMSxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0YXN5bmMgXCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGNvbnN0IGlucHV0ID0gZGF0YXNldC52YWx1ZTtcblx0XHRcdGlmIChpbnB1dCAmJiB0eXBlb2YgaW5wdXQgPT09IFwib2JqZWN0XCIpIHtcblx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRcdGRhdGFzZXQudmFsdWUgPSB7fTtcblx0XHRcdFx0Y29uc3QgZGF0YXNldHMgPSBhd2FpdCBQcm9taXNlLmFsbChPYmplY3QuZW50cmllcyhpbnB1dCkuZmlsdGVyKChba2V5JDFdKSA9PiAvKiBAX19QVVJFX18gKi8gX2lzVmFsaWRPYmplY3RLZXkoaW5wdXQsIGtleSQxKSkubWFwKChbZW50cnlLZXksIGVudHJ5VmFsdWVdKSA9PiBQcm9taXNlLmFsbChbXG5cdFx0XHRcdFx0ZW50cnlLZXksXG5cdFx0XHRcdFx0ZW50cnlWYWx1ZSxcblx0XHRcdFx0XHR0aGlzLmtleVtcIn5ydW5cIl0oeyB2YWx1ZTogZW50cnlLZXkgfSwgY29uZmlnJDEpLFxuXHRcdFx0XHRcdHRoaXMudmFsdWVbXCJ+cnVuXCJdKHsgdmFsdWU6IGVudHJ5VmFsdWUgfSwgY29uZmlnJDEpXG5cdFx0XHRcdF0pKSk7XG5cdFx0XHRcdGZvciAoY29uc3QgW2VudHJ5S2V5LCBlbnRyeVZhbHVlLCBrZXlEYXRhc2V0LCB2YWx1ZURhdGFzZXRdIG9mIGRhdGFzZXRzKSB7XG5cdFx0XHRcdFx0aWYgKGtleURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJvYmplY3RcIixcblx0XHRcdFx0XHRcdFx0b3JpZ2luOiBcImtleVwiLFxuXHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0a2V5OiBlbnRyeUtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IGVudHJ5VmFsdWVcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIGtleURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRcdGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0Lmlzc3Vlcz8ucHVzaChpc3N1ZSk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IGtleURhdGFzZXQuaXNzdWVzO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIHtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKHZhbHVlRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdGNvbnN0IHBhdGhJdGVtID0ge1xuXHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwidmFsdWVcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleTogZW50cnlLZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBlbnRyeVZhbHVlXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0Zm9yIChjb25zdCBpc3N1ZSBvZiB2YWx1ZURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChpc3N1ZS5wYXRoKSBpc3N1ZS5wYXRoLnVuc2hpZnQocGF0aEl0ZW0pO1xuXHRcdFx0XHRcdFx0XHRlbHNlIGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0Lmlzc3Vlcz8ucHVzaChpc3N1ZSk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IHZhbHVlRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIWtleURhdGFzZXQudHlwZWQgfHwgIXZhbHVlRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdGlmIChrZXlEYXRhc2V0LnR5cGVkKSBkYXRhc2V0LnZhbHVlW2tleURhdGFzZXQudmFsdWVdID0gdmFsdWVEYXRhc2V0LnZhbHVlO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL3NldC9zZXQudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBzZXQodmFsdWUkMSwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcInNldFwiLFxuXHRcdHJlZmVyZW5jZTogc2V0LFxuXHRcdGV4cGVjdHM6IFwiU2V0XCIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdHZhbHVlOiB2YWx1ZSQxLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKGlucHV0IGluc3RhbmNlb2YgU2V0KSB7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHRcdFx0Zm9yIChjb25zdCBpbnB1dFZhbHVlIG9mIGlucHV0KSB7XG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVEYXRhc2V0ID0gdGhpcy52YWx1ZVtcIn5ydW5cIl0oeyB2YWx1ZTogaW5wdXRWYWx1ZSB9LCBjb25maWckMSk7XG5cdFx0XHRcdFx0aWYgKHZhbHVlRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdGNvbnN0IHBhdGhJdGVtID0ge1xuXHRcdFx0XHRcdFx0XHR0eXBlOiBcInNldFwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwidmFsdWVcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleTogbnVsbCxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IGlucHV0VmFsdWVcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIHZhbHVlRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdFx0aWYgKGlzc3VlLnBhdGgpIGlzc3VlLnBhdGgudW5zaGlmdChwYXRoSXRlbSk7XG5cdFx0XHRcdFx0XHRcdGVsc2UgaXNzdWUucGF0aCA9IFtwYXRoSXRlbV07XG5cdFx0XHRcdFx0XHRcdGRhdGFzZXQuaXNzdWVzPy5wdXNoKGlzc3VlKTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmICghZGF0YXNldC5pc3N1ZXMpIGRhdGFzZXQuaXNzdWVzID0gdmFsdWVEYXRhc2V0Lmlzc3Vlcztcblx0XHRcdFx0XHRcdGlmIChjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmICghdmFsdWVEYXRhc2V0LnR5cGVkKSBkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0ZGF0YXNldC52YWx1ZS5hZGQodmFsdWVEYXRhc2V0LnZhbHVlKTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy9zZXQvc2V0QXN5bmMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBzZXRBc3luYyh2YWx1ZSQxLCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwic2V0XCIsXG5cdFx0cmVmZXJlbmNlOiBzZXRBc3luYyxcblx0XHRleHBlY3RzOiBcIlNldFwiLFxuXHRcdGFzeW5jOiB0cnVlLFxuXHRcdHZhbHVlOiB2YWx1ZSQxLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKGlucHV0IGluc3RhbmNlb2YgU2V0KSB7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHRcdFx0Y29uc3QgdmFsdWVEYXRhc2V0cyA9IGF3YWl0IFByb21pc2UuYWxsKFsuLi5pbnB1dF0ubWFwKGFzeW5jIChpbnB1dFZhbHVlKSA9PiBbaW5wdXRWYWx1ZSwgYXdhaXQgdGhpcy52YWx1ZVtcIn5ydW5cIl0oeyB2YWx1ZTogaW5wdXRWYWx1ZSB9LCBjb25maWckMSldKSk7XG5cdFx0XHRcdGZvciAoY29uc3QgW2lucHV0VmFsdWUsIHZhbHVlRGF0YXNldF0gb2YgdmFsdWVEYXRhc2V0cykge1xuXHRcdFx0XHRcdGlmICh2YWx1ZURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJzZXRcIixcblx0XHRcdFx0XHRcdFx0b3JpZ2luOiBcInZhbHVlXCIsXG5cdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRrZXk6IG51bGwsXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBpbnB1dFZhbHVlXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0Zm9yIChjb25zdCBpc3N1ZSBvZiB2YWx1ZURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChpc3N1ZS5wYXRoKSBpc3N1ZS5wYXRoLnVuc2hpZnQocGF0aEl0ZW0pO1xuXHRcdFx0XHRcdFx0XHRlbHNlIGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0Lmlzc3Vlcz8ucHVzaChpc3N1ZSk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IHZhbHVlRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIXZhbHVlRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdGRhdGFzZXQudmFsdWUuYWRkKHZhbHVlRGF0YXNldC52YWx1ZSk7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvc3RyaWN0T2JqZWN0L3N0cmljdE9iamVjdC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHN0cmljdE9iamVjdChlbnRyaWVzJDEsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJzdHJpY3Rfb2JqZWN0XCIsXG5cdFx0cmVmZXJlbmNlOiBzdHJpY3RPYmplY3QsXG5cdFx0ZXhwZWN0czogXCJPYmplY3RcIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0ZW50cmllczogZW50cmllcyQxLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKGlucHV0ICYmIHR5cGVvZiBpbnB1dCA9PT0gXCJvYmplY3RcIikge1xuXHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0ZGF0YXNldC52YWx1ZSA9IHt9O1xuXHRcdFx0XHRmb3IgKGNvbnN0IGtleSBpbiB0aGlzLmVudHJpZXMpIHtcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVNjaGVtYSA9IHRoaXMuZW50cmllc1trZXldO1xuXHRcdFx0XHRcdGlmIChrZXkgaW4gaW5wdXQgfHwgKHZhbHVlU2NoZW1hLnR5cGUgPT09IFwiZXhhY3Rfb3B0aW9uYWxcIiB8fCB2YWx1ZVNjaGVtYS50eXBlID09PSBcIm9wdGlvbmFsXCIgfHwgdmFsdWVTY2hlbWEudHlwZSA9PT0gXCJudWxsaXNoXCIpICYmIHZhbHVlU2NoZW1hLmRlZmF1bHQgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdFx0Y29uc3QgdmFsdWUkMSA9IGtleSBpbiBpbnB1dCA/IGlucHV0W2tleV0gOiAvKiBAX19QVVJFX18gKi8gZ2V0RGVmYXVsdCh2YWx1ZVNjaGVtYSk7XG5cdFx0XHRcdFx0XHRjb25zdCB2YWx1ZURhdGFzZXQgPSB2YWx1ZVNjaGVtYVtcIn5ydW5cIl0oeyB2YWx1ZTogdmFsdWUkMSB9LCBjb25maWckMSk7XG5cdFx0XHRcdFx0XHRpZiAodmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0XHR2YWx1ZTogdmFsdWUkMVxuXHRcdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIHZhbHVlRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0XHRlbHNlIGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRcdGRhdGFzZXQuaXNzdWVzPy5wdXNoKGlzc3VlKTtcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IHZhbHVlRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRcdGlmIChjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIXZhbHVlRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0ZGF0YXNldC52YWx1ZVtrZXldID0gdmFsdWVEYXRhc2V0LnZhbHVlO1xuXHRcdFx0XHRcdH0gZWxzZSBpZiAodmFsdWVTY2hlbWEuZmFsbGJhY2sgIT09IHZvaWQgMCkgZGF0YXNldC52YWx1ZVtrZXldID0gLyogQF9fUFVSRV9fICovIGdldEZhbGxiYWNrKHZhbHVlU2NoZW1hKTtcblx0XHRcdFx0XHRlbHNlIGlmICh2YWx1ZVNjaGVtYS50eXBlICE9PSBcImV4YWN0X29wdGlvbmFsXCIgJiYgdmFsdWVTY2hlbWEudHlwZSAhPT0gXCJvcHRpb25hbFwiICYmIHZhbHVlU2NoZW1hLnR5cGUgIT09IFwibnVsbGlzaFwiKSB7XG5cdFx0XHRcdFx0XHRfYWRkSXNzdWUodGhpcywgXCJrZXlcIiwgZGF0YXNldCwgY29uZmlnJDEsIHtcblx0XHRcdFx0XHRcdFx0aW5wdXQ6IHZvaWQgMCxcblx0XHRcdFx0XHRcdFx0ZXhwZWN0ZWQ6IGBcIiR7a2V5fVwiYCxcblx0XHRcdFx0XHRcdFx0cGF0aDogW3tcblx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJrZXlcIixcblx0XHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdFx0dmFsdWU6IGlucHV0W2tleV1cblx0XHRcdFx0XHRcdFx0fV1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIGJyZWFrO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzIHx8ICFjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBrZXkgaW4gaW5wdXQpIGlmICghKGtleSBpbiB0aGlzLmVudHJpZXMpKSB7XG5cdFx0XHRcdFx0XHRfYWRkSXNzdWUodGhpcywgXCJrZXlcIiwgZGF0YXNldCwgY29uZmlnJDEsIHtcblx0XHRcdFx0XHRcdFx0aW5wdXQ6IGtleSxcblx0XHRcdFx0XHRcdFx0ZXhwZWN0ZWQ6IFwibmV2ZXJcIixcblx0XHRcdFx0XHRcdFx0cGF0aDogW3tcblx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJrZXlcIixcblx0XHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdFx0dmFsdWU6IGlucHV0W2tleV1cblx0XHRcdFx0XHRcdFx0fV1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL3N0cmljdE9iamVjdC9zdHJpY3RPYmplY3RBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHN0cmljdE9iamVjdEFzeW5jKGVudHJpZXMkMSwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcInN0cmljdF9vYmplY3RcIixcblx0XHRyZWZlcmVuY2U6IHN0cmljdE9iamVjdEFzeW5jLFxuXHRcdGV4cGVjdHM6IFwiT2JqZWN0XCIsXG5cdFx0YXN5bmM6IHRydWUsXG5cdFx0ZW50cmllczogZW50cmllcyQxLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKGlucHV0ICYmIHR5cGVvZiBpbnB1dCA9PT0gXCJvYmplY3RcIikge1xuXHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0ZGF0YXNldC52YWx1ZSA9IHt9O1xuXHRcdFx0XHRjb25zdCB2YWx1ZURhdGFzZXRzID0gYXdhaXQgUHJvbWlzZS5hbGwoT2JqZWN0LmVudHJpZXModGhpcy5lbnRyaWVzKS5tYXAoYXN5bmMgKFtrZXksIHZhbHVlU2NoZW1hXSkgPT4ge1xuXHRcdFx0XHRcdGlmIChrZXkgaW4gaW5wdXQgfHwgKHZhbHVlU2NoZW1hLnR5cGUgPT09IFwiZXhhY3Rfb3B0aW9uYWxcIiB8fCB2YWx1ZVNjaGVtYS50eXBlID09PSBcIm9wdGlvbmFsXCIgfHwgdmFsdWVTY2hlbWEudHlwZSA9PT0gXCJudWxsaXNoXCIpICYmIHZhbHVlU2NoZW1hLmRlZmF1bHQgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdFx0Y29uc3QgdmFsdWUkMSA9IGtleSBpbiBpbnB1dCA/IGlucHV0W2tleV0gOiBhd2FpdCAvKiBAX19QVVJFX18gKi8gZ2V0RGVmYXVsdCh2YWx1ZVNjaGVtYSk7XG5cdFx0XHRcdFx0XHRyZXR1cm4gW1xuXHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlJDEsXG5cdFx0XHRcdFx0XHRcdHZhbHVlU2NoZW1hLFxuXHRcdFx0XHRcdFx0XHRhd2FpdCB2YWx1ZVNjaGVtYVtcIn5ydW5cIl0oeyB2YWx1ZTogdmFsdWUkMSB9LCBjb25maWckMSlcblx0XHRcdFx0XHRcdF07XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHJldHVybiBbXG5cdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRpbnB1dFtrZXldLFxuXHRcdFx0XHRcdFx0dmFsdWVTY2hlbWEsXG5cdFx0XHRcdFx0XHRudWxsXG5cdFx0XHRcdFx0XTtcblx0XHRcdFx0fSkpO1xuXHRcdFx0XHRmb3IgKGNvbnN0IFtrZXksIHZhbHVlJDEsIHZhbHVlU2NoZW1hLCB2YWx1ZURhdGFzZXRdIG9mIHZhbHVlRGF0YXNldHMpIGlmICh2YWx1ZURhdGFzZXQpIHtcblx0XHRcdFx0XHRpZiAodmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0Y29uc3QgcGF0aEl0ZW0gPSB7XG5cdFx0XHRcdFx0XHRcdHR5cGU6IFwib2JqZWN0XCIsXG5cdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0a2V5LFxuXHRcdFx0XHRcdFx0XHR2YWx1ZTogdmFsdWUkMVxuXHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRcdGZvciAoY29uc3QgaXNzdWUgb2YgdmFsdWVEYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMgPSB2YWx1ZURhdGFzZXQuaXNzdWVzO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIHtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCF2YWx1ZURhdGFzZXQudHlwZWQpIGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRkYXRhc2V0LnZhbHVlW2tleV0gPSB2YWx1ZURhdGFzZXQudmFsdWU7XG5cdFx0XHRcdH0gZWxzZSBpZiAodmFsdWVTY2hlbWEuZmFsbGJhY2sgIT09IHZvaWQgMCkgZGF0YXNldC52YWx1ZVtrZXldID0gYXdhaXQgLyogQF9fUFVSRV9fICovIGdldEZhbGxiYWNrKHZhbHVlU2NoZW1hKTtcblx0XHRcdFx0ZWxzZSBpZiAodmFsdWVTY2hlbWEudHlwZSAhPT0gXCJleGFjdF9vcHRpb25hbFwiICYmIHZhbHVlU2NoZW1hLnR5cGUgIT09IFwib3B0aW9uYWxcIiAmJiB2YWx1ZVNjaGVtYS50eXBlICE9PSBcIm51bGxpc2hcIikge1xuXHRcdFx0XHRcdF9hZGRJc3N1ZSh0aGlzLCBcImtleVwiLCBkYXRhc2V0LCBjb25maWckMSwge1xuXHRcdFx0XHRcdFx0aW5wdXQ6IHZvaWQgMCxcblx0XHRcdFx0XHRcdGV4cGVjdGVkOiBgXCIke2tleX1cImAsXG5cdFx0XHRcdFx0XHRwYXRoOiBbe1xuXHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwia2V5XCIsXG5cdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiB2YWx1ZSQxXG5cdFx0XHRcdFx0XHR9XVxuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdGlmIChjb25maWckMS5hYm9ydEVhcmx5KSBicmVhaztcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzIHx8ICFjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBrZXkgaW4gaW5wdXQpIGlmICghKGtleSBpbiB0aGlzLmVudHJpZXMpKSB7XG5cdFx0XHRcdFx0XHRfYWRkSXNzdWUodGhpcywgXCJrZXlcIiwgZGF0YXNldCwgY29uZmlnJDEsIHtcblx0XHRcdFx0XHRcdFx0aW5wdXQ6IGtleSxcblx0XHRcdFx0XHRcdFx0ZXhwZWN0ZWQ6IFwibmV2ZXJcIixcblx0XHRcdFx0XHRcdFx0cGF0aDogW3tcblx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJrZXlcIixcblx0XHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdFx0dmFsdWU6IGlucHV0W2tleV1cblx0XHRcdFx0XHRcdFx0fV1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL3N0cmljdFR1cGxlL3N0cmljdFR1cGxlLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gc3RyaWN0VHVwbGUoaXRlbXMsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJzdHJpY3RfdHVwbGVcIixcblx0XHRyZWZlcmVuY2U6IHN0cmljdFR1cGxlLFxuXHRcdGV4cGVjdHM6IFwiQXJyYXlcIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0aXRlbXMsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRjb25zdCBpbnB1dCA9IGRhdGFzZXQudmFsdWU7XG5cdFx0XHRpZiAoQXJyYXkuaXNBcnJheShpbnB1dCkpIHtcblx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRcdGRhdGFzZXQudmFsdWUgPSBbXTtcblx0XHRcdFx0Zm9yIChsZXQga2V5ID0gMDsga2V5IDwgdGhpcy5pdGVtcy5sZW5ndGg7IGtleSsrKSB7XG5cdFx0XHRcdFx0Y29uc3QgdmFsdWUkMSA9IGlucHV0W2tleV07XG5cdFx0XHRcdFx0Y29uc3QgaXRlbURhdGFzZXQgPSB0aGlzLml0ZW1zW2tleV1bXCJ+cnVuXCJdKHsgdmFsdWU6IHZhbHVlJDEgfSwgY29uZmlnJDEpO1xuXHRcdFx0XHRcdGlmIChpdGVtRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdGNvbnN0IHBhdGhJdGVtID0ge1xuXHRcdFx0XHRcdFx0XHR0eXBlOiBcImFycmF5XCIsXG5cdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0a2V5LFxuXHRcdFx0XHRcdFx0XHR2YWx1ZTogdmFsdWUkMVxuXHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRcdGZvciAoY29uc3QgaXNzdWUgb2YgaXRlbURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChpc3N1ZS5wYXRoKSBpc3N1ZS5wYXRoLnVuc2hpZnQocGF0aEl0ZW0pO1xuXHRcdFx0XHRcdFx0XHRlbHNlIGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0Lmlzc3Vlcz8ucHVzaChpc3N1ZSk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IGl0ZW1EYXRhc2V0Lmlzc3Vlcztcblx0XHRcdFx0XHRcdGlmIChjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmICghaXRlbURhdGFzZXQudHlwZWQpIGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRkYXRhc2V0LnZhbHVlLnB1c2goaXRlbURhdGFzZXQudmFsdWUpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmICghKGRhdGFzZXQuaXNzdWVzICYmIGNvbmZpZyQxLmFib3J0RWFybHkpICYmIHRoaXMuaXRlbXMubGVuZ3RoIDwgaW5wdXQubGVuZ3RoKSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7XG5cdFx0XHRcdFx0aW5wdXQ6IGlucHV0W3RoaXMuaXRlbXMubGVuZ3RoXSxcblx0XHRcdFx0XHRleHBlY3RlZDogXCJuZXZlclwiLFxuXHRcdFx0XHRcdHBhdGg6IFt7XG5cdFx0XHRcdFx0XHR0eXBlOiBcImFycmF5XCIsXG5cdFx0XHRcdFx0XHRvcmlnaW46IFwidmFsdWVcIixcblx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0a2V5OiB0aGlzLml0ZW1zLmxlbmd0aCxcblx0XHRcdFx0XHRcdHZhbHVlOiBpbnB1dFt0aGlzLml0ZW1zLmxlbmd0aF1cblx0XHRcdFx0XHR9XVxuXHRcdFx0XHR9KTtcblx0XHRcdH0gZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvc3RyaWN0VHVwbGUvc3RyaWN0VHVwbGVBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHN0cmljdFR1cGxlQXN5bmMoaXRlbXMsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJzdHJpY3RfdHVwbGVcIixcblx0XHRyZWZlcmVuY2U6IHN0cmljdFR1cGxlQXN5bmMsXG5cdFx0ZXhwZWN0czogXCJBcnJheVwiLFxuXHRcdGFzeW5jOiB0cnVlLFxuXHRcdGl0ZW1zLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkoaW5wdXQpKSB7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gW107XG5cdFx0XHRcdGNvbnN0IGl0ZW1EYXRhc2V0cyA9IGF3YWl0IFByb21pc2UuYWxsKHRoaXMuaXRlbXMubWFwKGFzeW5jIChpdGVtLCBrZXkpID0+IHtcblx0XHRcdFx0XHRjb25zdCB2YWx1ZSQxID0gaW5wdXRba2V5XTtcblx0XHRcdFx0XHRyZXR1cm4gW1xuXHRcdFx0XHRcdFx0a2V5LFxuXHRcdFx0XHRcdFx0dmFsdWUkMSxcblx0XHRcdFx0XHRcdGF3YWl0IGl0ZW1bXCJ+cnVuXCJdKHsgdmFsdWU6IHZhbHVlJDEgfSwgY29uZmlnJDEpXG5cdFx0XHRcdFx0XTtcblx0XHRcdFx0fSkpO1xuXHRcdFx0XHRmb3IgKGNvbnN0IFtrZXksIHZhbHVlJDEsIGl0ZW1EYXRhc2V0XSBvZiBpdGVtRGF0YXNldHMpIHtcblx0XHRcdFx0XHRpZiAoaXRlbURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJhcnJheVwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwidmFsdWVcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IHZhbHVlJDFcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIGl0ZW1EYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMgPSBpdGVtRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIWl0ZW1EYXRhc2V0LnR5cGVkKSBkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0ZGF0YXNldC52YWx1ZS5wdXNoKGl0ZW1EYXRhc2V0LnZhbHVlKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIShkYXRhc2V0Lmlzc3VlcyAmJiBjb25maWckMS5hYm9ydEVhcmx5KSAmJiB0aGlzLml0ZW1zLmxlbmd0aCA8IGlucHV0Lmxlbmd0aCkgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSwge1xuXHRcdFx0XHRcdGlucHV0OiBpbnB1dFt0aGlzLml0ZW1zLmxlbmd0aF0sXG5cdFx0XHRcdFx0ZXhwZWN0ZWQ6IFwibmV2ZXJcIixcblx0XHRcdFx0XHRwYXRoOiBbe1xuXHRcdFx0XHRcdFx0dHlwZTogXCJhcnJheVwiLFxuXHRcdFx0XHRcdFx0b3JpZ2luOiBcInZhbHVlXCIsXG5cdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdGtleTogdGhpcy5pdGVtcy5sZW5ndGgsXG5cdFx0XHRcdFx0XHR2YWx1ZTogaW5wdXRbdGhpcy5pdGVtcy5sZW5ndGhdXG5cdFx0XHRcdFx0fV1cblx0XHRcdFx0fSk7XG5cdFx0XHR9IGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL3N0cmluZy9zdHJpbmcudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBzdHJpbmcobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcInN0cmluZ1wiLFxuXHRcdHJlZmVyZW5jZTogc3RyaW5nLFxuXHRcdGV4cGVjdHM6IFwic3RyaW5nXCIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKHR5cGVvZiBkYXRhc2V0LnZhbHVlID09PSBcInN0cmluZ1wiKSBkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL3N5bWJvbC9zeW1ib2wudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBzeW1ib2wobWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcInN5bWJvbFwiLFxuXHRcdHJlZmVyZW5jZTogc3ltYm9sLFxuXHRcdGV4cGVjdHM6IFwic3ltYm9sXCIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKHR5cGVvZiBkYXRhc2V0LnZhbHVlID09PSBcInN5bWJvbFwiKSBkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL3R1cGxlL3R1cGxlLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdHVwbGUoaXRlbXMsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJ0dXBsZVwiLFxuXHRcdHJlZmVyZW5jZTogdHVwbGUsXG5cdFx0ZXhwZWN0czogXCJBcnJheVwiLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRpdGVtcyxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGNvbnN0IGlucHV0ID0gZGF0YXNldC52YWx1ZTtcblx0XHRcdGlmIChBcnJheS5pc0FycmF5KGlucHV0KSkge1xuXHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0ZGF0YXNldC52YWx1ZSA9IFtdO1xuXHRcdFx0XHRmb3IgKGxldCBrZXkgPSAwOyBrZXkgPCB0aGlzLml0ZW1zLmxlbmd0aDsga2V5KyspIHtcblx0XHRcdFx0XHRjb25zdCB2YWx1ZSQxID0gaW5wdXRba2V5XTtcblx0XHRcdFx0XHRjb25zdCBpdGVtRGF0YXNldCA9IHRoaXMuaXRlbXNba2V5XVtcIn5ydW5cIl0oeyB2YWx1ZTogdmFsdWUkMSB9LCBjb25maWckMSk7XG5cdFx0XHRcdFx0aWYgKGl0ZW1EYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0Y29uc3QgcGF0aEl0ZW0gPSB7XG5cdFx0XHRcdFx0XHRcdHR5cGU6IFwiYXJyYXlcIixcblx0XHRcdFx0XHRcdFx0b3JpZ2luOiBcInZhbHVlXCIsXG5cdFx0XHRcdFx0XHRcdGlucHV0LFxuXHRcdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiB2YWx1ZSQxXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0Zm9yIChjb25zdCBpc3N1ZSBvZiBpdGVtRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdFx0aWYgKGlzc3VlLnBhdGgpIGlzc3VlLnBhdGgudW5zaGlmdChwYXRoSXRlbSk7XG5cdFx0XHRcdFx0XHRcdGVsc2UgaXNzdWUucGF0aCA9IFtwYXRoSXRlbV07XG5cdFx0XHRcdFx0XHRcdGRhdGFzZXQuaXNzdWVzPy5wdXNoKGlzc3VlKTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmICghZGF0YXNldC5pc3N1ZXMpIGRhdGFzZXQuaXNzdWVzID0gaXRlbURhdGFzZXQuaXNzdWVzO1xuXHRcdFx0XHRcdFx0aWYgKGNvbmZpZyQxLmFib3J0RWFybHkpIHtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCFpdGVtRGF0YXNldC50eXBlZCkgZGF0YXNldC50eXBlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdGRhdGFzZXQudmFsdWUucHVzaChpdGVtRGF0YXNldC52YWx1ZSk7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvdHVwbGUvdHVwbGVBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHR1cGxlQXN5bmMoaXRlbXMsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJ0dXBsZVwiLFxuXHRcdHJlZmVyZW5jZTogdHVwbGVBc3luYyxcblx0XHRleHBlY3RzOiBcIkFycmF5XCIsXG5cdFx0YXN5bmM6IHRydWUsXG5cdFx0aXRlbXMsXG5cdFx0bWVzc2FnZTogbWVzc2FnZSQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9LFxuXHRcdGFzeW5jIFwifnJ1blwiKGRhdGFzZXQsIGNvbmZpZyQxKSB7XG5cdFx0XHRjb25zdCBpbnB1dCA9IGRhdGFzZXQudmFsdWU7XG5cdFx0XHRpZiAoQXJyYXkuaXNBcnJheShpbnB1dCkpIHtcblx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRcdGRhdGFzZXQudmFsdWUgPSBbXTtcblx0XHRcdFx0Y29uc3QgaXRlbURhdGFzZXRzID0gYXdhaXQgUHJvbWlzZS5hbGwodGhpcy5pdGVtcy5tYXAoYXN5bmMgKGl0ZW0sIGtleSkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IHZhbHVlJDEgPSBpbnB1dFtrZXldO1xuXHRcdFx0XHRcdHJldHVybiBbXG5cdFx0XHRcdFx0XHRrZXksXG5cdFx0XHRcdFx0XHR2YWx1ZSQxLFxuXHRcdFx0XHRcdFx0YXdhaXQgaXRlbVtcIn5ydW5cIl0oeyB2YWx1ZTogdmFsdWUkMSB9LCBjb25maWckMSlcblx0XHRcdFx0XHRdO1xuXHRcdFx0XHR9KSk7XG5cdFx0XHRcdGZvciAoY29uc3QgW2tleSwgdmFsdWUkMSwgaXRlbURhdGFzZXRdIG9mIGl0ZW1EYXRhc2V0cykge1xuXHRcdFx0XHRcdGlmIChpdGVtRGF0YXNldC5pc3N1ZXMpIHtcblx0XHRcdFx0XHRcdGNvbnN0IHBhdGhJdGVtID0ge1xuXHRcdFx0XHRcdFx0XHR0eXBlOiBcImFycmF5XCIsXG5cdFx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdFx0a2V5LFxuXHRcdFx0XHRcdFx0XHR2YWx1ZTogdmFsdWUkMVxuXHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRcdGZvciAoY29uc3QgaXNzdWUgb2YgaXRlbURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChpc3N1ZS5wYXRoKSBpc3N1ZS5wYXRoLnVuc2hpZnQocGF0aEl0ZW0pO1xuXHRcdFx0XHRcdFx0XHRlbHNlIGlzc3VlLnBhdGggPSBbcGF0aEl0ZW1dO1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0Lmlzc3Vlcz8ucHVzaChpc3N1ZSk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzKSBkYXRhc2V0Lmlzc3VlcyA9IGl0ZW1EYXRhc2V0Lmlzc3Vlcztcblx0XHRcdFx0XHRcdGlmIChjb25maWckMS5hYm9ydEVhcmx5KSB7XG5cdFx0XHRcdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmICghaXRlbURhdGFzZXQudHlwZWQpIGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRkYXRhc2V0LnZhbHVlLnB1c2goaXRlbURhdGFzZXQudmFsdWUpO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL3R1cGxlV2l0aFJlc3QvdHVwbGVXaXRoUmVzdC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHR1cGxlV2l0aFJlc3QoaXRlbXMsIHJlc3QsIG1lc3NhZ2UkMSkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2NoZW1hXCIsXG5cdFx0dHlwZTogXCJ0dXBsZV93aXRoX3Jlc3RcIixcblx0XHRyZWZlcmVuY2U6IHR1cGxlV2l0aFJlc3QsXG5cdFx0ZXhwZWN0czogXCJBcnJheVwiLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRpdGVtcyxcblx0XHRyZXN0LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkoaW5wdXQpKSB7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gW107XG5cdFx0XHRcdGZvciAobGV0IGtleSA9IDA7IGtleSA8IHRoaXMuaXRlbXMubGVuZ3RoOyBrZXkrKykge1xuXHRcdFx0XHRcdGNvbnN0IHZhbHVlJDEgPSBpbnB1dFtrZXldO1xuXHRcdFx0XHRcdGNvbnN0IGl0ZW1EYXRhc2V0ID0gdGhpcy5pdGVtc1trZXldW1wifnJ1blwiXSh7IHZhbHVlOiB2YWx1ZSQxIH0sIGNvbmZpZyQxKTtcblx0XHRcdFx0XHRpZiAoaXRlbURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJhcnJheVwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwidmFsdWVcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IHZhbHVlJDFcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIGl0ZW1EYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMgPSBpdGVtRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIWl0ZW1EYXRhc2V0LnR5cGVkKSBkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0ZGF0YXNldC52YWx1ZS5wdXNoKGl0ZW1EYXRhc2V0LnZhbHVlKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzIHx8ICFjb25maWckMS5hYm9ydEVhcmx5KSBmb3IgKGxldCBrZXkgPSB0aGlzLml0ZW1zLmxlbmd0aDsga2V5IDwgaW5wdXQubGVuZ3RoOyBrZXkrKykge1xuXHRcdFx0XHRcdGNvbnN0IHZhbHVlJDEgPSBpbnB1dFtrZXldO1xuXHRcdFx0XHRcdGNvbnN0IGl0ZW1EYXRhc2V0ID0gdGhpcy5yZXN0W1wifnJ1blwiXSh7IHZhbHVlOiB2YWx1ZSQxIH0sIGNvbmZpZyQxKTtcblx0XHRcdFx0XHRpZiAoaXRlbURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJhcnJheVwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwidmFsdWVcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IHZhbHVlJDFcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIGl0ZW1EYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMgPSBpdGVtRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIWl0ZW1EYXRhc2V0LnR5cGVkKSBkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0ZGF0YXNldC52YWx1ZS5wdXNoKGl0ZW1EYXRhc2V0LnZhbHVlKTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy90dXBsZVdpdGhSZXN0L3R1cGxlV2l0aFJlc3RBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHR1cGxlV2l0aFJlc3RBc3luYyhpdGVtcywgcmVzdCwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcInR1cGxlX3dpdGhfcmVzdFwiLFxuXHRcdHJlZmVyZW5jZTogdHVwbGVXaXRoUmVzdEFzeW5jLFxuXHRcdGV4cGVjdHM6IFwiQXJyYXlcIixcblx0XHRhc3luYzogdHJ1ZSxcblx0XHRpdGVtcyxcblx0XHRyZXN0LFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkoaW5wdXQpKSB7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0XHRkYXRhc2V0LnZhbHVlID0gW107XG5cdFx0XHRcdGNvbnN0IFtub3JtYWxEYXRhc2V0cywgcmVzdERhdGFzZXRzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtQcm9taXNlLmFsbCh0aGlzLml0ZW1zLm1hcChhc3luYyAoaXRlbSwga2V5KSA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgdmFsdWUkMSA9IGlucHV0W2tleV07XG5cdFx0XHRcdFx0cmV0dXJuIFtcblx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdHZhbHVlJDEsXG5cdFx0XHRcdFx0XHRhd2FpdCBpdGVtW1wifnJ1blwiXSh7IHZhbHVlOiB2YWx1ZSQxIH0sIGNvbmZpZyQxKVxuXHRcdFx0XHRcdF07XG5cdFx0XHRcdH0pKSwgUHJvbWlzZS5hbGwoaW5wdXQuc2xpY2UodGhpcy5pdGVtcy5sZW5ndGgpLm1hcChhc3luYyAodmFsdWUkMSwga2V5KSA9PiB7XG5cdFx0XHRcdFx0cmV0dXJuIFtcblx0XHRcdFx0XHRcdGtleSArIHRoaXMuaXRlbXMubGVuZ3RoLFxuXHRcdFx0XHRcdFx0dmFsdWUkMSxcblx0XHRcdFx0XHRcdGF3YWl0IHRoaXMucmVzdFtcIn5ydW5cIl0oeyB2YWx1ZTogdmFsdWUkMSB9LCBjb25maWckMSlcblx0XHRcdFx0XHRdO1xuXHRcdFx0XHR9KSldKTtcblx0XHRcdFx0Zm9yIChjb25zdCBba2V5LCB2YWx1ZSQxLCBpdGVtRGF0YXNldF0gb2Ygbm9ybWFsRGF0YXNldHMpIHtcblx0XHRcdFx0XHRpZiAoaXRlbURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJhcnJheVwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwidmFsdWVcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IHZhbHVlJDFcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIGl0ZW1EYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMgPSBpdGVtRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIWl0ZW1EYXRhc2V0LnR5cGVkKSBkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0ZGF0YXNldC52YWx1ZS5wdXNoKGl0ZW1EYXRhc2V0LnZhbHVlKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzIHx8ICFjb25maWckMS5hYm9ydEVhcmx5KSBmb3IgKGNvbnN0IFtrZXksIHZhbHVlJDEsIGl0ZW1EYXRhc2V0XSBvZiByZXN0RGF0YXNldHMpIHtcblx0XHRcdFx0XHRpZiAoaXRlbURhdGFzZXQuaXNzdWVzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBwYXRoSXRlbSA9IHtcblx0XHRcdFx0XHRcdFx0dHlwZTogXCJhcnJheVwiLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IFwidmFsdWVcIixcblx0XHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRcdGtleSxcblx0XHRcdFx0XHRcdFx0dmFsdWU6IHZhbHVlJDFcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlzc3VlIG9mIGl0ZW1EYXRhc2V0Lmlzc3Vlcykge1xuXHRcdFx0XHRcdFx0XHRpZiAoaXNzdWUucGF0aCkgaXNzdWUucGF0aC51bnNoaWZ0KHBhdGhJdGVtKTtcblx0XHRcdFx0XHRcdFx0ZWxzZSBpc3N1ZS5wYXRoID0gW3BhdGhJdGVtXTtcblx0XHRcdFx0XHRcdFx0ZGF0YXNldC5pc3N1ZXM/LnB1c2goaXNzdWUpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFkYXRhc2V0Lmlzc3VlcykgZGF0YXNldC5pc3N1ZXMgPSBpdGVtRGF0YXNldC5pc3N1ZXM7XG5cdFx0XHRcdFx0XHRpZiAoY29uZmlnJDEuYWJvcnRFYXJseSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIWl0ZW1EYXRhc2V0LnR5cGVkKSBkYXRhc2V0LnR5cGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0ZGF0YXNldC52YWx1ZS5wdXNoKGl0ZW1EYXRhc2V0LnZhbHVlKTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy91bmRlZmluZWQvdW5kZWZpbmVkLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdW5kZWZpbmVkXyhtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwidW5kZWZpbmVkXCIsXG5cdFx0cmVmZXJlbmNlOiB1bmRlZmluZWRfLFxuXHRcdGV4cGVjdHM6IFwidW5kZWZpbmVkXCIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgPT09IHZvaWQgMCkgZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy91bmRlZmluZWRhYmxlL3VuZGVmaW5lZGFibGUudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiB1bmRlZmluZWRhYmxlKHdyYXBwZWQsIGRlZmF1bHRfKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcInVuZGVmaW5lZGFibGVcIixcblx0XHRyZWZlcmVuY2U6IHVuZGVmaW5lZGFibGUsXG5cdFx0ZXhwZWN0czogYCgke3dyYXBwZWQuZXhwZWN0c30gfCB1bmRlZmluZWQpYCxcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0d3JhcHBlZCxcblx0XHRkZWZhdWx0OiBkZWZhdWx0Xyxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgPT09IHZvaWQgMCkge1xuXHRcdFx0XHRpZiAodGhpcy5kZWZhdWx0ICE9PSB2b2lkIDApIGRhdGFzZXQudmFsdWUgPSAvKiBAX19QVVJFX18gKi8gZ2V0RGVmYXVsdCh0aGlzLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRcdGlmIChkYXRhc2V0LnZhbHVlID09PSB2b2lkIDApIHtcblx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHRoaXMud3JhcHBlZFtcIn5ydW5cIl0oZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvdW5kZWZpbmVkYWJsZS91bmRlZmluZWRhYmxlQXN5bmMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiB1bmRlZmluZWRhYmxlQXN5bmMod3JhcHBlZCwgZGVmYXVsdF8pIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwidW5kZWZpbmVkYWJsZVwiLFxuXHRcdHJlZmVyZW5jZTogdW5kZWZpbmVkYWJsZUFzeW5jLFxuXHRcdGV4cGVjdHM6IGAoJHt3cmFwcGVkLmV4cGVjdHN9IHwgdW5kZWZpbmVkKWAsXG5cdFx0YXN5bmM6IHRydWUsXG5cdFx0d3JhcHBlZCxcblx0XHRkZWZhdWx0OiBkZWZhdWx0Xyxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgPT09IHZvaWQgMCkge1xuXHRcdFx0XHRpZiAodGhpcy5kZWZhdWx0ICE9PSB2b2lkIDApIGRhdGFzZXQudmFsdWUgPSBhd2FpdCAvKiBAX19QVVJFX18gKi8gZ2V0RGVmYXVsdCh0aGlzLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRcdGlmIChkYXRhc2V0LnZhbHVlID09PSB2b2lkIDApIHtcblx0XHRcdFx0XHRkYXRhc2V0LnR5cGVkID0gdHJ1ZTtcblx0XHRcdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHRoaXMud3JhcHBlZFtcIn5ydW5cIl0oZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvdW5pb24vdXRpbHMvX3N1Yklzc3Vlcy9fc3ViSXNzdWVzLnRzXG4vKipcbiogUmV0dXJucyB0aGUgc3ViIGlzc3VlcyBvZiB0aGUgcHJvdmlkZWQgZGF0YXNldHMgZm9yIHRoZSB1bmlvbiBpc3N1ZS5cbipcbiogQHBhcmFtIGRhdGFzZXRzIFRoZSBkYXRhc2V0cy5cbipcbiogQHJldHVybnMgVGhlIHN1YiBpc3N1ZXMuXG4qXG4qIEBpbnRlcm5hbFxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBfc3ViSXNzdWVzKGRhdGFzZXRzKSB7XG5cdGxldCBpc3N1ZXM7XG5cdGlmIChkYXRhc2V0cykgZm9yIChjb25zdCBkYXRhc2V0IG9mIGRhdGFzZXRzKSBpZiAoaXNzdWVzKSBmb3IgKGNvbnN0IGlzc3VlIG9mIGRhdGFzZXQuaXNzdWVzKSBpc3N1ZXMucHVzaChpc3N1ZSk7XG5cdGVsc2UgaXNzdWVzID0gZGF0YXNldC5pc3N1ZXM7XG5cdHJldHVybiBpc3N1ZXM7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL3VuaW9uL3VuaW9uLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdW5pb24ob3B0aW9ucywgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcInVuaW9uXCIsXG5cdFx0cmVmZXJlbmNlOiB1bmlvbixcblx0XHRleHBlY3RzOiAvKiBAX19QVVJFX18gKi8gX2pvaW5FeHBlY3RzKG9wdGlvbnMubWFwKChvcHRpb24pID0+IG9wdGlvbi5leHBlY3RzKSwgXCJ8XCIpLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRvcHRpb25zLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0bGV0IHZhbGlkRGF0YXNldDtcblx0XHRcdGxldCB0eXBlZERhdGFzZXRzO1xuXHRcdFx0bGV0IHVudHlwZWREYXRhc2V0cztcblx0XHRcdGZvciAoY29uc3Qgc2NoZW1hIG9mIHRoaXMub3B0aW9ucykge1xuXHRcdFx0XHRjb25zdCBvcHRpb25EYXRhc2V0ID0gc2NoZW1hW1wifnJ1blwiXSh7IHZhbHVlOiBkYXRhc2V0LnZhbHVlIH0sIGNvbmZpZyQxKTtcblx0XHRcdFx0aWYgKG9wdGlvbkRhdGFzZXQudHlwZWQpIGlmIChvcHRpb25EYXRhc2V0Lmlzc3VlcykgaWYgKHR5cGVkRGF0YXNldHMpIHR5cGVkRGF0YXNldHMucHVzaChvcHRpb25EYXRhc2V0KTtcblx0XHRcdFx0ZWxzZSB0eXBlZERhdGFzZXRzID0gW29wdGlvbkRhdGFzZXRdO1xuXHRcdFx0XHRlbHNlIHtcblx0XHRcdFx0XHR2YWxpZERhdGFzZXQgPSBvcHRpb25EYXRhc2V0O1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGVsc2UgaWYgKHVudHlwZWREYXRhc2V0cykgdW50eXBlZERhdGFzZXRzLnB1c2gob3B0aW9uRGF0YXNldCk7XG5cdFx0XHRcdGVsc2UgdW50eXBlZERhdGFzZXRzID0gW29wdGlvbkRhdGFzZXRdO1xuXHRcdFx0fVxuXHRcdFx0aWYgKHZhbGlkRGF0YXNldCkgcmV0dXJuIHZhbGlkRGF0YXNldDtcblx0XHRcdGlmICh0eXBlZERhdGFzZXRzKSB7XG5cdFx0XHRcdGlmICh0eXBlZERhdGFzZXRzLmxlbmd0aCA9PT0gMSkgcmV0dXJuIHR5cGVkRGF0YXNldHNbMF07XG5cdFx0XHRcdF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEsIHsgaXNzdWVzOiAvKiBAX19QVVJFX18gKi8gX3N1Yklzc3Vlcyh0eXBlZERhdGFzZXRzKSB9KTtcblx0XHRcdFx0ZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHR9IGVsc2UgaWYgKHVudHlwZWREYXRhc2V0cz8ubGVuZ3RoID09PSAxKSByZXR1cm4gdW50eXBlZERhdGFzZXRzWzBdO1xuXHRcdFx0ZWxzZSBfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IGlzc3VlczogLyogQF9fUFVSRV9fICovIF9zdWJJc3N1ZXModW50eXBlZERhdGFzZXRzKSB9KTtcblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3NjaGVtYXMvdW5pb24vdW5pb25Bc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHVuaW9uQXN5bmMob3B0aW9ucywgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcInVuaW9uXCIsXG5cdFx0cmVmZXJlbmNlOiB1bmlvbkFzeW5jLFxuXHRcdGV4cGVjdHM6IC8qIEBfX1BVUkVfXyAqLyBfam9pbkV4cGVjdHMob3B0aW9ucy5tYXAoKG9wdGlvbikgPT4gb3B0aW9uLmV4cGVjdHMpLCBcInxcIiksXG5cdFx0YXN5bmM6IHRydWUsXG5cdFx0b3B0aW9ucyxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0YXN5bmMgXCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGxldCB2YWxpZERhdGFzZXQ7XG5cdFx0XHRsZXQgdHlwZWREYXRhc2V0cztcblx0XHRcdGxldCB1bnR5cGVkRGF0YXNldHM7XG5cdFx0XHRmb3IgKGNvbnN0IHNjaGVtYSBvZiB0aGlzLm9wdGlvbnMpIHtcblx0XHRcdFx0Y29uc3Qgb3B0aW9uRGF0YXNldCA9IGF3YWl0IHNjaGVtYVtcIn5ydW5cIl0oeyB2YWx1ZTogZGF0YXNldC52YWx1ZSB9LCBjb25maWckMSk7XG5cdFx0XHRcdGlmIChvcHRpb25EYXRhc2V0LnR5cGVkKSBpZiAob3B0aW9uRGF0YXNldC5pc3N1ZXMpIGlmICh0eXBlZERhdGFzZXRzKSB0eXBlZERhdGFzZXRzLnB1c2gob3B0aW9uRGF0YXNldCk7XG5cdFx0XHRcdGVsc2UgdHlwZWREYXRhc2V0cyA9IFtvcHRpb25EYXRhc2V0XTtcblx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0dmFsaWREYXRhc2V0ID0gb3B0aW9uRGF0YXNldDtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0fVxuXHRcdFx0XHRlbHNlIGlmICh1bnR5cGVkRGF0YXNldHMpIHVudHlwZWREYXRhc2V0cy5wdXNoKG9wdGlvbkRhdGFzZXQpO1xuXHRcdFx0XHRlbHNlIHVudHlwZWREYXRhc2V0cyA9IFtvcHRpb25EYXRhc2V0XTtcblx0XHRcdH1cblx0XHRcdGlmICh2YWxpZERhdGFzZXQpIHJldHVybiB2YWxpZERhdGFzZXQ7XG5cdFx0XHRpZiAodHlwZWREYXRhc2V0cykge1xuXHRcdFx0XHRpZiAodHlwZWREYXRhc2V0cy5sZW5ndGggPT09IDEpIHJldHVybiB0eXBlZERhdGFzZXRzWzBdO1xuXHRcdFx0XHRfYWRkSXNzdWUodGhpcywgXCJ0eXBlXCIsIGRhdGFzZXQsIGNvbmZpZyQxLCB7IGlzc3VlczogLyogQF9fUFVSRV9fICovIF9zdWJJc3N1ZXModHlwZWREYXRhc2V0cykgfSk7XG5cdFx0XHRcdGRhdGFzZXQudHlwZWQgPSB0cnVlO1xuXHRcdFx0fSBlbHNlIGlmICh1bnR5cGVkRGF0YXNldHM/Lmxlbmd0aCA9PT0gMSkgcmV0dXJuIHVudHlwZWREYXRhc2V0c1swXTtcblx0XHRcdGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSwgeyBpc3N1ZXM6IC8qIEBfX1BVUkVfXyAqLyBfc3ViSXNzdWVzKHVudHlwZWREYXRhc2V0cykgfSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL3Vua25vd24vdW5rbm93bi50c1xuLyoqXG4qIENyZWF0ZXMgYSB1bmtub3duIHNjaGVtYS5cbipcbiogQHJldHVybnMgQSB1bmtub3duIHNjaGVtYS5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdW5rbm93bigpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwidW5rbm93blwiLFxuXHRcdHJlZmVyZW5jZTogdW5rbm93bixcblx0XHRleHBlY3RzOiBcInVua25vd25cIixcblx0XHRhc3luYzogZmFsc2UsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCkge1xuXHRcdFx0ZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL3ZhcmlhbnQvdmFyaWFudC50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHZhcmlhbnQoa2V5LCBvcHRpb25zLCBtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwidmFyaWFudFwiLFxuXHRcdHJlZmVyZW5jZTogdmFyaWFudCxcblx0XHRleHBlY3RzOiBcIk9iamVjdFwiLFxuXHRcdGFzeW5jOiBmYWxzZSxcblx0XHRrZXksXG5cdFx0b3B0aW9ucyxcblx0XHRtZXNzYWdlOiBtZXNzYWdlJDEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdGNvbnN0IGlucHV0ID0gZGF0YXNldC52YWx1ZTtcblx0XHRcdGlmIChpbnB1dCAmJiB0eXBlb2YgaW5wdXQgPT09IFwib2JqZWN0XCIpIHtcblx0XHRcdFx0bGV0IG91dHB1dERhdGFzZXQ7XG5cdFx0XHRcdGxldCBtYXhEaXNjcmltaW5hdG9yUHJpb3JpdHkgPSAwO1xuXHRcdFx0XHRsZXQgaW52YWxpZERpc2NyaW1pbmF0b3JLZXkgPSB0aGlzLmtleTtcblx0XHRcdFx0bGV0IGV4cGVjdGVkRGlzY3JpbWluYXRvcnMgPSBbXTtcblx0XHRcdFx0Y29uc3QgcGFyc2VPcHRpb25zID0gKHZhcmlhbnQkMSwgYWxsS2V5cykgPT4ge1xuXHRcdFx0XHRcdGZvciAoY29uc3Qgc2NoZW1hIG9mIHZhcmlhbnQkMS5vcHRpb25zKSB7XG5cdFx0XHRcdFx0XHRpZiAoc2NoZW1hLnR5cGUgPT09IFwidmFyaWFudFwiKSBwYXJzZU9wdGlvbnMoc2NoZW1hLCBuZXcgU2V0KGFsbEtleXMpLmFkZChzY2hlbWEua2V5KSk7XG5cdFx0XHRcdFx0XHRlbHNlIHtcblx0XHRcdFx0XHRcdFx0bGV0IGtleXNBcmVWYWxpZCA9IHRydWU7XG5cdFx0XHRcdFx0XHRcdGxldCBjdXJyZW50UHJpb3JpdHkgPSAwO1xuXHRcdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGN1cnJlbnRLZXkgb2YgYWxsS2V5cykge1xuXHRcdFx0XHRcdFx0XHRcdGNvbnN0IGRpc2NyaW1pbmF0b3JTY2hlbWEgPSBzY2hlbWEuZW50cmllc1tjdXJyZW50S2V5XTtcblx0XHRcdFx0XHRcdFx0XHRpZiAoY3VycmVudEtleSBpbiBpbnB1dCA/IGRpc2NyaW1pbmF0b3JTY2hlbWFbXCJ+cnVuXCJdKHtcblx0XHRcdFx0XHRcdFx0XHRcdHR5cGVkOiBmYWxzZSxcblx0XHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBpbnB1dFtjdXJyZW50S2V5XVxuXHRcdFx0XHRcdFx0XHRcdH0sIEFCT1JUX0VBUkxZX0NPTkZJRykuaXNzdWVzIDogZGlzY3JpbWluYXRvclNjaGVtYS50eXBlICE9PSBcImV4YWN0X29wdGlvbmFsXCIgJiYgZGlzY3JpbWluYXRvclNjaGVtYS50eXBlICE9PSBcIm9wdGlvbmFsXCIgJiYgZGlzY3JpbWluYXRvclNjaGVtYS50eXBlICE9PSBcIm51bGxpc2hcIikge1xuXHRcdFx0XHRcdFx0XHRcdFx0a2V5c0FyZVZhbGlkID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRcdFx0XHRpZiAoaW52YWxpZERpc2NyaW1pbmF0b3JLZXkgIT09IGN1cnJlbnRLZXkgJiYgKG1heERpc2NyaW1pbmF0b3JQcmlvcml0eSA8IGN1cnJlbnRQcmlvcml0eSB8fCBtYXhEaXNjcmltaW5hdG9yUHJpb3JpdHkgPT09IGN1cnJlbnRQcmlvcml0eSAmJiBjdXJyZW50S2V5IGluIGlucHV0ICYmICEoaW52YWxpZERpc2NyaW1pbmF0b3JLZXkgaW4gaW5wdXQpKSkge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRtYXhEaXNjcmltaW5hdG9yUHJpb3JpdHkgPSBjdXJyZW50UHJpb3JpdHk7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGludmFsaWREaXNjcmltaW5hdG9yS2V5ID0gY3VycmVudEtleTtcblx0XHRcdFx0XHRcdFx0XHRcdFx0ZXhwZWN0ZWREaXNjcmltaW5hdG9ycyA9IFtdO1xuXHRcdFx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHRcdFx0aWYgKGludmFsaWREaXNjcmltaW5hdG9yS2V5ID09PSBjdXJyZW50S2V5KSBleHBlY3RlZERpc2NyaW1pbmF0b3JzLnB1c2goc2NoZW1hLmVudHJpZXNbY3VycmVudEtleV0uZXhwZWN0cyk7XG5cdFx0XHRcdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRcdFx0Y3VycmVudFByaW9yaXR5Kys7XG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0aWYgKGtleXNBcmVWYWxpZCkge1xuXHRcdFx0XHRcdFx0XHRcdGNvbnN0IG9wdGlvbkRhdGFzZXQgPSBzY2hlbWFbXCJ+cnVuXCJdKHsgdmFsdWU6IGlucHV0IH0sIGNvbmZpZyQxKTtcblx0XHRcdFx0XHRcdFx0XHRpZiAoIW91dHB1dERhdGFzZXQgfHwgIW91dHB1dERhdGFzZXQudHlwZWQgJiYgb3B0aW9uRGF0YXNldC50eXBlZCkgb3V0cHV0RGF0YXNldCA9IG9wdGlvbkRhdGFzZXQ7XG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmIChvdXRwdXREYXRhc2V0ICYmICFvdXRwdXREYXRhc2V0Lmlzc3VlcykgYnJlYWs7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRwYXJzZU9wdGlvbnModGhpcywgbmV3IFNldChbdGhpcy5rZXldKSk7XG5cdFx0XHRcdGlmIChvdXRwdXREYXRhc2V0KSByZXR1cm4gb3V0cHV0RGF0YXNldDtcblx0XHRcdFx0X2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSwge1xuXHRcdFx0XHRcdGlucHV0OiBpbnB1dFtpbnZhbGlkRGlzY3JpbWluYXRvcktleV0sXG5cdFx0XHRcdFx0ZXhwZWN0ZWQ6IC8qIEBfX1BVUkVfXyAqLyBfam9pbkV4cGVjdHMoZXhwZWN0ZWREaXNjcmltaW5hdG9ycywgXCJ8XCIpLFxuXHRcdFx0XHRcdHBhdGg6IFt7XG5cdFx0XHRcdFx0XHR0eXBlOiBcIm9iamVjdFwiLFxuXHRcdFx0XHRcdFx0b3JpZ2luOiBcInZhbHVlXCIsXG5cdFx0XHRcdFx0XHRpbnB1dCxcblx0XHRcdFx0XHRcdGtleTogaW52YWxpZERpc2NyaW1pbmF0b3JLZXksXG5cdFx0XHRcdFx0XHR2YWx1ZTogaW5wdXRbaW52YWxpZERpc2NyaW1pbmF0b3JLZXldXG5cdFx0XHRcdFx0fV1cblx0XHRcdFx0fSk7XG5cdFx0XHR9IGVsc2UgX2FkZElzc3VlKHRoaXMsIFwidHlwZVwiLCBkYXRhc2V0LCBjb25maWckMSk7XG5cdFx0XHRyZXR1cm4gZGF0YXNldDtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zY2hlbWFzL3ZhcmlhbnQvdmFyaWFudEFzeW5jLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gdmFyaWFudEFzeW5jKGtleSwgb3B0aW9ucywgbWVzc2FnZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJzY2hlbWFcIixcblx0XHR0eXBlOiBcInZhcmlhbnRcIixcblx0XHRyZWZlcmVuY2U6IHZhcmlhbnRBc3luYyxcblx0XHRleHBlY3RzOiBcIk9iamVjdFwiLFxuXHRcdGFzeW5jOiB0cnVlLFxuXHRcdGtleSxcblx0XHRvcHRpb25zLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Y29uc3QgaW5wdXQgPSBkYXRhc2V0LnZhbHVlO1xuXHRcdFx0aWYgKGlucHV0ICYmIHR5cGVvZiBpbnB1dCA9PT0gXCJvYmplY3RcIikge1xuXHRcdFx0XHRsZXQgb3V0cHV0RGF0YXNldDtcblx0XHRcdFx0bGV0IG1heERpc2NyaW1pbmF0b3JQcmlvcml0eSA9IDA7XG5cdFx0XHRcdGxldCBpbnZhbGlkRGlzY3JpbWluYXRvcktleSA9IHRoaXMua2V5O1xuXHRcdFx0XHRsZXQgZXhwZWN0ZWREaXNjcmltaW5hdG9ycyA9IFtdO1xuXHRcdFx0XHRjb25zdCBwYXJzZU9wdGlvbnMgPSBhc3luYyAodmFyaWFudCQxLCBhbGxLZXlzKSA9PiB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBzY2hlbWEgb2YgdmFyaWFudCQxLm9wdGlvbnMpIHtcblx0XHRcdFx0XHRcdGlmIChzY2hlbWEudHlwZSA9PT0gXCJ2YXJpYW50XCIpIGF3YWl0IHBhcnNlT3B0aW9ucyhzY2hlbWEsIG5ldyBTZXQoYWxsS2V5cykuYWRkKHNjaGVtYS5rZXkpKTtcblx0XHRcdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdFx0XHRsZXQga2V5c0FyZVZhbGlkID0gdHJ1ZTtcblx0XHRcdFx0XHRcdFx0bGV0IGN1cnJlbnRQcmlvcml0eSA9IDA7XG5cdFx0XHRcdFx0XHRcdGZvciAoY29uc3QgY3VycmVudEtleSBvZiBhbGxLZXlzKSB7XG5cdFx0XHRcdFx0XHRcdFx0Y29uc3QgZGlzY3JpbWluYXRvclNjaGVtYSA9IHNjaGVtYS5lbnRyaWVzW2N1cnJlbnRLZXldO1xuXHRcdFx0XHRcdFx0XHRcdGlmIChjdXJyZW50S2V5IGluIGlucHV0ID8gKGF3YWl0IGRpc2NyaW1pbmF0b3JTY2hlbWFbXCJ+cnVuXCJdKHtcblx0XHRcdFx0XHRcdFx0XHRcdHR5cGVkOiBmYWxzZSxcblx0XHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBpbnB1dFtjdXJyZW50S2V5XVxuXHRcdFx0XHRcdFx0XHRcdH0sIEFCT1JUX0VBUkxZX0NPTkZJRykpLmlzc3VlcyA6IGRpc2NyaW1pbmF0b3JTY2hlbWEudHlwZSAhPT0gXCJleGFjdF9vcHRpb25hbFwiICYmIGRpc2NyaW1pbmF0b3JTY2hlbWEudHlwZSAhPT0gXCJvcHRpb25hbFwiICYmIGRpc2NyaW1pbmF0b3JTY2hlbWEudHlwZSAhPT0gXCJudWxsaXNoXCIpIHtcblx0XHRcdFx0XHRcdFx0XHRcdGtleXNBcmVWYWxpZCA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0XHRcdFx0aWYgKGludmFsaWREaXNjcmltaW5hdG9yS2V5ICE9PSBjdXJyZW50S2V5ICYmIChtYXhEaXNjcmltaW5hdG9yUHJpb3JpdHkgPCBjdXJyZW50UHJpb3JpdHkgfHwgbWF4RGlzY3JpbWluYXRvclByaW9yaXR5ID09PSBjdXJyZW50UHJpb3JpdHkgJiYgY3VycmVudEtleSBpbiBpbnB1dCAmJiAhKGludmFsaWREaXNjcmltaW5hdG9yS2V5IGluIGlucHV0KSkpIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0bWF4RGlzY3JpbWluYXRvclByaW9yaXR5ID0gY3VycmVudFByaW9yaXR5O1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRpbnZhbGlkRGlzY3JpbWluYXRvcktleSA9IGN1cnJlbnRLZXk7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGV4cGVjdGVkRGlzY3JpbWluYXRvcnMgPSBbXTtcblx0XHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0XHRcdGlmIChpbnZhbGlkRGlzY3JpbWluYXRvcktleSA9PT0gY3VycmVudEtleSkgZXhwZWN0ZWREaXNjcmltaW5hdG9ycy5wdXNoKHNjaGVtYS5lbnRyaWVzW2N1cnJlbnRLZXldLmV4cGVjdHMpO1xuXHRcdFx0XHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHRcdGN1cnJlbnRQcmlvcml0eSsrO1xuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRcdGlmIChrZXlzQXJlVmFsaWQpIHtcblx0XHRcdFx0XHRcdFx0XHRjb25zdCBvcHRpb25EYXRhc2V0ID0gYXdhaXQgc2NoZW1hW1wifnJ1blwiXSh7IHZhbHVlOiBpbnB1dCB9LCBjb25maWckMSk7XG5cdFx0XHRcdFx0XHRcdFx0aWYgKCFvdXRwdXREYXRhc2V0IHx8ICFvdXRwdXREYXRhc2V0LnR5cGVkICYmIG9wdGlvbkRhdGFzZXQudHlwZWQpIG91dHB1dERhdGFzZXQgPSBvcHRpb25EYXRhc2V0O1xuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAob3V0cHV0RGF0YXNldCAmJiAhb3V0cHV0RGF0YXNldC5pc3N1ZXMpIGJyZWFrO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fTtcblx0XHRcdFx0YXdhaXQgcGFyc2VPcHRpb25zKHRoaXMsIG5ldyBTZXQoW3RoaXMua2V5XSkpO1xuXHRcdFx0XHRpZiAob3V0cHV0RGF0YXNldCkgcmV0dXJuIG91dHB1dERhdGFzZXQ7XG5cdFx0XHRcdF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEsIHtcblx0XHRcdFx0XHRpbnB1dDogaW5wdXRbaW52YWxpZERpc2NyaW1pbmF0b3JLZXldLFxuXHRcdFx0XHRcdGV4cGVjdGVkOiAvKiBAX19QVVJFX18gKi8gX2pvaW5FeHBlY3RzKGV4cGVjdGVkRGlzY3JpbWluYXRvcnMsIFwifFwiKSxcblx0XHRcdFx0XHRwYXRoOiBbe1xuXHRcdFx0XHRcdFx0dHlwZTogXCJvYmplY3RcIixcblx0XHRcdFx0XHRcdG9yaWdpbjogXCJ2YWx1ZVwiLFxuXHRcdFx0XHRcdFx0aW5wdXQsXG5cdFx0XHRcdFx0XHRrZXk6IGludmFsaWREaXNjcmltaW5hdG9yS2V5LFxuXHRcdFx0XHRcdFx0dmFsdWU6IGlucHV0W2ludmFsaWREaXNjcmltaW5hdG9yS2V5XVxuXHRcdFx0XHRcdH1dXG5cdFx0XHRcdH0pO1xuXHRcdFx0fSBlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2NoZW1hcy92b2lkL3ZvaWQudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiB2b2lkXyhtZXNzYWdlJDEpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInNjaGVtYVwiLFxuXHRcdHR5cGU6IFwidm9pZFwiLFxuXHRcdHJlZmVyZW5jZTogdm9pZF8sXG5cdFx0ZXhwZWN0czogXCJ2b2lkXCIsXG5cdFx0YXN5bmM6IGZhbHNlLFxuXHRcdG1lc3NhZ2U6IG1lc3NhZ2UkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0aWYgKGRhdGFzZXQudmFsdWUgPT09IHZvaWQgMCkgZGF0YXNldC50eXBlZCA9IHRydWU7XG5cdFx0XHRlbHNlIF9hZGRJc3N1ZSh0aGlzLCBcInR5cGVcIiwgZGF0YXNldCwgY29uZmlnJDEpO1xuXHRcdFx0cmV0dXJuIGRhdGFzZXQ7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9rZXlvZi9rZXlvZi50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGtleW9mKHNjaGVtYSwgbWVzc2FnZSQxKSB7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gcGlja2xpc3QoT2JqZWN0LmtleXMoc2NoZW1hLmVudHJpZXMpLCBtZXNzYWdlJDEpO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9tZXNzYWdlL21lc3NhZ2UudHNcbi8qKlxuKiBDaGFuZ2VzIHRoZSBsb2NhbCBtZXNzYWdlIGNvbmZpZ3VyYXRpb24gb2YgYSBzY2hlbWEuXG4qXG4qIEBwYXJhbSBzY2hlbWEgVGhlIHNjaGVtYSB0byBjb25maWd1cmUuXG4qIEBwYXJhbSBtZXNzYWdlXyBUaGUgZXJyb3IgbWVzc2FnZS5cbipcbiogQHJldHVybnMgVGhlIGNvbmZpZ3VyZWQgc2NoZW1hLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBtZXNzYWdlKHNjaGVtYSwgbWVzc2FnZV8pIHtcblx0cmV0dXJuIHtcblx0XHQuLi5zY2hlbWEsXG5cdFx0Z2V0IFwifnN0YW5kYXJkXCIoKSB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIF9nZXRTdGFuZGFyZFByb3BzKHRoaXMpO1xuXHRcdH0sXG5cdFx0XCJ+cnVuXCIoZGF0YXNldCwgY29uZmlnJDEpIHtcblx0XHRcdHJldHVybiBzY2hlbWFbXCJ+cnVuXCJdKGRhdGFzZXQsIHtcblx0XHRcdFx0Li4uY29uZmlnJDEsXG5cdFx0XHRcdG1lc3NhZ2U6IG1lc3NhZ2VfXG5cdFx0XHR9KTtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXRob2RzL29taXQvb21pdC50c1xuLyoqXG4qIENyZWF0ZXMgYSBtb2RpZmllZCBjb3B5IG9mIGFuIG9iamVjdCBzY2hlbWEgdGhhdCBkb2VzIG5vdCBjb250YWluIHRoZVxuKiBzZWxlY3RlZCBlbnRyaWVzLlxuKlxuKiBAcGFyYW0gc2NoZW1hIFRoZSBzY2hlbWEgdG8gb21pdCBmcm9tLlxuKiBAcGFyYW0ga2V5cyBUaGUgc2VsZWN0ZWQgZW50cmllcy5cbipcbiogQHJldHVybnMgQW4gb2JqZWN0IHNjaGVtYS5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gb21pdChzY2hlbWEsIGtleXMpIHtcblx0Y29uc3QgZW50cmllcyQxID0geyAuLi5zY2hlbWEuZW50cmllcyB9O1xuXHRmb3IgKGNvbnN0IGtleSBvZiBrZXlzKSBkZWxldGUgZW50cmllcyQxW2tleV07XG5cdHJldHVybiB7XG5cdFx0Li4uc2NoZW1hLFxuXHRcdGVudHJpZXM6IGVudHJpZXMkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9wYXJzZS9wYXJzZS50c1xuLyoqXG4qIFBhcnNlcyBhbiB1bmtub3duIGlucHV0IGJhc2VkIG9uIGEgc2NoZW1hLlxuKlxuKiBAcGFyYW0gc2NoZW1hIFRoZSBzY2hlbWEgdG8gYmUgdXNlZC5cbiogQHBhcmFtIGlucHV0IFRoZSBpbnB1dCB0byBiZSBwYXJzZWQuXG4qIEBwYXJhbSBjb25maWcgVGhlIHBhcnNlIGNvbmZpZ3VyYXRpb24uXG4qXG4qIEByZXR1cm5zIFRoZSBwYXJzZWQgaW5wdXQuXG4qL1xuZnVuY3Rpb24gcGFyc2Uoc2NoZW1hLCBpbnB1dCwgY29uZmlnJDEpIHtcblx0Y29uc3QgZGF0YXNldCA9IHNjaGVtYVtcIn5ydW5cIl0oeyB2YWx1ZTogaW5wdXQgfSwgLyogQF9fUFVSRV9fICovIGdldEdsb2JhbENvbmZpZyhjb25maWckMSkpO1xuXHRpZiAoZGF0YXNldC5pc3N1ZXMpIHRocm93IG5ldyBWYWxpRXJyb3IoZGF0YXNldC5pc3N1ZXMpO1xuXHRyZXR1cm4gZGF0YXNldC52YWx1ZTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvcGFyc2UvcGFyc2VBc3luYy50c1xuLyoqXG4qIFBhcnNlcyBhbiB1bmtub3duIGlucHV0IGJhc2VkIG9uIGEgc2NoZW1hLlxuKlxuKiBAcGFyYW0gc2NoZW1hIFRoZSBzY2hlbWEgdG8gYmUgdXNlZC5cbiogQHBhcmFtIGlucHV0IFRoZSBpbnB1dCB0byBiZSBwYXJzZWQuXG4qIEBwYXJhbSBjb25maWcgVGhlIHBhcnNlIGNvbmZpZ3VyYXRpb24uXG4qXG4qIEByZXR1cm5zIFRoZSBwYXJzZWQgaW5wdXQuXG4qL1xuYXN5bmMgZnVuY3Rpb24gcGFyc2VBc3luYyhzY2hlbWEsIGlucHV0LCBjb25maWckMSkge1xuXHRjb25zdCBkYXRhc2V0ID0gYXdhaXQgc2NoZW1hW1wifnJ1blwiXSh7IHZhbHVlOiBpbnB1dCB9LCAvKiBAX19QVVJFX18gKi8gZ2V0R2xvYmFsQ29uZmlnKGNvbmZpZyQxKSk7XG5cdGlmIChkYXRhc2V0Lmlzc3VlcykgdGhyb3cgbmV3IFZhbGlFcnJvcihkYXRhc2V0Lmlzc3Vlcyk7XG5cdHJldHVybiBkYXRhc2V0LnZhbHVlO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9wYXJzZXIvcGFyc2VyLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gcGFyc2VyKHNjaGVtYSwgY29uZmlnJDEpIHtcblx0Y29uc3QgZnVuYyA9IChpbnB1dCkgPT4gcGFyc2Uoc2NoZW1hLCBpbnB1dCwgY29uZmlnJDEpO1xuXHRmdW5jLnNjaGVtYSA9IHNjaGVtYTtcblx0ZnVuYy5jb25maWcgPSBjb25maWckMTtcblx0cmV0dXJuIGZ1bmM7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXRob2RzL3BhcnNlci9wYXJzZXJBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHBhcnNlckFzeW5jKHNjaGVtYSwgY29uZmlnJDEpIHtcblx0Y29uc3QgZnVuYyA9IChpbnB1dCkgPT4gcGFyc2VBc3luYyhzY2hlbWEsIGlucHV0LCBjb25maWckMSk7XG5cdGZ1bmMuc2NoZW1hID0gc2NoZW1hO1xuXHRmdW5jLmNvbmZpZyA9IGNvbmZpZyQxO1xuXHRyZXR1cm4gZnVuYztcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvcGFydGlhbC9wYXJ0aWFsLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gcGFydGlhbChzY2hlbWEsIGtleXMpIHtcblx0Y29uc3QgZW50cmllcyQxID0ge307XG5cdGZvciAoY29uc3Qga2V5IGluIHNjaGVtYS5lbnRyaWVzKSBlbnRyaWVzJDFba2V5XSA9ICFrZXlzIHx8IGtleXMuaW5jbHVkZXMoa2V5KSA/IC8qIEBfX1BVUkVfXyAqLyBvcHRpb25hbChzY2hlbWEuZW50cmllc1trZXldKSA6IHNjaGVtYS5lbnRyaWVzW2tleV07XG5cdHJldHVybiB7XG5cdFx0Li4uc2NoZW1hLFxuXHRcdGVudHJpZXM6IGVudHJpZXMkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9wYXJ0aWFsL3BhcnRpYWxBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHBhcnRpYWxBc3luYyhzY2hlbWEsIGtleXMpIHtcblx0Y29uc3QgZW50cmllcyQxID0ge307XG5cdGZvciAoY29uc3Qga2V5IGluIHNjaGVtYS5lbnRyaWVzKSBlbnRyaWVzJDFba2V5XSA9ICFrZXlzIHx8IGtleXMuaW5jbHVkZXMoa2V5KSA/IC8qIEBfX1BVUkVfXyAqLyBvcHRpb25hbEFzeW5jKHNjaGVtYS5lbnRyaWVzW2tleV0pIDogc2NoZW1hLmVudHJpZXNba2V5XTtcblx0cmV0dXJuIHtcblx0XHQuLi5zY2hlbWEsXG5cdFx0ZW50cmllczogZW50cmllcyQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXRob2RzL3BpY2svcGljay50c1xuLyoqXG4qIENyZWF0ZXMgYSBtb2RpZmllZCBjb3B5IG9mIGFuIG9iamVjdCBzY2hlbWEgdGhhdCBjb250YWlucyBvbmx5IHRoZSBzZWxlY3RlZFxuKiBlbnRyaWVzLlxuKlxuKiBAcGFyYW0gc2NoZW1hIFRoZSBzY2hlbWEgdG8gcGljayBmcm9tLlxuKiBAcGFyYW0ga2V5cyBUaGUgc2VsZWN0ZWQgZW50cmllcy5cbipcbiogQHJldHVybnMgQW4gb2JqZWN0IHNjaGVtYS5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gcGljayhzY2hlbWEsIGtleXMpIHtcblx0Y29uc3QgZW50cmllcyQxID0ge307XG5cdGZvciAoY29uc3Qga2V5IG9mIGtleXMpIGVudHJpZXMkMVtrZXldID0gc2NoZW1hLmVudHJpZXNba2V5XTtcblx0cmV0dXJuIHtcblx0XHQuLi5zY2hlbWEsXG5cdFx0ZW50cmllczogZW50cmllcyQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXRob2RzL3BpcGUvcGlwZS50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHBpcGUoLi4ucGlwZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0Li4ucGlwZSQxWzBdLFxuXHRcdHBpcGU6IHBpcGUkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Zm9yIChjb25zdCBpdGVtIG9mIHBpcGUkMSkgaWYgKGl0ZW0ua2luZCAhPT0gXCJtZXRhZGF0YVwiKSB7XG5cdFx0XHRcdGlmIChkYXRhc2V0Lmlzc3VlcyAmJiAoaXRlbS5raW5kID09PSBcInNjaGVtYVwiIHx8IGl0ZW0ua2luZCA9PT0gXCJ0cmFuc2Zvcm1hdGlvblwiKSkge1xuXHRcdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzIHx8ICFjb25maWckMS5hYm9ydEVhcmx5ICYmICFjb25maWckMS5hYm9ydFBpcGVFYXJseSkgZGF0YXNldCA9IGl0ZW1bXCJ+cnVuXCJdKGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvcGlwZS9waXBlQXN5bmMudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBwaXBlQXN5bmMoLi4ucGlwZSQxKSB7XG5cdHJldHVybiB7XG5cdFx0Li4ucGlwZSQxWzBdLFxuXHRcdHBpcGU6IHBpcGUkMSxcblx0XHRhc3luYzogdHJ1ZSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fSxcblx0XHRhc3luYyBcIn5ydW5cIihkYXRhc2V0LCBjb25maWckMSkge1xuXHRcdFx0Zm9yIChjb25zdCBpdGVtIG9mIHBpcGUkMSkgaWYgKGl0ZW0ua2luZCAhPT0gXCJtZXRhZGF0YVwiKSB7XG5cdFx0XHRcdGlmIChkYXRhc2V0Lmlzc3VlcyAmJiAoaXRlbS5raW5kID09PSBcInNjaGVtYVwiIHx8IGl0ZW0ua2luZCA9PT0gXCJ0cmFuc2Zvcm1hdGlvblwiKSkge1xuXHRcdFx0XHRcdGRhdGFzZXQudHlwZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIWRhdGFzZXQuaXNzdWVzIHx8ICFjb25maWckMS5hYm9ydEVhcmx5ICYmICFjb25maWckMS5hYm9ydFBpcGVFYXJseSkgZGF0YXNldCA9IGF3YWl0IGl0ZW1bXCJ+cnVuXCJdKGRhdGFzZXQsIGNvbmZpZyQxKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBkYXRhc2V0O1xuXHRcdH1cblx0fTtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvcmVxdWlyZWQvcmVxdWlyZWQudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiByZXF1aXJlZChzY2hlbWEsIGFyZzIsIGFyZzMpIHtcblx0Y29uc3Qga2V5cyA9IEFycmF5LmlzQXJyYXkoYXJnMikgPyBhcmcyIDogdm9pZCAwO1xuXHRjb25zdCBtZXNzYWdlJDEgPSBBcnJheS5pc0FycmF5KGFyZzIpID8gYXJnMyA6IGFyZzI7XG5cdGNvbnN0IGVudHJpZXMkMSA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBzY2hlbWEuZW50cmllcykgZW50cmllcyQxW2tleV0gPSAha2V5cyB8fCBrZXlzLmluY2x1ZGVzKGtleSkgPyAvKiBAX19QVVJFX18gKi8gbm9uT3B0aW9uYWwoc2NoZW1hLmVudHJpZXNba2V5XSwgbWVzc2FnZSQxKSA6IHNjaGVtYS5lbnRyaWVzW2tleV07XG5cdHJldHVybiB7XG5cdFx0Li4uc2NoZW1hLFxuXHRcdGVudHJpZXM6IGVudHJpZXMkMSxcblx0XHRnZXQgXCJ+c3RhbmRhcmRcIigpIHtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gX2dldFN0YW5kYXJkUHJvcHModGhpcyk7XG5cdFx0fVxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9yZXF1aXJlZC9yZXF1aXJlZEFzeW5jLnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gcmVxdWlyZWRBc3luYyhzY2hlbWEsIGFyZzIsIGFyZzMpIHtcblx0Y29uc3Qga2V5cyA9IEFycmF5LmlzQXJyYXkoYXJnMikgPyBhcmcyIDogdm9pZCAwO1xuXHRjb25zdCBtZXNzYWdlJDEgPSBBcnJheS5pc0FycmF5KGFyZzIpID8gYXJnMyA6IGFyZzI7XG5cdGNvbnN0IGVudHJpZXMkMSA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBzY2hlbWEuZW50cmllcykgZW50cmllcyQxW2tleV0gPSAha2V5cyB8fCBrZXlzLmluY2x1ZGVzKGtleSkgPyAvKiBAX19QVVJFX18gKi8gbm9uT3B0aW9uYWxBc3luYyhzY2hlbWEuZW50cmllc1trZXldLCBtZXNzYWdlJDEpIDogc2NoZW1hLmVudHJpZXNba2V5XTtcblx0cmV0dXJuIHtcblx0XHQuLi5zY2hlbWEsXG5cdFx0ZW50cmllczogZW50cmllcyQxLFxuXHRcdGdldCBcIn5zdGFuZGFyZFwiKCkge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBfZ2V0U3RhbmRhcmRQcm9wcyh0aGlzKTtcblx0XHR9XG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXRob2RzL3NhZmVQYXJzZS9zYWZlUGFyc2UudHNcbi8qKlxuKiBQYXJzZXMgYW4gdW5rbm93biBpbnB1dCBiYXNlZCBvbiBhIHNjaGVtYS5cbipcbiogQHBhcmFtIHNjaGVtYSBUaGUgc2NoZW1hIHRvIGJlIHVzZWQuXG4qIEBwYXJhbSBpbnB1dCBUaGUgaW5wdXQgdG8gYmUgcGFyc2VkLlxuKiBAcGFyYW0gY29uZmlnIFRoZSBwYXJzZSBjb25maWd1cmF0aW9uLlxuKlxuKiBAcmV0dXJucyBUaGUgcGFyc2UgcmVzdWx0LlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBzYWZlUGFyc2Uoc2NoZW1hLCBpbnB1dCwgY29uZmlnJDEpIHtcblx0Y29uc3QgZGF0YXNldCA9IHNjaGVtYVtcIn5ydW5cIl0oeyB2YWx1ZTogaW5wdXQgfSwgLyogQF9fUFVSRV9fICovIGdldEdsb2JhbENvbmZpZyhjb25maWckMSkpO1xuXHRyZXR1cm4ge1xuXHRcdHR5cGVkOiBkYXRhc2V0LnR5cGVkLFxuXHRcdHN1Y2Nlc3M6ICFkYXRhc2V0Lmlzc3Vlcyxcblx0XHRvdXRwdXQ6IGRhdGFzZXQudmFsdWUsXG5cdFx0aXNzdWVzOiBkYXRhc2V0Lmlzc3Vlc1xuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9zYWZlUGFyc2Uvc2FmZVBhcnNlQXN5bmMudHNcbi8qKlxuKiBQYXJzZXMgYW4gdW5rbm93biBpbnB1dCBiYXNlZCBvbiBhIHNjaGVtYS5cbipcbiogQHBhcmFtIHNjaGVtYSBUaGUgc2NoZW1hIHRvIGJlIHVzZWQuXG4qIEBwYXJhbSBpbnB1dCBUaGUgaW5wdXQgdG8gYmUgcGFyc2VkLlxuKiBAcGFyYW0gY29uZmlnIFRoZSBwYXJzZSBjb25maWd1cmF0aW9uLlxuKlxuKiBAcmV0dXJucyBUaGUgcGFyc2UgcmVzdWx0LlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5hc3luYyBmdW5jdGlvbiBzYWZlUGFyc2VBc3luYyhzY2hlbWEsIGlucHV0LCBjb25maWckMSkge1xuXHRjb25zdCBkYXRhc2V0ID0gYXdhaXQgc2NoZW1hW1wifnJ1blwiXSh7IHZhbHVlOiBpbnB1dCB9LCAvKiBAX19QVVJFX18gKi8gZ2V0R2xvYmFsQ29uZmlnKGNvbmZpZyQxKSk7XG5cdHJldHVybiB7XG5cdFx0dHlwZWQ6IGRhdGFzZXQudHlwZWQsXG5cdFx0c3VjY2VzczogIWRhdGFzZXQuaXNzdWVzLFxuXHRcdG91dHB1dDogZGF0YXNldC52YWx1ZSxcblx0XHRpc3N1ZXM6IGRhdGFzZXQuaXNzdWVzXG5cdH07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXRob2RzL3NhZmVQYXJzZXIvc2FmZVBhcnNlci50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHNhZmVQYXJzZXIoc2NoZW1hLCBjb25maWckMSkge1xuXHRjb25zdCBmdW5jID0gKGlucHV0KSA9PiAvKiBAX19QVVJFX18gKi8gc2FmZVBhcnNlKHNjaGVtYSwgaW5wdXQsIGNvbmZpZyQxKTtcblx0ZnVuYy5zY2hlbWEgPSBzY2hlbWE7XG5cdGZ1bmMuY29uZmlnID0gY29uZmlnJDE7XG5cdHJldHVybiBmdW5jO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy9zYWZlUGFyc2VyL3NhZmVQYXJzZXJBc3luYy50c1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIHNhZmVQYXJzZXJBc3luYyhzY2hlbWEsIGNvbmZpZyQxKSB7XG5cdGNvbnN0IGZ1bmMgPSAoaW5wdXQpID0+IC8qIEBfX1BVUkVfXyAqLyBzYWZlUGFyc2VBc3luYyhzY2hlbWEsIGlucHV0LCBjb25maWckMSk7XG5cdGZ1bmMuc2NoZW1hID0gc2NoZW1hO1xuXHRmdW5jLmNvbmZpZyA9IGNvbmZpZyQxO1xuXHRyZXR1cm4gZnVuYztcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21ldGhvZHMvc3VtbWFyaXplL3N1bW1hcml6ZS50c1xuLyoqXG4qIFN1bW1hcml6ZSB0aGUgZXJyb3IgbWVzc2FnZXMgb2YgaXNzdWVzIGluIGEgcHJldHR5LXByaW50YWJsZSBtdWx0aS1saW5lIHN0cmluZy5cbipcbiogQHBhcmFtIGlzc3VlcyBUaGUgbGlzdCBvZiBpc3N1ZXMuXG4qXG4qIEByZXR1cm5zIEEgc3VtbWFyeSBvZiB0aGUgaXNzdWVzLlxuKlxuKiBAYmV0YVxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBzdW1tYXJpemUoaXNzdWVzKSB7XG5cdGxldCBzdW1tYXJ5ID0gXCJcIjtcblx0Zm9yIChjb25zdCBpc3N1ZSBvZiBpc3N1ZXMpIHtcblx0XHRpZiAoc3VtbWFyeSkgc3VtbWFyeSArPSBcIlxcblwiO1xuXHRcdHN1bW1hcnkgKz0gYMOXICR7aXNzdWUubWVzc2FnZX1gO1xuXHRcdGNvbnN0IGRvdFBhdGggPSAvKiBAX19QVVJFX18gKi8gZ2V0RG90UGF0aChpc3N1ZSk7XG5cdFx0aWYgKGRvdFBhdGgpIHN1bW1hcnkgKz0gYFxcbiAg4oaSIGF0ICR7ZG90UGF0aH1gO1xuXHR9XG5cdHJldHVybiBzdW1tYXJ5O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWV0aG9kcy91bndyYXAvdW53cmFwLnRzXG4vKipcbiogVW53cmFwcyB0aGUgd3JhcHBlZCBzY2hlbWEuXG4qXG4qIEBwYXJhbSBzY2hlbWEgVGhlIHNjaGVtYSB0byBiZSB1bndyYXBwZWQuXG4qXG4qIEByZXR1cm5zIFRoZSB1bndyYXBwZWQgc2NoZW1hLlxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiB1bndyYXAoc2NoZW1hKSB7XG5cdHJldHVybiBzY2hlbWEud3JhcHBlZDtcbn1cblxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBCQVNFNjRfUkVHRVgsIEJJQ19SRUdFWCwgQ1VJRDJfUkVHRVgsIERFQ0lNQUxfUkVHRVgsIERJR0lUU19SRUdFWCwgRE9NQUlOX1JFR0VYLCBFTUFJTF9SRUdFWCwgRU1PSklfUkVHRVgsIEhFWEFERUNJTUFMX1JFR0VYLCBIRVhfQ09MT1JfUkVHRVgsIElNRUlfUkVHRVgsIElQVjRfUkVHRVgsIElQVjZfUkVHRVgsIElQX1JFR0VYLCBJU09fREFURV9SRUdFWCwgSVNPX0RBVEVfVElNRV9SRUdFWCwgSVNPX0RBVEVfVElNRV9TRUNPTkRfUkVHRVgsIElTT19USU1FU1RBTVBfUkVHRVgsIElTT19USU1FX1JFR0VYLCBJU09fVElNRV9TRUNPTkRfUkVHRVgsIElTT19XRUVLX1JFR0VYLCBJU1JDX1JFR0VYLCBKV1NfQ09NUEFDVF9SRUdFWCwgTUFDNDhfUkVHRVgsIE1BQzY0X1JFR0VYLCBNQUNfUkVHRVgsIE5BTk9fSURfUkVHRVgsIE9DVEFMX1JFR0VYLCBSRkNfRU1BSUxfUkVHRVgsIFNMVUdfUkVHRVgsIFVMSURfUkVHRVgsIFVVSURfUkVHRVgsIFZhbGlFcnJvciwgX2FkZElzc3VlLCBfY2xvbmVEYXRhc2V0LCBfZm9ybWF0Q2FzZSwgX2dldEJ5dGVDb3VudCwgX2dldEdyYXBoZW1lQ291bnQsIF9nZXRMYXN0TWV0YWRhdGEsIF9nZXRTdGFuZGFyZFByb3BzLCBfZ2V0V29yZENvdW50LCBfaXNMdWhuQWxnbywgX2lzVmFsaWRPYmplY3RLZXksIF9qb2luRXhwZWN0cywgX3N0cmluZ2lmeSwgYW55LCBhcmdzLCBhcmdzQXN5bmMsIGFycmF5LCBhcnJheUFzeW5jLCBhc3NlcnQsIGF3YWl0QXN5bmMsIGJhc2U2NCwgYmljLCBiaWdpbnQsIGJsb2IsIGJvb2xlYW4sIGJyYW5kLCBieXRlcywgY2FjaGUsIGNhY2hlQXN5bmMsIGNoZWNrLCBjaGVja0FzeW5jLCBjaGVja0l0ZW1zLCBjaGVja0l0ZW1zQXN5bmMsIGNvbmZpZywgY3JlZGl0Q2FyZCwgY3VpZDIsIGN1c3RvbSwgY3VzdG9tQXN5bmMsIGRhdGUsIGRlY2ltYWwsIGRlbGV0ZUdsb2JhbENvbmZpZywgZGVsZXRlR2xvYmFsTWVzc2FnZSwgZGVsZXRlU2NoZW1hTWVzc2FnZSwgZGVsZXRlU3BlY2lmaWNNZXNzYWdlLCBkZXNjcmlwdGlvbiwgZGlnaXRzLCBkb21haW4sIGVtYWlsLCBlbW9qaSwgZW1wdHksIGVuZHNXaXRoLCBlbnRyaWVzLCBlbnRyaWVzRnJvbUxpc3QsIGVudHJpZXNGcm9tT2JqZWN0cywgZW51bV8gYXMgZW51bSwgZW51bV8sIGV2ZXJ5SXRlbSwgZXhhY3RPcHRpb25hbCwgZXhhY3RPcHRpb25hbEFzeW5jLCBleGFtcGxlcywgZXhjbHVkZXMsIGZhbGxiYWNrLCBmYWxsYmFja0FzeW5jLCBmaWxlLCBmaWx0ZXJJdGVtcywgZmluZEl0ZW0sIGZpbml0ZSwgZmxhdHRlbiwgZmxhdm9yLCBmb3J3YXJkLCBmb3J3YXJkQXN5bmMsIGZ1bmN0aW9uXyBhcyBmdW5jdGlvbiwgZnVuY3Rpb25fLCBnZXREZWZhdWx0LCBnZXREZWZhdWx0cywgZ2V0RGVmYXVsdHNBc3luYywgZ2V0RGVzY3JpcHRpb24sIGdldERvdFBhdGgsIGdldEV4YW1wbGVzLCBnZXRGYWxsYmFjaywgZ2V0RmFsbGJhY2tzLCBnZXRGYWxsYmFja3NBc3luYywgZ2V0R2xvYmFsQ29uZmlnLCBnZXRHbG9iYWxNZXNzYWdlLCBnZXRNZXRhZGF0YSwgZ2V0U2NoZW1hTWVzc2FnZSwgZ2V0U3BlY2lmaWNNZXNzYWdlLCBnZXRUaXRsZSwgZ3JhcGhlbWVzLCBndFZhbHVlLCBndWFyZCwgaGFzaCwgaGV4Q29sb3IsIGhleGFkZWNpbWFsLCBpbWVpLCBpbmNsdWRlcywgaW5zdGFuY2UsIGludGVnZXIsIGludGVyc2VjdCwgaW50ZXJzZWN0QXN5bmMsIGlwLCBpcHY0LCBpcHY2LCBpcywgaXNPZktpbmQsIGlzT2ZUeXBlLCBpc1ZhbGlFcnJvciwgaXNibiwgaXNvRGF0ZSwgaXNvRGF0ZVRpbWUsIGlzb0RhdGVUaW1lU2Vjb25kLCBpc29UaW1lLCBpc29UaW1lU2Vjb25kLCBpc29UaW1lc3RhbXAsIGlzb1dlZWssIGlzcmMsIGp3c0NvbXBhY3QsIGtleW9mLCBsYXp5LCBsYXp5QXN5bmMsIGxlbmd0aCwgbGl0ZXJhbCwgbG9vc2VPYmplY3QsIGxvb3NlT2JqZWN0QXN5bmMsIGxvb3NlVHVwbGUsIGxvb3NlVHVwbGVBc3luYywgbHRWYWx1ZSwgbWFjLCBtYWM0OCwgbWFjNjQsIG1hcCwgbWFwQXN5bmMsIG1hcEl0ZW1zLCBtYXhCeXRlcywgbWF4RW50cmllcywgbWF4R3JhcGhlbWVzLCBtYXhMZW5ndGgsIG1heFNpemUsIG1heFZhbHVlLCBtYXhXb3JkcywgbWVzc2FnZSwgbWV0YWRhdGEsIG1pbWVUeXBlLCBtaW5CeXRlcywgbWluRW50cmllcywgbWluR3JhcGhlbWVzLCBtaW5MZW5ndGgsIG1pblNpemUsIG1pblZhbHVlLCBtaW5Xb3JkcywgbXVsdGlwbGVPZiwgbmFuLCBuYW5vaWQsIG5ldmVyLCBub25FbXB0eSwgbm9uTnVsbGFibGUsIG5vbk51bGxhYmxlQXN5bmMsIG5vbk51bGxpc2gsIG5vbk51bGxpc2hBc3luYywgbm9uT3B0aW9uYWwsIG5vbk9wdGlvbmFsQXN5bmMsIG5vcm1hbGl6ZSwgbm90Qnl0ZXMsIG5vdEVudHJpZXMsIG5vdEdyYXBoZW1lcywgbm90TGVuZ3RoLCBub3RTaXplLCBub3RWYWx1ZSwgbm90VmFsdWVzLCBub3RXb3JkcywgbnVsbF8gYXMgbnVsbCwgbnVsbF8sIG51bGxhYmxlLCBudWxsYWJsZUFzeW5jLCBudWxsaXNoLCBudWxsaXNoQXN5bmMsIG51bWJlciwgb2JqZWN0LCBvYmplY3RBc3luYywgb2JqZWN0V2l0aFJlc3QsIG9iamVjdFdpdGhSZXN0QXN5bmMsIG9jdGFsLCBvbWl0LCBvcHRpb25hbCwgb3B0aW9uYWxBc3luYywgcGFyc2UsIHBhcnNlQXN5bmMsIHBhcnNlQm9vbGVhbiwgcGFyc2VKc29uLCBwYXJzZXIsIHBhcnNlckFzeW5jLCBwYXJ0aWFsLCBwYXJ0aWFsQXN5bmMsIHBhcnRpYWxDaGVjaywgcGFydGlhbENoZWNrQXN5bmMsIHBpY2ssIHBpY2tsaXN0LCBwaXBlLCBwaXBlQXN5bmMsIHByb21pc2UsIHJhd0NoZWNrLCByYXdDaGVja0FzeW5jLCByYXdUcmFuc2Zvcm0sIHJhd1RyYW5zZm9ybUFzeW5jLCByZWFkb25seSwgcmVjb3JkLCByZWNvcmRBc3luYywgcmVkdWNlSXRlbXMsIHJlZ2V4LCByZXF1aXJlZCwgcmVxdWlyZWRBc3luYywgcmV0dXJucywgcmV0dXJuc0FzeW5jLCByZmNFbWFpbCwgc2FmZUludGVnZXIsIHNhZmVQYXJzZSwgc2FmZVBhcnNlQXN5bmMsIHNhZmVQYXJzZXIsIHNhZmVQYXJzZXJBc3luYywgc2V0LCBzZXRBc3luYywgc2V0R2xvYmFsQ29uZmlnLCBzZXRHbG9iYWxNZXNzYWdlLCBzZXRTY2hlbWFNZXNzYWdlLCBzZXRTcGVjaWZpY01lc3NhZ2UsIHNpemUsIHNsdWcsIHNvbWVJdGVtLCBzb3J0SXRlbXMsIHN0YXJ0c1dpdGgsIHN0cmljdE9iamVjdCwgc3RyaWN0T2JqZWN0QXN5bmMsIHN0cmljdFR1cGxlLCBzdHJpY3RUdXBsZUFzeW5jLCBzdHJpbmcsIHN0cmluZ2lmeUpzb24sIHN1bW1hcml6ZSwgc3ltYm9sLCB0aXRsZSwgdG9CaWdpbnQsIHRvQm9vbGVhbiwgdG9DYW1lbENhc2UsIHRvRGF0ZSwgdG9LZWJhYkNhc2UsIHRvTG93ZXJDYXNlLCB0b01heFZhbHVlLCB0b01pblZhbHVlLCB0b051bWJlciwgdG9QYXNjYWxDYXNlLCB0b1NuYWtlQ2FzZSwgdG9TdHJpbmcsIHRvVXBwZXJDYXNlLCB0cmFuc2Zvcm0sIHRyYW5zZm9ybUFzeW5jLCB0cmltLCB0cmltRW5kLCB0cmltU3RhcnQsIHR1cGxlLCB0dXBsZUFzeW5jLCB0dXBsZVdpdGhSZXN0LCB0dXBsZVdpdGhSZXN0QXN5bmMsIHVsaWQsIHVuZGVmaW5lZF8gYXMgdW5kZWZpbmVkLCB1bmRlZmluZWRfLCB1bmRlZmluZWRhYmxlLCB1bmRlZmluZWRhYmxlQXN5bmMsIHVuaW9uLCB1bmlvbkFzeW5jLCB1bmtub3duLCB1bndyYXAsIHVybCwgdXVpZCwgdmFsdWUsIHZhbHVlcywgdmFyaWFudCwgdmFyaWFudEFzeW5jLCB2b2lkXyBhcyB2b2lkLCB2b2lkXywgd29yZHMgfTsiXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdLCJtYXBwaW5ncyI6IjtBQUNBLElBQUk7QUFDSixJQUFNLGlCQUFpQjtDQUN0QixNQUFNLEtBQUs7Q0FDWCxTQUFTLEtBQUs7Q0FDZCxZQUFZLEtBQUs7Q0FDakIsZ0JBQWdCLEtBQUs7QUFDdEI7Ozs7OztBQU1BLFNBQVMsZ0JBQWdCLFVBQVU7Q0FDbEMsVUFBVTtFQUNULEdBQUc7RUFDSCxHQUFHO0NBQ0o7QUFDRDs7Ozs7Ozs7O0FBU0EsU0FBUyxnQkFBZ0IsVUFBVTtDQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsT0FBTztDQUNsQyxPQUFPO0VBQ04sTUFBTSxVQUFVLFFBQVEsU0FBUztFQUNqQyxTQUFTLFVBQVU7RUFDbkIsWUFBWSxVQUFVLGNBQWMsU0FBUztFQUM3QyxnQkFBZ0IsVUFBVSxrQkFBa0IsU0FBUztDQUN0RDtBQUNEOzs7O0FBSUEsU0FBUyxxQkFBcUI7Q0FDN0IsVUFBVSxLQUFLO0FBQ2hCO0FBSUEsSUFBSTs7Ozs7OztBQU9KLFNBQVMsaUJBQWlCLFdBQVcsTUFBTTtDQUMxQyxJQUFJLENBQUMsU0FBUywwQkFBMEIsSUFBSSxJQUFJO0NBQ2hELFFBQVEsSUFBSSxNQUFNLFNBQVM7QUFDNUI7Ozs7Ozs7OztBQVNBLFNBQVMsaUJBQWlCLE1BQU07Q0FDL0IsT0FBTyxTQUFTLElBQUksSUFBSTtBQUN6Qjs7Ozs7O0FBTUEsU0FBUyxvQkFBb0IsTUFBTTtDQUNsQyxTQUFTLE9BQU8sSUFBSTtBQUNyQjtBQUlBLElBQUk7Ozs7Ozs7QUFPSixTQUFTLGlCQUFpQixXQUFXLE1BQU07Q0FDMUMsSUFBSSxDQUFDLFNBQVMsMEJBQTBCLElBQUksSUFBSTtDQUNoRCxRQUFRLElBQUksTUFBTSxTQUFTO0FBQzVCOzs7Ozs7Ozs7QUFTQSxTQUFTLGlCQUFpQixNQUFNO0NBQy9CLE9BQU8sU0FBUyxJQUFJLElBQUk7QUFDekI7Ozs7OztBQU1BLFNBQVMsb0JBQW9CLE1BQU07Q0FDbEMsU0FBUyxPQUFPLElBQUk7QUFDckI7QUFJQSxJQUFJOzs7Ozs7OztBQVFKLFNBQVMsbUJBQW1CLFdBQVcsV0FBVyxNQUFNO0NBQ3ZELElBQUksQ0FBQyxTQUFTLDBCQUEwQixJQUFJLElBQUk7Q0FDaEQsSUFBSSxDQUFDLFFBQVEsSUFBSSxTQUFTLEdBQUcsUUFBUSxJQUFJLDJCQUEyQixJQUFJLElBQUksQ0FBQztDQUM3RSxRQUFRLElBQUksU0FBUyxDQUFDLENBQUMsSUFBSSxNQUFNLFNBQVM7QUFDM0M7Ozs7Ozs7Ozs7QUFVQSxTQUFTLG1CQUFtQixXQUFXLE1BQU07Q0FDNUMsT0FBTyxTQUFTLElBQUksU0FBUyxDQUFDLEVBQUUsSUFBSSxJQUFJO0FBQ3pDOzs7Ozs7O0FBT0EsU0FBUyxzQkFBc0IsV0FBVyxNQUFNO0NBQy9DLFNBQVMsSUFBSSxTQUFTLENBQUMsRUFBRSxPQUFPLElBQUk7QUFDckM7Ozs7Ozs7Ozs7O0FBY0EsU0FBUyxXQUFXLE9BQU87Q0FDMUIsTUFBTSxPQUFPLE9BQU87Q0FDcEIsSUFBSSxTQUFTLFVBQVUsT0FBTyxJQUFJLE1BQU07Q0FDeEMsSUFBSSxTQUFTLFlBQVksU0FBUyxZQUFZLFNBQVMsV0FBVyxPQUFPLEdBQUc7Q0FDNUUsSUFBSSxTQUFTLFlBQVksU0FBUyxZQUFZLFFBQVEsU0FBUyxPQUFPLGVBQWUsS0FBSyxDQUFDLEVBQUUsYUFBYSxTQUFTO0NBQ25ILE9BQU87QUFDUjs7Ozs7Ozs7Ozs7O0FBZUEsU0FBUyxVQUFVLFNBQVMsT0FBTyxTQUFTLFVBQVUsT0FBTztDQUM1RCxNQUFNLFFBQVEsU0FBUyxXQUFXLFFBQVEsTUFBTSxRQUFRLFFBQVE7Q0FDaEUsTUFBTSxXQUFXLE9BQU8sWUFBWSxRQUFRLFdBQVc7Q0FDdkQsTUFBTSxXQUFXLE9BQU8sWUFBNEIsMkJBQVcsS0FBSztDQUNwRSxNQUFNLFFBQVE7RUFDYixNQUFNLFFBQVE7RUFDZCxNQUFNLFFBQVE7RUFDZDtFQUNBO0VBQ0E7RUFDQSxTQUFTLFdBQVcsTUFBTSxJQUFJLFdBQVcsWUFBWSxTQUFTLFVBQVUsSUFBSSxVQUFVO0VBQ3RGLGFBQWEsUUFBUTtFQUNyQixNQUFNLE9BQU87RUFDYixRQUFRLE9BQU87RUFDZixNQUFNLFNBQVM7RUFDZixZQUFZLFNBQVM7RUFDckIsZ0JBQWdCLFNBQVM7Q0FDMUI7Q0FDQSxNQUFNLFdBQVcsUUFBUSxTQUFTO0NBQ2xDLE1BQU0sWUFBWSxPQUFPLFdBQVcsUUFBUSxXQUEyQixtQ0FBbUIsUUFBUSxXQUFXLE1BQU0sSUFBSSxNQUFNLFdBQTJCLGlDQUFpQixNQUFNLElBQUksSUFBSSxTQUFTLFNBQVMsV0FBMkIsaUNBQWlCLE1BQU0sSUFBSTtDQUMvUCxJQUFJLGNBQWMsS0FBSyxHQUFHLE1BQU0sVUFBVSxPQUFPLGNBQWMsYUFBYSxVQUFVLEtBQUssSUFBSTtDQUMvRixJQUFJLFVBQVUsUUFBUSxRQUFRO0NBQzlCLElBQUksUUFBUSxRQUFRLFFBQVEsT0FBTyxLQUFLLEtBQUs7TUFDeEMsUUFBUSxTQUFTLENBQUMsS0FBSztBQUM3Qjs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsU0FBUyxjQUFjLFNBQVM7Q0FDL0IsT0FBTztFQUNOLE9BQU8sUUFBUTtFQUNmLE9BQU8sUUFBUTtFQUNmLFFBQVEsUUFBUSxVQUFVLENBQUMsR0FBRyxRQUFRLE1BQU07Q0FDN0M7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBOEJBLFNBQVMsWUFBWSxPQUFPLFdBQVcsVUFBVSxTQUFTO0NBQ3pELElBQUksU0FBUztDQUNiLElBQUksWUFBWTtDQUNoQixJQUFJLFFBQVE7Q0FDWixJQUFJLE9BQU87Q0FDWCxJQUFJLFdBQVc7Q0FDZixNQUFNLFNBQVMsUUFBUTtFQUN0QixJQUFJLE1BQU0sT0FBTztHQUNoQixJQUFJLE9BQU8sTUFBTSxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsWUFBWTtHQUMvQyxJQUFJLFlBQVksV0FBVyxTQUFTO0lBQ25DLE1BQU0sWUFBWSxLQUFLLFdBQVcsQ0FBQztJQUNuQyxJQUFJLGFBQWEsTUFBTSxhQUFhLEtBQUssT0FBTyxPQUFPLGFBQWEsWUFBWSxFQUFFLElBQUksS0FBSyxNQUFNLENBQUM7U0FDN0Y7S0FDSixNQUFNLFVBQVUsYUFBYSxTQUFTLGFBQWEsUUFBUSxJQUFJO0tBQy9ELE9BQU8sS0FBSyxNQUFNLEdBQUcsT0FBTyxDQUFDLENBQUMsWUFBWSxJQUFJLEtBQUssTUFBTSxPQUFPO0lBQ2pFO0dBQ0Q7R0FDQSxVQUFVLFlBQVksT0FBTyxZQUFZO0dBQ3pDLFlBQVk7RUFDYjtDQUNEO0NBQ0EsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLE1BQU0sUUFBUSxTQUFTO0VBQ2xELE1BQU0sT0FBTyxNQUFNLFdBQVcsS0FBSztFQUNuQyxJQUFJO0VBQ0osSUFBSSxTQUFTLE1BQU0sU0FBUyxLQUFLLFNBQVMsTUFBTSxTQUFTLE1BQU0sU0FBUyxNQUFNLFNBQVMsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0dBQ3hILE1BQU0sS0FBSztHQUNYLFFBQVEsUUFBUTtHQUNoQixPQUFPO0VBQ1IsT0FBTyxJQUFJLE9BQU8sS0FBSyxPQUFPLFFBQVEsTUFBTSxRQUFRLEtBQUssSUFBSSxRQUFRLE1BQU0sUUFBUSxNQUFNLElBQUk7T0FDeEY7R0FDSixNQUFNLE9BQU8sTUFBTTtHQUNuQixNQUFNLFlBQVksS0FBSyxZQUFZO0dBQ25DLE9BQU8sY0FBYyxLQUFLLFlBQVksSUFBSSxJQUFJLFNBQVMsWUFBWSxJQUFJO0VBQ3hFO0VBQ0EsSUFBSSxTQUFTLE1BQU0sU0FBUyxLQUFLLFNBQVMsTUFBTSxRQUFRLE9BQU87R0FDOUQsTUFBTSxLQUFLO0dBQ1gsUUFBUTtFQUNULE9BQU8sSUFBSSxTQUFTLEtBQUssU0FBUyxLQUFLLGFBQWEsS0FBSyxRQUFRLElBQUksT0FBTztHQUMzRSxNQUFNLFFBQVEsQ0FBQztHQUNmLFFBQVEsUUFBUTtFQUNqQjtFQUNBLFdBQVc7RUFDWCxPQUFPO0NBQ1I7Q0FDQSxNQUFNLE1BQU0sTUFBTTtDQUNsQixPQUFPO0FBQ1I7QUFJQSxJQUFJOzs7Ozs7Ozs7OztBQVdKLFNBQVMsY0FBYyxPQUFPO0NBQzdCLElBQUksQ0FBQyxhQUFhLGNBQWMsSUFBSSxZQUFZO0NBQ2hELE9BQU8sWUFBWSxPQUFPLEtBQUssQ0FBQyxDQUFDO0FBQ2xDO0FBSUEsSUFBSTs7Ozs7Ozs7Ozs7QUFXSixTQUFTLGtCQUFrQixPQUFPO0NBQ2pDLElBQUksQ0FBQyxXQUFXLFlBQVksSUFBSSxLQUFLLFVBQVU7Q0FDL0MsTUFBTSxXQUFXLFVBQVUsUUFBUSxLQUFLO0NBQ3hDLElBQUksUUFBUTtDQUNaLEtBQUssTUFBTSxLQUFLLFVBQVU7Q0FDMUIsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7O0FBZ0JBLFNBQVMsaUJBQWlCLFFBQVEsTUFBTTtDQUN2QyxJQUFJLFVBQVUsUUFBUTtFQUNyQixNQUFNLGdCQUFnQixDQUFDO0VBQ3ZCLEtBQUssSUFBSSxRQUFRLE9BQU8sS0FBSyxTQUFTLEdBQUcsU0FBUyxHQUFHLFNBQVM7R0FDN0QsTUFBTSxPQUFPLE9BQU8sS0FBSztHQUN6QixJQUFJLEtBQUssU0FBUyxZQUFZLFVBQVUsTUFBTSxjQUFjLEtBQUssSUFBSTtRQUNoRSxJQUFJLEtBQUssU0FBUyxjQUFjLEtBQUssU0FBUyxNQUFNLE9BQU8sS0FBSztFQUN0RTtFQUNBLEtBQUssTUFBTSxnQkFBZ0IsZUFBZTtHQUN6QyxNQUFNLFNBQXlCLGlDQUFpQixjQUFjLElBQUk7R0FDbEUsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPO0VBQy9CO0NBQ0Q7QUFDRDtBQUlBLElBQU0saUNBQWlDLElBQUksUUFBUTs7Ozs7Ozs7O0FBU25ELFNBQVMsa0JBQWtCLFNBQVM7Q0FDbkMsSUFBSSxTQUFTLGVBQWUsSUFBSSxPQUFPO0NBQ3ZDLElBQUksQ0FBQyxRQUFRO0VBQ1osU0FBUztHQUNSLFNBQVM7R0FDVCxRQUFRO0dBQ1IsU0FBUyxTQUFTO0lBQ2pCLE9BQU8sUUFBUSxPQUFPLENBQUMsRUFBRSxPQUFPLFFBQVEsR0FBbUIsZ0NBQWdCLENBQUM7R0FDN0U7RUFDRDtFQUNBLGVBQWUsSUFBSSxTQUFTLE1BQU07Q0FDbkM7Q0FDQSxPQUFPO0FBQ1I7QUFJQSxJQUFJOzs7Ozs7Ozs7Ozs7QUFZSixTQUFTLGNBQWMsU0FBUyxPQUFPO0NBQ3RDLElBQUksQ0FBQyxPQUFPLHdCQUF3QixJQUFJLElBQUk7Q0FDNUMsTUFBTSxNQUFNLE9BQU8sT0FBTztDQUMxQixJQUFJLGNBQWMsTUFBTSxJQUFJLEdBQUc7Q0FDL0IsSUFBSSxDQUFDLGFBQWE7RUFDakIsY0FBYyxJQUFJLEtBQUssVUFBVSxTQUFTLEVBQUUsYUFBYSxPQUFPLENBQUM7RUFDakUsTUFBTSxJQUFJLEtBQUssV0FBVztDQUMzQjtDQUNBLE1BQU0sV0FBVyxZQUFZLFFBQVEsS0FBSztDQUMxQyxJQUFJLFFBQVE7Q0FDWixLQUFLLE1BQU0sV0FBVyxVQUFVLElBQUksUUFBUSxZQUFZO0NBQ3hELE9BQU87QUFDUjs7OztBQU9BLElBQU0sa0JBQWtCOzs7Ozs7Ozs7OztBQVd4QixTQUFTLFlBQVksT0FBTztDQUMzQixNQUFNLFdBQVcsTUFBTSxRQUFRLGlCQUFpQixFQUFFO0NBQ2xELElBQUksV0FBVyxTQUFTO0NBQ3hCLElBQUksTUFBTTtDQUNWLElBQUksTUFBTTtDQUNWLE9BQU8sVUFBVTtFQUNoQixNQUFNLFVBQVUsQ0FBQyxTQUFTLEVBQUU7RUFDNUIsT0FBTztFQUNQLE9BQU8sTUFBTTtHQUNaO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0QsQ0FBQyxDQUFDLFdBQVc7Q0FDZDtDQUNBLE9BQU8sTUFBTSxPQUFPO0FBQ3JCOzs7Ozs7Ozs7Ozs7O0FBZ0JBLFNBQVMsa0JBQWtCLFVBQVUsS0FBSztDQUN6QyxPQUFPLE9BQU8sVUFBVSxlQUFlLEtBQUssVUFBVSxHQUFHLEtBQUssUUFBUSxlQUFlLFFBQVEsZUFBZSxRQUFRO0FBQ3JIOzs7Ozs7Ozs7Ozs7QUFlQSxTQUFTLGFBQWEsVUFBVSxXQUFXO0NBQzFDLE1BQU0sT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJLFFBQVEsQ0FBQztDQUNsQyxJQUFJLEtBQUssU0FBUyxHQUFHLE9BQU8sSUFBSSxLQUFLLEtBQUssSUFBSSxVQUFVLEVBQUUsRUFBRTtDQUM1RCxPQUFPLEtBQUssTUFBTTtBQUNuQjs7Ozs7Ozs7OztBQWFBLFNBQVMsZ0JBQWdCLE1BQU0sUUFBUTtDQUN0QyxNQUFNLFlBQVksQ0FBQztDQUNuQixLQUFLLE1BQU0sT0FBTyxNQUFNLFVBQVUsT0FBTztDQUN6QyxPQUFPO0FBQ1I7O0FBS0EsU0FBUyxtQkFBbUIsU0FBUztDQUNwQyxNQUFNLFlBQVksQ0FBQztDQUNuQixLQUFLLE1BQU0sVUFBVSxTQUFTLE9BQU8sT0FBTyxXQUFXLE9BQU8sT0FBTztDQUNyRSxPQUFPO0FBQ1I7O0FBS0EsU0FBUyxXQUFXLE9BQU87Q0FDMUIsSUFBSSxNQUFNLE1BQU07RUFDZixJQUFJLE1BQU07RUFDVixLQUFLLE1BQU0sUUFBUSxNQUFNLE1BQU0sSUFBSSxPQUFPLEtBQUssUUFBUSxZQUFZLE9BQU8sS0FBSyxRQUFRLFVBQVUsSUFBSSxLQUFLLE9BQU8sSUFBSSxLQUFLO09BQ3JILE9BQU8sS0FBSztPQUNaLE9BQU87RUFDWixPQUFPO0NBQ1I7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7QUFhQSxTQUFTLFNBQVMsTUFBTSxVQUFVO0NBQ2pDLE9BQU8sU0FBUyxTQUFTO0FBQzFCOzs7Ozs7Ozs7O0FBYUEsU0FBUyxTQUFTLE1BQU0sVUFBVTtDQUNqQyxPQUFPLFNBQVMsU0FBUztBQUMxQjs7Ozs7Ozs7O0FBWUEsU0FBUyxZQUFZLE9BQU87Q0FDM0IsT0FBTyxpQkFBaUI7QUFDekI7Ozs7QUFPQSxJQUFJLFlBQVksY0FBYyxNQUFNOzs7Ozs7Q0FNbkMsWUFBWSxRQUFRO0VBQ25CLE1BQU0sT0FBTyxFQUFFLENBQUMsT0FBTztFQUN2QixLQUFLLE9BQU87RUFDWixLQUFLLFNBQVM7Q0FDZjtBQUNEOztBQUtBLFNBQVMsS0FBSyxRQUFRO0NBQ3JCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1A7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixNQUFNLE9BQU8sUUFBUTtHQUNyQixRQUFRLFNBQVMsR0FBRyxVQUFVO0lBQzdCLE1BQU0sY0FBYyxLQUFLLE9BQU8sT0FBTyxDQUFDLEVBQUUsT0FBTyxNQUFNLEdBQUcsUUFBUTtJQUNsRSxJQUFJLFlBQVksUUFBUSxNQUFNLElBQUksVUFBVSxZQUFZLE1BQU07SUFDOUQsT0FBTyxLQUFLLEdBQUcsWUFBWSxLQUFLO0dBQ2pDO0dBQ0EsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFVBQVUsUUFBUTtDQUMxQixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQO0VBQ0EsT0FBTyxTQUFTLFVBQVU7R0FDekIsTUFBTSxPQUFPLFFBQVE7R0FDckIsUUFBUSxRQUFRLE9BQU8sR0FBRyxXQUFXO0lBQ3BDLE1BQU0sY0FBYyxNQUFNLE9BQU8sT0FBTyxDQUFDLEVBQUUsT0FBTyxPQUFPLEdBQUcsUUFBUTtJQUNwRSxJQUFJLFlBQVksUUFBUSxNQUFNLElBQUksVUFBVSxZQUFZLE1BQU07SUFDOUQsT0FBTyxLQUFLLEdBQUcsWUFBWSxLQUFLO0dBQ2pDO0dBQ0EsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7OztBQVVBLFNBQVMsYUFBYTtDQUNyQixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLE1BQU0sT0FBTyxTQUFTO0dBQ3JCLFFBQVEsUUFBUSxNQUFNLFFBQVE7R0FDOUIsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7OztBQU9BLElBQU0sZUFBZTs7OztBQUlyQixJQUFNLFlBQVk7Ozs7QUFJbEIsSUFBTSxjQUFjOzs7O0FBSXBCLElBQU0sZ0JBQWdCOzs7O0FBSXRCLElBQU0sZUFBZTs7Ozs7Ozs7QUFRckIsSUFBTSxlQUFlOzs7O0FBSXJCLElBQU0sY0FBYzs7Ozs7OztBQU9wQixJQUFNLGNBQWM7Ozs7OztBQU1wQixJQUFNLG9CQUFvQjs7Ozs7O0FBTTFCLElBQU0sa0JBQWtCOzs7O0FBSXhCLElBQU0sYUFBYTs7OztBQUluQixJQUFNLGFBQWE7Ozs7QUFJbkIsSUFBTSxhQUFhOzs7O0FBSW5CLElBQU0sV0FBVzs7OztBQUlqQixJQUFNLGlCQUFpQjs7OztBQUl2QixJQUFNLHNCQUFzQjs7OztBQUk1QixJQUFNLDZCQUE2Qjs7OztBQUluQyxJQUFNLGlCQUFpQjs7OztBQUl2QixJQUFNLHdCQUF3Qjs7Ozs7QUFLOUIsSUFBTSxzQkFBc0I7Ozs7QUFJNUIsSUFBTSxpQkFBaUI7Ozs7Ozs7OztBQVN2QixJQUFNLG9CQUFvQjs7OztBQUkxQixJQUFNLGFBQWE7Ozs7OztBQU1uQixJQUFNLGNBQWM7Ozs7OztBQU1wQixJQUFNLGNBQWM7Ozs7OztBQU1wQixJQUFNLFlBQVk7Ozs7QUFJbEIsSUFBTSxnQkFBZ0I7Ozs7QUFJdEIsSUFBTSxjQUFjOzs7Ozs7QUFNcEIsSUFBTSxrQkFBa0I7Ozs7QUFJeEIsSUFBTSxhQUFhOzs7Ozs7QUFNbkIsSUFBTSxhQUFhOzs7O0FBSW5CLElBQU0sYUFBYTs7QUFLbkIsU0FBUyxPQUFPLFdBQVc7Q0FDMUIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsYUFBYTtFQUNiLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxLQUFLLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxVQUFVLFNBQVMsUUFBUTtHQUN2RyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsSUFBSSxXQUFXO0NBQ3ZCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWE7RUFDYixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksS0FBSyxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sT0FBTyxTQUFTLFFBQVE7R0FDcEcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7Ozs7O0FBWUEsU0FBUyxNQUFNLE1BQU07Q0FDcEIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUDtFQUNBLE9BQU8sU0FBUztHQUNmLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxNQUFNLGFBQWEsV0FBVztDQUN0QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVMsR0FBRztFQUNaO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxPQUFPO0lBQ2xCLE1BQU0sV0FBMkIsOEJBQWMsUUFBUSxLQUFLO0lBQzVELElBQUksYUFBYSxLQUFLLGFBQWEsVUFBVSxNQUFNLFNBQVMsU0FBUyxVQUFVLEVBQUUsVUFBVSxHQUFHLFdBQVcsQ0FBQztHQUMzRztHQUNBLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxNQUFNLGFBQWEsV0FBVztDQUN0QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVDtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sU0FBUyxTQUFTLFFBQVE7R0FDakcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFdBQVcsYUFBYSxXQUFXO0NBQzNDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNUO0VBQ0EsU0FBUztFQUNULE1BQU0sT0FBTyxTQUFTLFVBQVU7R0FDL0IsSUFBSSxRQUFRLFNBQVMsQ0FBQyxNQUFNLEtBQUssWUFBWSxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sU0FBUyxTQUFTLFFBQVE7R0FDdkcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFdBQVcsYUFBYSxXQUFXO0NBQzNDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNUO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxPQUFPLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxRQUFRLE1BQU0sUUFBUSxTQUFTO0lBQzdFLE1BQU0sT0FBTyxRQUFRLE1BQU07SUFDM0IsSUFBSSxDQUFDLEtBQUssWUFBWSxNQUFNLE9BQU8sUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLFFBQVEsU0FBUyxVQUFVO0tBQzdGLE9BQU87S0FDUCxNQUFNLENBQUM7TUFDTixNQUFNO01BQ04sUUFBUTtNQUNSLE9BQU8sUUFBUTtNQUNmLEtBQUs7TUFDTCxPQUFPO0tBQ1IsQ0FBQztJQUNGLENBQUM7R0FDRjtHQUNBLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxnQkFBZ0IsYUFBYSxXQUFXO0NBQ2hELE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNUO0VBQ0EsU0FBUztFQUNULE1BQU0sT0FBTyxTQUFTLFVBQVU7R0FDL0IsSUFBSSxRQUFRLE9BQU87SUFDbEIsTUFBTSxxQkFBcUIsTUFBTSxRQUFRLElBQUksUUFBUSxNQUFNLElBQUksS0FBSyxXQUFXLENBQUM7SUFDaEYsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLFFBQVEsTUFBTSxRQUFRLFNBQVMsSUFBSSxDQUFDLG1CQUFtQixRQUFRO0tBQzFGLE1BQU0sT0FBTyxRQUFRLE1BQU07S0FDM0IsVUFBVSxNQUFNLFFBQVEsU0FBUyxVQUFVO01BQzFDLE9BQU87TUFDUCxNQUFNLENBQUM7T0FDTixNQUFNO09BQ04sUUFBUTtPQUNSLE9BQU8sUUFBUTtPQUNmLEtBQUs7T0FDTCxPQUFPO01BQ1IsQ0FBQztLQUNGLENBQUM7SUFDRjtHQUNEO0dBQ0EsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7OztBQU9BLElBQU0sb0JBQW9COzs7O0FBSTFCLElBQU0saUJBQWlCOzs7O0FBSXZCLElBQU0sc0JBQXNCO0NBQzNCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Q7O0FBRUEsU0FBUyxXQUFXLFdBQVc7Q0FDOUIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsWUFBWSxPQUFPO0dBQ2xCLElBQUk7R0FDSixPQUFPLGtCQUFrQixLQUFLLEtBQUssTUFBTSxZQUFZLE1BQU0sUUFBUSxnQkFBZ0IsRUFBRSxNQUFNLG9CQUFvQixNQUFNLFlBQVksUUFBUSxLQUFLLFNBQVMsQ0FBQyxLQUFxQiw0QkFBWSxTQUFTO0VBQ25NO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxlQUFlLFNBQVMsUUFBUTtHQUN2RyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsTUFBTSxXQUFXO0NBQ3pCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWE7RUFDYixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksS0FBSyxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sU0FBUyxTQUFTLFFBQVE7R0FDdEcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFFBQVEsV0FBVztDQUMzQixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxhQUFhO0VBQ2IsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLFdBQVcsU0FBUyxRQUFRO0dBQ3hHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7OztBQVlBLFNBQVMsWUFBWSxjQUFjO0NBQ2xDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxhQUFhO0NBQ2Q7QUFDRDs7QUFLQSxTQUFTLE9BQU8sV0FBVztDQUMxQixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxhQUFhO0VBQ2IsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLFVBQVUsU0FBUyxRQUFRO0dBQ3ZHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxPQUFPLFdBQVc7Q0FDMUIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsYUFBYTtFQUNiLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxLQUFLLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxVQUFVLFNBQVMsUUFBUTtHQUN2RyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsTUFBTSxXQUFXO0NBQ3pCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQLGFBQWE7RUFDYixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksS0FBSyxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sU0FBUyxTQUFTLFFBQVE7R0FDdEcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLE1BQU0sV0FBVztDQUN6QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxhQUFhO0VBQ2IsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLFNBQVMsU0FBUyxRQUFRO0dBQ3RHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxNQUFNLFdBQVc7Q0FDekIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLFFBQVEsTUFBTSxTQUFTLEdBQUcsVUFBVSxNQUFNLFVBQVUsU0FBUyxVQUFVLEVBQUUsVUFBVSxHQUFHLFFBQVEsTUFBTSxTQUFTLENBQUM7R0FDbkksT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFNBQVMsYUFBYSxXQUFXO0NBQ3pDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyxJQUFJLFlBQVk7RUFDekI7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxRQUFRLE1BQU0sU0FBUyxLQUFLLFdBQVcsR0FBRyxVQUFVLE1BQU0sT0FBTyxTQUFTLFVBQVUsRUFBRSxVQUFVLElBQUksUUFBUSxNQUFNLE1BQU0sQ0FBQyxLQUFLLFlBQVksTUFBTSxFQUFFLEdBQUcsQ0FBQztHQUM1SyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsUUFBUSxhQUFhLFdBQVc7Q0FDeEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLEdBQUc7RUFDWjtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLENBQUMsUUFBUSxPQUFPLE9BQU87R0FDM0IsTUFBTSxRQUFRLE9BQU8sS0FBSyxRQUFRLEtBQUssQ0FBQyxDQUFDO0dBQ3pDLElBQUksUUFBUSxTQUFTLFVBQVUsS0FBSyxhQUFhLFVBQVUsTUFBTSxXQUFXLFNBQVMsVUFBVSxFQUFFLFVBQVUsR0FBRyxRQUFRLENBQUM7R0FDdkgsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFVBQVUsYUFBYSxXQUFXO0NBQzFDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNUO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsUUFBUSxNQUFNLE1BQU0sS0FBSyxXQUFXLEdBQUcsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ3RHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7O0FBY0EsU0FBUyxTQUFTLFdBQVc7Q0FDNUIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFVBQVU7Q0FDWDtBQUNEOztBQUtBLFNBQVMsU0FBUyxhQUFhLFdBQVc7Q0FDekMsTUFBTSxXQUEyQiwyQkFBVyxXQUFXO0NBQ3ZELE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyxJQUFJO0VBQ2I7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsUUFBUSxNQUFNLFNBQVMsS0FBSyxXQUFXLEdBQUcsVUFBVSxNQUFNLFdBQVcsU0FBUyxVQUFVLEVBQUUsU0FBUyxDQUFDO0dBQ3pILE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxZQUFZLFdBQVc7Q0FDL0IsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUDtFQUNBLE9BQU8sU0FBUztHQUNmLFFBQVEsUUFBUSxRQUFRLE1BQU0sT0FBTyxLQUFLLFNBQVM7R0FDbkQsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFNBQVMsV0FBVztDQUM1QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQO0VBQ0EsT0FBTyxTQUFTO0dBQ2YsUUFBUSxRQUFRLFFBQVEsTUFBTSxLQUFLLEtBQUssU0FBUztHQUNqRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsT0FBTyxXQUFXO0NBQzFCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWEsT0FBTztFQUNwQixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLFVBQVUsU0FBUyxRQUFRO0dBQ2xHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7O0FBY0EsU0FBUyxPQUFPLE1BQU07Q0FDckIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUDtFQUNBLE9BQU8sU0FBUztHQUNmLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxVQUFVLGFBQWEsV0FBVztDQUMxQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVMsR0FBRztFQUNaO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxPQUFPO0lBQ2xCLE1BQU0sUUFBd0Isa0NBQWtCLFFBQVEsS0FBSztJQUM3RCxJQUFJLFVBQVUsS0FBSyxhQUFhLFVBQVUsTUFBTSxhQUFhLFNBQVMsVUFBVSxFQUFFLFVBQVUsR0FBRyxRQUFRLENBQUM7R0FDekc7R0FDQSxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsUUFBUSxhQUFhLFdBQVc7Q0FDeEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLElBQUksdUJBQXVCLE9BQU8sWUFBWSxPQUFPLElBQW9CLDJCQUFXLFdBQVc7RUFDeEc7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsRUFBRSxRQUFRLFFBQVEsS0FBSyxjQUFjLFVBQVUsTUFBTSxTQUFTLFNBQVMsVUFBVSxFQUFFLFVBQVUsUUFBUSxpQkFBaUIsT0FBTyxRQUFRLE1BQU0sT0FBTyxJQUFvQiwyQkFBVyxRQUFRLEtBQUssRUFBRSxDQUFDO0dBQ3ROLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxNQUFNLGFBQWEsV0FBVztDQUN0QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLFFBQVEsS0FBSyxHQUFHO0lBQ3RELFVBQVUsTUFBTSxTQUFTLFNBQVMsUUFBUTtJQUMxQyxRQUFRLFFBQVE7R0FDakI7R0FDQSxPQUFPO0VBQ1I7Q0FDRDtBQUNEOzs7O0FBT0EsSUFBTSxlQUFlO0NBQ3BCLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsTUFBTTtDQUNOLFFBQVE7Q0FDUixRQUFRO0NBQ1IsUUFBUTtDQUNSLFdBQVc7Q0FDWCxXQUFXO0NBQ1gsVUFBVTtDQUNWLFVBQVU7Q0FDVixVQUFVO0NBQ1YsT0FBTztDQUNQLFFBQVE7Q0FDUixTQUFTO0FBQ1Y7O0FBRUEsU0FBUyxLQUFLLE9BQU8sV0FBVztDQUMvQixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUCxhQUFhLE9BQU8sTUFBTSxLQUFLLFNBQVMsZ0JBQWdCLGFBQWEsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHO0VBQzlGLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxLQUFLLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNyRyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsWUFBWSxXQUFXO0NBQy9CLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWE7RUFDYixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksS0FBSyxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sZUFBZSxTQUFTLFFBQVE7R0FDNUcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFNBQVMsV0FBVztDQUM1QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxhQUFhO0VBQ2IsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLGFBQWEsU0FBUyxRQUFRO0dBQzFHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxLQUFLLFdBQVc7Q0FDeEIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsWUFBWSxPQUFPO0dBQ2xCLE9BQU8sV0FBVyxLQUFLLEtBQUssS0FBcUIsNEJBQVksS0FBSztFQUNuRTtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDaEcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFNBQVMsYUFBYSxXQUFXO0NBQ3pDLE1BQU0sVUFBMEIsMkJBQVcsV0FBVztDQUN0RCxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQO0VBQ0E7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxRQUFRLE1BQU0sU0FBUyxLQUFLLFdBQVcsR0FBRyxVQUFVLE1BQU0sV0FBVyxTQUFTLFVBQVUsRUFBRSxVQUFVLElBQUksVUFBVSxDQUFDO0dBQ3pJLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxRQUFRLFdBQVc7Q0FDM0IsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsYUFBYSxPQUFPO0VBQ3BCLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sV0FBVyxTQUFTLFFBQVE7R0FDbkcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLEdBQUcsV0FBVztDQUN0QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxhQUFhO0VBQ2IsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLE1BQU0sU0FBUyxRQUFRO0dBQ25HLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxLQUFLLFdBQVc7Q0FDeEIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsYUFBYTtFQUNiLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxLQUFLLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNyRyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsS0FBSyxXQUFXO0NBQ3hCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWE7RUFDYixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksS0FBSyxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDckcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7Ozs7OztBQWFBLFNBQVMsVUFBVSxPQUFPO0NBQ3pCLE1BQU0sV0FBVyxNQUFNLE1BQU0sRUFBRSxDQUFDLENBQUMsS0FBSyxNQUFNLE1BQU0sTUFBTSxLQUFLLFNBQVMsQ0FBQyxDQUFDO0NBQ3hFLElBQUksTUFBTTtDQUNWLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUssT0FBTyxTQUFTLE1BQU0sS0FBSztDQUN4RCxPQUFPLE1BQU0sT0FBTztBQUNyQjs7Ozs7Ozs7OztBQWFBLFNBQVMsVUFBVSxPQUFPO0NBQ3pCLE1BQU0sV0FBVyxNQUFNLE1BQU0sRUFBRSxDQUFDLENBQUMsS0FBSyxNQUFNLFNBQVMsQ0FBQyxDQUFDO0NBQ3ZELElBQUksTUFBTTtDQUNWLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUssT0FBTyxTQUFTLE1BQU0sSUFBSSxNQUFNLElBQUksSUFBSTtDQUNyRSxPQUFPLE1BQU0sT0FBTztBQUNyQjs7OztBQU9BLElBQU0sdUJBQXVCOzs7O0FBSTdCLElBQU0sMEJBQTBCOzs7O0FBSWhDLElBQU0sMEJBQTBCOztBQUVoQyxTQUFTLEtBQUssV0FBVztDQUN4QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxZQUFZLE9BQU87R0FDbEIsTUFBTSxnQkFBZ0IsTUFBTSxRQUFRLHNCQUFzQixFQUFFO0dBQzVELElBQUksd0JBQXdCLEtBQUssYUFBYSxHQUFHLE9BQU8sVUFBVSxhQUFhO1FBQzFFLElBQUksd0JBQXdCLEtBQUssYUFBYSxHQUFHLE9BQU8sVUFBVSxhQUFhO0dBQ3BGLE9BQU87RUFDUjtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDaEcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLEtBQUssV0FBVztDQUN4QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxhQUFhO0VBQ2IsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ3JHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxRQUFRLFdBQVc7Q0FDM0IsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsYUFBYTtFQUNiLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxLQUFLLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNyRyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsWUFBWSxXQUFXO0NBQy9CLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWE7RUFDYixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksS0FBSyxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sYUFBYSxTQUFTLFFBQVE7R0FDMUcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLGtCQUFrQixXQUFXO0NBQ3JDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWE7RUFDYixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksS0FBSyxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sb0JBQW9CLFNBQVMsUUFBUTtHQUNqSCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsUUFBUSxXQUFXO0NBQzNCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWE7RUFDYixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksS0FBSyxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDckcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLGNBQWMsV0FBVztDQUNqQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxhQUFhO0VBQ2IsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLGVBQWUsU0FBUyxRQUFRO0dBQzVHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxhQUFhLFdBQVc7Q0FDaEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsYUFBYTtFQUNiLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxLQUFLLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxhQUFhLFNBQVMsUUFBUTtHQUMxRyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsUUFBUSxXQUFXO0NBQzNCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWE7RUFDYixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksS0FBSyxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDckcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFdBQVcsV0FBVztDQUM5QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxhQUFhO0VBQ2IsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLGVBQWUsU0FBUyxRQUFRO0dBQzVHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxPQUFPLGFBQWEsV0FBVztDQUN2QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVMsR0FBRztFQUNaO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLFFBQVEsTUFBTSxXQUFXLEtBQUssYUFBYSxVQUFVLE1BQU0sVUFBVSxTQUFTLFVBQVUsRUFBRSxVQUFVLEdBQUcsUUFBUSxNQUFNLFNBQVMsQ0FBQztHQUNwSixPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsUUFBUSxhQUFhLFdBQVc7Q0FDeEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLElBQUksdUJBQXVCLE9BQU8sWUFBWSxPQUFPLElBQW9CLDJCQUFXLFdBQVc7RUFDeEc7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsRUFBRSxRQUFRLFFBQVEsS0FBSyxjQUFjLFVBQVUsTUFBTSxTQUFTLFNBQVMsVUFBVSxFQUFFLFVBQVUsUUFBUSxpQkFBaUIsT0FBTyxRQUFRLE1BQU0sT0FBTyxJQUFvQiwyQkFBVyxRQUFRLEtBQUssRUFBRSxDQUFDO0dBQ3ROLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxJQUFJLFdBQVc7Q0FDdkIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsYUFBYTtFQUNiLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxLQUFLLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxPQUFPLFNBQVMsUUFBUTtHQUNwRyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsTUFBTSxXQUFXO0NBQ3pCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWE7RUFDYixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksS0FBSyxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sY0FBYyxTQUFTLFFBQVE7R0FDM0csT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLE1BQU0sV0FBVztDQUN6QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxhQUFhO0VBQ2IsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLGNBQWMsU0FBUyxRQUFRO0dBQzNHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxTQUFTLFdBQVc7Q0FDNUIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUDtFQUNBLE9BQU8sU0FBUztHQUNmLFFBQVEsUUFBUSxRQUFRLE1BQU0sSUFBSSxLQUFLLFNBQVM7R0FDaEQsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFNBQVMsYUFBYSxXQUFXO0NBQ3pDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyxLQUFLO0VBQ2Q7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLE9BQU87SUFDbEIsTUFBTSxXQUEyQiw4QkFBYyxRQUFRLEtBQUs7SUFDNUQsSUFBSSxXQUFXLEtBQUssYUFBYSxVQUFVLE1BQU0sU0FBUyxTQUFTLFVBQVUsRUFBRSxVQUFVLEdBQUcsV0FBVyxDQUFDO0dBQ3pHO0dBQ0EsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFdBQVcsYUFBYSxXQUFXO0NBQzNDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyxLQUFLO0VBQ2Q7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxDQUFDLFFBQVEsT0FBTyxPQUFPO0dBQzNCLE1BQU0sUUFBUSxPQUFPLEtBQUssUUFBUSxLQUFLLENBQUMsQ0FBQztHQUN6QyxJQUFJLFFBQVEsU0FBUyxRQUFRLEtBQUssYUFBYSxVQUFVLE1BQU0sV0FBVyxTQUFTLFVBQVUsRUFBRSxVQUFVLEdBQUcsUUFBUSxDQUFDO0dBQ3JILE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxhQUFhLGFBQWEsV0FBVztDQUM3QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVMsS0FBSztFQUNkO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxPQUFPO0lBQ2xCLE1BQU0sUUFBd0Isa0NBQWtCLFFBQVEsS0FBSztJQUM3RCxJQUFJLFFBQVEsS0FBSyxhQUFhLFVBQVUsTUFBTSxhQUFhLFNBQVMsVUFBVSxFQUFFLFVBQVUsR0FBRyxRQUFRLENBQUM7R0FDdkc7R0FDQSxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsVUFBVSxhQUFhLFdBQVc7Q0FDMUMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLEtBQUs7RUFDZDtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxRQUFRLE1BQU0sU0FBUyxLQUFLLGFBQWEsVUFBVSxNQUFNLFVBQVUsU0FBUyxVQUFVLEVBQUUsVUFBVSxHQUFHLFFBQVEsTUFBTSxTQUFTLENBQUM7R0FDbEosT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFFBQVEsYUFBYSxXQUFXO0NBQ3hDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyxLQUFLO0VBQ2Q7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsUUFBUSxNQUFNLE9BQU8sS0FBSyxhQUFhLFVBQVUsTUFBTSxRQUFRLFNBQVMsVUFBVSxFQUFFLFVBQVUsR0FBRyxRQUFRLE1BQU0sT0FBTyxDQUFDO0dBQzVJLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxTQUFTLGFBQWEsV0FBVztDQUN6QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVMsS0FBSyx1QkFBdUIsT0FBTyxZQUFZLE9BQU8sSUFBb0IsMkJBQVcsV0FBVztFQUN6RztFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxFQUFFLFFBQVEsU0FBUyxLQUFLLGNBQWMsVUFBVSxNQUFNLFNBQVMsU0FBUyxVQUFVLEVBQUUsVUFBVSxRQUFRLGlCQUFpQixPQUFPLFFBQVEsTUFBTSxPQUFPLElBQW9CLDJCQUFXLFFBQVEsS0FBSyxFQUFFLENBQUM7R0FDdk4sT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFNBQVMsU0FBUyxhQUFhLFdBQVc7Q0FDbEQsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLEtBQUs7RUFDZDtFQUNBO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxPQUFPO0lBQ2xCLE1BQU0sUUFBd0IsOEJBQWMsS0FBSyxTQUFTLFFBQVEsS0FBSztJQUN2RSxJQUFJLFFBQVEsS0FBSyxhQUFhLFVBQVUsTUFBTSxTQUFTLFNBQVMsVUFBVSxFQUFFLFVBQVUsR0FBRyxRQUFRLENBQUM7R0FDbkc7R0FDQSxPQUFPO0VBQ1I7Q0FDRDtBQUNEOzs7Ozs7Ozs7QUFZQSxTQUFTLFNBQVMsV0FBVztDQUM1QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsVUFBVTtDQUNYO0FBQ0Q7O0FBS0EsU0FBUyxTQUFTLGFBQWEsV0FBVztDQUN6QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQXlCLDZCQUFhLFlBQVksS0FBSyxXQUFXLElBQUksT0FBTyxFQUFFLEdBQUcsR0FBRztFQUNyRjtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxTQUFTLFFBQVEsTUFBTSxJQUFJLEdBQUcsVUFBVSxNQUFNLGFBQWEsU0FBUyxVQUFVLEVBQUUsVUFBVSxJQUFJLFFBQVEsTUFBTSxLQUFLLEdBQUcsQ0FBQztHQUM1SixPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsU0FBUyxhQUFhLFdBQVc7Q0FDekMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLEtBQUs7RUFDZDtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsT0FBTztJQUNsQixNQUFNLFdBQTJCLDhCQUFjLFFBQVEsS0FBSztJQUM1RCxJQUFJLFdBQVcsS0FBSyxhQUFhLFVBQVUsTUFBTSxTQUFTLFNBQVMsVUFBVSxFQUFFLFVBQVUsR0FBRyxXQUFXLENBQUM7R0FDekc7R0FDQSxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsV0FBVyxhQUFhLFdBQVc7Q0FDM0MsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLEtBQUs7RUFDZDtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLENBQUMsUUFBUSxPQUFPLE9BQU87R0FDM0IsTUFBTSxRQUFRLE9BQU8sS0FBSyxRQUFRLEtBQUssQ0FBQyxDQUFDO0dBQ3pDLElBQUksUUFBUSxTQUFTLFFBQVEsS0FBSyxhQUFhLFVBQVUsTUFBTSxXQUFXLFNBQVMsVUFBVSxFQUFFLFVBQVUsR0FBRyxRQUFRLENBQUM7R0FDckgsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLGFBQWEsYUFBYSxXQUFXO0NBQzdDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyxLQUFLO0VBQ2Q7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLE9BQU87SUFDbEIsTUFBTSxRQUF3QixrQ0FBa0IsUUFBUSxLQUFLO0lBQzdELElBQUksUUFBUSxLQUFLLGFBQWEsVUFBVSxNQUFNLGFBQWEsU0FBUyxVQUFVLEVBQUUsVUFBVSxHQUFHLFFBQVEsQ0FBQztHQUN2RztHQUNBLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxVQUFVLGFBQWEsV0FBVztDQUMxQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVMsS0FBSztFQUNkO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLFFBQVEsTUFBTSxTQUFTLEtBQUssYUFBYSxVQUFVLE1BQU0sVUFBVSxTQUFTLFVBQVUsRUFBRSxVQUFVLEdBQUcsUUFBUSxNQUFNLFNBQVMsQ0FBQztHQUNsSixPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsUUFBUSxhQUFhLFdBQVc7Q0FDeEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLEtBQUs7RUFDZDtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxRQUFRLE1BQU0sT0FBTyxLQUFLLGFBQWEsVUFBVSxNQUFNLFFBQVEsU0FBUyxVQUFVLEVBQUUsVUFBVSxHQUFHLFFBQVEsTUFBTSxPQUFPLENBQUM7R0FDNUksT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFNBQVMsYUFBYSxXQUFXO0NBQ3pDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyxLQUFLLHVCQUF1QixPQUFPLFlBQVksT0FBTyxJQUFvQiwyQkFBVyxXQUFXO0VBQ3pHO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLEVBQUUsUUFBUSxTQUFTLEtBQUssY0FBYyxVQUFVLE1BQU0sU0FBUyxTQUFTLFVBQVUsRUFBRSxVQUFVLFFBQVEsaUJBQWlCLE9BQU8sUUFBUSxNQUFNLE9BQU8sSUFBb0IsMkJBQVcsUUFBUSxLQUFLLEVBQUUsQ0FBQztHQUN2TixPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsU0FBUyxTQUFTLGFBQWEsV0FBVztDQUNsRCxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVMsS0FBSztFQUNkO0VBQ0E7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLE9BQU87SUFDbEIsTUFBTSxRQUF3Qiw4QkFBYyxLQUFLLFNBQVMsUUFBUSxLQUFLO0lBQ3ZFLElBQUksUUFBUSxLQUFLLGFBQWEsVUFBVSxNQUFNLFNBQVMsU0FBUyxVQUFVLEVBQUUsVUFBVSxHQUFHLFFBQVEsQ0FBQztHQUNuRztHQUNBLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxXQUFXLGFBQWEsV0FBVztDQUMzQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVMsSUFBSTtFQUNiO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLFFBQVEsUUFBUSxLQUFLLGVBQWUsR0FBRyxVQUFVLE1BQU0sWUFBWSxTQUFTLFFBQVE7R0FDekcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLE9BQU8sV0FBVztDQUMxQixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxhQUFhO0VBQ2IsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLFdBQVcsU0FBUyxRQUFRO0dBQ3hHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxTQUFTLFdBQVc7Q0FDNUIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLFFBQVEsTUFBTSxXQUFXLEdBQUcsVUFBVSxNQUFNLFVBQVUsU0FBUyxVQUFVLEVBQUUsVUFBVSxJQUFJLENBQUM7R0FDL0csT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFVBQVUsTUFBTTtDQUN4QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQO0VBQ0EsT0FBTyxTQUFTO0dBQ2YsUUFBUSxRQUFRLFFBQVEsTUFBTSxVQUFVLEtBQUssSUFBSTtHQUNqRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsU0FBUyxhQUFhLFdBQVc7Q0FDekMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLElBQUk7RUFDYjtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsT0FBTztJQUNsQixNQUFNLFdBQTJCLDhCQUFjLFFBQVEsS0FBSztJQUM1RCxJQUFJLGFBQWEsS0FBSyxhQUFhLFVBQVUsTUFBTSxTQUFTLFNBQVMsVUFBVSxFQUFFLFVBQVUsR0FBRyxXQUFXLENBQUM7R0FDM0c7R0FDQSxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsV0FBVyxhQUFhLFdBQVc7Q0FDM0MsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLElBQUk7RUFDYjtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLENBQUMsUUFBUSxPQUFPLE9BQU87R0FDM0IsTUFBTSxRQUFRLE9BQU8sS0FBSyxRQUFRLEtBQUssQ0FBQyxDQUFDO0dBQ3pDLElBQUksUUFBUSxTQUFTLFVBQVUsS0FBSyxhQUFhLFVBQVUsTUFBTSxXQUFXLFNBQVMsVUFBVSxFQUFFLFVBQVUsR0FBRyxRQUFRLENBQUM7R0FDdkgsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLGFBQWEsYUFBYSxXQUFXO0NBQzdDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyxJQUFJO0VBQ2I7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLE9BQU87SUFDbEIsTUFBTSxRQUF3QixrQ0FBa0IsUUFBUSxLQUFLO0lBQzdELElBQUksVUFBVSxLQUFLLGFBQWEsVUFBVSxNQUFNLGFBQWEsU0FBUyxVQUFVLEVBQUUsVUFBVSxHQUFHLFFBQVEsQ0FBQztHQUN6RztHQUNBLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxVQUFVLGFBQWEsV0FBVztDQUMxQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVMsSUFBSTtFQUNiO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLFFBQVEsTUFBTSxXQUFXLEtBQUssYUFBYSxVQUFVLE1BQU0sVUFBVSxTQUFTLFVBQVUsRUFBRSxVQUFVLEdBQUcsUUFBUSxNQUFNLFNBQVMsQ0FBQztHQUNwSixPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsUUFBUSxhQUFhLFdBQVc7Q0FDeEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLElBQUk7RUFDYjtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxRQUFRLE1BQU0sU0FBUyxLQUFLLGFBQWEsVUFBVSxNQUFNLFFBQVEsU0FBUyxVQUFVLEVBQUUsVUFBVSxHQUFHLFFBQVEsTUFBTSxPQUFPLENBQUM7R0FDOUksT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFNBQVMsYUFBYSxXQUFXO0NBQ3pDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyx1QkFBdUIsT0FBTyxJQUFJLFlBQVksT0FBTyxNQUFNLElBQW9CLDJCQUFXLFdBQVc7RUFDOUc7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsS0FBSyxlQUFlLFFBQVEsU0FBUyxLQUFLLGVBQWUsUUFBUSxPQUFPLFVBQVUsTUFBTSxTQUFTLFNBQVMsVUFBVSxFQUFFLFVBQVUsUUFBUSxpQkFBaUIsT0FBTyxRQUFRLE1BQU0sT0FBTyxJQUFvQiwyQkFBVyxRQUFRLEtBQUssRUFBRSxDQUFDO0dBQ3pQLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxVQUFVLGFBQWEsV0FBVztDQUMxQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVMsSUFBb0IsNkJBQWEsWUFBWSxLQUFLLFlBQVksbUJBQW1CLE9BQU8sUUFBUSxPQUFPLElBQW9CLDJCQUFXLE9BQU8sQ0FBQyxHQUFHLEdBQUc7RUFDN0o7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsS0FBSyxZQUFZLE1BQU0sWUFBWSxXQUFXLFFBQVEsU0FBUyxXQUFXLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxTQUFTLFNBQVMsVUFBVSxFQUFFLFVBQVUsUUFBUSxpQkFBaUIsT0FBTyxRQUFRLE1BQU0sT0FBTyxJQUFvQiwyQkFBVyxRQUFRLEtBQUssRUFBRSxDQUFDO0dBQzNRLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxTQUFTLFNBQVMsYUFBYSxXQUFXO0NBQ2xELE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyxJQUFJO0VBQ2I7RUFDQTtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsT0FBTztJQUNsQixNQUFNLFFBQXdCLDhCQUFjLEtBQUssU0FBUyxRQUFRLEtBQUs7SUFDdkUsSUFBSSxVQUFVLEtBQUssYUFBYSxVQUFVLE1BQU0sU0FBUyxTQUFTLFVBQVUsRUFBRSxVQUFVLEdBQUcsUUFBUSxDQUFDO0dBQ3JHO0dBQ0EsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLE1BQU0sV0FBVztDQUN6QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxhQUFhO0VBQ2IsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLFNBQVMsU0FBUyxRQUFRO0dBQ3RHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7QUFJQSxJQUFNLFNBQVM7Q0FDZDtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Q7QUFDQSxJQUFNLFFBQVE7Q0FDYjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Q7O0FBRUEsU0FBUyxhQUFhLFVBQVUsV0FBVztDQUMxQyxNQUFNLGVBQWUsTUFBTSxPQUFPLE1BQU0sV0FBVyxFQUFFLFlBQVksSUFBSTtDQUNyRSxNQUFNLFlBQVksVUFBVSxVQUFVO0NBQ3RDLE1BQU0sV0FBVyxVQUFVLFNBQVM7Q0FDcEMsTUFBTSxTQUFTLFVBQVUsU0FBUyxTQUFTLE9BQU8sSUFBSSxXQUFXLElBQUk7Q0FDckUsTUFBTSxRQUFRLFVBQVUsUUFBUSxTQUFTLE1BQU0sSUFBSSxXQUFXLElBQUk7Q0FDbEUsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQXlCLDZCQUFhLENBQUMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLENBQUMsSUFBSSxVQUFVLEdBQUcsR0FBRztFQUN0RixRQUFRO0VBQ1IsU0FBUztFQUNULE9BQU87RUFDUCxPQUFPLFNBQVMsVUFBVTtHQUN6QixNQUFNLFFBQVEsWUFBWSxRQUFRLEtBQUs7R0FDdkMsSUFBSSxPQUFPLFNBQVMsS0FBSyxHQUFHLFFBQVEsUUFBUTtRQUN2QyxJQUFJLE1BQU0sU0FBUyxLQUFLLEdBQUcsUUFBUSxRQUFRO1FBQzNDO0lBQ0osVUFBVSxNQUFNLFdBQVcsU0FBUyxRQUFRO0lBQzVDLFFBQVEsUUFBUTtHQUNqQjtHQUNBLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxVQUFVLFVBQVUsV0FBVztDQUN2QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsUUFBUTtFQUNSLFNBQVM7RUFDVCxPQUFPO0VBQ1AsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSTtJQUNILFFBQVEsUUFBUSxLQUFLLE1BQU0sUUFBUSxPQUFPLEtBQUssUUFBUSxPQUFPO0dBQy9ELFNBQVMsT0FBTztJQUNmLElBQUksaUJBQWlCLE9BQU87S0FDM0IsVUFBVSxNQUFNLFFBQVEsU0FBUyxVQUFVLEVBQUUsVUFBVSxJQUFJLE1BQU0sUUFBUSxHQUFHLENBQUM7S0FDN0UsUUFBUSxRQUFRO0lBQ2pCLE9BQU8sTUFBTTtHQUNkO0dBQ0EsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7O0FBZUEsU0FBUyxrQkFBa0IsU0FBUyxPQUFPO0NBQzFDLElBQUksUUFBUSxRQUFRLEtBQUssTUFBTSxRQUFRLE9BQU8sS0FBSyxNQUFNLFNBQVMsUUFBUSxRQUFRO0VBQ2pGLElBQUksUUFBUTtFQUNaLE1BQU0sUUFBUSxLQUFLLElBQUksS0FBSyxRQUFRLE1BQU0sTUFBTSxVQUFVLENBQUM7RUFDM0QsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLE9BQU8sU0FBUyxJQUFJLEtBQUssV0FBVyxNQUFNLEtBQUssTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLE9BQU8sTUFBTSxLQUFLLE1BQU0sQ0FBQyxTQUFTLFVBQVU7R0FDckosUUFBUTtHQUNSO0VBQ0Q7RUFDQSxJQUFJLENBQUMsT0FBTyxPQUFPO0NBQ3BCO0NBQ0EsT0FBTztBQUNSOztBQUtBLFNBQVMsYUFBYSxPQUFPLGFBQWEsV0FBVztDQUNwRCxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVDtFQUNBO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLEtBQUssUUFBUSxTQUF5QixrQ0FBa0IsU0FBUyxLQUFLLE1BQU0sQ0FBQyxLQUFLLFlBQVksUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLFNBQVMsU0FBUyxRQUFRO0dBQ3hKLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxrQkFBa0IsT0FBTyxhQUFhLFdBQVc7Q0FDekQsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1Q7RUFDQTtFQUNBLFNBQVM7RUFDVCxNQUFNLE9BQU8sU0FBUyxVQUFVO0dBQy9CLEtBQUssUUFBUSxTQUF5QixrQ0FBa0IsU0FBUyxLQUFLLE1BQU0sQ0FBQyxNQUFNLEtBQUssWUFBWSxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sU0FBUyxTQUFTLFFBQVE7R0FDOUosT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7Ozs7O0FBWUEsU0FBUyxTQUFTLFFBQVE7Q0FDekIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsT0FBTztJQUNOO0lBQ0EsUUFBUTtJQUNSLFdBQVcsU0FBUyxVQUFVLE1BQU0sTUFBTSxTQUFTLFNBQVMsU0FBUyxVQUFVLElBQUk7R0FDcEYsQ0FBQztHQUNELE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7OztBQVlBLFNBQVMsY0FBYyxRQUFRO0NBQzlCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULE1BQU0sT0FBTyxTQUFTLFVBQVU7R0FDL0IsTUFBTSxPQUFPO0lBQ1o7SUFDQSxRQUFRO0lBQ1IsV0FBVyxTQUFTLFVBQVUsTUFBTSxNQUFNLFNBQVMsU0FBUyxTQUFTLFVBQVUsSUFBSTtHQUNwRixDQUFDO0dBQ0QsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7Ozs7O0FBWUEsU0FBUyxhQUFhLFFBQVE7Q0FDN0IsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxPQUFPLFNBQVMsVUFBVTtHQUN6QixNQUFNLFNBQVMsT0FBTztJQUNyQjtJQUNBLFFBQVE7SUFDUixXQUFXLFNBQVMsVUFBVSxNQUFNLE1BQU0sU0FBUyxTQUFTLFNBQVMsVUFBVSxJQUFJO0lBQ25GLE9BQU87R0FDUixDQUFDO0dBQ0QsSUFBSSxRQUFRLFFBQVEsUUFBUSxRQUFRO1FBQy9CLFFBQVEsUUFBUTtHQUNyQixPQUFPO0VBQ1I7Q0FDRDtBQUNEOzs7Ozs7Ozs7QUFZQSxTQUFTLGtCQUFrQixRQUFRO0NBQ2xDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsTUFBTSxPQUFPLFNBQVMsVUFBVTtHQUMvQixNQUFNLFNBQVMsTUFBTSxPQUFPO0lBQzNCO0lBQ0EsUUFBUTtJQUNSLFdBQVcsU0FBUyxVQUFVLE1BQU0sTUFBTSxTQUFTLFNBQVMsU0FBUyxVQUFVLElBQUk7SUFDbkYsT0FBTztHQUNSLENBQUM7R0FDRCxJQUFJLFFBQVEsUUFBUSxRQUFRLFFBQVE7UUFDL0IsUUFBUSxRQUFRO0dBQ3JCLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxXQUFXO0NBQ25CLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsT0FBTyxTQUFTO0dBQ2YsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFlBQVksV0FBVyxTQUFTO0NBQ3hDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1A7RUFDQTtFQUNBLE9BQU8sU0FBUztHQUNmLFFBQVEsUUFBUSxRQUFRLE1BQU0sT0FBTyxLQUFLLFdBQVcsS0FBSyxPQUFPO0dBQ2pFLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxNQUFNLGFBQWEsV0FBVztDQUN0QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVMsR0FBRztFQUNaO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLFVBQVUsU0FBUyxRQUFRO0dBQ3ZHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxRQUFRLFFBQVE7Q0FDeEIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUDtFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLE1BQU0sT0FBTyxRQUFRO0dBQ3JCLFFBQVEsU0FBUyxHQUFHLFVBQVU7SUFDN0IsTUFBTSxpQkFBaUIsS0FBSyxPQUFPLE9BQU8sQ0FBQyxFQUFFLE9BQU8sS0FBSyxHQUFHLEtBQUssRUFBRSxHQUFHLFFBQVE7SUFDOUUsSUFBSSxlQUFlLFFBQVEsTUFBTSxJQUFJLFVBQVUsZUFBZSxNQUFNO0lBQ3BFLE9BQU8sZUFBZTtHQUN2QjtHQUNBLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxhQUFhLFFBQVE7Q0FDN0IsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUDtFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLE1BQU0sT0FBTyxRQUFRO0dBQ3JCLFFBQVEsUUFBUSxPQUFPLEdBQUcsVUFBVTtJQUNuQyxNQUFNLGlCQUFpQixNQUFNLEtBQUssT0FBTyxPQUFPLENBQUMsRUFBRSxPQUFPLE1BQU0sS0FBSyxHQUFHLEtBQUssRUFBRSxHQUFHLFFBQVE7SUFDMUYsSUFBSSxlQUFlLFFBQVEsTUFBTSxJQUFJLFVBQVUsZUFBZSxNQUFNO0lBQ3BFLE9BQU8sZUFBZTtHQUN2QjtHQUNBLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxTQUFTLFdBQVc7Q0FDNUIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsYUFBYTtFQUNiLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxLQUFLLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxTQUFTLFNBQVMsUUFBUTtHQUN0RyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsWUFBWSxXQUFXO0NBQy9CLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWEsT0FBTztFQUNwQixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksUUFBUSxLQUFLLEdBQUcsVUFBVSxNQUFNLGdCQUFnQixTQUFTLFFBQVE7R0FDeEcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLEtBQUssYUFBYSxXQUFXO0NBQ3JDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyxHQUFHO0VBQ1o7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsUUFBUSxNQUFNLFNBQVMsS0FBSyxhQUFhLFVBQVUsTUFBTSxRQUFRLFNBQVMsVUFBVSxFQUFFLFVBQVUsR0FBRyxRQUFRLE1BQU0sT0FBTyxDQUFDO0dBQzlJLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxLQUFLLFdBQVc7Q0FDeEIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsYUFBYTtFQUNiLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxLQUFLLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNyRyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsU0FBUyxhQUFhLFdBQVc7Q0FDekMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1Q7RUFDQSxTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxRQUFRLE1BQU0sS0FBSyxLQUFLLFdBQVcsR0FBRyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDckcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFVBQVUsV0FBVztDQUM3QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQO0VBQ0EsT0FBTyxTQUFTO0dBQ2YsUUFBUSxRQUFRLFFBQVEsTUFBTSxLQUFLLEtBQUssU0FBUztHQUNqRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsV0FBVyxhQUFhLFdBQVc7Q0FDM0MsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLElBQUksWUFBWTtFQUN6QjtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLFFBQVEsTUFBTSxXQUFXLEtBQUssV0FBVyxHQUFHLFVBQVUsTUFBTSxTQUFTLFNBQVMsVUFBVSxFQUFFLFVBQVUsSUFBSSxRQUFRLE1BQU0sTUFBTSxHQUFHLEtBQUssWUFBWSxNQUFNLEVBQUUsR0FBRyxDQUFDO0dBQ2xMLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxjQUFjLFVBQVUsV0FBVztDQUMzQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULFFBQVE7RUFDUixPQUFPO0VBQ1AsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSTtJQUNILE1BQU0sU0FBUyxLQUFLLFVBQVUsUUFBUSxPQUFPLEtBQUssUUFBUSxVQUFVLEtBQUssUUFBUSxLQUFLO0lBQ3RGLElBQUksV0FBVyxLQUFLLEdBQUc7S0FDdEIsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0tBQ3pDLFFBQVEsUUFBUTtJQUNqQjtJQUNBLFFBQVEsUUFBUTtHQUNqQixTQUFTLE9BQU87SUFDZixJQUFJLGlCQUFpQixPQUFPO0tBQzNCLFVBQVUsTUFBTSxRQUFRLFNBQVMsVUFBVSxFQUFFLFVBQVUsSUFBSSxNQUFNLFFBQVEsR0FBRyxDQUFDO0tBQzdFLFFBQVEsUUFBUTtJQUNqQixPQUFPLE1BQU07R0FDZDtHQUNBLE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7OztBQVlBLFNBQVMsTUFBTSxRQUFRO0NBQ3RCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0NBQ1I7QUFDRDs7QUFLQSxTQUFTLFNBQVMsV0FBVztDQUM1QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJO0lBQ0gsUUFBUSxRQUFRLE9BQU8sUUFBUSxLQUFLO0dBQ3JDLFFBQVE7SUFDUCxVQUFVLE1BQU0sVUFBVSxTQUFTLFFBQVE7SUFDM0MsUUFBUSxRQUFRO0dBQ2pCO0dBQ0EsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7Ozs7O0FBWUEsU0FBUyxZQUFZO0NBQ3BCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsT0FBTyxTQUFTO0dBQ2YsUUFBUSxRQUFRLFFBQVEsUUFBUSxLQUFLO0dBQ3JDLE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQkEsU0FBUyxjQUFjO0NBQ3RCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsT0FBTyxTQUFTO0dBQ2YsUUFBUSxRQUF3Qiw0QkFBWSxRQUFRLE9BQU8sSUFBSSxPQUFPLElBQUk7R0FDMUUsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLE9BQU8sV0FBVztDQUMxQixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJO0lBQ0gsUUFBUSxRQUFRLElBQUksS0FBSyxRQUFRLEtBQUs7SUFDdEMsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHO0tBQ3pCLFVBQVUsTUFBTSxRQUFRLFNBQVMsVUFBVSxFQUFFLFVBQVUsbUJBQW1CLENBQUM7S0FDM0UsUUFBUSxRQUFRO0lBQ2pCO0dBQ0QsUUFBUTtJQUNQLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtJQUN6QyxRQUFRLFFBQVE7R0FDakI7R0FDQSxPQUFPO0VBQ1I7Q0FDRDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7O0FBbUJBLFNBQVMsY0FBYztDQUN0QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLE9BQU8sU0FBUztHQUNmLFFBQVEsUUFBd0IsNEJBQVksUUFBUSxPQUFPLEtBQUssT0FBTyxLQUFLO0dBQzVFLE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7QUFVQSxTQUFTLGNBQWM7Q0FDdEIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxPQUFPLFNBQVM7R0FDZixRQUFRLFFBQVEsUUFBUSxNQUFNLFlBQVk7R0FDMUMsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7Ozs7O0FBWUEsU0FBUyxXQUFXLGFBQWE7Q0FDaEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUDtFQUNBLE9BQU8sU0FBUztHQUNmLFFBQVEsUUFBUSxRQUFRLFFBQVEsS0FBSyxjQUFjLEtBQUssY0FBYyxRQUFRO0dBQzlFLE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7OztBQVlBLFNBQVMsV0FBVyxhQUFhO0NBQ2hDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1A7RUFDQSxPQUFPLFNBQVM7R0FDZixRQUFRLFFBQVEsUUFBUSxRQUFRLEtBQUssY0FBYyxLQUFLLGNBQWMsUUFBUTtHQUM5RSxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsU0FBUyxXQUFXO0NBQzVCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUk7SUFDSCxRQUFRLFFBQVEsT0FBTyxRQUFRLEtBQUs7SUFDcEMsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHO0tBQ3pCLFVBQVUsTUFBTSxVQUFVLFNBQVMsUUFBUTtLQUMzQyxRQUFRLFFBQVE7SUFDakI7R0FDRCxRQUFRO0lBQ1AsVUFBVSxNQUFNLFVBQVUsU0FBUyxRQUFRO0lBQzNDLFFBQVEsUUFBUTtHQUNqQjtHQUNBLE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQkEsU0FBUyxlQUFlO0NBQ3ZCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsT0FBTyxTQUFTO0dBQ2YsUUFBUSxRQUF3Qiw0QkFBWSxRQUFRLE9BQU8sSUFBSSxNQUFNLElBQUk7R0FDekUsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxTQUFTLGNBQWM7Q0FDdEIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxPQUFPLFNBQVM7R0FDZixRQUFRLFFBQXdCLDRCQUFZLFFBQVEsT0FBTyxLQUFLLE9BQU8sS0FBSztHQUM1RSxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsU0FBUyxXQUFXO0NBQzVCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUk7SUFDSCxRQUFRLFFBQVEsT0FBTyxRQUFRLEtBQUs7R0FDckMsUUFBUTtJQUNQLFVBQVUsTUFBTSxVQUFVLFNBQVMsUUFBUTtJQUMzQyxRQUFRLFFBQVE7R0FDakI7R0FDQSxPQUFPO0VBQ1I7Q0FDRDtBQUNEOzs7Ozs7O0FBVUEsU0FBUyxjQUFjO0NBQ3RCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsT0FBTyxTQUFTO0dBQ2YsUUFBUSxRQUFRLFFBQVEsTUFBTSxZQUFZO0dBQzFDLE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7OztBQVlBLFNBQVMsVUFBVSxXQUFXO0NBQzdCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1A7RUFDQSxPQUFPLFNBQVM7R0FDZixRQUFRLFFBQVEsS0FBSyxVQUFVLFFBQVEsS0FBSztHQUM1QyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOzs7Ozs7Ozs7QUFZQSxTQUFTLGVBQWUsV0FBVztDQUNsQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQO0VBQ0EsTUFBTSxPQUFPLFNBQVM7R0FDckIsUUFBUSxRQUFRLE1BQU0sS0FBSyxVQUFVLFFBQVEsS0FBSztHQUNsRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOzs7Ozs7O0FBVUEsU0FBUyxPQUFPO0NBQ2YsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxPQUFPLFNBQVM7R0FDZixRQUFRLFFBQVEsUUFBUSxNQUFNLEtBQUs7R0FDbkMsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7OztBQVVBLFNBQVMsVUFBVTtDQUNsQixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsT0FBTztFQUNQLE9BQU8sU0FBUztHQUNmLFFBQVEsUUFBUSxRQUFRLE1BQU0sUUFBUTtHQUN0QyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOzs7Ozs7O0FBVUEsU0FBUyxZQUFZO0NBQ3BCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsT0FBTyxTQUFTO0dBQ2YsUUFBUSxRQUFRLFFBQVEsTUFBTSxVQUFVO0dBQ3hDLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxLQUFLLFdBQVc7Q0FDeEIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0VBQ1QsYUFBYTtFQUNiLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxDQUFDLEtBQUssWUFBWSxLQUFLLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNyRyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsSUFBSSxXQUFXO0NBQ3ZCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULFlBQVksT0FBTztHQUNsQixJQUFJO0lBQ0gsSUFBSSxJQUFJLEtBQUs7SUFDYixPQUFPO0dBQ1IsUUFBUTtJQUNQLE9BQU87R0FDUjtFQUNEO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxPQUFPLFNBQVMsUUFBUTtHQUMvRixPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsS0FBSyxXQUFXO0NBQ3hCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWE7RUFDYixTQUFTO0VBQ1QsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFlBQVksS0FBSyxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDckcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLE1BQU0sYUFBYSxXQUFXO0NBQ3RDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyx1QkFBdUIsT0FBTyxZQUFZLE9BQU8sSUFBb0IsMkJBQVcsV0FBVztFQUNwRztFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsU0FBUyxFQUFFLEtBQUssZUFBZSxRQUFRLFNBQVMsS0FBSyxlQUFlLFFBQVEsUUFBUSxVQUFVLE1BQU0sU0FBUyxTQUFTLFVBQVUsRUFBRSxVQUFVLFFBQVEsaUJBQWlCLE9BQU8sUUFBUSxNQUFNLE9BQU8sSUFBb0IsMkJBQVcsUUFBUSxLQUFLLEVBQUUsQ0FBQztHQUM1UCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsT0FBTyxhQUFhLFdBQVc7Q0FDdkMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTLEdBQW1CLDZCQUFhLFlBQVksS0FBSyxZQUFZLG1CQUFtQixPQUFPLFFBQVEsT0FBTyxJQUFvQiwyQkFBVyxPQUFPLENBQUMsR0FBRyxHQUFHO0VBQzVKO0VBQ0EsU0FBUztFQUNULE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxTQUFTLENBQUMsS0FBSyxZQUFZLE1BQU0sWUFBWSxXQUFXLFFBQVEsU0FBUyxXQUFXLFFBQVEsS0FBSyxHQUFHLFVBQVUsTUFBTSxTQUFTLFNBQVMsVUFBVSxFQUFFLFVBQVUsUUFBUSxpQkFBaUIsT0FBTyxRQUFRLE1BQU0sT0FBTyxJQUFvQiwyQkFBVyxRQUFRLEtBQUssRUFBRSxDQUFDO0dBQzVRLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxNQUFNLFNBQVMsYUFBYSxXQUFXO0NBQy9DLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUyxHQUFHO0VBQ1o7RUFDQTtFQUNBLFNBQVM7RUFDVCxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsT0FBTztJQUNsQixNQUFNLFFBQXdCLDhCQUFjLEtBQUssU0FBUyxRQUFRLEtBQUs7SUFDdkUsSUFBSSxVQUFVLEtBQUssYUFBYSxVQUFVLE1BQU0sU0FBUyxTQUFTLFVBQVUsRUFBRSxVQUFVLEdBQUcsUUFBUSxDQUFDO0dBQ3JHO0dBQ0EsT0FBTztFQUNSO0NBQ0Q7QUFDRDtBQUlBLElBQU0scUJBQXFCLEVBQUUsWUFBWSxLQUFLOzs7Ozs7OztBQVc5QyxTQUFTLE9BQU8sUUFBUSxPQUFPO0NBQzlCLE1BQU0sU0FBUyxPQUFPLE9BQU8sQ0FBQyxFQUFFLE9BQU8sTUFBTSxHQUFHLGtCQUFrQixDQUFDLENBQUM7Q0FDcEUsSUFBSSxRQUFRLE1BQU0sSUFBSSxVQUFVLE1BQU07QUFDdkM7Ozs7QUFPQSxJQUFJLFlBQVksTUFBTTtDQUNyQixZQUFZLFVBQVU7RUFDckIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssVUFBVSxVQUFVLFdBQVc7RUFDcEMsS0FBSyxTQUFTLFVBQVUsVUFBVTtFQUNsQyxLQUFLLFlBQVksU0FBUyxLQUFLLE1BQU07Q0FDdEM7Ozs7Ozs7O0NBUUEsVUFBVSxPQUFPO0VBQ2hCLE1BQU0sT0FBTyxPQUFPO0VBQ3BCLElBQUksU0FBUyxVQUFVLE9BQU8sSUFBSSxNQUFNO0VBQ3hDLElBQUksU0FBUyxZQUFZLFNBQVMsV0FBVyxPQUFPLEdBQUc7RUFDdkQsSUFBSSxTQUFTLFVBQVUsT0FBTyxHQUFHLE1BQU07RUFDdkMsSUFBSSxTQUFTLFlBQVksU0FBUyxZQUFZO0dBQzdDLElBQUksT0FBTztJQUNWLEtBQUssV0FBVyxLQUFLLHlCQUF5QixJQUFJLFFBQVE7SUFDMUQsSUFBSSxLQUFLLEtBQUssT0FBTyxJQUFJLEtBQUs7SUFDOUIsSUFBSSxDQUFDLElBQUk7S0FDUixLQUFLLEVBQUUsS0FBSztLQUNaLEtBQUssT0FBTyxJQUFJLE9BQU8sRUFBRTtJQUMxQjtJQUNBLE9BQU8sSUFBSTtHQUNaO0dBQ0EsT0FBTztFQUNSO0VBQ0EsT0FBTztDQUNSOzs7Ozs7Ozs7Q0FTQSxJQUFJLE9BQU8sV0FBVyxDQUFDLEdBQUc7RUFDekIsT0FBTyxHQUFHLEtBQUssVUFBVSxLQUFLLEVBQUUsR0FBRyxLQUFLLFVBQVUsU0FBUyxJQUFJLEVBQUUsR0FBRyxLQUFLLFVBQVUsU0FBUyxPQUFPLEVBQUUsR0FBRyxLQUFLLFVBQVUsU0FBUyxVQUFVLEVBQUUsR0FBRyxLQUFLLFVBQVUsU0FBUyxjQUFjO0NBQ3RMOzs7Ozs7OztDQVFBLElBQUksS0FBSztFQUNSLElBQUksQ0FBQyxLQUFLLE9BQU8sT0FBTyxLQUFLO0VBQzdCLE1BQU0sUUFBUSxLQUFLLE1BQU0sSUFBSSxHQUFHO0VBQ2hDLElBQUksQ0FBQyxPQUFPLE9BQU8sS0FBSztFQUN4QixJQUFJLEtBQUssYUFBYSxLQUFLLElBQUksSUFBSSxNQUFNLEtBQUssS0FBSyxRQUFRO0dBQzFELEtBQUssTUFBTSxPQUFPLEdBQUc7R0FDckI7RUFDRDtFQUNBLEtBQUssTUFBTSxPQUFPLEdBQUc7RUFDckIsS0FBSyxNQUFNLElBQUksS0FBSyxLQUFLO0VBQ3pCLE9BQU8sTUFBTTtDQUNkOzs7Ozs7O0NBT0EsSUFBSSxLQUFLLFNBQVM7RUFDakIsS0FBSyxVQUFVLEtBQUssd0JBQXdCLElBQUksSUFBSTtFQUNwRCxLQUFLLE1BQU0sT0FBTyxHQUFHO0VBQ3JCLE1BQU0sWUFBWSxLQUFLLFlBQVksS0FBSyxJQUFJLElBQUk7RUFDaEQsS0FBSyxNQUFNLElBQUksS0FBSyxDQUFDLFNBQVMsU0FBUyxDQUFDO0VBQ3hDLElBQUksS0FBSyxNQUFNLE9BQU8sS0FBSyxTQUFTLEtBQUssTUFBTSxPQUFPLEtBQUssTUFBTSxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLO0NBQ3JGOzs7O0NBSUEsUUFBUTtFQUNQLEtBQUssT0FBTyxNQUFNO0NBQ25CO0FBQ0Q7O0FBS0EsU0FBUyxNQUFNLFFBQVEsVUFBVTtDQUNoQyxPQUFPO0VBQ04sR0FBRztFQUNILGFBQWE7RUFDYixPQUFPLElBQUksVUFBVSxRQUFRO0VBQzdCLElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxXQUFXO0dBQzFCLE1BQU0sTUFBTSxLQUFLLE1BQU0sSUFBSSxRQUFRLE9BQU8sU0FBUztHQUNuRCxJQUFJLGdCQUFnQixLQUFLLE1BQU0sSUFBSSxHQUFHO0dBQ3RDLElBQUksQ0FBQyxlQUFlLEtBQUssTUFBTSxJQUFJLEtBQUssZ0JBQWdCLE9BQU8sT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDO0dBQzFGLE9BQXVCLDhCQUFjLGFBQWE7RUFDbkQ7Q0FDRDtBQUNEOztBQUtBLFNBQVMsV0FBVyxRQUFRLFVBQVU7Q0FDckMsSUFBSTtDQUNKLE9BQU87RUFDTixHQUFHO0VBQ0gsT0FBTztFQUNQLGFBQWE7RUFDYixPQUFPLElBQUksVUFBVSxRQUFRO0VBQzdCLElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE1BQU0sT0FBTyxTQUFTLFdBQVc7R0FDaEMsTUFBTSxNQUFNLEtBQUssTUFBTSxJQUFJLFFBQVEsT0FBTyxTQUFTO0dBQ25ELE1BQU0sU0FBUyxLQUFLLE1BQU0sSUFBSSxHQUFHO0dBQ2pDLElBQUksUUFBUSxPQUF1Qiw4QkFBYyxNQUFNO0dBQ3ZELElBQUksWUFBWSxZQUFZLElBQUksR0FBRztHQUNuQyxJQUFJLENBQUMsV0FBVztJQUNmLGVBQWUsNkJBQTZCLElBQUksSUFBSTtJQUNwRCxZQUFZLFFBQVEsUUFBUSxPQUFPLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQztJQUM5RCxXQUFXLElBQUksS0FBSyxTQUFTO0dBQzlCO0dBQ0EsSUFBSTtJQUNILE1BQU0sZ0JBQWdCLE1BQU07SUFDNUIsS0FBSyxNQUFNLElBQUksS0FBSyxhQUFhO0lBQ2pDLE9BQXVCLDhCQUFjLGFBQWE7R0FDbkQsVUFBVTtJQUNULFlBQVksT0FBTyxHQUFHO0dBQ3ZCO0VBQ0Q7Q0FDRDtBQUNEOzs7Ozs7Ozs7O0FBYUEsU0FBUyxPQUFPLFFBQVEsVUFBVTtDQUNqQyxPQUFPO0VBQ04sR0FBRztFQUNILElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxTQUFTO0dBQ3hCLE9BQU8sT0FBTyxPQUFPLENBQUMsU0FBUztJQUM5QixHQUFHO0lBQ0gsR0FBRztHQUNKLENBQUM7RUFDRjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7O0FBY0EsU0FBUyxZQUFZLFFBQVEsU0FBUyxVQUFVO0NBQy9DLE9BQU8sT0FBTyxPQUFPLGFBQWEsYUFBYSxPQUFPLFNBQVMsU0FBUyxRQUFRLElBQUksT0FBTztBQUM1Rjs7Ozs7Ozs7OztBQWFBLFNBQVMsU0FBUyxRQUFRLFlBQVk7Q0FDckMsT0FBTztFQUNOLEdBQUc7RUFDSCxVQUFVO0VBQ1YsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsT0FBTyxTQUFTLFVBQVU7R0FDekIsTUFBTSxnQkFBZ0IsT0FBTyxPQUFPLENBQUMsU0FBUyxRQUFRO0dBQ3RELE9BQU8sY0FBYyxTQUFTO0lBQzdCLE9BQU87SUFDUCxPQUF1Qiw0QkFBWSxNQUFNLGVBQWUsUUFBUTtHQUNqRSxJQUFJO0VBQ0w7Q0FDRDtBQUNEOzs7Ozs7Ozs7O0FBYUEsU0FBUyxjQUFjLFFBQVEsWUFBWTtDQUMxQyxPQUFPO0VBQ04sR0FBRztFQUNILFVBQVU7RUFDVixPQUFPO0VBQ1AsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsTUFBTSxPQUFPLFNBQVMsVUFBVTtHQUMvQixNQUFNLGdCQUFnQixNQUFNLE9BQU8sT0FBTyxDQUFDLFNBQVMsUUFBUTtHQUM1RCxPQUFPLGNBQWMsU0FBUztJQUM3QixPQUFPO0lBQ1AsT0FBTyxNQUFzQiw0QkFBWSxNQUFNLGVBQWUsUUFBUTtHQUN2RSxJQUFJO0VBQ0w7Q0FDRDtBQUNEOztBQUtBLFNBQVMsUUFBUSxRQUFRO0NBQ3hCLE1BQU0sYUFBYSxDQUFDO0NBQ3BCLEtBQUssTUFBTSxTQUFTLFFBQVEsSUFBSSxNQUFNLE1BQU07RUFDM0MsTUFBTSxVQUEwQiwyQkFBVyxLQUFLO0VBQ2hELElBQUksU0FBUztHQUNaLElBQUksQ0FBQyxXQUFXLFFBQVEsV0FBVyxTQUFTLENBQUM7R0FDN0MsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLFdBQVcsUUFBUSxPQUFPLEdBQUcsV0FBVyxPQUFPLFFBQVEsQ0FBQyxLQUFLLE1BQU0sT0FBTztRQUM5RyxXQUFXLE9BQU8sV0FBVyxDQUFDLE1BQU0sT0FBTztFQUNqRCxPQUFPLElBQUksV0FBVyxPQUFPLFdBQVcsTUFBTSxLQUFLLE1BQU0sT0FBTztPQUMzRCxXQUFXLFFBQVEsQ0FBQyxNQUFNLE9BQU87Q0FDdkMsT0FBTyxJQUFJLFdBQVcsTUFBTSxXQUFXLEtBQUssS0FBSyxNQUFNLE9BQU87TUFDekQsV0FBVyxPQUFPLENBQUMsTUFBTSxPQUFPO0NBQ3JDLE9BQU87QUFDUjs7Ozs7Ozs7OztBQWFBLFNBQVMsUUFBUSxRQUFRLE1BQU07Q0FDOUIsT0FBTztFQUNOLEdBQUc7RUFDSCxPQUFPLFNBQVMsVUFBVTtHQUN6QixNQUFNLGFBQWEsUUFBUSxVQUFVLENBQUMsR0FBRyxRQUFRLE1BQU07R0FDdkQsVUFBVSxPQUFPLE9BQU8sQ0FBQyxTQUFTLFFBQVE7R0FDMUMsSUFBSSxRQUFRLFFBQ047U0FBQSxNQUFNLFNBQVMsUUFBUSxRQUFRLElBQUksQ0FBQyxZQUFZLFNBQVMsS0FBSyxHQUFHO0tBQ3JFLElBQUksWUFBWSxRQUFRO0tBQ3hCLEtBQUssTUFBTSxPQUFPLE1BQU07TUFDdkIsTUFBTSxZQUFZLFVBQVU7TUFDNUIsTUFBTSxXQUFXO09BQ2hCLE1BQU07T0FDTixRQUFRO09BQ1IsT0FBTztPQUNQO09BQ0EsT0FBTztNQUNSO01BQ0EsSUFBSSxNQUFNLE1BQU0sTUFBTSxLQUFLLEtBQUssUUFBUTtXQUNuQyxNQUFNLE9BQU8sQ0FBQyxRQUFRO01BQzNCLElBQUksQ0FBQyxXQUFXO01BQ2hCLFlBQVk7S0FDYjtJQUNEOztHQUVELE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7QUFhQSxTQUFTLGFBQWEsUUFBUSxNQUFNO0NBQ25DLE9BQU87RUFDTixHQUFHO0VBQ0gsT0FBTztFQUNQLE1BQU0sT0FBTyxTQUFTLFVBQVU7R0FDL0IsTUFBTSxhQUFhLFFBQVEsVUFBVSxDQUFDLEdBQUcsUUFBUSxNQUFNO0dBQ3ZELFVBQVUsTUFBTSxPQUFPLE9BQU8sQ0FBQyxTQUFTLFFBQVE7R0FDaEQsSUFBSSxRQUFRLFFBQ047U0FBQSxNQUFNLFNBQVMsUUFBUSxRQUFRLElBQUksQ0FBQyxZQUFZLFNBQVMsS0FBSyxHQUFHO0tBQ3JFLElBQUksWUFBWSxRQUFRO0tBQ3hCLEtBQUssTUFBTSxPQUFPLE1BQU07TUFDdkIsTUFBTSxZQUFZLFVBQVU7TUFDNUIsTUFBTSxXQUFXO09BQ2hCLE1BQU07T0FDTixRQUFRO09BQ1IsT0FBTztPQUNQO09BQ0EsT0FBTztNQUNSO01BQ0EsSUFBSSxNQUFNLE1BQU0sTUFBTSxLQUFLLEtBQUssUUFBUTtXQUNuQyxNQUFNLE9BQU8sQ0FBQyxRQUFRO01BQzNCLElBQUksQ0FBQyxXQUFXO01BQ2hCLFlBQVk7S0FDYjtJQUNEOztHQUVELE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7O0FBY0EsU0FBUyxXQUFXLFFBQVEsU0FBUyxVQUFVO0NBQzlDLE9BQU8sT0FBTyxPQUFPLFlBQVksYUFBYSxPQUFPLFFBQVEsU0FBUyxRQUFRLElBQUksT0FBTztBQUMxRjs7Ozs7Ozs7Ozs7OztBQWdCQSxTQUFTLFlBQVksUUFBUTtDQUM1QixJQUFJLGFBQWEsUUFBUTtFQUN4QixNQUFNLFdBQVcsQ0FBQztFQUNsQixLQUFLLE1BQU0sT0FBTyxPQUFPLFNBQVMsU0FBUyxPQUF1Qiw0QkFBWSxPQUFPLFFBQVEsSUFBSTtFQUNqRyxPQUFPO0NBQ1I7Q0FDQSxJQUFJLFdBQVcsUUFBUSxPQUFPLE9BQU8sTUFBTSxJQUFJLFdBQVc7Q0FDMUQsT0FBdUIsMkJBQVcsTUFBTTtBQUN6Qzs7Ozs7Ozs7Ozs7OztBQWdCQSxlQUFlLGlCQUFpQixRQUFRO0NBQ3ZDLElBQUksYUFBYSxRQUFRLE9BQU8sT0FBTyxZQUFZLE1BQU0sUUFBUSxJQUFJLE9BQU8sUUFBUSxPQUFPLE9BQU8sQ0FBQyxDQUFDLElBQUksT0FBTyxDQUFDLEtBQUssYUFBYSxDQUFDLEtBQUssTUFBc0IsaUNBQWlCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztDQUMxTCxJQUFJLFdBQVcsUUFBUSxPQUFPLFFBQVEsSUFBSSxPQUFPLE1BQU0sSUFBSSxnQkFBZ0IsQ0FBQztDQUM1RSxPQUF1QiwyQkFBVyxNQUFNO0FBQ3pDOzs7Ozs7Ozs7Ozs7OztBQWlCQSxTQUFTLGVBQWUsUUFBUTtDQUMvQixPQUF1QixpQ0FBaUIsUUFBUSxhQUFhO0FBQzlEOzs7Ozs7Ozs7Ozs7OztBQWlCQSxTQUFTLFlBQVksUUFBUTtDQUM1QixNQUFNLGFBQWEsQ0FBQztDQUNwQixTQUFTLGtCQUFrQixVQUFVO0VBQ3BDLElBQUksVUFBVSxVQUNSO1FBQUEsTUFBTSxRQUFRLFNBQVMsTUFBTSxJQUFJLEtBQUssU0FBUyxZQUFZLFVBQVUsTUFBTSxrQkFBa0IsSUFBSTtRQUNqRyxJQUFJLEtBQUssU0FBUyxjQUFjLEtBQUssU0FBUyxZQUFZLEtBQUssTUFBTSxXQUFXLEtBQUssVUFBVSxXQUFXLEtBQUssT0FBTztFQUFBO0NBRTdIO0NBQ0Esa0JBQWtCLE1BQU07Q0FDeEIsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7O0FBZ0JBLFNBQVMsYUFBYSxRQUFRO0NBQzdCLElBQUksYUFBYSxRQUFRO0VBQ3hCLE1BQU0sV0FBVyxDQUFDO0VBQ2xCLEtBQUssTUFBTSxPQUFPLE9BQU8sU0FBUyxTQUFTLE9BQXVCLDZCQUFhLE9BQU8sUUFBUSxJQUFJO0VBQ2xHLE9BQU87Q0FDUjtDQUNBLElBQUksV0FBVyxRQUFRLE9BQU8sT0FBTyxNQUFNLElBQUksWUFBWTtDQUMzRCxPQUF1Qiw0QkFBWSxNQUFNO0FBQzFDOzs7Ozs7Ozs7Ozs7O0FBZ0JBLGVBQWUsa0JBQWtCLFFBQVE7Q0FDeEMsSUFBSSxhQUFhLFFBQVEsT0FBTyxPQUFPLFlBQVksTUFBTSxRQUFRLElBQUksT0FBTyxRQUFRLE9BQU8sT0FBTyxDQUFDLENBQUMsSUFBSSxPQUFPLENBQUMsS0FBSyxhQUFhLENBQUMsS0FBSyxNQUFzQixrQ0FBa0IsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0NBQzNMLElBQUksV0FBVyxRQUFRLE9BQU8sUUFBUSxJQUFJLE9BQU8sTUFBTSxJQUFJLGlCQUFpQixDQUFDO0NBQzdFLE9BQXVCLDRCQUFZLE1BQU07QUFDMUM7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQVMsWUFBWSxRQUFRO0NBQzVCLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLFNBQVMsZ0JBQWdCLFVBQVU7RUFDbEMsSUFBSSxVQUFVLFVBQ1I7UUFBQSxNQUFNLFFBQVEsU0FBUyxNQUFNLElBQUksS0FBSyxTQUFTLFlBQVksVUFBVSxNQUFNLGdCQUFnQixJQUFJO1FBQy9GLElBQUksS0FBSyxTQUFTLGNBQWMsS0FBSyxTQUFTLFlBQVksT0FBTyxPQUFPLFFBQVEsS0FBSyxRQUFRO0VBQUE7Q0FFcEc7Q0FDQSxnQkFBZ0IsTUFBTTtDQUN0QixPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQVMsU0FBUyxRQUFRO0NBQ3pCLE9BQXVCLGlDQUFpQixRQUFRLE9BQU87QUFDeEQ7Ozs7Ozs7Ozs7O0FBY0EsU0FBUyxHQUFHLFFBQVEsT0FBTztDQUMxQixPQUFPLENBQUMsT0FBTyxPQUFPLENBQUMsRUFBRSxPQUFPLE1BQU0sR0FBRyxrQkFBa0IsQ0FBQyxDQUFDO0FBQzlEOzs7Ozs7Ozs7OztBQWNBLFNBQVMsTUFBTTtDQUNkLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQLElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUztHQUNmLFFBQVEsUUFBUTtHQUNoQixPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsTUFBTSxNQUFNLFdBQVc7Q0FDL0IsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1A7RUFDQSxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsT0FBTyxTQUFTLFVBQVU7R0FDekIsTUFBTSxRQUFRLFFBQVE7R0FDdEIsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHO0lBQ3pCLFFBQVEsUUFBUTtJQUNoQixRQUFRLFFBQVEsQ0FBQztJQUNqQixLQUFLLElBQUksTUFBTSxHQUFHLE1BQU0sTUFBTSxRQUFRLE9BQU87S0FDNUMsTUFBTSxVQUFVLE1BQU07S0FDdEIsTUFBTSxjQUFjLEtBQUssS0FBSyxPQUFPLENBQUMsRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0tBQ2xFLElBQUksWUFBWSxRQUFRO01BQ3ZCLE1BQU0sV0FBVztPQUNoQixNQUFNO09BQ04sUUFBUTtPQUNSO09BQ0E7T0FDQSxPQUFPO01BQ1I7TUFDQSxLQUFLLE1BQU0sU0FBUyxZQUFZLFFBQVE7T0FDdkMsSUFBSSxNQUFNLE1BQU0sTUFBTSxLQUFLLFFBQVEsUUFBUTtZQUN0QyxNQUFNLE9BQU8sQ0FBQyxRQUFRO09BQzNCLFFBQVEsUUFBUSxLQUFLLEtBQUs7TUFDM0I7TUFDQSxJQUFJLENBQUMsUUFBUSxRQUFRLFFBQVEsU0FBUyxZQUFZO01BQ2xELElBQUksU0FBUyxZQUFZO09BQ3hCLFFBQVEsUUFBUTtPQUNoQjtNQUNEO0tBQ0Q7S0FDQSxJQUFJLENBQUMsWUFBWSxPQUFPLFFBQVEsUUFBUTtLQUN4QyxRQUFRLE1BQU0sS0FBSyxZQUFZLEtBQUs7SUFDckM7R0FDRCxPQUFPLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNoRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsV0FBVyxNQUFNLFdBQVc7Q0FDcEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1A7RUFDQSxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsTUFBTSxPQUFPLFNBQVMsVUFBVTtHQUMvQixNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7SUFDekIsUUFBUSxRQUFRO0lBQ2hCLFFBQVEsUUFBUSxDQUFDO0lBQ2pCLE1BQU0sZUFBZSxNQUFNLFFBQVEsSUFBSSxNQUFNLEtBQUssWUFBWSxLQUFLLEtBQUssT0FBTyxDQUFDLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUSxDQUFDLENBQUM7SUFDOUcsS0FBSyxJQUFJLE1BQU0sR0FBRyxNQUFNLGFBQWEsUUFBUSxPQUFPO0tBQ25ELE1BQU0sY0FBYyxhQUFhO0tBQ2pDLElBQUksWUFBWSxRQUFRO01BQ3ZCLE1BQU0sV0FBVztPQUNoQixNQUFNO09BQ04sUUFBUTtPQUNSO09BQ0E7T0FDQSxPQUFPLE1BQU07TUFDZDtNQUNBLEtBQUssTUFBTSxTQUFTLFlBQVksUUFBUTtPQUN2QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO1lBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLFlBQVk7TUFDbEQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksQ0FBQyxZQUFZLE9BQU8sUUFBUSxRQUFRO0tBQ3hDLFFBQVEsTUFBTSxLQUFLLFlBQVksS0FBSztJQUNyQztHQUNELE9BQU8sVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ2hELE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxPQUFPLFdBQVc7Q0FDMUIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksT0FBTyxRQUFRLFVBQVUsVUFBVSxRQUFRLFFBQVE7UUFDbEQsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQzlDLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxLQUFLLFdBQVc7Q0FDeEIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxpQkFBaUIsTUFBTSxRQUFRLFFBQVE7UUFDOUMsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQzlDLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxRQUFRLFdBQVc7Q0FDM0IsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksT0FBTyxRQUFRLFVBQVUsV0FBVyxRQUFRLFFBQVE7UUFDbkQsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQzlDLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxPQUFPLFNBQVMsV0FBVztDQUNuQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUCxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksS0FBSyxNQUFNLFFBQVEsS0FBSyxHQUFHLFFBQVEsUUFBUTtRQUMxQyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDOUMsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFlBQVksU0FBUyxXQUFXO0NBQ3hDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQLE9BQU87RUFDUCxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsTUFBTSxPQUFPLFNBQVMsVUFBVTtHQUMvQixJQUFJLE1BQU0sS0FBSyxNQUFNLFFBQVEsS0FBSyxHQUFHLFFBQVEsUUFBUTtRQUNoRCxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDOUMsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLEtBQUssV0FBVztDQUN4QixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUCxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLGlCQUFpQixNQUFNLElBQUksQ0FBQyxNQUFNLFFBQVEsS0FBSyxHQUFHLFFBQVEsUUFBUTtRQUN6RSxVQUFVLE1BQU0sUUFBUSxTQUFTLFVBQVUsRUFBRSxVQUFVLG1CQUFtQixDQUFDO1FBQzNFLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUM5QyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsTUFBTSxRQUFRLFdBQVc7Q0FDakMsTUFBTSxVQUFVLENBQUM7Q0FDakIsS0FBSyxNQUFNLE9BQU8sUUFBUSxJQUFJLEdBQUcsQ0FBQyxVQUFVLE9BQU8sT0FBTyxPQUFPLFNBQVMsWUFBWSxDQUFDLE9BQU8sR0FBRyxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUcsR0FBRyxRQUFRLEtBQUssT0FBTyxJQUFJO0NBQ3JKLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUF5Qiw2QkFBYSxRQUFRLElBQUksVUFBVSxHQUFHLEdBQUc7RUFDbEUsT0FBTztFQUNQLE1BQU07RUFDTjtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLEtBQUssUUFBUSxTQUFTLFFBQVEsS0FBSyxHQUFHLFFBQVEsUUFBUTtRQUNyRCxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDOUMsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLGNBQWMsU0FBUyxVQUFVO0NBQ3pDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTLFFBQVE7RUFDakIsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLE9BQU8sS0FBSyxRQUFRLE9BQU8sQ0FBQyxTQUFTLFFBQVE7RUFDOUM7Q0FDRDtBQUNEOztBQUtBLFNBQVMsbUJBQW1CLFNBQVMsVUFBVTtDQUM5QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUyxRQUFRO0VBQ2pCLE9BQU87RUFDUDtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxNQUFNLE9BQU8sU0FBUyxVQUFVO0dBQy9CLE9BQU8sS0FBSyxRQUFRLE9BQU8sQ0FBQyxTQUFTLFFBQVE7RUFDOUM7Q0FDRDtBQUNEOztBQUtBLFNBQVMsS0FBSyxXQUFXO0NBQ3hCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsaUJBQWlCLE1BQU0sUUFBUSxRQUFRO1FBQzlDLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUM5QyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsVUFBVSxXQUFXO0NBQzdCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLE9BQU8sUUFBUSxVQUFVLFlBQVksUUFBUSxRQUFRO1FBQ3BELFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUM5QyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsU0FBUyxRQUFRLFdBQVc7Q0FDcEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVMsT0FBTztFQUNoQixPQUFPO0VBQ1AsT0FBTztFQUNQLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsaUJBQWlCLEtBQUssT0FBTyxRQUFRLFFBQVE7UUFDcEQsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQzlDLE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7OztBQWVBLFNBQVMsT0FBTyxRQUFRLFFBQVE7Q0FDL0IsSUFBSSxPQUFPLFdBQVcsT0FBTyxRQUFRO0VBQ3BDLElBQUksV0FBVyxVQUFVLGtCQUFrQixRQUFRLGtCQUFrQixRQUFRLENBQUMsV0FBVyxDQUFDLFFBQVEsT0FBTyxFQUFFLE9BQU8sT0FBTztFQUN6SCxJQUFJLFVBQVUsVUFBVSxPQUFPLGdCQUFnQixVQUFVLE9BQU8sZ0JBQWdCLFFBQVE7R0FDdkYsTUFBTSxZQUFZLEVBQUUsR0FBRyxPQUFPO0dBQzlCLEtBQUssTUFBTSxPQUFPLFFBQVEsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLFFBQVEsR0FBRyxHQUFHO0lBQ2hGLE1BQU0sVUFBMEIsdUJBQU8sT0FBTyxNQUFNLE9BQU8sSUFBSTtJQUMvRCxJQUFJLFFBQVEsT0FBTyxPQUFPO0lBQzFCLFVBQVUsT0FBTyxRQUFRO0dBQzFCLE9BQU8sVUFBVSxPQUFPLE9BQU87R0FDL0IsT0FBTyxFQUFFLE9BQU8sVUFBVTtFQUMzQjtFQUNBLElBQUksTUFBTSxRQUFRLE1BQU0sS0FBSyxNQUFNLFFBQVEsTUFBTSxHQUM1QztPQUFBLE9BQU8sV0FBVyxPQUFPLFFBQVE7SUFDcEMsTUFBTSxZQUFZLENBQUMsR0FBRyxNQUFNO0lBQzVCLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxPQUFPLFFBQVEsU0FBUztLQUNuRCxNQUFNLFVBQTBCLHVCQUFPLE9BQU8sUUFBUSxPQUFPLE1BQU07S0FDbkUsSUFBSSxRQUFRLE9BQU8sT0FBTztLQUMxQixVQUFVLFNBQVMsUUFBUTtJQUM1QjtJQUNBLE9BQU8sRUFBRSxPQUFPLFVBQVU7R0FDM0I7O0NBRUY7Q0FDQSxPQUFPLEVBQUUsT0FBTyxLQUFLO0FBQ3RCOztBQUtBLFNBQVMsVUFBVSxTQUFTLFdBQVc7Q0FDdEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQXlCLDZCQUFhLFFBQVEsS0FBSyxXQUFXLE9BQU8sT0FBTyxHQUFHLEdBQUc7RUFDbEYsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksS0FBSyxRQUFRLFFBQVE7SUFDeEIsTUFBTSxRQUFRLFFBQVE7SUFDdEIsSUFBSTtJQUNKLFFBQVEsUUFBUTtJQUNoQixLQUFLLE1BQU0sVUFBVSxLQUFLLFNBQVM7S0FDbEMsTUFBTSxnQkFBZ0IsT0FBTyxPQUFPLENBQUMsRUFBRSxPQUFPLE1BQU0sR0FBRyxRQUFRO0tBQy9ELElBQUksY0FBYyxRQUFRO01BQ3pCLElBQUksUUFBUSxRQUFRLEtBQUssTUFBTSxTQUFTLGNBQWMsUUFBUSxRQUFRLE9BQU8sS0FBSyxLQUFLO1dBQ2xGLFFBQVEsU0FBUyxjQUFjO01BQ3BDLElBQUksU0FBUyxZQUFZO09BQ3hCLFFBQVEsUUFBUTtPQUNoQjtNQUNEO0tBQ0Q7S0FDQSxJQUFJLENBQUMsY0FBYyxPQUFPLFFBQVEsUUFBUTtLQUMxQyxJQUFJLFFBQVEsT0FBTyxJQUFJLFNBQVMsUUFBUSxLQUFLLGNBQWMsS0FBSztVQUMzRCxVQUFVLENBQUMsY0FBYyxLQUFLO0lBQ3BDO0lBQ0EsSUFBSSxRQUFRLE9BQU87S0FDbEIsUUFBUSxRQUFRLFFBQVE7S0FDeEIsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLFFBQVEsUUFBUSxTQUFTO01BQ3BELE1BQU0sZUFBK0IsdUJBQU8sUUFBUSxPQUFPLFFBQVEsTUFBTTtNQUN6RSxJQUFJLGFBQWEsT0FBTztPQUN2QixVQUFVLE1BQU0sUUFBUSxTQUFTLFVBQVUsRUFBRSxVQUFVLFVBQVUsQ0FBQztPQUNsRTtNQUNEO01BQ0EsUUFBUSxRQUFRLGFBQWE7S0FDOUI7SUFDRDtHQUNELE9BQU8sVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ2hELE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxlQUFlLFNBQVMsV0FBVztDQUMzQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBeUIsNkJBQWEsUUFBUSxLQUFLLFdBQVcsT0FBTyxPQUFPLEdBQUcsR0FBRztFQUNsRixPQUFPO0VBQ1A7RUFDQSxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsTUFBTSxPQUFPLFNBQVMsVUFBVTtHQUMvQixJQUFJLEtBQUssUUFBUSxRQUFRO0lBQ3hCLE1BQU0sUUFBUSxRQUFRO0lBQ3RCLElBQUk7SUFDSixRQUFRLFFBQVE7SUFDaEIsTUFBTSxpQkFBaUIsTUFBTSxRQUFRLElBQUksS0FBSyxRQUFRLEtBQUssV0FBVyxPQUFPLE9BQU8sQ0FBQyxFQUFFLE9BQU8sTUFBTSxHQUFHLFFBQVEsQ0FBQyxDQUFDO0lBQ2pILEtBQUssTUFBTSxpQkFBaUIsZ0JBQWdCO0tBQzNDLElBQUksY0FBYyxRQUFRO01BQ3pCLElBQUksUUFBUSxRQUFRLEtBQUssTUFBTSxTQUFTLGNBQWMsUUFBUSxRQUFRLE9BQU8sS0FBSyxLQUFLO1dBQ2xGLFFBQVEsU0FBUyxjQUFjO01BQ3BDLElBQUksU0FBUyxZQUFZO09BQ3hCLFFBQVEsUUFBUTtPQUNoQjtNQUNEO0tBQ0Q7S0FDQSxJQUFJLENBQUMsY0FBYyxPQUFPLFFBQVEsUUFBUTtLQUMxQyxJQUFJLFFBQVEsT0FBTyxJQUFJLFNBQVMsUUFBUSxLQUFLLGNBQWMsS0FBSztVQUMzRCxVQUFVLENBQUMsY0FBYyxLQUFLO0lBQ3BDO0lBQ0EsSUFBSSxRQUFRLE9BQU87S0FDbEIsUUFBUSxRQUFRLFFBQVE7S0FDeEIsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLFFBQVEsUUFBUSxTQUFTO01BQ3BELE1BQU0sZUFBK0IsdUJBQU8sUUFBUSxPQUFPLFFBQVEsTUFBTTtNQUN6RSxJQUFJLGFBQWEsT0FBTztPQUN2QixVQUFVLE1BQU0sUUFBUSxTQUFTLFVBQVUsRUFBRSxVQUFVLFVBQVUsQ0FBQztPQUNsRTtNQUNEO01BQ0EsUUFBUSxRQUFRLGFBQWE7S0FDOUI7SUFDRDtHQUNELE9BQU8sVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ2hELE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7OztBQVlBLFNBQVMsS0FBSyxRQUFRO0NBQ3JCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQO0VBQ0EsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsT0FBTyxTQUFTLFVBQVU7R0FDekIsT0FBTyxLQUFLLE9BQU8sUUFBUSxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxRQUFRO0VBQzVEO0NBQ0Q7QUFDRDs7Ozs7Ozs7O0FBWUEsU0FBUyxVQUFVLFFBQVE7Q0FDMUIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1A7RUFDQSxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxNQUFNLE9BQU8sU0FBUyxVQUFVO0dBQy9CLFFBQVEsTUFBTSxLQUFLLE9BQU8sUUFBUSxLQUFLLEVBQUEsQ0FBRyxPQUFPLENBQUMsU0FBUyxRQUFRO0VBQ3BFO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFFBQVEsVUFBVSxXQUFXO0NBQ3JDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUF5QiwyQkFBVyxRQUFRO0VBQzVDLE9BQU87RUFDUCxTQUFTO0VBQ1QsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxVQUFVLEtBQUssU0FBUyxRQUFRLFFBQVE7UUFDL0MsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQzlDLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxZQUFZLFdBQVcsV0FBVztDQUMxQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUCxTQUFTO0VBQ1QsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksU0FBUyxPQUFPLFVBQVUsVUFBVTtJQUN2QyxRQUFRLFFBQVE7SUFDaEIsUUFBUSxRQUFRLENBQUM7SUFDakIsS0FBSyxNQUFNLE9BQU8sS0FBSyxTQUFTO0tBQy9CLE1BQU0sY0FBYyxLQUFLLFFBQVE7S0FDakMsSUFBSSxPQUFPLFVBQVUsWUFBWSxTQUFTLG9CQUFvQixZQUFZLFNBQVMsY0FBYyxZQUFZLFNBQVMsY0FBYyxZQUFZLFlBQVksS0FBSyxHQUFHO01BQ25LLE1BQU0sVUFBVSxPQUFPLFFBQVEsTUFBTSxPQUF1QiwyQkFBVyxXQUFXO01BQ2xGLE1BQU0sZUFBZSxZQUFZLE9BQU8sQ0FBQyxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7TUFDckUsSUFBSSxhQUFhLFFBQVE7T0FDeEIsTUFBTSxXQUFXO1FBQ2hCLE1BQU07UUFDTixRQUFRO1FBQ1I7UUFDQTtRQUNBLE9BQU87T0FDUjtPQUNBLEtBQUssTUFBTSxTQUFTLGFBQWEsUUFBUTtRQUN4QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO2FBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7UUFDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztPQUMzQjtPQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLGFBQWE7T0FDbkQsSUFBSSxTQUFTLFlBQVk7UUFDeEIsUUFBUSxRQUFRO1FBQ2hCO09BQ0Q7TUFDRDtNQUNBLElBQUksQ0FBQyxhQUFhLE9BQU8sUUFBUSxRQUFRO01BQ3pDLFFBQVEsTUFBTSxPQUFPLGFBQWE7S0FDbkMsT0FBTyxJQUFJLFlBQVksYUFBYSxLQUFLLEdBQUcsUUFBUSxNQUFNLE9BQXVCLDRCQUFZLFdBQVc7VUFDbkcsSUFBSSxZQUFZLFNBQVMsb0JBQW9CLFlBQVksU0FBUyxjQUFjLFlBQVksU0FBUyxXQUFXO01BQ3BILFVBQVUsTUFBTSxPQUFPLFNBQVMsVUFBVTtPQUN6QyxPQUFPLEtBQUs7T0FDWixVQUFVLElBQUksSUFBSTtPQUNsQixNQUFNLENBQUM7UUFDTixNQUFNO1FBQ04sUUFBUTtRQUNSO1FBQ0E7UUFDQSxPQUFPLE1BQU07T0FDZCxDQUFDO01BQ0YsQ0FBQztNQUNELElBQUksU0FBUyxZQUFZO0tBQzFCO0lBQ0Q7SUFDQSxJQUFJLENBQUMsUUFBUSxVQUFVLENBQUMsU0FBUyxZQUMzQjtVQUFBLE1BQU0sT0FBTyxPQUFPLElBQW9CLGtDQUFrQixPQUFPLEdBQUcsS0FBSyxFQUFFLE9BQU8sS0FBSyxVQUFVLFFBQVEsTUFBTSxPQUFPLE1BQU07SUFBQTtHQUVuSSxPQUFPLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNoRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsaUJBQWlCLFdBQVcsV0FBVztDQUMvQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUCxTQUFTO0VBQ1QsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE1BQU0sT0FBTyxTQUFTLFVBQVU7R0FDL0IsTUFBTSxRQUFRLFFBQVE7R0FDdEIsSUFBSSxTQUFTLE9BQU8sVUFBVSxVQUFVO0lBQ3ZDLFFBQVEsUUFBUTtJQUNoQixRQUFRLFFBQVEsQ0FBQztJQUNqQixNQUFNLGdCQUFnQixNQUFNLFFBQVEsSUFBSSxPQUFPLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxLQUFLLGlCQUFpQjtLQUN0RyxJQUFJLE9BQU8sVUFBVSxZQUFZLFNBQVMsb0JBQW9CLFlBQVksU0FBUyxjQUFjLFlBQVksU0FBUyxjQUFjLFlBQVksWUFBWSxLQUFLLEdBQUc7TUFDbkssTUFBTSxVQUFVLE9BQU8sUUFBUSxNQUFNLE9BQU8sTUFBc0IsMkJBQVcsV0FBVztNQUN4RixPQUFPO09BQ047T0FDQTtPQUNBO09BQ0EsTUFBTSxZQUFZLE9BQU8sQ0FBQyxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7TUFDdkQ7S0FDRDtLQUNBLE9BQU87TUFDTjtNQUNBLE1BQU07TUFDTjtNQUNBO0tBQ0Q7SUFDRCxDQUFDLENBQUM7SUFDRixLQUFLLE1BQU0sQ0FBQyxLQUFLLFNBQVMsYUFBYSxpQkFBaUIsZUFBZSxJQUFJLGNBQWM7S0FDeEYsSUFBSSxhQUFhLFFBQVE7TUFDeEIsTUFBTSxXQUFXO09BQ2hCLE1BQU07T0FDTixRQUFRO09BQ1I7T0FDQTtPQUNBLE9BQU87TUFDUjtNQUNBLEtBQUssTUFBTSxTQUFTLGFBQWEsUUFBUTtPQUN4QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO1lBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLGFBQWE7TUFDbkQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksQ0FBQyxhQUFhLE9BQU8sUUFBUSxRQUFRO0tBQ3pDLFFBQVEsTUFBTSxPQUFPLGFBQWE7SUFDbkMsT0FBTyxJQUFJLFlBQVksYUFBYSxLQUFLLEdBQUcsUUFBUSxNQUFNLE9BQU8sTUFBc0IsNEJBQVksV0FBVztTQUN6RyxJQUFJLFlBQVksU0FBUyxvQkFBb0IsWUFBWSxTQUFTLGNBQWMsWUFBWSxTQUFTLFdBQVc7S0FDcEgsVUFBVSxNQUFNLE9BQU8sU0FBUyxVQUFVO01BQ3pDLE9BQU8sS0FBSztNQUNaLFVBQVUsSUFBSSxJQUFJO01BQ2xCLE1BQU0sQ0FBQztPQUNOLE1BQU07T0FDTixRQUFRO09BQ1I7T0FDQTtPQUNBLE9BQU87TUFDUixDQUFDO0tBQ0YsQ0FBQztLQUNELElBQUksU0FBUyxZQUFZO0lBQzFCO0lBQ0EsSUFBSSxDQUFDLFFBQVEsVUFBVSxDQUFDLFNBQVMsWUFDM0I7VUFBQSxNQUFNLE9BQU8sT0FBTyxJQUFvQixrQ0FBa0IsT0FBTyxHQUFHLEtBQUssRUFBRSxPQUFPLEtBQUssVUFBVSxRQUFRLE1BQU0sT0FBTyxNQUFNO0lBQUE7R0FFbkksT0FBTyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDaEQsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFdBQVcsT0FBTyxXQUFXO0NBQ3JDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRztJQUN6QixRQUFRLFFBQVE7SUFDaEIsUUFBUSxRQUFRLENBQUM7SUFDakIsS0FBSyxJQUFJLE1BQU0sR0FBRyxNQUFNLEtBQUssTUFBTSxRQUFRLE9BQU87S0FDakQsTUFBTSxVQUFVLE1BQU07S0FDdEIsTUFBTSxjQUFjLEtBQUssTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtLQUN4RSxJQUFJLFlBQVksUUFBUTtNQUN2QixNQUFNLFdBQVc7T0FDaEIsTUFBTTtPQUNOLFFBQVE7T0FDUjtPQUNBO09BQ0EsT0FBTztNQUNSO01BQ0EsS0FBSyxNQUFNLFNBQVMsWUFBWSxRQUFRO09BQ3ZDLElBQUksTUFBTSxNQUFNLE1BQU0sS0FBSyxRQUFRLFFBQVE7WUFDdEMsTUFBTSxPQUFPLENBQUMsUUFBUTtPQUMzQixRQUFRLFFBQVEsS0FBSyxLQUFLO01BQzNCO01BQ0EsSUFBSSxDQUFDLFFBQVEsUUFBUSxRQUFRLFNBQVMsWUFBWTtNQUNsRCxJQUFJLFNBQVMsWUFBWTtPQUN4QixRQUFRLFFBQVE7T0FDaEI7TUFDRDtLQUNEO0tBQ0EsSUFBSSxDQUFDLFlBQVksT0FBTyxRQUFRLFFBQVE7S0FDeEMsUUFBUSxNQUFNLEtBQUssWUFBWSxLQUFLO0lBQ3JDO0lBQ0EsSUFBSSxDQUFDLFFBQVEsVUFBVSxDQUFDLFNBQVMsWUFBWSxLQUFLLElBQUksTUFBTSxLQUFLLE1BQU0sUUFBUSxNQUFNLE1BQU0sUUFBUSxPQUFPLFFBQVEsTUFBTSxLQUFLLE1BQU0sSUFBSTtHQUN4SSxPQUFPLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNoRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsZ0JBQWdCLE9BQU8sV0FBVztDQUMxQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUDtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxNQUFNLE9BQU8sU0FBUyxVQUFVO0dBQy9CLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRztJQUN6QixRQUFRLFFBQVE7SUFDaEIsUUFBUSxRQUFRLENBQUM7SUFDakIsTUFBTSxlQUFlLE1BQU0sUUFBUSxJQUFJLEtBQUssTUFBTSxJQUFJLE9BQU8sTUFBTSxRQUFRO0tBQzFFLE1BQU0sVUFBVSxNQUFNO0tBQ3RCLE9BQU87TUFDTjtNQUNBO01BQ0EsTUFBTSxLQUFLLE9BQU8sQ0FBQyxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7S0FDaEQ7SUFDRCxDQUFDLENBQUM7SUFDRixLQUFLLE1BQU0sQ0FBQyxLQUFLLFNBQVMsZ0JBQWdCLGNBQWM7S0FDdkQsSUFBSSxZQUFZLFFBQVE7TUFDdkIsTUFBTSxXQUFXO09BQ2hCLE1BQU07T0FDTixRQUFRO09BQ1I7T0FDQTtPQUNBLE9BQU87TUFDUjtNQUNBLEtBQUssTUFBTSxTQUFTLFlBQVksUUFBUTtPQUN2QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO1lBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLFlBQVk7TUFDbEQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksQ0FBQyxZQUFZLE9BQU8sUUFBUSxRQUFRO0tBQ3hDLFFBQVEsTUFBTSxLQUFLLFlBQVksS0FBSztJQUNyQztJQUNBLElBQUksQ0FBQyxRQUFRLFVBQVUsQ0FBQyxTQUFTLFlBQVksS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNLFFBQVEsTUFBTSxNQUFNLFFBQVEsT0FBTyxRQUFRLE1BQU0sS0FBSyxNQUFNLElBQUk7R0FDeEksT0FBTyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDaEQsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLElBQUksS0FBSyxTQUFTLFdBQVc7Q0FDckMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1A7RUFDQSxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksaUJBQWlCLEtBQUs7SUFDekIsUUFBUSxRQUFRO0lBQ2hCLFFBQVEsd0JBQXdCLElBQUksSUFBSTtJQUN4QyxLQUFLLE1BQU0sQ0FBQyxVQUFVLGVBQWUsT0FBTztLQUMzQyxNQUFNLGFBQWEsS0FBSyxJQUFJLE9BQU8sQ0FBQyxFQUFFLE9BQU8sU0FBUyxHQUFHLFFBQVE7S0FDakUsSUFBSSxXQUFXLFFBQVE7TUFDdEIsTUFBTSxXQUFXO09BQ2hCLE1BQU07T0FDTixRQUFRO09BQ1I7T0FDQSxLQUFLO09BQ0wsT0FBTztNQUNSO01BQ0EsS0FBSyxNQUFNLFNBQVMsV0FBVyxRQUFRO09BQ3RDLElBQUksTUFBTSxNQUFNLE1BQU0sS0FBSyxRQUFRLFFBQVE7WUFDdEMsTUFBTSxPQUFPLENBQUMsUUFBUTtPQUMzQixRQUFRLFFBQVEsS0FBSyxLQUFLO01BQzNCO01BQ0EsSUFBSSxDQUFDLFFBQVEsUUFBUSxRQUFRLFNBQVMsV0FBVztNQUNqRCxJQUFJLFNBQVMsWUFBWTtPQUN4QixRQUFRLFFBQVE7T0FDaEI7TUFDRDtLQUNEO0tBQ0EsTUFBTSxlQUFlLEtBQUssTUFBTSxPQUFPLENBQUMsRUFBRSxPQUFPLFdBQVcsR0FBRyxRQUFRO0tBQ3ZFLElBQUksYUFBYSxRQUFRO01BQ3hCLE1BQU0sV0FBVztPQUNoQixNQUFNO09BQ04sUUFBUTtPQUNSO09BQ0EsS0FBSztPQUNMLE9BQU87TUFDUjtNQUNBLEtBQUssTUFBTSxTQUFTLGFBQWEsUUFBUTtPQUN4QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO1lBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLGFBQWE7TUFDbkQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksQ0FBQyxXQUFXLFNBQVMsQ0FBQyxhQUFhLE9BQU8sUUFBUSxRQUFRO0tBQzlELFFBQVEsTUFBTSxJQUFJLFdBQVcsT0FBTyxhQUFhLEtBQUs7SUFDdkQ7R0FDRCxPQUFPLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNoRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsU0FBUyxLQUFLLFNBQVMsV0FBVztDQUMxQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUDtFQUNBLE9BQU87RUFDUCxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsTUFBTSxPQUFPLFNBQVMsVUFBVTtHQUMvQixNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLGlCQUFpQixLQUFLO0lBQ3pCLFFBQVEsUUFBUTtJQUNoQixRQUFRLHdCQUF3QixJQUFJLElBQUk7SUFDeEMsTUFBTSxXQUFXLE1BQU0sUUFBUSxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxnQkFBZ0IsUUFBUSxJQUFJO0tBQ3pGO0tBQ0E7S0FDQSxLQUFLLElBQUksT0FBTyxDQUFDLEVBQUUsT0FBTyxTQUFTLEdBQUcsUUFBUTtLQUM5QyxLQUFLLE1BQU0sT0FBTyxDQUFDLEVBQUUsT0FBTyxXQUFXLEdBQUcsUUFBUTtJQUNuRCxDQUFDLENBQUMsQ0FBQztJQUNILEtBQUssTUFBTSxDQUFDLFVBQVUsWUFBWSxZQUFZLGlCQUFpQixVQUFVO0tBQ3hFLElBQUksV0FBVyxRQUFRO01BQ3RCLE1BQU0sV0FBVztPQUNoQixNQUFNO09BQ04sUUFBUTtPQUNSO09BQ0EsS0FBSztPQUNMLE9BQU87TUFDUjtNQUNBLEtBQUssTUFBTSxTQUFTLFdBQVcsUUFBUTtPQUN0QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO1lBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLFdBQVc7TUFDakQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksYUFBYSxRQUFRO01BQ3hCLE1BQU0sV0FBVztPQUNoQixNQUFNO09BQ04sUUFBUTtPQUNSO09BQ0EsS0FBSztPQUNMLE9BQU87TUFDUjtNQUNBLEtBQUssTUFBTSxTQUFTLGFBQWEsUUFBUTtPQUN4QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO1lBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLGFBQWE7TUFDbkQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksQ0FBQyxXQUFXLFNBQVMsQ0FBQyxhQUFhLE9BQU8sUUFBUSxRQUFRO0tBQzlELFFBQVEsTUFBTSxJQUFJLFdBQVcsT0FBTyxhQUFhLEtBQUs7SUFDdkQ7R0FDRCxPQUFPLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNoRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsSUFBSSxXQUFXO0NBQ3ZCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLE9BQU8sTUFBTSxRQUFRLEtBQUssR0FBRyxRQUFRLFFBQVE7UUFDNUMsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQzlDLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxNQUFNLFdBQVc7Q0FDekIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUN6QyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsWUFBWSxTQUFTLFdBQVc7Q0FDeEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1A7RUFDQSxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLFVBQVUsTUFBTSxVQUFVLEtBQUssUUFBUSxPQUFPLENBQUMsU0FBUyxRQUFRO0dBQzVFLElBQUksUUFBUSxVQUFVLE1BQU0sVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ3JFLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxpQkFBaUIsU0FBUyxXQUFXO0NBQzdDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE1BQU0sT0FBTyxTQUFTLFVBQVU7R0FDL0IsSUFBSSxRQUFRLFVBQVUsTUFBTSxVQUFVLE1BQU0sS0FBSyxRQUFRLE9BQU8sQ0FBQyxTQUFTLFFBQVE7R0FDbEYsSUFBSSxRQUFRLFVBQVUsTUFBTSxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDckUsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFdBQVcsU0FBUyxXQUFXO0NBQ3ZDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksRUFBRSxRQUFRLFVBQVUsUUFBUSxRQUFRLFVBQVUsS0FBSyxJQUFJLFVBQVUsS0FBSyxRQUFRLE9BQU8sQ0FBQyxTQUFTLFFBQVE7R0FDM0csSUFBSSxRQUFRLFVBQVUsUUFBUSxRQUFRLFVBQVUsS0FBSyxHQUFHLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNqRyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsZ0JBQWdCLFNBQVMsV0FBVztDQUM1QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUDtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxNQUFNLE9BQU8sU0FBUyxVQUFVO0dBQy9CLElBQUksRUFBRSxRQUFRLFVBQVUsUUFBUSxRQUFRLFVBQVUsS0FBSyxJQUFJLFVBQVUsTUFBTSxLQUFLLFFBQVEsT0FBTyxDQUFDLFNBQVMsUUFBUTtHQUNqSCxJQUFJLFFBQVEsVUFBVSxRQUFRLFFBQVEsVUFBVSxLQUFLLEdBQUcsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ2pHLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxZQUFZLFNBQVMsV0FBVztDQUN4QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUDtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsVUFBVSxLQUFLLEdBQUcsVUFBVSxLQUFLLFFBQVEsT0FBTyxDQUFDLFNBQVMsUUFBUTtHQUM5RSxJQUFJLFFBQVEsVUFBVSxLQUFLLEdBQUcsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ3ZFLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxpQkFBaUIsU0FBUyxXQUFXO0NBQzdDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE1BQU0sT0FBTyxTQUFTLFVBQVU7R0FDL0IsSUFBSSxRQUFRLFVBQVUsS0FBSyxHQUFHLFVBQVUsTUFBTSxLQUFLLFFBQVEsT0FBTyxDQUFDLFNBQVMsUUFBUTtHQUNwRixJQUFJLFFBQVEsVUFBVSxLQUFLLEdBQUcsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ3ZFLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxNQUFNLFdBQVc7Q0FDekIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxVQUFVLE1BQU0sUUFBUSxRQUFRO1FBQ3ZDLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUM5QyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsU0FBUyxTQUFTLFVBQVU7Q0FDcEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVMsSUFBSSxRQUFRLFFBQVE7RUFDN0IsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxVQUFVLE1BQU07SUFDM0IsSUFBSSxLQUFLLFlBQVksS0FBSyxHQUFHLFFBQVEsUUFBd0IsMkJBQVcsTUFBTSxTQUFTLFFBQVE7SUFDL0YsSUFBSSxRQUFRLFVBQVUsTUFBTTtLQUMzQixRQUFRLFFBQVE7S0FDaEIsT0FBTztJQUNSO0dBQ0Q7R0FDQSxPQUFPLEtBQUssUUFBUSxPQUFPLENBQUMsU0FBUyxRQUFRO0VBQzlDO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLGNBQWMsU0FBUyxVQUFVO0NBQ3pDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTLElBQUksUUFBUSxRQUFRO0VBQzdCLE9BQU87RUFDUDtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxNQUFNLE9BQU8sU0FBUyxVQUFVO0dBQy9CLElBQUksUUFBUSxVQUFVLE1BQU07SUFDM0IsSUFBSSxLQUFLLFlBQVksS0FBSyxHQUFHLFFBQVEsUUFBUSxNQUFzQiwyQkFBVyxNQUFNLFNBQVMsUUFBUTtJQUNyRyxJQUFJLFFBQVEsVUFBVSxNQUFNO0tBQzNCLFFBQVEsUUFBUTtLQUNoQixPQUFPO0lBQ1I7R0FDRDtHQUNBLE9BQU8sS0FBSyxRQUFRLE9BQU8sQ0FBQyxTQUFTLFFBQVE7RUFDOUM7Q0FDRDtBQUNEOztBQUtBLFNBQVMsUUFBUSxTQUFTLFVBQVU7Q0FDbkMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVMsSUFBSSxRQUFRLFFBQVE7RUFDN0IsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxVQUFVLFFBQVEsUUFBUSxVQUFVLEtBQUssR0FBRztJQUN2RCxJQUFJLEtBQUssWUFBWSxLQUFLLEdBQUcsUUFBUSxRQUF3QiwyQkFBVyxNQUFNLFNBQVMsUUFBUTtJQUMvRixJQUFJLFFBQVEsVUFBVSxRQUFRLFFBQVEsVUFBVSxLQUFLLEdBQUc7S0FDdkQsUUFBUSxRQUFRO0tBQ2hCLE9BQU87SUFDUjtHQUNEO0dBQ0EsT0FBTyxLQUFLLFFBQVEsT0FBTyxDQUFDLFNBQVMsUUFBUTtFQUM5QztDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxhQUFhLFNBQVMsVUFBVTtDQUN4QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUyxJQUFJLFFBQVEsUUFBUTtFQUM3QixPQUFPO0VBQ1A7RUFDQSxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsTUFBTSxPQUFPLFNBQVMsVUFBVTtHQUMvQixJQUFJLFFBQVEsVUFBVSxRQUFRLFFBQVEsVUFBVSxLQUFLLEdBQUc7SUFDdkQsSUFBSSxLQUFLLFlBQVksS0FBSyxHQUFHLFFBQVEsUUFBUSxNQUFzQiwyQkFBVyxNQUFNLFNBQVMsUUFBUTtJQUNyRyxJQUFJLFFBQVEsVUFBVSxRQUFRLFFBQVEsVUFBVSxLQUFLLEdBQUc7S0FDdkQsUUFBUSxRQUFRO0tBQ2hCLE9BQU87SUFDUjtHQUNEO0dBQ0EsT0FBTyxLQUFLLFFBQVEsT0FBTyxDQUFDLFNBQVMsUUFBUTtFQUM5QztDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxPQUFPLFdBQVc7Q0FDMUIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksT0FBTyxRQUFRLFVBQVUsWUFBWSxDQUFDLE1BQU0sUUFBUSxLQUFLLEdBQUcsUUFBUSxRQUFRO1FBQzNFLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUM5QyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsT0FBTyxXQUFXLFdBQVc7Q0FDckMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLFNBQVMsT0FBTyxVQUFVLFVBQVU7SUFDdkMsUUFBUSxRQUFRO0lBQ2hCLFFBQVEsUUFBUSxDQUFDO0lBQ2pCLEtBQUssTUFBTSxPQUFPLEtBQUssU0FBUztLQUMvQixNQUFNLGNBQWMsS0FBSyxRQUFRO0tBQ2pDLElBQUksT0FBTyxVQUFVLFlBQVksU0FBUyxvQkFBb0IsWUFBWSxTQUFTLGNBQWMsWUFBWSxTQUFTLGNBQWMsWUFBWSxZQUFZLEtBQUssR0FBRztNQUNuSyxNQUFNLFVBQVUsT0FBTyxRQUFRLE1BQU0sT0FBdUIsMkJBQVcsV0FBVztNQUNsRixNQUFNLGVBQWUsWUFBWSxPQUFPLENBQUMsRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO01BQ3JFLElBQUksYUFBYSxRQUFRO09BQ3hCLE1BQU0sV0FBVztRQUNoQixNQUFNO1FBQ04sUUFBUTtRQUNSO1FBQ0E7UUFDQSxPQUFPO09BQ1I7T0FDQSxLQUFLLE1BQU0sU0FBUyxhQUFhLFFBQVE7UUFDeEMsSUFBSSxNQUFNLE1BQU0sTUFBTSxLQUFLLFFBQVEsUUFBUTthQUN0QyxNQUFNLE9BQU8sQ0FBQyxRQUFRO1FBQzNCLFFBQVEsUUFBUSxLQUFLLEtBQUs7T0FDM0I7T0FDQSxJQUFJLENBQUMsUUFBUSxRQUFRLFFBQVEsU0FBUyxhQUFhO09BQ25ELElBQUksU0FBUyxZQUFZO1FBQ3hCLFFBQVEsUUFBUTtRQUNoQjtPQUNEO01BQ0Q7TUFDQSxJQUFJLENBQUMsYUFBYSxPQUFPLFFBQVEsUUFBUTtNQUN6QyxRQUFRLE1BQU0sT0FBTyxhQUFhO0tBQ25DLE9BQU8sSUFBSSxZQUFZLGFBQWEsS0FBSyxHQUFHLFFBQVEsTUFBTSxPQUF1Qiw0QkFBWSxXQUFXO1VBQ25HLElBQUksWUFBWSxTQUFTLG9CQUFvQixZQUFZLFNBQVMsY0FBYyxZQUFZLFNBQVMsV0FBVztNQUNwSCxVQUFVLE1BQU0sT0FBTyxTQUFTLFVBQVU7T0FDekMsT0FBTyxLQUFLO09BQ1osVUFBVSxJQUFJLElBQUk7T0FDbEIsTUFBTSxDQUFDO1FBQ04sTUFBTTtRQUNOLFFBQVE7UUFDUjtRQUNBO1FBQ0EsT0FBTyxNQUFNO09BQ2QsQ0FBQztNQUNGLENBQUM7TUFDRCxJQUFJLFNBQVMsWUFBWTtLQUMxQjtJQUNEO0dBQ0QsT0FBTyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDaEQsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFlBQVksV0FBVyxXQUFXO0NBQzFDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQLFNBQVM7RUFDVCxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsTUFBTSxPQUFPLFNBQVMsVUFBVTtHQUMvQixNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLFNBQVMsT0FBTyxVQUFVLFVBQVU7SUFDdkMsUUFBUSxRQUFRO0lBQ2hCLFFBQVEsUUFBUSxDQUFDO0lBQ2pCLE1BQU0sZ0JBQWdCLE1BQU0sUUFBUSxJQUFJLE9BQU8sUUFBUSxLQUFLLE9BQU8sQ0FBQyxDQUFDLElBQUksT0FBTyxDQUFDLEtBQUssaUJBQWlCO0tBQ3RHLElBQUksT0FBTyxVQUFVLFlBQVksU0FBUyxvQkFBb0IsWUFBWSxTQUFTLGNBQWMsWUFBWSxTQUFTLGNBQWMsWUFBWSxZQUFZLEtBQUssR0FBRztNQUNuSyxNQUFNLFVBQVUsT0FBTyxRQUFRLE1BQU0sT0FBTyxNQUFzQiwyQkFBVyxXQUFXO01BQ3hGLE9BQU87T0FDTjtPQUNBO09BQ0E7T0FDQSxNQUFNLFlBQVksT0FBTyxDQUFDLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtNQUN2RDtLQUNEO0tBQ0EsT0FBTztNQUNOO01BQ0EsTUFBTTtNQUNOO01BQ0E7S0FDRDtJQUNELENBQUMsQ0FBQztJQUNGLEtBQUssTUFBTSxDQUFDLEtBQUssU0FBUyxhQUFhLGlCQUFpQixlQUFlLElBQUksY0FBYztLQUN4RixJQUFJLGFBQWEsUUFBUTtNQUN4QixNQUFNLFdBQVc7T0FDaEIsTUFBTTtPQUNOLFFBQVE7T0FDUjtPQUNBO09BQ0EsT0FBTztNQUNSO01BQ0EsS0FBSyxNQUFNLFNBQVMsYUFBYSxRQUFRO09BQ3hDLElBQUksTUFBTSxNQUFNLE1BQU0sS0FBSyxRQUFRLFFBQVE7WUFDdEMsTUFBTSxPQUFPLENBQUMsUUFBUTtPQUMzQixRQUFRLFFBQVEsS0FBSyxLQUFLO01BQzNCO01BQ0EsSUFBSSxDQUFDLFFBQVEsUUFBUSxRQUFRLFNBQVMsYUFBYTtNQUNuRCxJQUFJLFNBQVMsWUFBWTtPQUN4QixRQUFRLFFBQVE7T0FDaEI7TUFDRDtLQUNEO0tBQ0EsSUFBSSxDQUFDLGFBQWEsT0FBTyxRQUFRLFFBQVE7S0FDekMsUUFBUSxNQUFNLE9BQU8sYUFBYTtJQUNuQyxPQUFPLElBQUksWUFBWSxhQUFhLEtBQUssR0FBRyxRQUFRLE1BQU0sT0FBTyxNQUFzQiw0QkFBWSxXQUFXO1NBQ3pHLElBQUksWUFBWSxTQUFTLG9CQUFvQixZQUFZLFNBQVMsY0FBYyxZQUFZLFNBQVMsV0FBVztLQUNwSCxVQUFVLE1BQU0sT0FBTyxTQUFTLFVBQVU7TUFDekMsT0FBTyxLQUFLO01BQ1osVUFBVSxJQUFJLElBQUk7TUFDbEIsTUFBTSxDQUFDO09BQ04sTUFBTTtPQUNOLFFBQVE7T0FDUjtPQUNBO09BQ0EsT0FBTztNQUNSLENBQUM7S0FDRixDQUFDO0tBQ0QsSUFBSSxTQUFTLFlBQVk7SUFDMUI7R0FDRCxPQUFPLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNoRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsZUFBZSxXQUFXLE1BQU0sV0FBVztDQUNuRCxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUCxTQUFTO0VBQ1Q7RUFDQSxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsT0FBTyxTQUFTLFVBQVU7R0FDekIsTUFBTSxRQUFRLFFBQVE7R0FDdEIsSUFBSSxTQUFTLE9BQU8sVUFBVSxVQUFVO0lBQ3ZDLFFBQVEsUUFBUTtJQUNoQixRQUFRLFFBQVEsQ0FBQztJQUNqQixLQUFLLE1BQU0sT0FBTyxLQUFLLFNBQVM7S0FDL0IsTUFBTSxjQUFjLEtBQUssUUFBUTtLQUNqQyxJQUFJLE9BQU8sVUFBVSxZQUFZLFNBQVMsb0JBQW9CLFlBQVksU0FBUyxjQUFjLFlBQVksU0FBUyxjQUFjLFlBQVksWUFBWSxLQUFLLEdBQUc7TUFDbkssTUFBTSxVQUFVLE9BQU8sUUFBUSxNQUFNLE9BQXVCLDJCQUFXLFdBQVc7TUFDbEYsTUFBTSxlQUFlLFlBQVksT0FBTyxDQUFDLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtNQUNyRSxJQUFJLGFBQWEsUUFBUTtPQUN4QixNQUFNLFdBQVc7UUFDaEIsTUFBTTtRQUNOLFFBQVE7UUFDUjtRQUNBO1FBQ0EsT0FBTztPQUNSO09BQ0EsS0FBSyxNQUFNLFNBQVMsYUFBYSxRQUFRO1FBQ3hDLElBQUksTUFBTSxNQUFNLE1BQU0sS0FBSyxRQUFRLFFBQVE7YUFDdEMsTUFBTSxPQUFPLENBQUMsUUFBUTtRQUMzQixRQUFRLFFBQVEsS0FBSyxLQUFLO09BQzNCO09BQ0EsSUFBSSxDQUFDLFFBQVEsUUFBUSxRQUFRLFNBQVMsYUFBYTtPQUNuRCxJQUFJLFNBQVMsWUFBWTtRQUN4QixRQUFRLFFBQVE7UUFDaEI7T0FDRDtNQUNEO01BQ0EsSUFBSSxDQUFDLGFBQWEsT0FBTyxRQUFRLFFBQVE7TUFDekMsUUFBUSxNQUFNLE9BQU8sYUFBYTtLQUNuQyxPQUFPLElBQUksWUFBWSxhQUFhLEtBQUssR0FBRyxRQUFRLE1BQU0sT0FBdUIsNEJBQVksV0FBVztVQUNuRyxJQUFJLFlBQVksU0FBUyxvQkFBb0IsWUFBWSxTQUFTLGNBQWMsWUFBWSxTQUFTLFdBQVc7TUFDcEgsVUFBVSxNQUFNLE9BQU8sU0FBUyxVQUFVO09BQ3pDLE9BQU8sS0FBSztPQUNaLFVBQVUsSUFBSSxJQUFJO09BQ2xCLE1BQU0sQ0FBQztRQUNOLE1BQU07UUFDTixRQUFRO1FBQ1I7UUFDQTtRQUNBLE9BQU8sTUFBTTtPQUNkLENBQUM7TUFDRixDQUFDO01BQ0QsSUFBSSxTQUFTLFlBQVk7S0FDMUI7SUFDRDtJQUNBLElBQUksQ0FBQyxRQUFRLFVBQVUsQ0FBQyxTQUFTLFlBQzNCO1VBQUEsTUFBTSxPQUFPLE9BQU8sSUFBb0Isa0NBQWtCLE9BQU8sR0FBRyxLQUFLLEVBQUUsT0FBTyxLQUFLLFVBQVU7TUFDckcsTUFBTSxlQUFlLEtBQUssS0FBSyxPQUFPLENBQUMsRUFBRSxPQUFPLE1BQU0sS0FBSyxHQUFHLFFBQVE7TUFDdEUsSUFBSSxhQUFhLFFBQVE7T0FDeEIsTUFBTSxXQUFXO1FBQ2hCLE1BQU07UUFDTixRQUFRO1FBQ1I7UUFDQTtRQUNBLE9BQU8sTUFBTTtPQUNkO09BQ0EsS0FBSyxNQUFNLFNBQVMsYUFBYSxRQUFRO1FBQ3hDLElBQUksTUFBTSxNQUFNLE1BQU0sS0FBSyxRQUFRLFFBQVE7YUFDdEMsTUFBTSxPQUFPLENBQUMsUUFBUTtRQUMzQixRQUFRLFFBQVEsS0FBSyxLQUFLO09BQzNCO09BQ0EsSUFBSSxDQUFDLFFBQVEsUUFBUSxRQUFRLFNBQVMsYUFBYTtPQUNuRCxJQUFJLFNBQVMsWUFBWTtRQUN4QixRQUFRLFFBQVE7UUFDaEI7T0FDRDtNQUNEO01BQ0EsSUFBSSxDQUFDLGFBQWEsT0FBTyxRQUFRLFFBQVE7TUFDekMsUUFBUSxNQUFNLE9BQU8sYUFBYTtLQUNuQzs7R0FFRixPQUFPLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNoRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsb0JBQW9CLFdBQVcsTUFBTSxXQUFXO0NBQ3hELE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQLFNBQVM7RUFDVDtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxNQUFNLE9BQU8sU0FBUyxVQUFVO0dBQy9CLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksU0FBUyxPQUFPLFVBQVUsVUFBVTtJQUN2QyxRQUFRLFFBQVE7SUFDaEIsUUFBUSxRQUFRLENBQUM7SUFDakIsTUFBTSxDQUFDLGdCQUFnQixnQkFBZ0IsTUFBTSxRQUFRLElBQUksQ0FBQyxRQUFRLElBQUksT0FBTyxRQUFRLEtBQUssT0FBTyxDQUFDLENBQUMsSUFBSSxPQUFPLENBQUMsS0FBSyxpQkFBaUI7S0FDcEksSUFBSSxPQUFPLFVBQVUsWUFBWSxTQUFTLG9CQUFvQixZQUFZLFNBQVMsY0FBYyxZQUFZLFNBQVMsY0FBYyxZQUFZLFlBQVksS0FBSyxHQUFHO01BQ25LLE1BQU0sVUFBVSxPQUFPLFFBQVEsTUFBTSxPQUFPLE1BQXNCLDJCQUFXLFdBQVc7TUFDeEYsT0FBTztPQUNOO09BQ0E7T0FDQTtPQUNBLE1BQU0sWUFBWSxPQUFPLENBQUMsRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO01BQ3ZEO0tBQ0Q7S0FDQSxPQUFPO01BQ047TUFDQSxNQUFNO01BQ047TUFDQTtLQUNEO0lBQ0QsQ0FBQyxDQUFDLEdBQUcsUUFBUSxJQUFJLE9BQU8sUUFBUSxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBeUIsa0NBQWtCLE9BQU8sR0FBRyxLQUFLLEVBQUUsT0FBTyxLQUFLLFFBQVEsQ0FBQyxDQUFDLElBQUksT0FBTyxDQUFDLEtBQUssYUFBYTtLQUMvSjtLQUNBO0tBQ0EsTUFBTSxLQUFLLEtBQUssT0FBTyxDQUFDLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtJQUNyRCxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ0osS0FBSyxNQUFNLENBQUMsS0FBSyxTQUFTLGFBQWEsaUJBQWlCLGdCQUFnQixJQUFJLGNBQWM7S0FDekYsSUFBSSxhQUFhLFFBQVE7TUFDeEIsTUFBTSxXQUFXO09BQ2hCLE1BQU07T0FDTixRQUFRO09BQ1I7T0FDQTtPQUNBLE9BQU87TUFDUjtNQUNBLEtBQUssTUFBTSxTQUFTLGFBQWEsUUFBUTtPQUN4QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO1lBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLGFBQWE7TUFDbkQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksQ0FBQyxhQUFhLE9BQU8sUUFBUSxRQUFRO0tBQ3pDLFFBQVEsTUFBTSxPQUFPLGFBQWE7SUFDbkMsT0FBTyxJQUFJLFlBQVksYUFBYSxLQUFLLEdBQUcsUUFBUSxNQUFNLE9BQU8sTUFBc0IsNEJBQVksV0FBVztTQUN6RyxJQUFJLFlBQVksU0FBUyxvQkFBb0IsWUFBWSxTQUFTLGNBQWMsWUFBWSxTQUFTLFdBQVc7S0FDcEgsVUFBVSxNQUFNLE9BQU8sU0FBUyxVQUFVO01BQ3pDLE9BQU8sS0FBSztNQUNaLFVBQVUsSUFBSSxJQUFJO01BQ2xCLE1BQU0sQ0FBQztPQUNOLE1BQU07T0FDTixRQUFRO09BQ1I7T0FDQTtPQUNBLE9BQU87TUFDUixDQUFDO0tBQ0YsQ0FBQztLQUNELElBQUksU0FBUyxZQUFZO0lBQzFCO0lBQ0EsSUFBSSxDQUFDLFFBQVEsVUFBVSxDQUFDLFNBQVMsWUFBWSxLQUFLLE1BQU0sQ0FBQyxLQUFLLFNBQVMsaUJBQWlCLGNBQWM7S0FDckcsSUFBSSxhQUFhLFFBQVE7TUFDeEIsTUFBTSxXQUFXO09BQ2hCLE1BQU07T0FDTixRQUFRO09BQ1I7T0FDQTtPQUNBLE9BQU87TUFDUjtNQUNBLEtBQUssTUFBTSxTQUFTLGFBQWEsUUFBUTtPQUN4QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO1lBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLGFBQWE7TUFDbkQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksQ0FBQyxhQUFhLE9BQU8sUUFBUSxRQUFRO0tBQ3pDLFFBQVEsTUFBTSxPQUFPLGFBQWE7SUFDbkM7R0FDRCxPQUFPLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNoRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsU0FBUyxTQUFTLFVBQVU7Q0FDcEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVMsSUFBSSxRQUFRLFFBQVE7RUFDN0IsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxVQUFVLEtBQUssR0FBRztJQUM3QixJQUFJLEtBQUssWUFBWSxLQUFLLEdBQUcsUUFBUSxRQUF3QiwyQkFBVyxNQUFNLFNBQVMsUUFBUTtJQUMvRixJQUFJLFFBQVEsVUFBVSxLQUFLLEdBQUc7S0FDN0IsUUFBUSxRQUFRO0tBQ2hCLE9BQU87SUFDUjtHQUNEO0dBQ0EsT0FBTyxLQUFLLFFBQVEsT0FBTyxDQUFDLFNBQVMsUUFBUTtFQUM5QztDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxjQUFjLFNBQVMsVUFBVTtDQUN6QyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUyxJQUFJLFFBQVEsUUFBUTtFQUM3QixPQUFPO0VBQ1A7RUFDQSxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsTUFBTSxPQUFPLFNBQVMsVUFBVTtHQUMvQixJQUFJLFFBQVEsVUFBVSxLQUFLLEdBQUc7SUFDN0IsSUFBSSxLQUFLLFlBQVksS0FBSyxHQUFHLFFBQVEsUUFBUSxNQUFzQiwyQkFBVyxNQUFNLFNBQVMsUUFBUTtJQUNyRyxJQUFJLFFBQVEsVUFBVSxLQUFLLEdBQUc7S0FDN0IsUUFBUSxRQUFRO0tBQ2hCLE9BQU87SUFDUjtHQUNEO0dBQ0EsT0FBTyxLQUFLLFFBQVEsT0FBTyxDQUFDLFNBQVMsUUFBUTtFQUM5QztDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxTQUFTLFNBQVMsV0FBVztDQUNyQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBeUIsNkJBQWEsUUFBUSxJQUFJLFVBQVUsR0FBRyxHQUFHO0VBQ2xFLE9BQU87RUFDUDtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLEtBQUssUUFBUSxTQUFTLFFBQVEsS0FBSyxHQUFHLFFBQVEsUUFBUTtRQUNyRCxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDOUMsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFFBQVEsV0FBVztDQUMzQixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUCxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsT0FBTyxTQUFTLFVBQVU7R0FDekIsSUFBSSxRQUFRLGlCQUFpQixTQUFTLFFBQVEsUUFBUTtRQUNqRCxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDOUMsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLE9BQU8sS0FBSyxTQUFTLFdBQVc7Q0FDeEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1A7RUFDQSxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksU0FBUyxPQUFPLFVBQVUsVUFBVTtJQUN2QyxRQUFRLFFBQVE7SUFDaEIsUUFBUSxRQUFRLENBQUM7SUFDakIsS0FBSyxNQUFNLFlBQVksT0FBTyxJQUFvQixrQ0FBa0IsT0FBTyxRQUFRLEdBQUc7S0FDckYsTUFBTSxhQUFhLE1BQU07S0FDekIsTUFBTSxhQUFhLEtBQUssSUFBSSxPQUFPLENBQUMsRUFBRSxPQUFPLFNBQVMsR0FBRyxRQUFRO0tBQ2pFLElBQUksV0FBVyxRQUFRO01BQ3RCLE1BQU0sV0FBVztPQUNoQixNQUFNO09BQ04sUUFBUTtPQUNSO09BQ0EsS0FBSztPQUNMLE9BQU87TUFDUjtNQUNBLEtBQUssTUFBTSxTQUFTLFdBQVcsUUFBUTtPQUN0QyxNQUFNLE9BQU8sQ0FBQyxRQUFRO09BQ3RCLFFBQVEsUUFBUSxLQUFLLEtBQUs7TUFDM0I7TUFDQSxJQUFJLENBQUMsUUFBUSxRQUFRLFFBQVEsU0FBUyxXQUFXO01BQ2pELElBQUksU0FBUyxZQUFZO09BQ3hCLFFBQVEsUUFBUTtPQUNoQjtNQUNEO0tBQ0Q7S0FDQSxNQUFNLGVBQWUsS0FBSyxNQUFNLE9BQU8sQ0FBQyxFQUFFLE9BQU8sV0FBVyxHQUFHLFFBQVE7S0FDdkUsSUFBSSxhQUFhLFFBQVE7TUFDeEIsTUFBTSxXQUFXO09BQ2hCLE1BQU07T0FDTixRQUFRO09BQ1I7T0FDQSxLQUFLO09BQ0wsT0FBTztNQUNSO01BQ0EsS0FBSyxNQUFNLFNBQVMsYUFBYSxRQUFRO09BQ3hDLElBQUksTUFBTSxNQUFNLE1BQU0sS0FBSyxRQUFRLFFBQVE7WUFDdEMsTUFBTSxPQUFPLENBQUMsUUFBUTtPQUMzQixRQUFRLFFBQVEsS0FBSyxLQUFLO01BQzNCO01BQ0EsSUFBSSxDQUFDLFFBQVEsUUFBUSxRQUFRLFNBQVMsYUFBYTtNQUNuRCxJQUFJLFNBQVMsWUFBWTtPQUN4QixRQUFRLFFBQVE7T0FDaEI7TUFDRDtLQUNEO0tBQ0EsSUFBSSxDQUFDLFdBQVcsU0FBUyxDQUFDLGFBQWEsT0FBTyxRQUFRLFFBQVE7S0FDOUQsSUFBSSxXQUFXLE9BQU8sUUFBUSxNQUFNLFdBQVcsU0FBUyxhQUFhO0lBQ3RFO0dBQ0QsT0FBTyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDaEQsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFlBQVksS0FBSyxTQUFTLFdBQVc7Q0FDN0MsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1A7RUFDQSxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE1BQU0sT0FBTyxTQUFTLFVBQVU7R0FDL0IsTUFBTSxRQUFRLFFBQVE7R0FDdEIsSUFBSSxTQUFTLE9BQU8sVUFBVSxVQUFVO0lBQ3ZDLFFBQVEsUUFBUTtJQUNoQixRQUFRLFFBQVEsQ0FBQztJQUNqQixNQUFNLFdBQVcsTUFBTSxRQUFRLElBQUksT0FBTyxRQUFRLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUEyQixrQ0FBa0IsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLGdCQUFnQixRQUFRLElBQUk7S0FDeks7S0FDQTtLQUNBLEtBQUssSUFBSSxPQUFPLENBQUMsRUFBRSxPQUFPLFNBQVMsR0FBRyxRQUFRO0tBQzlDLEtBQUssTUFBTSxPQUFPLENBQUMsRUFBRSxPQUFPLFdBQVcsR0FBRyxRQUFRO0lBQ25ELENBQUMsQ0FBQyxDQUFDO0lBQ0gsS0FBSyxNQUFNLENBQUMsVUFBVSxZQUFZLFlBQVksaUJBQWlCLFVBQVU7S0FDeEUsSUFBSSxXQUFXLFFBQVE7TUFDdEIsTUFBTSxXQUFXO09BQ2hCLE1BQU07T0FDTixRQUFRO09BQ1I7T0FDQSxLQUFLO09BQ0wsT0FBTztNQUNSO01BQ0EsS0FBSyxNQUFNLFNBQVMsV0FBVyxRQUFRO09BQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDdEIsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLFdBQVc7TUFDakQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksYUFBYSxRQUFRO01BQ3hCLE1BQU0sV0FBVztPQUNoQixNQUFNO09BQ04sUUFBUTtPQUNSO09BQ0EsS0FBSztPQUNMLE9BQU87TUFDUjtNQUNBLEtBQUssTUFBTSxTQUFTLGFBQWEsUUFBUTtPQUN4QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO1lBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLGFBQWE7TUFDbkQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksQ0FBQyxXQUFXLFNBQVMsQ0FBQyxhQUFhLE9BQU8sUUFBUSxRQUFRO0tBQzlELElBQUksV0FBVyxPQUFPLFFBQVEsTUFBTSxXQUFXLFNBQVMsYUFBYTtJQUN0RTtHQUNELE9BQU8sVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ2hELE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxJQUFJLFNBQVMsV0FBVztDQUNoQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUCxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksaUJBQWlCLEtBQUs7SUFDekIsUUFBUSxRQUFRO0lBQ2hCLFFBQVEsd0JBQXdCLElBQUksSUFBSTtJQUN4QyxLQUFLLE1BQU0sY0FBYyxPQUFPO0tBQy9CLE1BQU0sZUFBZSxLQUFLLE1BQU0sT0FBTyxDQUFDLEVBQUUsT0FBTyxXQUFXLEdBQUcsUUFBUTtLQUN2RSxJQUFJLGFBQWEsUUFBUTtNQUN4QixNQUFNLFdBQVc7T0FDaEIsTUFBTTtPQUNOLFFBQVE7T0FDUjtPQUNBLEtBQUs7T0FDTCxPQUFPO01BQ1I7TUFDQSxLQUFLLE1BQU0sU0FBUyxhQUFhLFFBQVE7T0FDeEMsSUFBSSxNQUFNLE1BQU0sTUFBTSxLQUFLLFFBQVEsUUFBUTtZQUN0QyxNQUFNLE9BQU8sQ0FBQyxRQUFRO09BQzNCLFFBQVEsUUFBUSxLQUFLLEtBQUs7TUFDM0I7TUFDQSxJQUFJLENBQUMsUUFBUSxRQUFRLFFBQVEsU0FBUyxhQUFhO01BQ25ELElBQUksU0FBUyxZQUFZO09BQ3hCLFFBQVEsUUFBUTtPQUNoQjtNQUNEO0tBQ0Q7S0FDQSxJQUFJLENBQUMsYUFBYSxPQUFPLFFBQVEsUUFBUTtLQUN6QyxRQUFRLE1BQU0sSUFBSSxhQUFhLEtBQUs7SUFDckM7R0FDRCxPQUFPLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNoRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsU0FBUyxTQUFTLFdBQVc7Q0FDckMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsT0FBTztFQUNQLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxNQUFNLE9BQU8sU0FBUyxVQUFVO0dBQy9CLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksaUJBQWlCLEtBQUs7SUFDekIsUUFBUSxRQUFRO0lBQ2hCLFFBQVEsd0JBQXdCLElBQUksSUFBSTtJQUN4QyxNQUFNLGdCQUFnQixNQUFNLFFBQVEsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsSUFBSSxPQUFPLGVBQWUsQ0FBQyxZQUFZLE1BQU0sS0FBSyxNQUFNLE9BQU8sQ0FBQyxFQUFFLE9BQU8sV0FBVyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDckosS0FBSyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsZUFBZTtLQUN2RCxJQUFJLGFBQWEsUUFBUTtNQUN4QixNQUFNLFdBQVc7T0FDaEIsTUFBTTtPQUNOLFFBQVE7T0FDUjtPQUNBLEtBQUs7T0FDTCxPQUFPO01BQ1I7TUFDQSxLQUFLLE1BQU0sU0FBUyxhQUFhLFFBQVE7T0FDeEMsSUFBSSxNQUFNLE1BQU0sTUFBTSxLQUFLLFFBQVEsUUFBUTtZQUN0QyxNQUFNLE9BQU8sQ0FBQyxRQUFRO09BQzNCLFFBQVEsUUFBUSxLQUFLLEtBQUs7TUFDM0I7TUFDQSxJQUFJLENBQUMsUUFBUSxRQUFRLFFBQVEsU0FBUyxhQUFhO01BQ25ELElBQUksU0FBUyxZQUFZO09BQ3hCLFFBQVEsUUFBUTtPQUNoQjtNQUNEO0tBQ0Q7S0FDQSxJQUFJLENBQUMsYUFBYSxPQUFPLFFBQVEsUUFBUTtLQUN6QyxRQUFRLE1BQU0sSUFBSSxhQUFhLEtBQUs7SUFDckM7R0FDRCxPQUFPLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNoRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsYUFBYSxXQUFXLFdBQVc7Q0FDM0MsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLFNBQVMsT0FBTyxVQUFVLFVBQVU7SUFDdkMsUUFBUSxRQUFRO0lBQ2hCLFFBQVEsUUFBUSxDQUFDO0lBQ2pCLEtBQUssTUFBTSxPQUFPLEtBQUssU0FBUztLQUMvQixNQUFNLGNBQWMsS0FBSyxRQUFRO0tBQ2pDLElBQUksT0FBTyxVQUFVLFlBQVksU0FBUyxvQkFBb0IsWUFBWSxTQUFTLGNBQWMsWUFBWSxTQUFTLGNBQWMsWUFBWSxZQUFZLEtBQUssR0FBRztNQUNuSyxNQUFNLFVBQVUsT0FBTyxRQUFRLE1BQU0sT0FBdUIsMkJBQVcsV0FBVztNQUNsRixNQUFNLGVBQWUsWUFBWSxPQUFPLENBQUMsRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO01BQ3JFLElBQUksYUFBYSxRQUFRO09BQ3hCLE1BQU0sV0FBVztRQUNoQixNQUFNO1FBQ04sUUFBUTtRQUNSO1FBQ0E7UUFDQSxPQUFPO09BQ1I7T0FDQSxLQUFLLE1BQU0sU0FBUyxhQUFhLFFBQVE7UUFDeEMsSUFBSSxNQUFNLE1BQU0sTUFBTSxLQUFLLFFBQVEsUUFBUTthQUN0QyxNQUFNLE9BQU8sQ0FBQyxRQUFRO1FBQzNCLFFBQVEsUUFBUSxLQUFLLEtBQUs7T0FDM0I7T0FDQSxJQUFJLENBQUMsUUFBUSxRQUFRLFFBQVEsU0FBUyxhQUFhO09BQ25ELElBQUksU0FBUyxZQUFZO1FBQ3hCLFFBQVEsUUFBUTtRQUNoQjtPQUNEO01BQ0Q7TUFDQSxJQUFJLENBQUMsYUFBYSxPQUFPLFFBQVEsUUFBUTtNQUN6QyxRQUFRLE1BQU0sT0FBTyxhQUFhO0tBQ25DLE9BQU8sSUFBSSxZQUFZLGFBQWEsS0FBSyxHQUFHLFFBQVEsTUFBTSxPQUF1Qiw0QkFBWSxXQUFXO1VBQ25HLElBQUksWUFBWSxTQUFTLG9CQUFvQixZQUFZLFNBQVMsY0FBYyxZQUFZLFNBQVMsV0FBVztNQUNwSCxVQUFVLE1BQU0sT0FBTyxTQUFTLFVBQVU7T0FDekMsT0FBTyxLQUFLO09BQ1osVUFBVSxJQUFJLElBQUk7T0FDbEIsTUFBTSxDQUFDO1FBQ04sTUFBTTtRQUNOLFFBQVE7UUFDUjtRQUNBO1FBQ0EsT0FBTyxNQUFNO09BQ2QsQ0FBQztNQUNGLENBQUM7TUFDRCxJQUFJLFNBQVMsWUFBWTtLQUMxQjtJQUNEO0lBQ0EsSUFBSSxDQUFDLFFBQVEsVUFBVSxDQUFDLFNBQVMsWUFDM0I7VUFBQSxNQUFNLE9BQU8sT0FBTyxJQUFJLEVBQUUsT0FBTyxLQUFLLFVBQVU7TUFDcEQsVUFBVSxNQUFNLE9BQU8sU0FBUyxVQUFVO09BQ3pDLE9BQU87T0FDUCxVQUFVO09BQ1YsTUFBTSxDQUFDO1FBQ04sTUFBTTtRQUNOLFFBQVE7UUFDUjtRQUNBO1FBQ0EsT0FBTyxNQUFNO09BQ2QsQ0FBQztNQUNGLENBQUM7TUFDRDtLQUNEOztHQUVGLE9BQU8sVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ2hELE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxrQkFBa0IsV0FBVyxXQUFXO0NBQ2hELE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQLFNBQVM7RUFDVCxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsTUFBTSxPQUFPLFNBQVMsVUFBVTtHQUMvQixNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLFNBQVMsT0FBTyxVQUFVLFVBQVU7SUFDdkMsUUFBUSxRQUFRO0lBQ2hCLFFBQVEsUUFBUSxDQUFDO0lBQ2pCLE1BQU0sZ0JBQWdCLE1BQU0sUUFBUSxJQUFJLE9BQU8sUUFBUSxLQUFLLE9BQU8sQ0FBQyxDQUFDLElBQUksT0FBTyxDQUFDLEtBQUssaUJBQWlCO0tBQ3RHLElBQUksT0FBTyxVQUFVLFlBQVksU0FBUyxvQkFBb0IsWUFBWSxTQUFTLGNBQWMsWUFBWSxTQUFTLGNBQWMsWUFBWSxZQUFZLEtBQUssR0FBRztNQUNuSyxNQUFNLFVBQVUsT0FBTyxRQUFRLE1BQU0sT0FBTyxNQUFzQiwyQkFBVyxXQUFXO01BQ3hGLE9BQU87T0FDTjtPQUNBO09BQ0E7T0FDQSxNQUFNLFlBQVksT0FBTyxDQUFDLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtNQUN2RDtLQUNEO0tBQ0EsT0FBTztNQUNOO01BQ0EsTUFBTTtNQUNOO01BQ0E7S0FDRDtJQUNELENBQUMsQ0FBQztJQUNGLEtBQUssTUFBTSxDQUFDLEtBQUssU0FBUyxhQUFhLGlCQUFpQixlQUFlLElBQUksY0FBYztLQUN4RixJQUFJLGFBQWEsUUFBUTtNQUN4QixNQUFNLFdBQVc7T0FDaEIsTUFBTTtPQUNOLFFBQVE7T0FDUjtPQUNBO09BQ0EsT0FBTztNQUNSO01BQ0EsS0FBSyxNQUFNLFNBQVMsYUFBYSxRQUFRO09BQ3hDLElBQUksTUFBTSxNQUFNLE1BQU0sS0FBSyxRQUFRLFFBQVE7WUFDdEMsTUFBTSxPQUFPLENBQUMsUUFBUTtPQUMzQixRQUFRLFFBQVEsS0FBSyxLQUFLO01BQzNCO01BQ0EsSUFBSSxDQUFDLFFBQVEsUUFBUSxRQUFRLFNBQVMsYUFBYTtNQUNuRCxJQUFJLFNBQVMsWUFBWTtPQUN4QixRQUFRLFFBQVE7T0FDaEI7TUFDRDtLQUNEO0tBQ0EsSUFBSSxDQUFDLGFBQWEsT0FBTyxRQUFRLFFBQVE7S0FDekMsUUFBUSxNQUFNLE9BQU8sYUFBYTtJQUNuQyxPQUFPLElBQUksWUFBWSxhQUFhLEtBQUssR0FBRyxRQUFRLE1BQU0sT0FBTyxNQUFzQiw0QkFBWSxXQUFXO1NBQ3pHLElBQUksWUFBWSxTQUFTLG9CQUFvQixZQUFZLFNBQVMsY0FBYyxZQUFZLFNBQVMsV0FBVztLQUNwSCxVQUFVLE1BQU0sT0FBTyxTQUFTLFVBQVU7TUFDekMsT0FBTyxLQUFLO01BQ1osVUFBVSxJQUFJLElBQUk7TUFDbEIsTUFBTSxDQUFDO09BQ04sTUFBTTtPQUNOLFFBQVE7T0FDUjtPQUNBO09BQ0EsT0FBTztNQUNSLENBQUM7S0FDRixDQUFDO0tBQ0QsSUFBSSxTQUFTLFlBQVk7SUFDMUI7SUFDQSxJQUFJLENBQUMsUUFBUSxVQUFVLENBQUMsU0FBUyxZQUMzQjtVQUFBLE1BQU0sT0FBTyxPQUFPLElBQUksRUFBRSxPQUFPLEtBQUssVUFBVTtNQUNwRCxVQUFVLE1BQU0sT0FBTyxTQUFTLFVBQVU7T0FDekMsT0FBTztPQUNQLFVBQVU7T0FDVixNQUFNLENBQUM7UUFDTixNQUFNO1FBQ04sUUFBUTtRQUNSO1FBQ0E7UUFDQSxPQUFPLE1BQU07T0FDZCxDQUFDO01BQ0YsQ0FBQztNQUNEO0tBQ0Q7O0dBRUYsT0FBTyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDaEQsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFlBQVksT0FBTyxXQUFXO0NBQ3RDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRztJQUN6QixRQUFRLFFBQVE7SUFDaEIsUUFBUSxRQUFRLENBQUM7SUFDakIsS0FBSyxJQUFJLE1BQU0sR0FBRyxNQUFNLEtBQUssTUFBTSxRQUFRLE9BQU87S0FDakQsTUFBTSxVQUFVLE1BQU07S0FDdEIsTUFBTSxjQUFjLEtBQUssTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtLQUN4RSxJQUFJLFlBQVksUUFBUTtNQUN2QixNQUFNLFdBQVc7T0FDaEIsTUFBTTtPQUNOLFFBQVE7T0FDUjtPQUNBO09BQ0EsT0FBTztNQUNSO01BQ0EsS0FBSyxNQUFNLFNBQVMsWUFBWSxRQUFRO09BQ3ZDLElBQUksTUFBTSxNQUFNLE1BQU0sS0FBSyxRQUFRLFFBQVE7WUFDdEMsTUFBTSxPQUFPLENBQUMsUUFBUTtPQUMzQixRQUFRLFFBQVEsS0FBSyxLQUFLO01BQzNCO01BQ0EsSUFBSSxDQUFDLFFBQVEsUUFBUSxRQUFRLFNBQVMsWUFBWTtNQUNsRCxJQUFJLFNBQVMsWUFBWTtPQUN4QixRQUFRLFFBQVE7T0FDaEI7TUFDRDtLQUNEO0tBQ0EsSUFBSSxDQUFDLFlBQVksT0FBTyxRQUFRLFFBQVE7S0FDeEMsUUFBUSxNQUFNLEtBQUssWUFBWSxLQUFLO0lBQ3JDO0lBQ0EsSUFBSSxFQUFFLFFBQVEsVUFBVSxTQUFTLGVBQWUsS0FBSyxNQUFNLFNBQVMsTUFBTSxRQUFRLFVBQVUsTUFBTSxRQUFRLFNBQVMsVUFBVTtLQUM1SCxPQUFPLE1BQU0sS0FBSyxNQUFNO0tBQ3hCLFVBQVU7S0FDVixNQUFNLENBQUM7TUFDTixNQUFNO01BQ04sUUFBUTtNQUNSO01BQ0EsS0FBSyxLQUFLLE1BQU07TUFDaEIsT0FBTyxNQUFNLEtBQUssTUFBTTtLQUN6QixDQUFDO0lBQ0YsQ0FBQztHQUNGLE9BQU8sVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ2hELE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxpQkFBaUIsT0FBTyxXQUFXO0NBQzNDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE1BQU0sT0FBTyxTQUFTLFVBQVU7R0FDL0IsTUFBTSxRQUFRLFFBQVE7R0FDdEIsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHO0lBQ3pCLFFBQVEsUUFBUTtJQUNoQixRQUFRLFFBQVEsQ0FBQztJQUNqQixNQUFNLGVBQWUsTUFBTSxRQUFRLElBQUksS0FBSyxNQUFNLElBQUksT0FBTyxNQUFNLFFBQVE7S0FDMUUsTUFBTSxVQUFVLE1BQU07S0FDdEIsT0FBTztNQUNOO01BQ0E7TUFDQSxNQUFNLEtBQUssT0FBTyxDQUFDLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtLQUNoRDtJQUNELENBQUMsQ0FBQztJQUNGLEtBQUssTUFBTSxDQUFDLEtBQUssU0FBUyxnQkFBZ0IsY0FBYztLQUN2RCxJQUFJLFlBQVksUUFBUTtNQUN2QixNQUFNLFdBQVc7T0FDaEIsTUFBTTtPQUNOLFFBQVE7T0FDUjtPQUNBO09BQ0EsT0FBTztNQUNSO01BQ0EsS0FBSyxNQUFNLFNBQVMsWUFBWSxRQUFRO09BQ3ZDLElBQUksTUFBTSxNQUFNLE1BQU0sS0FBSyxRQUFRLFFBQVE7WUFDdEMsTUFBTSxPQUFPLENBQUMsUUFBUTtPQUMzQixRQUFRLFFBQVEsS0FBSyxLQUFLO01BQzNCO01BQ0EsSUFBSSxDQUFDLFFBQVEsUUFBUSxRQUFRLFNBQVMsWUFBWTtNQUNsRCxJQUFJLFNBQVMsWUFBWTtPQUN4QixRQUFRLFFBQVE7T0FDaEI7TUFDRDtLQUNEO0tBQ0EsSUFBSSxDQUFDLFlBQVksT0FBTyxRQUFRLFFBQVE7S0FDeEMsUUFBUSxNQUFNLEtBQUssWUFBWSxLQUFLO0lBQ3JDO0lBQ0EsSUFBSSxFQUFFLFFBQVEsVUFBVSxTQUFTLGVBQWUsS0FBSyxNQUFNLFNBQVMsTUFBTSxRQUFRLFVBQVUsTUFBTSxRQUFRLFNBQVMsVUFBVTtLQUM1SCxPQUFPLE1BQU0sS0FBSyxNQUFNO0tBQ3hCLFVBQVU7S0FDVixNQUFNLENBQUM7TUFDTixNQUFNO01BQ04sUUFBUTtNQUNSO01BQ0EsS0FBSyxLQUFLLE1BQU07TUFDaEIsT0FBTyxNQUFNLEtBQUssTUFBTTtLQUN6QixDQUFDO0lBQ0YsQ0FBQztHQUNGLE9BQU8sVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ2hELE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxPQUFPLFdBQVc7Q0FDMUIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksT0FBTyxRQUFRLFVBQVUsVUFBVSxRQUFRLFFBQVE7UUFDbEQsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQzlDLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxPQUFPLFdBQVc7Q0FDMUIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksT0FBTyxRQUFRLFVBQVUsVUFBVSxRQUFRLFFBQVE7UUFDbEQsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQzlDLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxNQUFNLE9BQU8sV0FBVztDQUNoQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUDtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7SUFDekIsUUFBUSxRQUFRO0lBQ2hCLFFBQVEsUUFBUSxDQUFDO0lBQ2pCLEtBQUssSUFBSSxNQUFNLEdBQUcsTUFBTSxLQUFLLE1BQU0sUUFBUSxPQUFPO0tBQ2pELE1BQU0sVUFBVSxNQUFNO0tBQ3RCLE1BQU0sY0FBYyxLQUFLLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7S0FDeEUsSUFBSSxZQUFZLFFBQVE7TUFDdkIsTUFBTSxXQUFXO09BQ2hCLE1BQU07T0FDTixRQUFRO09BQ1I7T0FDQTtPQUNBLE9BQU87TUFDUjtNQUNBLEtBQUssTUFBTSxTQUFTLFlBQVksUUFBUTtPQUN2QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO1lBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLFlBQVk7TUFDbEQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksQ0FBQyxZQUFZLE9BQU8sUUFBUSxRQUFRO0tBQ3hDLFFBQVEsTUFBTSxLQUFLLFlBQVksS0FBSztJQUNyQztHQUNELE9BQU8sVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ2hELE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxXQUFXLE9BQU8sV0FBVztDQUNyQyxPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUDtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxNQUFNLE9BQU8sU0FBUyxVQUFVO0dBQy9CLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRztJQUN6QixRQUFRLFFBQVE7SUFDaEIsUUFBUSxRQUFRLENBQUM7SUFDakIsTUFBTSxlQUFlLE1BQU0sUUFBUSxJQUFJLEtBQUssTUFBTSxJQUFJLE9BQU8sTUFBTSxRQUFRO0tBQzFFLE1BQU0sVUFBVSxNQUFNO0tBQ3RCLE9BQU87TUFDTjtNQUNBO01BQ0EsTUFBTSxLQUFLLE9BQU8sQ0FBQyxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7S0FDaEQ7SUFDRCxDQUFDLENBQUM7SUFDRixLQUFLLE1BQU0sQ0FBQyxLQUFLLFNBQVMsZ0JBQWdCLGNBQWM7S0FDdkQsSUFBSSxZQUFZLFFBQVE7TUFDdkIsTUFBTSxXQUFXO09BQ2hCLE1BQU07T0FDTixRQUFRO09BQ1I7T0FDQTtPQUNBLE9BQU87TUFDUjtNQUNBLEtBQUssTUFBTSxTQUFTLFlBQVksUUFBUTtPQUN2QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO1lBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLFlBQVk7TUFDbEQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksQ0FBQyxZQUFZLE9BQU8sUUFBUSxRQUFRO0tBQ3hDLFFBQVEsTUFBTSxLQUFLLFlBQVksS0FBSztJQUNyQztHQUNELE9BQU8sVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ2hELE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxjQUFjLE9BQU8sTUFBTSxXQUFXO0NBQzlDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQO0VBQ0E7RUFDQSxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsT0FBTyxTQUFTLFVBQVU7R0FDekIsTUFBTSxRQUFRLFFBQVE7R0FDdEIsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHO0lBQ3pCLFFBQVEsUUFBUTtJQUNoQixRQUFRLFFBQVEsQ0FBQztJQUNqQixLQUFLLElBQUksTUFBTSxHQUFHLE1BQU0sS0FBSyxNQUFNLFFBQVEsT0FBTztLQUNqRCxNQUFNLFVBQVUsTUFBTTtLQUN0QixNQUFNLGNBQWMsS0FBSyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0tBQ3hFLElBQUksWUFBWSxRQUFRO01BQ3ZCLE1BQU0sV0FBVztPQUNoQixNQUFNO09BQ04sUUFBUTtPQUNSO09BQ0E7T0FDQSxPQUFPO01BQ1I7TUFDQSxLQUFLLE1BQU0sU0FBUyxZQUFZLFFBQVE7T0FDdkMsSUFBSSxNQUFNLE1BQU0sTUFBTSxLQUFLLFFBQVEsUUFBUTtZQUN0QyxNQUFNLE9BQU8sQ0FBQyxRQUFRO09BQzNCLFFBQVEsUUFBUSxLQUFLLEtBQUs7TUFDM0I7TUFDQSxJQUFJLENBQUMsUUFBUSxRQUFRLFFBQVEsU0FBUyxZQUFZO01BQ2xELElBQUksU0FBUyxZQUFZO09BQ3hCLFFBQVEsUUFBUTtPQUNoQjtNQUNEO0tBQ0Q7S0FDQSxJQUFJLENBQUMsWUFBWSxPQUFPLFFBQVEsUUFBUTtLQUN4QyxRQUFRLE1BQU0sS0FBSyxZQUFZLEtBQUs7SUFDckM7SUFDQSxJQUFJLENBQUMsUUFBUSxVQUFVLENBQUMsU0FBUyxZQUFZLEtBQUssSUFBSSxNQUFNLEtBQUssTUFBTSxRQUFRLE1BQU0sTUFBTSxRQUFRLE9BQU87S0FDekcsTUFBTSxVQUFVLE1BQU07S0FDdEIsTUFBTSxjQUFjLEtBQUssS0FBSyxPQUFPLENBQUMsRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0tBQ2xFLElBQUksWUFBWSxRQUFRO01BQ3ZCLE1BQU0sV0FBVztPQUNoQixNQUFNO09BQ04sUUFBUTtPQUNSO09BQ0E7T0FDQSxPQUFPO01BQ1I7TUFDQSxLQUFLLE1BQU0sU0FBUyxZQUFZLFFBQVE7T0FDdkMsSUFBSSxNQUFNLE1BQU0sTUFBTSxLQUFLLFFBQVEsUUFBUTtZQUN0QyxNQUFNLE9BQU8sQ0FBQyxRQUFRO09BQzNCLFFBQVEsUUFBUSxLQUFLLEtBQUs7TUFDM0I7TUFDQSxJQUFJLENBQUMsUUFBUSxRQUFRLFFBQVEsU0FBUyxZQUFZO01BQ2xELElBQUksU0FBUyxZQUFZO09BQ3hCLFFBQVEsUUFBUTtPQUNoQjtNQUNEO0tBQ0Q7S0FDQSxJQUFJLENBQUMsWUFBWSxPQUFPLFFBQVEsUUFBUTtLQUN4QyxRQUFRLE1BQU0sS0FBSyxZQUFZLEtBQUs7SUFDckM7R0FDRCxPQUFPLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNoRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsbUJBQW1CLE9BQU8sTUFBTSxXQUFXO0NBQ25ELE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQO0VBQ0E7RUFDQSxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0VBQ0EsTUFBTSxPQUFPLFNBQVMsVUFBVTtHQUMvQixNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7SUFDekIsUUFBUSxRQUFRO0lBQ2hCLFFBQVEsUUFBUSxDQUFDO0lBQ2pCLE1BQU0sQ0FBQyxnQkFBZ0IsZ0JBQWdCLE1BQU0sUUFBUSxJQUFJLENBQUMsUUFBUSxJQUFJLEtBQUssTUFBTSxJQUFJLE9BQU8sTUFBTSxRQUFRO0tBQ3pHLE1BQU0sVUFBVSxNQUFNO0tBQ3RCLE9BQU87TUFDTjtNQUNBO01BQ0EsTUFBTSxLQUFLLE9BQU8sQ0FBQyxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7S0FDaEQ7SUFDRCxDQUFDLENBQUMsR0FBRyxRQUFRLElBQUksTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLENBQUMsQ0FBQyxJQUFJLE9BQU8sU0FBUyxRQUFRO0tBQzNFLE9BQU87TUFDTixNQUFNLEtBQUssTUFBTTtNQUNqQjtNQUNBLE1BQU0sS0FBSyxLQUFLLE9BQU8sQ0FBQyxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7S0FDckQ7SUFDRCxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ0osS0FBSyxNQUFNLENBQUMsS0FBSyxTQUFTLGdCQUFnQixnQkFBZ0I7S0FDekQsSUFBSSxZQUFZLFFBQVE7TUFDdkIsTUFBTSxXQUFXO09BQ2hCLE1BQU07T0FDTixRQUFRO09BQ1I7T0FDQTtPQUNBLE9BQU87TUFDUjtNQUNBLEtBQUssTUFBTSxTQUFTLFlBQVksUUFBUTtPQUN2QyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssUUFBUSxRQUFRO1lBQ3RDLE1BQU0sT0FBTyxDQUFDLFFBQVE7T0FDM0IsUUFBUSxRQUFRLEtBQUssS0FBSztNQUMzQjtNQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsUUFBUSxTQUFTLFlBQVk7TUFDbEQsSUFBSSxTQUFTLFlBQVk7T0FDeEIsUUFBUSxRQUFRO09BQ2hCO01BQ0Q7S0FDRDtLQUNBLElBQUksQ0FBQyxZQUFZLE9BQU8sUUFBUSxRQUFRO0tBQ3hDLFFBQVEsTUFBTSxLQUFLLFlBQVksS0FBSztJQUNyQztJQUNBLElBQUksQ0FBQyxRQUFRLFVBQVUsQ0FBQyxTQUFTLFlBQVksS0FBSyxNQUFNLENBQUMsS0FBSyxTQUFTLGdCQUFnQixjQUFjO0tBQ3BHLElBQUksWUFBWSxRQUFRO01BQ3ZCLE1BQU0sV0FBVztPQUNoQixNQUFNO09BQ04sUUFBUTtPQUNSO09BQ0E7T0FDQSxPQUFPO01BQ1I7TUFDQSxLQUFLLE1BQU0sU0FBUyxZQUFZLFFBQVE7T0FDdkMsSUFBSSxNQUFNLE1BQU0sTUFBTSxLQUFLLFFBQVEsUUFBUTtZQUN0QyxNQUFNLE9BQU8sQ0FBQyxRQUFRO09BQzNCLFFBQVEsUUFBUSxLQUFLLEtBQUs7TUFDM0I7TUFDQSxJQUFJLENBQUMsUUFBUSxRQUFRLFFBQVEsU0FBUyxZQUFZO01BQ2xELElBQUksU0FBUyxZQUFZO09BQ3hCLFFBQVEsUUFBUTtPQUNoQjtNQUNEO0tBQ0Q7S0FDQSxJQUFJLENBQUMsWUFBWSxPQUFPLFFBQVEsUUFBUTtLQUN4QyxRQUFRLE1BQU0sS0FBSyxZQUFZLEtBQUs7SUFDckM7R0FDRCxPQUFPLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUNoRCxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsV0FBVyxXQUFXO0NBQzlCLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixJQUFJLFFBQVEsVUFBVSxLQUFLLEdBQUcsUUFBUSxRQUFRO1FBQ3pDLFVBQVUsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUM5QyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsY0FBYyxTQUFTLFVBQVU7Q0FDekMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVMsSUFBSSxRQUFRLFFBQVE7RUFDN0IsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxVQUFVLEtBQUssR0FBRztJQUM3QixJQUFJLEtBQUssWUFBWSxLQUFLLEdBQUcsUUFBUSxRQUF3QiwyQkFBVyxNQUFNLFNBQVMsUUFBUTtJQUMvRixJQUFJLFFBQVEsVUFBVSxLQUFLLEdBQUc7S0FDN0IsUUFBUSxRQUFRO0tBQ2hCLE9BQU87SUFDUjtHQUNEO0dBQ0EsT0FBTyxLQUFLLFFBQVEsT0FBTyxDQUFDLFNBQVMsUUFBUTtFQUM5QztDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxtQkFBbUIsU0FBUyxVQUFVO0NBQzlDLE9BQU87RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTLElBQUksUUFBUSxRQUFRO0VBQzdCLE9BQU87RUFDUDtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxNQUFNLE9BQU8sU0FBUyxVQUFVO0dBQy9CLElBQUksUUFBUSxVQUFVLEtBQUssR0FBRztJQUM3QixJQUFJLEtBQUssWUFBWSxLQUFLLEdBQUcsUUFBUSxRQUFRLE1BQXNCLDJCQUFXLE1BQU0sU0FBUyxRQUFRO0lBQ3JHLElBQUksUUFBUSxVQUFVLEtBQUssR0FBRztLQUM3QixRQUFRLFFBQVE7S0FDaEIsT0FBTztJQUNSO0dBQ0Q7R0FDQSxPQUFPLEtBQUssUUFBUSxPQUFPLENBQUMsU0FBUyxRQUFRO0VBQzlDO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7QUFjQSxTQUFTLFdBQVcsVUFBVTtDQUM3QixJQUFJO0NBQ0osSUFBSSxVQUFVLEtBQUssTUFBTSxXQUFXLFVBQVUsSUFBSSxRQUFRLEtBQUssTUFBTSxTQUFTLFFBQVEsUUFBUSxPQUFPLEtBQUssS0FBSztNQUMxRyxTQUFTLFFBQVE7Q0FDdEIsT0FBTztBQUNSOztBQUtBLFNBQVMsTUFBTSxTQUFTLFdBQVc7Q0FDbEMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQXlCLDZCQUFhLFFBQVEsS0FBSyxXQUFXLE9BQU8sT0FBTyxHQUFHLEdBQUc7RUFDbEYsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLEtBQUssTUFBTSxVQUFVLEtBQUssU0FBUztJQUNsQyxNQUFNLGdCQUFnQixPQUFPLE9BQU8sQ0FBQyxFQUFFLE9BQU8sUUFBUSxNQUFNLEdBQUcsUUFBUTtJQUN2RSxJQUFJLGNBQWMsT0FBTyxJQUFJLGNBQWMsUUFBUSxJQUFJLGVBQWUsY0FBYyxLQUFLLGFBQWE7U0FDakcsZ0JBQWdCLENBQUMsYUFBYTtTQUM5QjtLQUNKLGVBQWU7S0FDZjtJQUNEO1NBQ0ssSUFBSSxpQkFBaUIsZ0JBQWdCLEtBQUssYUFBYTtTQUN2RCxrQkFBa0IsQ0FBQyxhQUFhO0dBQ3RDO0dBQ0EsSUFBSSxjQUFjLE9BQU87R0FDekIsSUFBSSxlQUFlO0lBQ2xCLElBQUksY0FBYyxXQUFXLEdBQUcsT0FBTyxjQUFjO0lBQ3JELFVBQVUsTUFBTSxRQUFRLFNBQVMsVUFBVSxFQUFFLFFBQXdCLDJCQUFXLGFBQWEsRUFBRSxDQUFDO0lBQ2hHLFFBQVEsUUFBUTtHQUNqQixPQUFPLElBQUksaUJBQWlCLFdBQVcsR0FBRyxPQUFPLGdCQUFnQjtRQUM1RCxVQUFVLE1BQU0sUUFBUSxTQUFTLFVBQVUsRUFBRSxRQUF3QiwyQkFBVyxlQUFlLEVBQUUsQ0FBQztHQUN2RyxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsV0FBVyxTQUFTLFdBQVc7Q0FDdkMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQXlCLDZCQUFhLFFBQVEsS0FBSyxXQUFXLE9BQU8sT0FBTyxHQUFHLEdBQUc7RUFDbEYsT0FBTztFQUNQO0VBQ0EsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE1BQU0sT0FBTyxTQUFTLFVBQVU7R0FDL0IsSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osS0FBSyxNQUFNLFVBQVUsS0FBSyxTQUFTO0lBQ2xDLE1BQU0sZ0JBQWdCLE1BQU0sT0FBTyxPQUFPLENBQUMsRUFBRSxPQUFPLFFBQVEsTUFBTSxHQUFHLFFBQVE7SUFDN0UsSUFBSSxjQUFjLE9BQU8sSUFBSSxjQUFjLFFBQVEsSUFBSSxlQUFlLGNBQWMsS0FBSyxhQUFhO1NBQ2pHLGdCQUFnQixDQUFDLGFBQWE7U0FDOUI7S0FDSixlQUFlO0tBQ2Y7SUFDRDtTQUNLLElBQUksaUJBQWlCLGdCQUFnQixLQUFLLGFBQWE7U0FDdkQsa0JBQWtCLENBQUMsYUFBYTtHQUN0QztHQUNBLElBQUksY0FBYyxPQUFPO0dBQ3pCLElBQUksZUFBZTtJQUNsQixJQUFJLGNBQWMsV0FBVyxHQUFHLE9BQU8sY0FBYztJQUNyRCxVQUFVLE1BQU0sUUFBUSxTQUFTLFVBQVUsRUFBRSxRQUF3QiwyQkFBVyxhQUFhLEVBQUUsQ0FBQztJQUNoRyxRQUFRLFFBQVE7R0FDakIsT0FBTyxJQUFJLGlCQUFpQixXQUFXLEdBQUcsT0FBTyxnQkFBZ0I7UUFDNUQsVUFBVSxNQUFNLFFBQVEsU0FBUyxVQUFVLEVBQUUsUUFBd0IsMkJBQVcsZUFBZSxFQUFFLENBQUM7R0FDdkcsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7OztBQVVBLFNBQVMsVUFBVTtDQUNsQixPQUFPO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixXQUFXO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVM7R0FDZixRQUFRLFFBQVE7R0FDaEIsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLFFBQVEsS0FBSyxTQUFTLFdBQVc7Q0FDekMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1A7RUFDQTtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLFNBQVMsT0FBTyxVQUFVLFVBQVU7SUFDdkMsSUFBSTtJQUNKLElBQUksMkJBQTJCO0lBQy9CLElBQUksMEJBQTBCLEtBQUs7SUFDbkMsSUFBSSx5QkFBeUIsQ0FBQztJQUM5QixNQUFNLGdCQUFnQixXQUFXLFlBQVk7S0FDNUMsS0FBSyxNQUFNLFVBQVUsVUFBVSxTQUFTO01BQ3ZDLElBQUksT0FBTyxTQUFTLFdBQVcsYUFBYSxRQUFRLElBQUksSUFBSSxPQUFPLENBQUMsQ0FBQyxJQUFJLE9BQU8sR0FBRyxDQUFDO1dBQy9FO09BQ0osSUFBSSxlQUFlO09BQ25CLElBQUksa0JBQWtCO09BQ3RCLEtBQUssTUFBTSxjQUFjLFNBQVM7UUFDakMsTUFBTSxzQkFBc0IsT0FBTyxRQUFRO1FBQzNDLElBQUksY0FBYyxRQUFRLG9CQUFvQixPQUFPLENBQUM7U0FDckQsT0FBTztTQUNQLE9BQU8sTUFBTTtRQUNkLEdBQUcsa0JBQWtCLENBQUMsQ0FBQyxTQUFTLG9CQUFvQixTQUFTLG9CQUFvQixvQkFBb0IsU0FBUyxjQUFjLG9CQUFvQixTQUFTLFdBQVc7U0FDbkssZUFBZTtTQUNmLElBQUksNEJBQTRCLGVBQWUsMkJBQTJCLG1CQUFtQiw2QkFBNkIsbUJBQW1CLGNBQWMsU0FBUyxFQUFFLDJCQUEyQixTQUFTO1VBQ3pNLDJCQUEyQjtVQUMzQiwwQkFBMEI7VUFDMUIseUJBQXlCLENBQUM7U0FDM0I7U0FDQSxJQUFJLDRCQUE0QixZQUFZLHVCQUF1QixLQUFLLE9BQU8sUUFBUSxXQUFXLENBQUMsT0FBTztTQUMxRztRQUNEO1FBQ0E7T0FDRDtPQUNBLElBQUksY0FBYztRQUNqQixNQUFNLGdCQUFnQixPQUFPLE9BQU8sQ0FBQyxFQUFFLE9BQU8sTUFBTSxHQUFHLFFBQVE7UUFDL0QsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsU0FBUyxjQUFjLE9BQU8sZ0JBQWdCO09BQ3BGO01BQ0Q7TUFDQSxJQUFJLGlCQUFpQixDQUFDLGNBQWMsUUFBUTtLQUM3QztJQUNEO0lBQ0EsYUFBYSxzQkFBTSxJQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0lBQ3RDLElBQUksZUFBZSxPQUFPO0lBQzFCLFVBQVUsTUFBTSxRQUFRLFNBQVMsVUFBVTtLQUMxQyxPQUFPLE1BQU07S0FDYixVQUEwQiw2QkFBYSx3QkFBd0IsR0FBRztLQUNsRSxNQUFNLENBQUM7TUFDTixNQUFNO01BQ04sUUFBUTtNQUNSO01BQ0EsS0FBSztNQUNMLE9BQU8sTUFBTTtLQUNkLENBQUM7SUFDRixDQUFDO0dBQ0YsT0FBTyxVQUFVLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDaEQsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFLQSxTQUFTLGFBQWEsS0FBSyxTQUFTLFdBQVc7Q0FDOUMsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1A7RUFDQTtFQUNBLFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxNQUFNLE9BQU8sU0FBUyxVQUFVO0dBQy9CLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksU0FBUyxPQUFPLFVBQVUsVUFBVTtJQUN2QyxJQUFJO0lBQ0osSUFBSSwyQkFBMkI7SUFDL0IsSUFBSSwwQkFBMEIsS0FBSztJQUNuQyxJQUFJLHlCQUF5QixDQUFDO0lBQzlCLE1BQU0sZUFBZSxPQUFPLFdBQVcsWUFBWTtLQUNsRCxLQUFLLE1BQU0sVUFBVSxVQUFVLFNBQVM7TUFDdkMsSUFBSSxPQUFPLFNBQVMsV0FBVyxNQUFNLGFBQWEsUUFBUSxJQUFJLElBQUksT0FBTyxDQUFDLENBQUMsSUFBSSxPQUFPLEdBQUcsQ0FBQztXQUNyRjtPQUNKLElBQUksZUFBZTtPQUNuQixJQUFJLGtCQUFrQjtPQUN0QixLQUFLLE1BQU0sY0FBYyxTQUFTO1FBQ2pDLE1BQU0sc0JBQXNCLE9BQU8sUUFBUTtRQUMzQyxJQUFJLGNBQWMsU0FBUyxNQUFNLG9CQUFvQixPQUFPLENBQUM7U0FDNUQsT0FBTztTQUNQLE9BQU8sTUFBTTtRQUNkLEdBQUcsa0JBQWtCLEVBQUEsQ0FBRyxTQUFTLG9CQUFvQixTQUFTLG9CQUFvQixvQkFBb0IsU0FBUyxjQUFjLG9CQUFvQixTQUFTLFdBQVc7U0FDcEssZUFBZTtTQUNmLElBQUksNEJBQTRCLGVBQWUsMkJBQTJCLG1CQUFtQiw2QkFBNkIsbUJBQW1CLGNBQWMsU0FBUyxFQUFFLDJCQUEyQixTQUFTO1VBQ3pNLDJCQUEyQjtVQUMzQiwwQkFBMEI7VUFDMUIseUJBQXlCLENBQUM7U0FDM0I7U0FDQSxJQUFJLDRCQUE0QixZQUFZLHVCQUF1QixLQUFLLE9BQU8sUUFBUSxXQUFXLENBQUMsT0FBTztTQUMxRztRQUNEO1FBQ0E7T0FDRDtPQUNBLElBQUksY0FBYztRQUNqQixNQUFNLGdCQUFnQixNQUFNLE9BQU8sT0FBTyxDQUFDLEVBQUUsT0FBTyxNQUFNLEdBQUcsUUFBUTtRQUNyRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsY0FBYyxTQUFTLGNBQWMsT0FBTyxnQkFBZ0I7T0FDcEY7TUFDRDtNQUNBLElBQUksaUJBQWlCLENBQUMsY0FBYyxRQUFRO0tBQzdDO0lBQ0Q7SUFDQSxNQUFNLGFBQWEsc0JBQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztJQUM1QyxJQUFJLGVBQWUsT0FBTztJQUMxQixVQUFVLE1BQU0sUUFBUSxTQUFTLFVBQVU7S0FDMUMsT0FBTyxNQUFNO0tBQ2IsVUFBMEIsNkJBQWEsd0JBQXdCLEdBQUc7S0FDbEUsTUFBTSxDQUFDO01BQ04sTUFBTTtNQUNOLFFBQVE7TUFDUjtNQUNBLEtBQUs7TUFDTCxPQUFPLE1BQU07S0FDZCxDQUFDO0lBQ0YsQ0FBQztHQUNGLE9BQU8sVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQ2hELE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxNQUFNLFdBQVc7Q0FDekIsT0FBTztFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVM7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztFQUNBLE9BQU8sU0FBUyxVQUFVO0dBQ3pCLElBQUksUUFBUSxVQUFVLEtBQUssR0FBRyxRQUFRLFFBQVE7UUFDekMsVUFBVSxNQUFNLFFBQVEsU0FBUyxRQUFRO0dBQzlDLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxNQUFNLFFBQVEsV0FBVztDQUNqQyxPQUF1Qix5QkFBUyxPQUFPLEtBQUssT0FBTyxPQUFPLEdBQUcsU0FBUztBQUN2RTs7Ozs7Ozs7OztBQWFBLFNBQVMsUUFBUSxRQUFRLFVBQVU7Q0FDbEMsT0FBTztFQUNOLEdBQUc7RUFDSCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixPQUFPLE9BQU8sT0FBTyxDQUFDLFNBQVM7SUFDOUIsR0FBRztJQUNILFNBQVM7R0FDVixDQUFDO0VBQ0Y7Q0FDRDtBQUNEOzs7Ozs7Ozs7OztBQWNBLFNBQVMsS0FBSyxRQUFRLE1BQU07Q0FDM0IsTUFBTSxZQUFZLEVBQUUsR0FBRyxPQUFPLFFBQVE7Q0FDdEMsS0FBSyxNQUFNLE9BQU8sTUFBTSxPQUFPLFVBQVU7Q0FDekMsT0FBTztFQUNOLEdBQUc7RUFDSCxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0NBQ0Q7QUFDRDs7Ozs7Ozs7OztBQWFBLFNBQVMsTUFBTSxRQUFRLE9BQU8sVUFBVTtDQUN2QyxNQUFNLFVBQVUsT0FBTyxPQUFPLENBQUMsRUFBRSxPQUFPLE1BQU0sR0FBbUIsZ0NBQWdCLFFBQVEsQ0FBQztDQUMxRixJQUFJLFFBQVEsUUFBUSxNQUFNLElBQUksVUFBVSxRQUFRLE1BQU07Q0FDdEQsT0FBTyxRQUFRO0FBQ2hCOzs7Ozs7Ozs7O0FBYUEsZUFBZSxXQUFXLFFBQVEsT0FBTyxVQUFVO0NBQ2xELE1BQU0sVUFBVSxNQUFNLE9BQU8sT0FBTyxDQUFDLEVBQUUsT0FBTyxNQUFNLEdBQW1CLGdDQUFnQixRQUFRLENBQUM7Q0FDaEcsSUFBSSxRQUFRLFFBQVEsTUFBTSxJQUFJLFVBQVUsUUFBUSxNQUFNO0NBQ3RELE9BQU8sUUFBUTtBQUNoQjs7QUFLQSxTQUFTLE9BQU8sUUFBUSxVQUFVO0NBQ2pDLE1BQU0sUUFBUSxVQUFVLE1BQU0sUUFBUSxPQUFPLFFBQVE7Q0FDckQsS0FBSyxTQUFTO0NBQ2QsS0FBSyxTQUFTO0NBQ2QsT0FBTztBQUNSOztBQUtBLFNBQVMsWUFBWSxRQUFRLFVBQVU7Q0FDdEMsTUFBTSxRQUFRLFVBQVUsV0FBVyxRQUFRLE9BQU8sUUFBUTtDQUMxRCxLQUFLLFNBQVM7Q0FDZCxLQUFLLFNBQVM7Q0FDZCxPQUFPO0FBQ1I7O0FBS0EsU0FBUyxRQUFRLFFBQVEsTUFBTTtDQUM5QixNQUFNLFlBQVksQ0FBQztDQUNuQixLQUFLLE1BQU0sT0FBTyxPQUFPLFNBQVMsVUFBVSxPQUFPLENBQUMsUUFBUSxLQUFLLFNBQVMsR0FBRyxJQUFvQix5QkFBUyxPQUFPLFFBQVEsSUFBSSxJQUFJLE9BQU8sUUFBUTtDQUNoSixPQUFPO0VBQ04sR0FBRztFQUNILFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7Q0FDRDtBQUNEOztBQUtBLFNBQVMsYUFBYSxRQUFRLE1BQU07Q0FDbkMsTUFBTSxZQUFZLENBQUM7Q0FDbkIsS0FBSyxNQUFNLE9BQU8sT0FBTyxTQUFTLFVBQVUsT0FBTyxDQUFDLFFBQVEsS0FBSyxTQUFTLEdBQUcsSUFBb0IsOEJBQWMsT0FBTyxRQUFRLElBQUksSUFBSSxPQUFPLFFBQVE7Q0FDckosT0FBTztFQUNOLEdBQUc7RUFDSCxTQUFTO0VBQ1QsSUFBSSxjQUFjO0dBQ2pCLE9BQXVCLGtDQUFrQixJQUFJO0VBQzlDO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7QUFjQSxTQUFTLEtBQUssUUFBUSxNQUFNO0NBQzNCLE1BQU0sWUFBWSxDQUFDO0NBQ25CLEtBQUssTUFBTSxPQUFPLE1BQU0sVUFBVSxPQUFPLE9BQU8sUUFBUTtDQUN4RCxPQUFPO0VBQ04sR0FBRztFQUNILFNBQVM7RUFDVCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7Q0FDRDtBQUNEOztBQUtBLFNBQVMsS0FBSyxHQUFHLFFBQVE7Q0FDeEIsT0FBTztFQUNOLEdBQUcsT0FBTztFQUNWLE1BQU07RUFDTixJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxPQUFPLFNBQVMsVUFBVTtHQUN6QixLQUFLLE1BQU0sUUFBUSxRQUFRLElBQUksS0FBSyxTQUFTLFlBQVk7SUFDeEQsSUFBSSxRQUFRLFdBQVcsS0FBSyxTQUFTLFlBQVksS0FBSyxTQUFTLG1CQUFtQjtLQUNqRixRQUFRLFFBQVE7S0FDaEI7SUFDRDtJQUNBLElBQUksQ0FBQyxRQUFRLFVBQVUsQ0FBQyxTQUFTLGNBQWMsQ0FBQyxTQUFTLGdCQUFnQixVQUFVLEtBQUssT0FBTyxDQUFDLFNBQVMsUUFBUTtHQUNsSDtHQUNBLE9BQU87RUFDUjtDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxVQUFVLEdBQUcsUUFBUTtDQUM3QixPQUFPO0VBQ04sR0FBRyxPQUFPO0VBQ1YsTUFBTTtFQUNOLE9BQU87RUFDUCxJQUFJLGNBQWM7R0FDakIsT0FBdUIsa0NBQWtCLElBQUk7RUFDOUM7RUFDQSxNQUFNLE9BQU8sU0FBUyxVQUFVO0dBQy9CLEtBQUssTUFBTSxRQUFRLFFBQVEsSUFBSSxLQUFLLFNBQVMsWUFBWTtJQUN4RCxJQUFJLFFBQVEsV0FBVyxLQUFLLFNBQVMsWUFBWSxLQUFLLFNBQVMsbUJBQW1CO0tBQ2pGLFFBQVEsUUFBUTtLQUNoQjtJQUNEO0lBQ0EsSUFBSSxDQUFDLFFBQVEsVUFBVSxDQUFDLFNBQVMsY0FBYyxDQUFDLFNBQVMsZ0JBQWdCLFVBQVUsTUFBTSxLQUFLLE9BQU8sQ0FBQyxTQUFTLFFBQVE7R0FDeEg7R0FDQSxPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUtBLFNBQVMsU0FBUyxRQUFRLE1BQU0sTUFBTTtDQUNyQyxNQUFNLE9BQU8sTUFBTSxRQUFRLElBQUksSUFBSSxPQUFPLEtBQUs7Q0FDL0MsTUFBTSxZQUFZLE1BQU0sUUFBUSxJQUFJLElBQUksT0FBTztDQUMvQyxNQUFNLFlBQVksQ0FBQztDQUNuQixLQUFLLE1BQU0sT0FBTyxPQUFPLFNBQVMsVUFBVSxPQUFPLENBQUMsUUFBUSxLQUFLLFNBQVMsR0FBRyxJQUFvQiw0QkFBWSxPQUFPLFFBQVEsTUFBTSxTQUFTLElBQUksT0FBTyxRQUFRO0NBQzlKLE9BQU87RUFDTixHQUFHO0VBQ0gsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztDQUNEO0FBQ0Q7O0FBS0EsU0FBUyxjQUFjLFFBQVEsTUFBTSxNQUFNO0NBQzFDLE1BQU0sT0FBTyxNQUFNLFFBQVEsSUFBSSxJQUFJLE9BQU8sS0FBSztDQUMvQyxNQUFNLFlBQVksTUFBTSxRQUFRLElBQUksSUFBSSxPQUFPO0NBQy9DLE1BQU0sWUFBWSxDQUFDO0NBQ25CLEtBQUssTUFBTSxPQUFPLE9BQU8sU0FBUyxVQUFVLE9BQU8sQ0FBQyxRQUFRLEtBQUssU0FBUyxHQUFHLElBQW9CLGlDQUFpQixPQUFPLFFBQVEsTUFBTSxTQUFTLElBQUksT0FBTyxRQUFRO0NBQ25LLE9BQU87RUFDTixHQUFHO0VBQ0gsU0FBUztFQUNULElBQUksY0FBYztHQUNqQixPQUF1QixrQ0FBa0IsSUFBSTtFQUM5QztDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7O0FBY0EsU0FBUyxVQUFVLFFBQVEsT0FBTyxVQUFVO0NBQzNDLE1BQU0sVUFBVSxPQUFPLE9BQU8sQ0FBQyxFQUFFLE9BQU8sTUFBTSxHQUFtQixnQ0FBZ0IsUUFBUSxDQUFDO0NBQzFGLE9BQU87RUFDTixPQUFPLFFBQVE7RUFDZixTQUFTLENBQUMsUUFBUTtFQUNsQixRQUFRLFFBQVE7RUFDaEIsUUFBUSxRQUFRO0NBQ2pCO0FBQ0Q7Ozs7Ozs7Ozs7O0FBY0EsZUFBZSxlQUFlLFFBQVEsT0FBTyxVQUFVO0NBQ3RELE1BQU0sVUFBVSxNQUFNLE9BQU8sT0FBTyxDQUFDLEVBQUUsT0FBTyxNQUFNLEdBQW1CLGdDQUFnQixRQUFRLENBQUM7Q0FDaEcsT0FBTztFQUNOLE9BQU8sUUFBUTtFQUNmLFNBQVMsQ0FBQyxRQUFRO0VBQ2xCLFFBQVEsUUFBUTtFQUNoQixRQUFRLFFBQVE7Q0FDakI7QUFDRDs7QUFLQSxTQUFTLFdBQVcsUUFBUSxVQUFVO0NBQ3JDLE1BQU0sUUFBUSxVQUEwQiwwQkFBVSxRQUFRLE9BQU8sUUFBUTtDQUN6RSxLQUFLLFNBQVM7Q0FDZCxLQUFLLFNBQVM7Q0FDZCxPQUFPO0FBQ1I7O0FBS0EsU0FBUyxnQkFBZ0IsUUFBUSxVQUFVO0NBQzFDLE1BQU0sUUFBUSxVQUEwQiwrQkFBZSxRQUFRLE9BQU8sUUFBUTtDQUM5RSxLQUFLLFNBQVM7Q0FDZCxLQUFLLFNBQVM7Q0FDZCxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7O0FBY0EsU0FBUyxVQUFVLFFBQVE7Q0FDMUIsSUFBSSxVQUFVO0NBQ2QsS0FBSyxNQUFNLFNBQVMsUUFBUTtFQUMzQixJQUFJLFNBQVMsV0FBVztFQUN4QixXQUFXLEtBQUssTUFBTTtFQUN0QixNQUFNLFVBQTBCLDJCQUFXLEtBQUs7RUFDaEQsSUFBSSxTQUFTLFdBQVcsWUFBWTtDQUNyQztDQUNBLE9BQU87QUFDUjs7Ozs7Ozs7O0FBWUEsU0FBUyxPQUFPLFFBQVE7Q0FDdkIsT0FBTyxPQUFPO0FBQ2YifQ==