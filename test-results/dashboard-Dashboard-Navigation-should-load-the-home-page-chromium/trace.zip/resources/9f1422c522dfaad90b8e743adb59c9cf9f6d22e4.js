import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/organization/_auth.tsx");const $$splitNotFoundComponentImporter = () => import("/src/routes/organization/_auth.tsx?tsr-split=notFoundComponent");
const $$splitComponentImporter = () => import("/src/routes/organization/_auth.tsx?tsr-split=component");
import { lazyRouteComponent } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=03f72e91";
import { createFileRoute } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=03f72e91";
const TSRSplitComponent = (() => {
	const hot = import.meta.hot;
	const hotData = hot ? hot.data ??= {} : undefined;
	return hotData?.["tsr-split-component:component"] ?? lazyRouteComponent($$splitComponentImporter, "component");
})();
if (import.meta.hot) {
	(import.meta.hot.data ??= {})["tsr-split-component:component"] = TSRSplitComponent;
}
const TSRSplitNotFoundComponent = (() => {
	const hot = import.meta.hot;
	const hotData = hot ? hot.data ??= {} : undefined;
	return hotData?.["tsr-split-component:notFoundComponent"] ?? lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent");
})();
if (import.meta.hot) {
	(import.meta.hot.data ??= {})["tsr-split-component:notFoundComponent"] = TSRSplitNotFoundComponent;
}
export const Route = createFileRoute("/organization/_auth")({
	component: TSRSplitComponent,
	notFoundComponent: TSRSplitNotFoundComponent
});
const hot = import.meta.hot;
if (hot && typeof window !== "undefined") {
	hot.data ??= {};
	const tsrReactRefresh = window.__TSR_REACT_REFRESH__ ??= (() => {
		const ignoredExportsById = new Map();
		const previousGetIgnoredExports = window.__getReactRefreshIgnoredExports;
		window.__getReactRefreshIgnoredExports = (ctx) => {
			const ignoredExports = previousGetIgnoredExports?.(ctx) ?? [];
			const moduleIgnored = ignoredExportsById.get(ctx.id) ?? [];
			return [...ignoredExports, ...moduleIgnored];
		};
		return { ignoredExportsById };
	})();
	tsrReactRefresh.ignoredExportsById.set("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/organization/_auth.tsx", ["Route"]);
}
export function TSRFastRefreshAnchor() {
	return null;
}
_c = TSRFastRefreshAnchor;
if (import.meta.hot) {
	const hot = import.meta.hot;
	const hotData = hot.data ??= {};
	const handleRouteUpdate = function handleRouteUpdate(routeId, newRoute) {
		const router = window.__TSR_ROUTER__;
		const oldRoute = router.routesById[routeId];
		if (!oldRoute) return;
		const generatedRouteOptionKeys = new Set([
			"id",
			"path",
			"getParentRoute"
		]);
		const generatedRouteOptions = {};
		generatedRouteOptionKeys.forEach((key) => {
			if (key in oldRoute.options) generatedRouteOptions[key] = oldRoute.options[key];
		});
		const preserveComponentIdentity = "shellComponent" in oldRoute.options === "shellComponent" in newRoute.options;
		const componentKeys = [
			"component",
			"shellComponent",
			"pendingComponent",
			"errorComponent",
			"notFoundComponent"
		];
		if (preserveComponentIdentity) componentKeys.forEach((key) => {
			if (key in oldRoute.options && key in newRoute.options) newRoute.options[key] = oldRoute.options[key];
		});
		const nextOptions = {
			...newRoute.options,
			...generatedRouteOptions
		};
		oldRoute.options = nextOptions;
		oldRoute.update(nextOptions);
		router._replaceRouteChunk(oldRoute, newRoute.lazyFn);
		router.setRoutes(router.buildRouteTree());
		syncHotRouteExport(oldRoute);
		router.resolvePathCache.clear();
		router._refreshRoute?.();
		function syncHotRouteExport(liveRoute) {
			newRoute.options = liveRoute.options;
			newRoute.parentRoute = liveRoute.parentRoute;
			newRoute._path = liveRoute._path;
			newRoute._id = liveRoute._id;
			newRoute._fullPath = liveRoute._fullPath;
			newRoute._to = liveRoute._to;
		}
	};
	const initialRouteId = "/organization/_auth" ?? hotData["tsr-route-id"];
	if (initialRouteId) {
		hotData["tsr-route-id"] = initialRouteId;
	}
	const existingRoute = typeof window !== "undefined" && initialRouteId ? window.__TSR_ROUTER__?.routesById?.[initialRouteId] : undefined;
	if (initialRouteId && existingRoute && existingRoute !== Route) {
		handleRouteUpdate(initialRouteId, Route);
		hotData["tsr-route-update-handled"] = Route;
	}
	hot.accept((newModule) => {
		if (Route && newModule && newModule.Route) {
			const routeId = hotData["tsr-route-id"] ?? "/organization/_auth";
			if (routeId) {
				hotData["tsr-route-id"] = routeId;
			}
			if (hotData["tsr-route-update-handled"] === newModule.Route) {
				delete hotData["tsr-route-update-handled"];
				return;
			}
			handleRouteUpdate(routeId, newModule.Route);
		}
	});
}
var _c;
$RefreshReg$(_c, "TSRFastRefreshAnchor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/organization/_auth.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/organization/_auth.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/organization/_auth.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/routes/organization/_auth.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7O0FBQUEsU0FBU0EsdUJBQXVCO0FBQXlCLE1BQUFDLDJCQUFBO0NBQUEsTUFBQUMsTUFBQUMsWUFBQUQ7Q0FBQSxNQUFBRSxVQUFBRixVQUFBRyxTQUFBLEtBQUFDO0NBQUEsT0FBQUYsVUFBQSxvQ0FBQUcsbUJBQUFDLDBCQUFBO0FBQUE7QUFBQSxJQUFBTCxZQUFBRCxLQUFBO0NBQUEsQ0FBQUMsWUFBQUQsSUFBQUcsU0FBQSx1Q0FBQUo7QUFBQTtBQUFBLE1BQUFRLG1DQUFBO0NBQUEsTUFBQVAsTUFBQUMsWUFBQUQ7Q0FBQSxNQUFBRSxVQUFBRixVQUFBRyxTQUFBLEtBQUFDO0NBQUEsT0FBQUYsVUFBQSw0Q0FBQUcsbUJBQUFHLGtDQUFBO0FBQUE7QUFBQSxJQUFBUCxZQUFBRCxLQUFBO0NBQUEsQ0FBQUMsWUFBQUQsSUFBQUcsU0FBQSwrQ0FBQUk7QUFBQTtBQUt6RCxPQUFPLE1BQU1FLFFBQVFYLGdCQUFnQixxQkFBcUIsQ0FBQyxDQUFDO0NBQzNEWSxXQUFTWDtDQUNUWSxtQkFBaUJKO0FBQ2xCLENBQUM7QUFBRSxNQUFBUCxNQUFBQyxZQUFBRDtBQUFBLElBQUFBLE9BQUEsT0FBQVksV0FBQTtDQUFBWixJQUFBRyxTQUFBO0NBQUEsTUFBQVUsa0JBQUFELE9BQUFFLGlDQUFBO0VBQUEsTUFBQUMscUJBQUEsSUFBQUMsSUFBQTtFQUFBLE1BQUFDLDRCQUFBTCxPQUFBTTtFQUFBTixPQUFBTSxtQ0FBQUMsUUFBQTtHQUFBLE1BQUFDLGlCQUFBSCw0QkFBQUUsR0FBQTtHQUFBLE1BQUFFLGdCQUFBTixtQkFBQU8sSUFBQUgsSUFBQUksRUFBQTtHQUFBLFdBQUFILGdCQUFBLEdBQUFDLGFBQUE7RUFBQTtFQUFBLFNBQUFOLG1CQUFBO0NBQUE7Q0FBQUYsZ0JBQUFFLG1CQUFBUyxJQUFBO0FBQUE7QUFBQSxnQkFBQUMsdUJBQUE7Q0FBQTtBQUFBOztBQUFBLElBQUF4QixZQUFBRCxLQUFBO0NBQUEsTUFBQUEsTUFBQUMsWUFBQUQ7Q0FBQSxNQUFBRSxVQUFBRixJQUFBRyxTQUFBO0NBQUEsTUFBQXVCLG9CQUFBLFNBQUFBLGtCQUFBQyxTQUFBQyxVQUFBO0VBQUEsTUFBQUMsU0FBQWpCLE9BQUFrQjtFQUFBLE1BQUFDLFdBQUFGLE9BQUFHLFdBQUFMO0VBQUEsS0FBQUksVUFBQTtFQUFBLE1BQUFFLDJCQUFBLElBQUFDLElBQUE7R0FBQTtHQUFBO0dBQUE7RUFBQTtFQUFBLE1BQUFDLHdCQUFBO0VBQUFGLHlCQUFBRyxTQUFBQyxRQUFBO0dBQUEsSUFBQUEsT0FBQU4sU0FBQU8sU0FBQUgsc0JBQUFFLE9BQUFOLFNBQUFPLFFBQUFEO0VBQUE7RUFBQSxNQUFBRSw0QkFBQSxvQkFBQVIsU0FBQU8sWUFBQSxvQkFBQVYsU0FBQVU7RUFBQSxNQUFBRSxnQkFBQTtHQUFBO0dBQUE7R0FBQTtHQUFBO0dBQUE7RUFBQTtFQUFBLElBQUFELDJCQUFBQyxjQUFBSixTQUFBQyxRQUFBO0dBQUEsSUFBQUEsT0FBQU4sU0FBQU8sV0FBQUQsT0FBQVQsU0FBQVUsU0FBQVYsU0FBQVUsUUFBQUQsT0FBQU4sU0FBQU8sUUFBQUQ7RUFBQTtFQUFBLE1BQUFJLGNBQUE7R0FBQSxHQUFBYixTQUFBVTtHQUFBLEdBQUFIO0VBQUE7RUFBQUosU0FBQU8sVUFBQUc7RUFBQVYsU0FBQVcsT0FBQUQsV0FBQTtFQUFBWixPQUFBYyxtQkFBQVosVUFBQUgsU0FBQWdCLE1BQUE7RUFBQWYsT0FBQWdCLFVBQUFoQixPQUFBaUIsZUFBQTtFQUFBQyxtQkFBQWhCLFFBQUE7RUFBQUYsT0FBQW1CLGlCQUFBQyxNQUFBO0VBQUFwQixPQUFBcUIsZ0JBQUE7RUFBQSxTQUFBSCxtQkFBQUksV0FBQTtHQUFBdkIsU0FBQVUsVUFBQWEsVUFBQWI7R0FBQVYsU0FBQXdCLGNBQUFELFVBQUFDO0dBQUF4QixTQUFBeUIsUUFBQUYsVUFBQUU7R0FBQXpCLFNBQUEwQixNQUFBSCxVQUFBRztHQUFBMUIsU0FBQTJCLFlBQUFKLFVBQUFJO0dBQUEzQixTQUFBNEIsTUFBQUwsVUFBQUs7RUFBQTtDQUFBO0NBQUEsTUFBQUMsaUJBQUEseUJBQUF2RCxRQUFBO0NBQUEsSUFBQXVELGdCQUFBO0VBQUF2RCxRQUFBLGtCQUFBdUQ7Q0FBQTtDQUFBLE1BQUFDLGdCQUFBLE9BQUE5QyxXQUFBLGVBQUE2QyxpQkFBQTdDLE9BQUFrQixnQkFBQUUsYUFBQXlCLGtCQUFBckQ7Q0FBQSxJQUFBcUQsa0JBQUFDLG1DQUFBakQsT0FBQTtFQUFBaUIsa0JBQUErQixnQkFBQWhELEtBQUE7RUFBQVAsUUFBQSw4QkFBQU87Q0FBQTtDQUFBVCxJQUFBMkQsUUFBQUMsY0FBQTtFQUFBLElBQUFuRCxTQUFBbUQsdUJBQUFuRCxPQUFBO0dBQUEsTUFBQWtCLFVBQUF6QixRQUFBO0dBQUEsSUFBQXlCLFNBQUE7SUFBQXpCLFFBQUEsa0JBQUF5QjtHQUFBO0dBQUEsSUFBQXpCLFFBQUEsZ0NBQUEwRCxVQUFBbkQsT0FBQTtJQUFBLE9BQUFQLFFBQUE7SUFBQTtHQUFBO0dBQUF3QixrQkFBQUMsU0FBQWlDLFVBQUFuRCxLQUFBO0VBQUE7Q0FBQTtBQUFBIiwibmFtZXMiOlsiY3JlYXRlRmlsZVJvdXRlIiwiVFNSU3BsaXRDb21wb25lbnQiLCJob3QiLCJpbXBvcnQiLCJob3REYXRhIiwiZGF0YSIsInVuZGVmaW5lZCIsImxhenlSb3V0ZUNvbXBvbmVudCIsIiQkc3BsaXRDb21wb25lbnRJbXBvcnRlciIsIlRTUlNwbGl0Tm90Rm91bmRDb21wb25lbnQiLCIkJHNwbGl0Tm90Rm91bmRDb21wb25lbnRJbXBvcnRlciIsIlJvdXRlIiwiY29tcG9uZW50Iiwibm90Rm91bmRDb21wb25lbnQiLCJ3aW5kb3ciLCJ0c3JSZWFjdFJlZnJlc2giLCJfX1RTUl9SRUFDVF9SRUZSRVNIX18iLCJpZ25vcmVkRXhwb3J0c0J5SWQiLCJNYXAiLCJwcmV2aW91c0dldElnbm9yZWRFeHBvcnRzIiwiX19nZXRSZWFjdFJlZnJlc2hJZ25vcmVkRXhwb3J0cyIsImN0eCIsImlnbm9yZWRFeHBvcnRzIiwibW9kdWxlSWdub3JlZCIsImdldCIsImlkIiwic2V0IiwiVFNSRmFzdFJlZnJlc2hBbmNob3IiLCJoYW5kbGVSb3V0ZVVwZGF0ZSIsInJvdXRlSWQiLCJuZXdSb3V0ZSIsInJvdXRlciIsIl9fVFNSX1JPVVRFUl9fIiwib2xkUm91dGUiLCJyb3V0ZXNCeUlkIiwiZ2VuZXJhdGVkUm91dGVPcHRpb25LZXlzIiwiU2V0IiwiZ2VuZXJhdGVkUm91dGVPcHRpb25zIiwiZm9yRWFjaCIsImtleSIsIm9wdGlvbnMiLCJwcmVzZXJ2ZUNvbXBvbmVudElkZW50aXR5IiwiY29tcG9uZW50S2V5cyIsIm5leHRPcHRpb25zIiwidXBkYXRlIiwiX3JlcGxhY2VSb3V0ZUNodW5rIiwibGF6eUZuIiwic2V0Um91dGVzIiwiYnVpbGRSb3V0ZVRyZWUiLCJzeW5jSG90Um91dGVFeHBvcnQiLCJyZXNvbHZlUGF0aENhY2hlIiwiY2xlYXIiLCJfcmVmcmVzaFJvdXRlIiwibGl2ZVJvdXRlIiwicGFyZW50Um91dGUiLCJfcGF0aCIsIl9pZCIsIl9mdWxsUGF0aCIsIl90byIsImluaXRpYWxSb3V0ZUlkIiwiZXhpc3RpbmdSb3V0ZSIsImFjY2VwdCIsIm5ld01vZHVsZSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJfYXV0aC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlRmlsZVJvdXRlIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1yb3V0ZXJcIjtcclxuaW1wb3J0IE5vdEZvdW5kIGZyb20gXCIjL2NvbXBvbmVudHMvTm90Rm91bmRcIjtcclxuaW1wb3J0IHsgT3JnU2lkZWJhciB9IGZyb20gXCIjL2NvbXBvbmVudHMvT3JnU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBSb3V0ZVRyYW5zaXRpb25MYXlvdXQgfSBmcm9tIFwiIy9jb21wb25lbnRzL1JvdXRlVHJhbnNpdGlvbkxheW91dFwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKFwiL29yZ2FuaXphdGlvbi9fYXV0aFwiKSh7XHJcblx0Y29tcG9uZW50OiBPcmdhbml6YXRpb25BdXRoTGF5b3V0LFxyXG5cdG5vdEZvdW5kQ29tcG9uZW50OiAoKSA9PiA8Tm90Rm91bmQgLz4sXHJcbn0pO1xyXG5cclxuZnVuY3Rpb24gT3JnYW5pemF0aW9uQXV0aExheW91dCgpIHtcclxuXHRyZXR1cm4gPFJvdXRlVHJhbnNpdGlvbkxheW91dCBzaWRlYmFyPXtPcmdTaWRlYmFyfSAvPjtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL3plbHRvL09uZURyaXZlL0RvY3VtZW50b3MvR2l0SHViL1hpdGlxdWVBcHBVSS9zcmMvcm91dGVzL29yZ2FuaXphdGlvbi9fYXV0aC50c3gifQ==