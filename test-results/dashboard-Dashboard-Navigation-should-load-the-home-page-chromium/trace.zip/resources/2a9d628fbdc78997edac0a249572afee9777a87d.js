const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];const ReactDOM = __vite__cjsImport1_reactDom_client;var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/main.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
;
(function __tsdConsolePipe() {
	// Detect environment
	var isServer = typeof window === "undefined";
	var envKey = isServer ? "__TSD_SERVER_CONSOLE_PIPE_INITIALIZED__" : "__TSD_CONSOLE_PIPE_INITIALIZED__";
	var globalObj = isServer ? globalThis : window;
	// Only run once per environment
	if (globalObj[envKey]) return;
	globalObj[envKey] = true;
	var CONSOLE_LEVELS = [
		"log",
		"warn",
		"error",
		"info",
		"debug"
	];
	var VITE_SERVER_URL = "http://localhost:4000";
	// Store original console methods before we override them
	var originalConsole = {};
	for (var i = 0; i < CONSOLE_LEVELS.length; i++) {
		var level = CONSOLE_LEVELS[i];
		originalConsole[level] = console[level].bind(console);
	}
	// Simple inline batcher implementation
	var batchedEntries = [];
	var batchTimeout = null;
	var BATCH_WAIT = isServer ? 50 : 100;
	var BATCH_MAX_SIZE = isServer ? 20 : 50;
	function flushBatch() {
		if (batchedEntries.length === 0) return;
		var entries = batchedEntries;
		batchedEntries = [];
		batchTimeout = null;
		// Determine endpoint based on environment
		var endpoint = isServer ? VITE_SERVER_URL + "/__tsd/console-pipe/server" : "/__tsd/console-pipe";
		// Send to Vite server via fetch
		fetch(endpoint, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ entries })
		}).catch(function() {
			// Swallow errors  
		});
	}
	function addToBatch(entry) {
		batchedEntries.push(entry);
		if (batchedEntries.length >= BATCH_MAX_SIZE) {
			if (batchTimeout) {
				clearTimeout(batchTimeout);
				batchTimeout = null;
			}
			flushBatch();
		} else if (!batchTimeout) {
			batchTimeout = setTimeout(flushBatch, BATCH_WAIT);
		}
	}
	var MAX_DEPTH = 6;
	var MAX_ARRAY_LEN = 100;
	var MAX_OBJECT_KEYS = 100;
	var MAX_STRING_LENGTH = 1e4;
	function truncateString(value) {
		if (value.length <= MAX_STRING_LENGTH) return value;
		return value.slice(0, MAX_STRING_LENGTH) + "... (" + (value.length - MAX_STRING_LENGTH) + " more chars)";
	}
	function formatDomElement(element) {
		var tagName = element.tagName ? element.tagName.toLowerCase() : "element";
		var output = "<" + tagName;
		var attrs = [
			"id",
			"class",
			"name",
			"type",
			"role",
			"aria-label",
			"data-testid"
		];
		for (var attrIndex = 0; attrIndex < attrs.length; attrIndex++) {
			var attrName = attrs[attrIndex];
			var attrValue = element.getAttribute && element.getAttribute(attrName);
			if (attrValue) {
				output += " " + attrName + "=\"" + truncateString(String(attrValue)).replace(/"/g, "&quot;") + "\"";
			}
		}
		return output + ">";
	}
	function getObjectTypeName(arg) {
		return arg && arg.constructor && arg.constructor.name ? arg.constructor.name : "Object";
	}
	function formatArrayBufferView(arg) {
		var length = typeof arg.length === "number" ? arg.length : arg.byteLength;
		return "[" + getObjectTypeName(arg) + "(" + length + ")]";
	}
	function serializeConsoleArg(arg, seen, depth) {
		if (depth === undefined) depth = 0;
		if (arg === undefined) return "undefined";
		if (arg === null) return null;
		var argType = typeof arg;
		if (argType === "function") return "[Function" + (arg.name ? ": " + arg.name : "") + "]";
		if (argType === "symbol") return arg.toString();
		if (argType === "bigint") return arg.toString() + "n";
		if (argType === "string") return truncateString(arg);
		if (argType !== "object") return arg;
		if (!isServer) {
			if (arg.nodeType === 1 && typeof arg.tagName === "string" && typeof arg.getAttribute === "function") {
				return formatDomElement(arg);
			}
			if (arg.nodeType === 9) {
				return "[Document]";
			}
			if (typeof Window !== "undefined" && arg instanceof Window) {
				return "[Window]";
			}
			if (typeof Event !== "undefined" && arg instanceof Event) {
				return {
					type: arg.type,
					target: serializeConsoleArg(arg.target, seen, depth + 1),
					currentTarget: serializeConsoleArg(arg.currentTarget, seen, depth + 1),
					defaultPrevented: arg.defaultPrevented
				};
			}
			if (typeof Node !== "undefined" && arg instanceof Node) {
				return "[Node: " + arg.nodeName + "]";
			}
		}
		if (arg instanceof Error) {
			return {
				name: arg.name,
				message: truncateString(arg.message),
				stack: arg.stack ? truncateString(arg.stack) : arg.stack
			};
		}
		if (arg instanceof Date) {
			return arg.toISOString();
		}
		if (arg instanceof RegExp) {
			return arg.toString();
		}
		if (typeof ArrayBuffer !== "undefined") {
			if (ArrayBuffer.isView && ArrayBuffer.isView(arg)) {
				return formatArrayBufferView(arg);
			}
			if (arg instanceof ArrayBuffer) {
				return "[ArrayBuffer(" + arg.byteLength + ")]";
			}
		}
		if (typeof SharedArrayBuffer !== "undefined" && arg instanceof SharedArrayBuffer) {
			return "[SharedArrayBuffer(" + arg.byteLength + ")]";
		}
		if (depth >= MAX_DEPTH) {
			return "[MaxDepth]";
		}
		if (seen.indexOf(arg) !== -1) {
			return "[Circular]";
		}
		seen.push(arg);
		if (Array.isArray(arg)) {
			var arrayResult = [];
			var arrayLength = Math.min(arg.length, MAX_ARRAY_LEN);
			for (var arrayIndex = 0; arrayIndex < arrayLength; arrayIndex++) {
				arrayResult.push(serializeConsoleArg(arg[arrayIndex], seen, depth + 1));
			}
			if (arg.length > MAX_ARRAY_LEN) {
				arrayResult.push("... (" + (arg.length - MAX_ARRAY_LEN) + " more)");
			}
			seen.pop();
			return arrayResult;
		}
		var objectResult = {};
		var keys = Object.keys(arg);
		var keyLength = Math.min(keys.length, MAX_OBJECT_KEYS);
		for (var keyIndex = 0; keyIndex < keyLength; keyIndex++) {
			var key = keys[keyIndex];
			try {
				objectResult[key] = serializeConsoleArg(arg[key], seen, depth + 1);
			} catch (error) {
				objectResult[key] = "[Thrown: " + String(error) + "]";
			}
		}
		if (keys.length > MAX_OBJECT_KEYS) {
			objectResult["..."] = "(" + (keys.length - MAX_OBJECT_KEYS) + " more keys)";
		}
		seen.pop();
		return objectResult;
	}
	// Override global console methods
	for (var j = 0; j < CONSOLE_LEVELS.length; j++) {
		(function(level) {
			var original = originalConsole[level];
			console[level] = function() {
				var args = Array.prototype.slice.call(arguments);
				// Always call original first so logs appear normally
				original.apply(console, args);
				// Skip our own TSD Console Pipe logs to avoid recursion/noise
				if (args.length > 0 && typeof args[0] === "string" && (args[0].indexOf("[TSD Console Pipe]") !== -1 || args[0].indexOf("[@tanstack/devtools") !== -1)) {
					return;
				}
				var safeArgs = args.map(function(arg) {
					try {
						return serializeConsoleArg(arg, [], 0);
					} catch (e) {
						return String(arg);
					}
				});
				var entry = {
					level,
					args: safeArgs,
					source: isServer ? "server" : "client",
					timestamp: Date.now()
				};
				addToBatch(entry);
			};
		})(CONSOLE_LEVELS[j]);
	}
	// CLIENT ONLY: Listen for server console logs via SSE
	if (!isServer) {
		// Transform server log args - strip ANSI codes and convert source paths to clickable URLs
		function transformServerLogArgs(args) {
			var escChar = String.fromCharCode(27);
			var transformed = [];
			for (var k = 0; k < args.length; k++) {
				var arg = args[k];
				if (typeof arg === "string") {
					// Strip ANSI escape sequences (ESC[...m patterns)
					var cleaned = arg;
					// Remove ESC character followed by [...m] - need to build regex dynamically
					while (cleaned.indexOf(escChar) !== -1) {
						cleaned = cleaned.split(escChar).join("");
					}
					// Also remove any leftover bracket codes like [35m
					cleaned = cleaned.replace(/\[[0-9;]*m/g, "");
					// Transform source paths to clickable URLs
					// Match patterns like /src/components/Header.tsx:17:3
					var sourceRegex = /(\/[^\s]+:\d+:\d+)/g;
					cleaned = cleaned.replace(sourceRegex, function(match) {
						return window.location.origin + "/__tsd/open-source?source=" + encodeURIComponent(match);
					});
					if (cleaned.trim()) {
						transformed.push(cleaned);
					}
				} else {
					transformed.push(arg);
				}
			}
			return transformed;
		}
		var eventSource = new EventSource("/__tsd/console-pipe/sse");
		eventSource.onmessage = function(event) {
			try {
				var data = JSON.parse(event.data);
				if (data.entries) {
					for (var m = 0; m < data.entries.length; m++) {
						var entry = data.entries[m];
						var transformedArgs = transformServerLogArgs(entry.args);
						var prefix = "%c[Server]%c";
						var prefixStyle = "color: #9333ea; font-weight: bold;";
						var resetStyle = "color: inherit;";
						var logMethod = originalConsole[entry.level] || originalConsole.log;
						logMethod.apply(console, [
							prefix,
							prefixStyle,
							resetStyle
						].concat(transformedArgs));
					}
				}
			} catch (err) {}
		};
		eventSource.onerror = function() {
			// Swallow errors  
		};
		// Flush on page unload
		window.addEventListener("beforeunload", flushBatch);
	}
})();
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=03f72e91";
import "/node_modules/.pnpm/ldrs@1.1.9/node_modules/ldrs/dist/react/Ring2.css";
import { RouterProvider } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=03f72e91";
import { getRouter } from "/src/router.tsx";
import "/src/styles.css";
const router = getRouter();
const rootElement = document.getElementById("app");
if (!rootElement) {
	throw new Error("Root element #app was not found.");
}
if (!rootElement.innerHTML) {
	const root = ReactDOM.createRoot(rootElement);
	root.render(/* @__PURE__ */ _jsxDEV(RouterProvider, { router }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 328,
		columnNumber: 14
	}, this));
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFDQTtDQUFFLFNBQVMsbUJBQW1COztDQUU1QixJQUFJLFdBQVcsT0FBTyxXQUFXO0NBQ2pDLElBQUksU0FBUyxXQUFXLDRDQUE0QztDQUNwRSxJQUFJLFlBQVksV0FBVyxhQUFhOztDQUd4QyxJQUFJLFVBQVUsU0FBUztDQUN2QixVQUFVLFVBQVU7Q0FFcEIsSUFBSSxpQkFBaUI7RUFBQztFQUFNO0VBQU87RUFBUTtFQUFPO0NBQU87Q0FDekQsSUFBSSxrQkFBa0I7O0NBR3RCLElBQUksa0JBQWtCLENBQUM7Q0FDdkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGVBQWUsUUFBUSxLQUFLO0VBQzlDLElBQUksUUFBUSxlQUFlO0VBQzNCLGdCQUFnQixTQUFTLFFBQVEsTUFBTSxDQUFDLEtBQUssT0FBTztDQUN0RDs7Q0FHQSxJQUFJLGlCQUFpQixDQUFDO0NBQ3RCLElBQUksZUFBZTtDQUNuQixJQUFJLGFBQWEsV0FBVyxLQUFLO0NBQ2pDLElBQUksaUJBQWlCLFdBQVcsS0FBSztDQUVyQyxTQUFTLGFBQWE7RUFDcEIsSUFBSSxlQUFlLFdBQVcsR0FBRztFQUVqQyxJQUFJLFVBQVU7RUFDZCxpQkFBaUIsQ0FBQztFQUNsQixlQUFlOztFQUdmLElBQUksV0FBVyxXQUNYLGtCQUFrQiwrQkFDbEI7O0VBR0osTUFBTSxVQUFVO0dBQ2QsUUFBUTtHQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0dBQzlDLE1BQU0sS0FBSyxVQUFVLEVBQVcsUUFBUSxDQUFDO0VBQzNDLENBQUMsQ0FBQyxDQUFDLE1BQU0sV0FBWTs7RUFFckIsQ0FBQztDQUNIO0NBRUEsU0FBUyxXQUFXLE9BQU87RUFDekIsZUFBZSxLQUFLLEtBQUs7RUFFekIsSUFBSSxlQUFlLFVBQVUsZ0JBQWdCO0dBQzNDLElBQUksY0FBYztJQUNoQixhQUFhLFlBQVk7SUFDekIsZUFBZTtHQUNqQjtHQUNBLFdBQVc7RUFDYixPQUFPLElBQUksQ0FBQyxjQUFjO0dBQ3hCLGVBQWUsV0FBVyxZQUFZLFVBQVU7RUFDbEQ7Q0FDRjtDQUVBLElBQUksWUFBWTtDQUNoQixJQUFJLGdCQUFnQjtDQUNwQixJQUFJLGtCQUFrQjtDQUN0QixJQUFJLG9CQUFvQjtDQUV4QixTQUFTLGVBQWUsT0FBTztFQUM3QixJQUFJLE1BQU0sVUFBVSxtQkFBbUIsT0FBTztFQUM5QyxPQUFPLE1BQU0sTUFBTSxHQUFHLGlCQUFpQixJQUFJLFdBQVcsTUFBTSxTQUFTLHFCQUFxQjtDQUM1RjtDQUVBLFNBQVMsaUJBQWlCLFNBQVM7RUFDakMsSUFBSSxVQUFVLFFBQVEsVUFBVSxRQUFRLFFBQVEsWUFBWSxJQUFJO0VBQ2hFLElBQUksU0FBUyxNQUFNO0VBQ25CLElBQUksUUFBUTtHQUFDO0dBQU07R0FBUztHQUFRO0dBQVE7R0FBUTtHQUFjO0VBQWE7RUFFL0UsS0FBSyxJQUFJLFlBQVksR0FBRyxZQUFZLE1BQU0sUUFBUSxhQUFhO0dBQzdELElBQUksV0FBVyxNQUFNO0dBQ3JCLElBQUksWUFBWSxRQUFRLGdCQUFnQixRQUFRLGFBQWEsUUFBUTtHQUNyRSxJQUFJLFdBQVc7SUFDYixVQUFVLE1BQU0sV0FBVyxRQUFPLGVBQWUsT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLFFBQVEsTUFBTSxRQUFRLElBQUk7R0FDaEc7RUFDRjtFQUVBLE9BQU8sU0FBUztDQUNsQjtDQUVBLFNBQVMsa0JBQWtCLEtBQUs7RUFDOUIsT0FBTyxPQUFPLElBQUksZUFBZSxJQUFJLFlBQVksT0FBTyxJQUFJLFlBQVksT0FBTztDQUNqRjtDQUVBLFNBQVMsc0JBQXNCLEtBQUs7RUFDbEMsSUFBSSxTQUFTLE9BQU8sSUFBSSxXQUFXLFdBQVcsSUFBSSxTQUFTLElBQUk7RUFDL0QsT0FBTyxNQUFNLGtCQUFrQixHQUFHLElBQUksTUFBTSxTQUFTO0NBQ3ZEO0NBRUEsU0FBUyxvQkFBb0IsS0FBSyxNQUFNLE9BQU87RUFDN0MsSUFBSSxVQUFVLFdBQVcsUUFBUTtFQUNqQyxJQUFJLFFBQVEsV0FBVyxPQUFPO0VBQzlCLElBQUksUUFBUSxNQUFNLE9BQU87RUFFekIsSUFBSSxVQUFVLE9BQU87RUFFckIsSUFBSSxZQUFZLFlBQVksT0FBTyxlQUFlLElBQUksT0FBTyxPQUFPLElBQUksT0FBTyxNQUFNO0VBQ3JGLElBQUksWUFBWSxVQUFVLE9BQU8sSUFBSSxTQUFTO0VBQzlDLElBQUksWUFBWSxVQUFVLE9BQU8sSUFBSSxTQUFTLElBQUk7RUFDbEQsSUFBSSxZQUFZLFVBQVUsT0FBTyxlQUFlLEdBQUc7RUFDbkQsSUFBSSxZQUFZLFVBQVUsT0FBTztFQUVqQyxJQUFJLENBQUMsVUFBVTtHQUNiLElBQ0UsSUFBSSxhQUFhLEtBQ2pCLE9BQU8sSUFBSSxZQUFZLFlBQ3ZCLE9BQU8sSUFBSSxpQkFBaUIsWUFDNUI7SUFDQSxPQUFPLGlCQUFpQixHQUFHO0dBQzdCO0dBQ0EsSUFBSSxJQUFJLGFBQWEsR0FBRztJQUN0QixPQUFPO0dBQ1Q7R0FDQSxJQUFJLE9BQU8sV0FBVyxlQUFlLGVBQWUsUUFBUTtJQUMxRCxPQUFPO0dBQ1Q7R0FDQSxJQUFJLE9BQU8sVUFBVSxlQUFlLGVBQWUsT0FBTztJQUN4RCxPQUFPO0tBQ0wsTUFBTSxJQUFJO0tBQ1YsUUFBUSxvQkFBb0IsSUFBSSxRQUFRLE1BQU0sUUFBUSxDQUFDO0tBQ3ZELGVBQWUsb0JBQW9CLElBQUksZUFBZSxNQUFNLFFBQVEsQ0FBQztLQUNyRSxrQkFBa0IsSUFBSTtJQUN4QjtHQUNGO0dBQ0EsSUFBSSxPQUFPLFNBQVMsZUFBZSxlQUFlLE1BQU07SUFDdEQsT0FBTyxZQUFZLElBQUksV0FBVztHQUNwQztFQUNGO0VBRUEsSUFBSSxlQUFlLE9BQU87R0FDeEIsT0FBTztJQUNMLE1BQU0sSUFBSTtJQUNWLFNBQVMsZUFBZSxJQUFJLE9BQU87SUFDbkMsT0FBTyxJQUFJLFFBQVEsZUFBZSxJQUFJLEtBQUssSUFBSSxJQUFJO0dBQ3JEO0VBQ0Y7RUFFQSxJQUFJLGVBQWUsTUFBTTtHQUN2QixPQUFPLElBQUksWUFBWTtFQUN6QjtFQUVBLElBQUksZUFBZSxRQUFRO0dBQ3pCLE9BQU8sSUFBSSxTQUFTO0VBQ3RCO0VBRUEsSUFBSSxPQUFPLGdCQUFnQixhQUFhO0dBQ3RDLElBQUksWUFBWSxVQUFVLFlBQVksT0FBTyxHQUFHLEdBQUc7SUFDakQsT0FBTyxzQkFBc0IsR0FBRztHQUNsQztHQUNBLElBQUksZUFBZSxhQUFhO0lBQzlCLE9BQU8sa0JBQWtCLElBQUksYUFBYTtHQUM1QztFQUNGO0VBRUEsSUFBSSxPQUFPLHNCQUFzQixlQUFlLGVBQWUsbUJBQW1CO0dBQ2hGLE9BQU8sd0JBQXdCLElBQUksYUFBYTtFQUNsRDtFQUVBLElBQUksU0FBUyxXQUFXO0dBQ3RCLE9BQU87RUFDVDtFQUVBLElBQUksS0FBSyxRQUFRLEdBQUcsTUFBTSxDQUFDLEdBQUc7R0FDNUIsT0FBTztFQUNUO0VBRUEsS0FBSyxLQUFLLEdBQUc7RUFFYixJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7R0FDdEIsSUFBSSxjQUFjLENBQUM7R0FDbkIsSUFBSSxjQUFjLEtBQUssSUFBSSxJQUFJLFFBQVEsYUFBYTtHQUNwRCxLQUFLLElBQUksYUFBYSxHQUFHLGFBQWEsYUFBYSxjQUFjO0lBQy9ELFlBQVksS0FBSyxvQkFBb0IsSUFBSSxhQUFhLE1BQU0sUUFBUSxDQUFDLENBQUM7R0FDeEU7R0FDQSxJQUFJLElBQUksU0FBUyxlQUFlO0lBQzlCLFlBQVksS0FBSyxXQUFXLElBQUksU0FBUyxpQkFBaUIsUUFBUTtHQUNwRTtHQUNBLEtBQUssSUFBSTtHQUNULE9BQU87RUFDVDtFQUVBLElBQUksZUFBZSxDQUFDO0VBQ3BCLElBQUksT0FBTyxPQUFPLEtBQUssR0FBRztFQUMxQixJQUFJLFlBQVksS0FBSyxJQUFJLEtBQUssUUFBUSxlQUFlO0VBQ3JELEtBQUssSUFBSSxXQUFXLEdBQUcsV0FBVyxXQUFXLFlBQVk7R0FDdkQsSUFBSSxNQUFNLEtBQUs7R0FDZixJQUFJO0lBQ0YsYUFBYSxPQUFPLG9CQUFvQixJQUFJLE1BQU0sTUFBTSxRQUFRLENBQUM7R0FDbkUsU0FBUyxPQUFPO0lBQ2QsYUFBYSxPQUFPLGNBQWMsT0FBTyxLQUFLLElBQUk7R0FDcEQ7RUFDRjtFQUNBLElBQUksS0FBSyxTQUFTLGlCQUFpQjtHQUNqQyxhQUFhLFNBQVMsT0FBTyxLQUFLLFNBQVMsbUJBQW1CO0VBQ2hFO0VBQ0EsS0FBSyxJQUFJO0VBQ1QsT0FBTztDQUNUOztDQUdBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxlQUFlLFFBQVEsS0FBSztFQUM5QyxDQUFDLFNBQVMsT0FBTztHQUNmLElBQUksV0FBVyxnQkFBZ0I7R0FDL0IsUUFBUSxTQUFTLFdBQVc7SUFDMUIsSUFBSSxPQUFPLE1BQU0sVUFBVSxNQUFNLEtBQUssU0FBUzs7SUFHL0MsU0FBUyxNQUFNLFNBQVMsSUFBSTs7SUFHNUIsSUFBSSxLQUFLLFNBQVMsS0FBSyxPQUFPLEtBQUssT0FBTyxhQUNyQyxLQUFLLEVBQUUsQ0FBQyxRQUFRLG9CQUFvQixNQUFNLENBQUMsS0FDM0MsS0FBSyxFQUFFLENBQUMsUUFBUSxxQkFBcUIsTUFBTSxDQUFDLElBQUk7S0FDbkQ7SUFDRjtJQUVBLElBQUksV0FBVyxLQUFLLElBQUksU0FBUyxLQUFLO0tBQ3BDLElBQUk7TUFDRixPQUFPLG9CQUFvQixLQUFLLENBQUMsR0FBRyxDQUFDO0tBQ3ZDLFNBQVMsR0FBRztNQUNWLE9BQU8sT0FBTyxHQUFHO0tBQ25CO0lBQ0YsQ0FBQztJQUVELElBQUksUUFBUTtLQUNIO0tBQ1AsTUFBTTtLQUNOLFFBQVEsV0FBVyxXQUFXO0tBQzlCLFdBQVcsS0FBSyxJQUFJO0lBQ3RCO0lBRUEsV0FBVyxLQUFLO0dBQ2xCO0VBQ0YsRUFBQyxDQUFFLGVBQWUsRUFBRTtDQUN0Qjs7Q0FHQSxJQUFJLENBQUMsVUFBVTs7RUFFYixTQUFTLHVCQUF1QixNQUFNO0dBQ3BDLElBQUksVUFBVSxPQUFPLGFBQWEsRUFBRTtHQUNwQyxJQUFJLGNBQWMsQ0FBQztHQUVuQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUs7SUFDcEMsSUFBSSxNQUFNLEtBQUs7SUFDZixJQUFJLE9BQU8sUUFBUSxVQUFVOztLQUUzQixJQUFJLFVBQVU7O0tBRWQsT0FBTyxRQUFRLFFBQVEsT0FBTyxNQUFNLENBQUMsR0FBRztNQUN0QyxVQUFVLFFBQVEsTUFBTSxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUU7S0FDMUM7O0tBRUEsVUFBVSxRQUFRLFFBQVEsZUFBZSxFQUFFOzs7S0FJM0MsSUFBSSxjQUFjO0tBQ2xCLFVBQVUsUUFBUSxRQUFRLGFBQWEsU0FBUyxPQUFPO01BQ3JELE9BQU8sT0FBTyxTQUFTLFNBQVMsK0JBQStCLG1CQUFtQixLQUFLO0tBQ3pGLENBQUM7S0FFRCxJQUFJLFFBQVEsS0FBSyxHQUFHO01BQ2xCLFlBQVksS0FBSyxPQUFPO0tBQzFCO0lBQ0YsT0FBTztLQUNMLFlBQVksS0FBSyxHQUFHO0lBQ3RCO0dBQ0Y7R0FFQSxPQUFPO0VBQ1Q7RUFFQSxJQUFJLGNBQWMsSUFBSSxZQUFZLHlCQUF5QjtFQUUzRCxZQUFZLFlBQVksU0FBUyxPQUFPO0dBQ3RDLElBQUk7SUFDRixJQUFJLE9BQU8sS0FBSyxNQUFNLE1BQU0sSUFBSTtJQUNoQyxJQUFJLEtBQUssU0FBUztLQUNoQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLFFBQVEsS0FBSztNQUM1QyxJQUFJLFFBQVEsS0FBSyxRQUFRO01BQ3pCLElBQUksa0JBQWtCLHVCQUF1QixNQUFNLElBQUk7TUFDdkQsSUFBSSxTQUFTO01BQ2IsSUFBSSxjQUFjO01BQ2xCLElBQUksYUFBYTtNQUNqQixJQUFJLFlBQVksZ0JBQWdCLE1BQU0sVUFBVSxnQkFBZ0I7TUFDaEUsVUFBVSxNQUFNLFNBQVM7T0FBQztPQUFRO09BQWE7TUFBVSxDQUFDLENBQUMsT0FBTyxlQUFlLENBQUM7S0FDcEY7SUFDRjtHQUNGLFNBQVMsS0FBSyxDQUVkO0VBQ0Y7RUFFQSxZQUFZLFVBQVUsV0FBVzs7RUFFakM7O0VBR0EsT0FBTyxpQkFBaUIsZ0JBQWdCLFVBQVU7Q0FDcEQ7QUFDRixFQUFDLENBQUU7QUFFSCxPQUFPLGNBQWM7QUFDckIsT0FBTztBQUNQLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsaUJBQWlCO0FBQzFCLE9BQU87QUFFUCxNQUFNLFNBQVMsVUFBVTtBQUN6QixNQUFNLGNBQWMsU0FBUyxlQUFlLEtBQUs7QUFFakQsSUFBSSxDQUFDLGFBQWE7Q0FDakIsTUFBTSxJQUFJLE1BQU0sa0NBQWtDO0FBQ25EO0FBRUEsSUFBSSxDQUFDLFlBQVksV0FBVztDQUMzQixNQUFNLE9BQU8sU0FBUyxXQUFXLFdBQVc7Q0FDNUMsS0FBSyxPQUFPLHdCQUFDLGdCQUFELEVBQXdCLE9BQVM7Ozs7U0FBQztBQUMvQyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJtYWluLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJcbjsoZnVuY3Rpb24gX190c2RDb25zb2xlUGlwZSgpIHtcbiAgLy8gRGV0ZWN0IGVudmlyb25tZW50XG4gIHZhciBpc1NlcnZlciA9IHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnO1xuICB2YXIgZW52S2V5ID0gaXNTZXJ2ZXIgPyAnX19UU0RfU0VSVkVSX0NPTlNPTEVfUElQRV9JTklUSUFMSVpFRF9fJyA6ICdfX1RTRF9DT05TT0xFX1BJUEVfSU5JVElBTElaRURfXyc7XG4gIHZhciBnbG9iYWxPYmogPSBpc1NlcnZlciA/IGdsb2JhbFRoaXMgOiB3aW5kb3c7XG4gIFxuICAvLyBPbmx5IHJ1biBvbmNlIHBlciBlbnZpcm9ubWVudFxuICBpZiAoZ2xvYmFsT2JqW2VudktleV0pIHJldHVybjtcbiAgZ2xvYmFsT2JqW2VudktleV0gPSB0cnVlO1xuXG4gIHZhciBDT05TT0xFX0xFVkVMUyA9IFtcImxvZ1wiLFwid2FyblwiLFwiZXJyb3JcIixcImluZm9cIixcImRlYnVnXCJdO1xuICB2YXIgVklURV9TRVJWRVJfVVJMID0gXCJodHRwOi8vbG9jYWxob3N0OjQwMDBcIjtcblxuICAvLyBTdG9yZSBvcmlnaW5hbCBjb25zb2xlIG1ldGhvZHMgYmVmb3JlIHdlIG92ZXJyaWRlIHRoZW1cbiAgdmFyIG9yaWdpbmFsQ29uc29sZSA9IHt9O1xuICBmb3IgKHZhciBpID0gMDsgaSA8IENPTlNPTEVfTEVWRUxTLmxlbmd0aDsgaSsrKSB7XG4gICAgdmFyIGxldmVsID0gQ09OU09MRV9MRVZFTFNbaV07XG4gICAgb3JpZ2luYWxDb25zb2xlW2xldmVsXSA9IGNvbnNvbGVbbGV2ZWxdLmJpbmQoY29uc29sZSk7XG4gIH1cblxuICAvLyBTaW1wbGUgaW5saW5lIGJhdGNoZXIgaW1wbGVtZW50YXRpb25cbiAgdmFyIGJhdGNoZWRFbnRyaWVzID0gW107XG4gIHZhciBiYXRjaFRpbWVvdXQgPSBudWxsO1xuICB2YXIgQkFUQ0hfV0FJVCA9IGlzU2VydmVyID8gNTAgOiAxMDA7XG4gIHZhciBCQVRDSF9NQVhfU0laRSA9IGlzU2VydmVyID8gMjAgOiA1MDtcblxuICBmdW5jdGlvbiBmbHVzaEJhdGNoKCkge1xuICAgIGlmIChiYXRjaGVkRW50cmllcy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgICBcbiAgICB2YXIgZW50cmllcyA9IGJhdGNoZWRFbnRyaWVzO1xuICAgIGJhdGNoZWRFbnRyaWVzID0gW107XG4gICAgYmF0Y2hUaW1lb3V0ID0gbnVsbDtcbiAgICBcbiAgICAvLyBEZXRlcm1pbmUgZW5kcG9pbnQgYmFzZWQgb24gZW52aXJvbm1lbnRcbiAgICB2YXIgZW5kcG9pbnQgPSBpc1NlcnZlciBcbiAgICAgID8gVklURV9TRVJWRVJfVVJMICsgJy9fX3RzZC9jb25zb2xlLXBpcGUvc2VydmVyJ1xuICAgICAgOiAnL19fdHNkL2NvbnNvbGUtcGlwZSc7XG4gICAgXG4gICAgLy8gU2VuZCB0byBWaXRlIHNlcnZlciB2aWEgZmV0Y2hcbiAgICBmZXRjaChlbmRwb2ludCwge1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgZW50cmllczogZW50cmllcyB9KSxcbiAgICB9KS5jYXRjaChmdW5jdGlvbiggKSB7XG4gICAgIC8vIFN3YWxsb3cgZXJyb3JzICBcbiAgICB9KTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGFkZFRvQmF0Y2goZW50cnkpIHtcbiAgICBiYXRjaGVkRW50cmllcy5wdXNoKGVudHJ5KTtcbiAgICBcbiAgICBpZiAoYmF0Y2hlZEVudHJpZXMubGVuZ3RoID49IEJBVENIX01BWF9TSVpFKSB7XG4gICAgICBpZiAoYmF0Y2hUaW1lb3V0KSB7XG4gICAgICAgIGNsZWFyVGltZW91dChiYXRjaFRpbWVvdXQpO1xuICAgICAgICBiYXRjaFRpbWVvdXQgPSBudWxsO1xuICAgICAgfVxuICAgICAgZmx1c2hCYXRjaCgpO1xuICAgIH0gZWxzZSBpZiAoIWJhdGNoVGltZW91dCkge1xuICAgICAgYmF0Y2hUaW1lb3V0ID0gc2V0VGltZW91dChmbHVzaEJhdGNoLCBCQVRDSF9XQUlUKTtcbiAgICB9XG4gIH1cblxuICB2YXIgTUFYX0RFUFRIID0gNjtcbiAgdmFyIE1BWF9BUlJBWV9MRU4gPSAxMDA7XG4gIHZhciBNQVhfT0JKRUNUX0tFWVMgPSAxMDA7XG4gIHZhciBNQVhfU1RSSU5HX0xFTkdUSCA9IDEwMDAwO1xuXG4gIGZ1bmN0aW9uIHRydW5jYXRlU3RyaW5nKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlLmxlbmd0aCA8PSBNQVhfU1RSSU5HX0xFTkdUSCkgcmV0dXJuIHZhbHVlO1xuICAgIHJldHVybiB2YWx1ZS5zbGljZSgwLCBNQVhfU1RSSU5HX0xFTkdUSCkgKyAnLi4uICgnICsgKHZhbHVlLmxlbmd0aCAtIE1BWF9TVFJJTkdfTEVOR1RIKSArICcgbW9yZSBjaGFycyknO1xuICB9XG5cbiAgZnVuY3Rpb24gZm9ybWF0RG9tRWxlbWVudChlbGVtZW50KSB7XG4gICAgdmFyIHRhZ05hbWUgPSBlbGVtZW50LnRhZ05hbWUgPyBlbGVtZW50LnRhZ05hbWUudG9Mb3dlckNhc2UoKSA6ICdlbGVtZW50JztcbiAgICB2YXIgb3V0cHV0ID0gJzwnICsgdGFnTmFtZTtcbiAgICB2YXIgYXR0cnMgPSBbJ2lkJywgJ2NsYXNzJywgJ25hbWUnLCAndHlwZScsICdyb2xlJywgJ2FyaWEtbGFiZWwnLCAnZGF0YS10ZXN0aWQnXTtcblxuICAgIGZvciAodmFyIGF0dHJJbmRleCA9IDA7IGF0dHJJbmRleCA8IGF0dHJzLmxlbmd0aDsgYXR0ckluZGV4KyspIHtcbiAgICAgIHZhciBhdHRyTmFtZSA9IGF0dHJzW2F0dHJJbmRleF07XG4gICAgICB2YXIgYXR0clZhbHVlID0gZWxlbWVudC5nZXRBdHRyaWJ1dGUgJiYgZWxlbWVudC5nZXRBdHRyaWJ1dGUoYXR0ck5hbWUpO1xuICAgICAgaWYgKGF0dHJWYWx1ZSkge1xuICAgICAgICBvdXRwdXQgKz0gJyAnICsgYXR0ck5hbWUgKyAnPVwiJyArIHRydW5jYXRlU3RyaW5nKFN0cmluZyhhdHRyVmFsdWUpKS5yZXBsYWNlKC9cIi9nLCAnJnF1b3Q7JykgKyAnXCInO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBvdXRwdXQgKyAnPic7XG4gIH1cblxuICBmdW5jdGlvbiBnZXRPYmplY3RUeXBlTmFtZShhcmcpIHtcbiAgICByZXR1cm4gYXJnICYmIGFyZy5jb25zdHJ1Y3RvciAmJiBhcmcuY29uc3RydWN0b3IubmFtZSA/IGFyZy5jb25zdHJ1Y3Rvci5uYW1lIDogJ09iamVjdCc7XG4gIH1cblxuICBmdW5jdGlvbiBmb3JtYXRBcnJheUJ1ZmZlclZpZXcoYXJnKSB7XG4gICAgdmFyIGxlbmd0aCA9IHR5cGVvZiBhcmcubGVuZ3RoID09PSAnbnVtYmVyJyA/IGFyZy5sZW5ndGggOiBhcmcuYnl0ZUxlbmd0aDtcbiAgICByZXR1cm4gJ1snICsgZ2V0T2JqZWN0VHlwZU5hbWUoYXJnKSArICcoJyArIGxlbmd0aCArICcpXSc7XG4gIH1cblxuICBmdW5jdGlvbiBzZXJpYWxpemVDb25zb2xlQXJnKGFyZywgc2VlbiwgZGVwdGgpIHtcbiAgICBpZiAoZGVwdGggPT09IHVuZGVmaW5lZCkgZGVwdGggPSAwO1xuICAgIGlmIChhcmcgPT09IHVuZGVmaW5lZCkgcmV0dXJuICd1bmRlZmluZWQnO1xuICAgIGlmIChhcmcgPT09IG51bGwpIHJldHVybiBudWxsO1xuXG4gICAgdmFyIGFyZ1R5cGUgPSB0eXBlb2YgYXJnO1xuXG4gICAgaWYgKGFyZ1R5cGUgPT09ICdmdW5jdGlvbicpIHJldHVybiAnW0Z1bmN0aW9uJyArIChhcmcubmFtZSA/ICc6ICcgKyBhcmcubmFtZSA6ICcnKSArICddJztcbiAgICBpZiAoYXJnVHlwZSA9PT0gJ3N5bWJvbCcpIHJldHVybiBhcmcudG9TdHJpbmcoKTtcbiAgICBpZiAoYXJnVHlwZSA9PT0gJ2JpZ2ludCcpIHJldHVybiBhcmcudG9TdHJpbmcoKSArICduJztcbiAgICBpZiAoYXJnVHlwZSA9PT0gJ3N0cmluZycpIHJldHVybiB0cnVuY2F0ZVN0cmluZyhhcmcpO1xuICAgIGlmIChhcmdUeXBlICE9PSAnb2JqZWN0JykgcmV0dXJuIGFyZztcblxuICAgIGlmICghaXNTZXJ2ZXIpIHtcbiAgICAgIGlmIChcbiAgICAgICAgYXJnLm5vZGVUeXBlID09PSAxICYmXG4gICAgICAgIHR5cGVvZiBhcmcudGFnTmFtZSA9PT0gJ3N0cmluZycgJiZcbiAgICAgICAgdHlwZW9mIGFyZy5nZXRBdHRyaWJ1dGUgPT09ICdmdW5jdGlvbidcbiAgICAgICkge1xuICAgICAgICByZXR1cm4gZm9ybWF0RG9tRWxlbWVudChhcmcpO1xuICAgICAgfVxuICAgICAgaWYgKGFyZy5ub2RlVHlwZSA9PT0gOSkge1xuICAgICAgICByZXR1cm4gJ1tEb2N1bWVudF0nO1xuICAgICAgfVxuICAgICAgaWYgKHR5cGVvZiBXaW5kb3cgIT09ICd1bmRlZmluZWQnICYmIGFyZyBpbnN0YW5jZW9mIFdpbmRvdykge1xuICAgICAgICByZXR1cm4gJ1tXaW5kb3ddJztcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2YgRXZlbnQgIT09ICd1bmRlZmluZWQnICYmIGFyZyBpbnN0YW5jZW9mIEV2ZW50KSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgdHlwZTogYXJnLnR5cGUsXG4gICAgICAgICAgdGFyZ2V0OiBzZXJpYWxpemVDb25zb2xlQXJnKGFyZy50YXJnZXQsIHNlZW4sIGRlcHRoICsgMSksXG4gICAgICAgICAgY3VycmVudFRhcmdldDogc2VyaWFsaXplQ29uc29sZUFyZyhhcmcuY3VycmVudFRhcmdldCwgc2VlbiwgZGVwdGggKyAxKSxcbiAgICAgICAgICBkZWZhdWx0UHJldmVudGVkOiBhcmcuZGVmYXVsdFByZXZlbnRlZCxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2YgTm9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgYXJnIGluc3RhbmNlb2YgTm9kZSkge1xuICAgICAgICByZXR1cm4gJ1tOb2RlOiAnICsgYXJnLm5vZGVOYW1lICsgJ10nO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChhcmcgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbmFtZTogYXJnLm5hbWUsXG4gICAgICAgIG1lc3NhZ2U6IHRydW5jYXRlU3RyaW5nKGFyZy5tZXNzYWdlKSxcbiAgICAgICAgc3RhY2s6IGFyZy5zdGFjayA/IHRydW5jYXRlU3RyaW5nKGFyZy5zdGFjaykgOiBhcmcuc3RhY2ssXG4gICAgICB9O1xuICAgIH1cblxuICAgIGlmIChhcmcgaW5zdGFuY2VvZiBEYXRlKSB7XG4gICAgICByZXR1cm4gYXJnLnRvSVNPU3RyaW5nKCk7XG4gICAgfVxuXG4gICAgaWYgKGFyZyBpbnN0YW5jZW9mIFJlZ0V4cCkge1xuICAgICAgcmV0dXJuIGFyZy50b1N0cmluZygpO1xuICAgIH1cblxuICAgIGlmICh0eXBlb2YgQXJyYXlCdWZmZXIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICBpZiAoQXJyYXlCdWZmZXIuaXNWaWV3ICYmIEFycmF5QnVmZmVyLmlzVmlldyhhcmcpKSB7XG4gICAgICAgIHJldHVybiBmb3JtYXRBcnJheUJ1ZmZlclZpZXcoYXJnKTtcbiAgICAgIH1cbiAgICAgIGlmIChhcmcgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcikge1xuICAgICAgICByZXR1cm4gJ1tBcnJheUJ1ZmZlcignICsgYXJnLmJ5dGVMZW5ndGggKyAnKV0nO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICh0eXBlb2YgU2hhcmVkQXJyYXlCdWZmZXIgIT09ICd1bmRlZmluZWQnICYmIGFyZyBpbnN0YW5jZW9mIFNoYXJlZEFycmF5QnVmZmVyKSB7XG4gICAgICByZXR1cm4gJ1tTaGFyZWRBcnJheUJ1ZmZlcignICsgYXJnLmJ5dGVMZW5ndGggKyAnKV0nO1xuICAgIH1cblxuICAgIGlmIChkZXB0aCA+PSBNQVhfREVQVEgpIHtcbiAgICAgIHJldHVybiAnW01heERlcHRoXSc7XG4gICAgfVxuXG4gICAgaWYgKHNlZW4uaW5kZXhPZihhcmcpICE9PSAtMSkge1xuICAgICAgcmV0dXJuICdbQ2lyY3VsYXJdJztcbiAgICB9XG5cbiAgICBzZWVuLnB1c2goYXJnKTtcblxuICAgIGlmIChBcnJheS5pc0FycmF5KGFyZykpIHtcbiAgICAgIHZhciBhcnJheVJlc3VsdCA9IFtdO1xuICAgICAgdmFyIGFycmF5TGVuZ3RoID0gTWF0aC5taW4oYXJnLmxlbmd0aCwgTUFYX0FSUkFZX0xFTik7XG4gICAgICBmb3IgKHZhciBhcnJheUluZGV4ID0gMDsgYXJyYXlJbmRleCA8IGFycmF5TGVuZ3RoOyBhcnJheUluZGV4KyspIHtcbiAgICAgICAgYXJyYXlSZXN1bHQucHVzaChzZXJpYWxpemVDb25zb2xlQXJnKGFyZ1thcnJheUluZGV4XSwgc2VlbiwgZGVwdGggKyAxKSk7XG4gICAgICB9XG4gICAgICBpZiAoYXJnLmxlbmd0aCA+IE1BWF9BUlJBWV9MRU4pIHtcbiAgICAgICAgYXJyYXlSZXN1bHQucHVzaCgnLi4uICgnICsgKGFyZy5sZW5ndGggLSBNQVhfQVJSQVlfTEVOKSArICcgbW9yZSknKTtcbiAgICAgIH1cbiAgICAgIHNlZW4ucG9wKCk7XG4gICAgICByZXR1cm4gYXJyYXlSZXN1bHQ7XG4gICAgfVxuXG4gICAgdmFyIG9iamVjdFJlc3VsdCA9IHt9O1xuICAgIHZhciBrZXlzID0gT2JqZWN0LmtleXMoYXJnKTtcbiAgICB2YXIga2V5TGVuZ3RoID0gTWF0aC5taW4oa2V5cy5sZW5ndGgsIE1BWF9PQkpFQ1RfS0VZUyk7XG4gICAgZm9yICh2YXIga2V5SW5kZXggPSAwOyBrZXlJbmRleCA8IGtleUxlbmd0aDsga2V5SW5kZXgrKykge1xuICAgICAgdmFyIGtleSA9IGtleXNba2V5SW5kZXhdO1xuICAgICAgdHJ5IHtcbiAgICAgICAgb2JqZWN0UmVzdWx0W2tleV0gPSBzZXJpYWxpemVDb25zb2xlQXJnKGFyZ1trZXldLCBzZWVuLCBkZXB0aCArIDEpO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgb2JqZWN0UmVzdWx0W2tleV0gPSAnW1Rocm93bjogJyArIFN0cmluZyhlcnJvcikgKyAnXSc7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChrZXlzLmxlbmd0aCA+IE1BWF9PQkpFQ1RfS0VZUykge1xuICAgICAgb2JqZWN0UmVzdWx0WycuLi4nXSA9ICcoJyArIChrZXlzLmxlbmd0aCAtIE1BWF9PQkpFQ1RfS0VZUykgKyAnIG1vcmUga2V5cyknO1xuICAgIH1cbiAgICBzZWVuLnBvcCgpO1xuICAgIHJldHVybiBvYmplY3RSZXN1bHQ7XG4gIH1cblxuICAvLyBPdmVycmlkZSBnbG9iYWwgY29uc29sZSBtZXRob2RzXG4gIGZvciAodmFyIGogPSAwOyBqIDwgQ09OU09MRV9MRVZFTFMubGVuZ3RoOyBqKyspIHtcbiAgICAoZnVuY3Rpb24obGV2ZWwpIHtcbiAgICAgIHZhciBvcmlnaW5hbCA9IG9yaWdpbmFsQ29uc29sZVtsZXZlbF07XG4gICAgICBjb25zb2xlW2xldmVsXSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgYXJncyA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cyk7XG4gICAgICAgIFxuICAgICAgICAvLyBBbHdheXMgY2FsbCBvcmlnaW5hbCBmaXJzdCBzbyBsb2dzIGFwcGVhciBub3JtYWxseVxuICAgICAgICBvcmlnaW5hbC5hcHBseShjb25zb2xlLCBhcmdzKTtcbiAgICAgICAgXG4gICAgICAgIC8vIFNraXAgb3VyIG93biBUU0QgQ29uc29sZSBQaXBlIGxvZ3MgdG8gYXZvaWQgcmVjdXJzaW9uL25vaXNlXG4gICAgICAgIGlmIChhcmdzLmxlbmd0aCA+IDAgJiYgdHlwZW9mIGFyZ3NbMF0gPT09ICdzdHJpbmcnICYmIFxuICAgICAgICAgICAgKGFyZ3NbMF0uaW5kZXhPZignW1RTRCBDb25zb2xlIFBpcGVdJykgIT09IC0xIHx8IFxuICAgICAgICAgICAgIGFyZ3NbMF0uaW5kZXhPZignW0B0YW5zdGFjay9kZXZ0b29scycpICE9PSAtMSkpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgc2FmZUFyZ3MgPSBhcmdzLm1hcChmdW5jdGlvbihhcmcpIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgcmV0dXJuIHNlcmlhbGl6ZUNvbnNvbGVBcmcoYXJnLCBbXSwgMCk7XG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgcmV0dXJuIFN0cmluZyhhcmcpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgdmFyIGVudHJ5ID0ge1xuICAgICAgICAgIGxldmVsOiBsZXZlbCxcbiAgICAgICAgICBhcmdzOiBzYWZlQXJncyxcbiAgICAgICAgICBzb3VyY2U6IGlzU2VydmVyID8gJ3NlcnZlcicgOiAnY2xpZW50JyxcbiAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgIH07XG4gICAgICAgIFxuICAgICAgICBhZGRUb0JhdGNoKGVudHJ5KTtcbiAgICAgIH07XG4gICAgfSkoQ09OU09MRV9MRVZFTFNbal0pO1xuICB9XG5cbiAgLy8gQ0xJRU5UIE9OTFk6IExpc3RlbiBmb3Igc2VydmVyIGNvbnNvbGUgbG9ncyB2aWEgU1NFXG4gIGlmICghaXNTZXJ2ZXIpIHtcbiAgICAvLyBUcmFuc2Zvcm0gc2VydmVyIGxvZyBhcmdzIC0gc3RyaXAgQU5TSSBjb2RlcyBhbmQgY29udmVydCBzb3VyY2UgcGF0aHMgdG8gY2xpY2thYmxlIFVSTHNcbiAgICBmdW5jdGlvbiB0cmFuc2Zvcm1TZXJ2ZXJMb2dBcmdzKGFyZ3MpIHtcbiAgICAgIHZhciBlc2NDaGFyID0gU3RyaW5nLmZyb21DaGFyQ29kZSgyNyk7XG4gICAgICB2YXIgdHJhbnNmb3JtZWQgPSBbXTtcbiAgICAgIFxuICAgICAgZm9yICh2YXIgayA9IDA7IGsgPCBhcmdzLmxlbmd0aDsgaysrKSB7XG4gICAgICAgIHZhciBhcmcgPSBhcmdzW2tdO1xuICAgICAgICBpZiAodHlwZW9mIGFyZyA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAvLyBTdHJpcCBBTlNJIGVzY2FwZSBzZXF1ZW5jZXMgKEVTQ1suLi5tIHBhdHRlcm5zKVxuICAgICAgICAgIHZhciBjbGVhbmVkID0gYXJnO1xuICAgICAgICAgIC8vIFJlbW92ZSBFU0MgY2hhcmFjdGVyIGZvbGxvd2VkIGJ5IFsuLi5tXSAtIG5lZWQgdG8gYnVpbGQgcmVnZXggZHluYW1pY2FsbHlcbiAgICAgICAgICB3aGlsZSAoY2xlYW5lZC5pbmRleE9mKGVzY0NoYXIpICE9PSAtMSkge1xuICAgICAgICAgICAgY2xlYW5lZCA9IGNsZWFuZWQuc3BsaXQoZXNjQ2hhcikuam9pbignJyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIEFsc28gcmVtb3ZlIGFueSBsZWZ0b3ZlciBicmFja2V0IGNvZGVzIGxpa2UgWzM1bVxuICAgICAgICAgIGNsZWFuZWQgPSBjbGVhbmVkLnJlcGxhY2UoL1xcW1swLTk7XSptL2csICcnKTtcbiAgICAgICAgICBcbiAgICAgICAgICAvLyBUcmFuc2Zvcm0gc291cmNlIHBhdGhzIHRvIGNsaWNrYWJsZSBVUkxzXG4gICAgICAgICAgLy8gTWF0Y2ggcGF0dGVybnMgbGlrZSAvc3JjL2NvbXBvbmVudHMvSGVhZGVyLnRzeDoxNzozXG4gICAgICAgICAgdmFyIHNvdXJjZVJlZ2V4ID0gLyhcXC9bXlxcc10rOlxcZCs6XFxkKykvZztcbiAgICAgICAgICBjbGVhbmVkID0gY2xlYW5lZC5yZXBsYWNlKHNvdXJjZVJlZ2V4LCBmdW5jdGlvbihtYXRjaCkge1xuICAgICAgICAgICAgcmV0dXJuIHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gKyAnL19fdHNkL29wZW4tc291cmNlP3NvdXJjZT0nICsgZW5jb2RlVVJJQ29tcG9uZW50KG1hdGNoKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBcbiAgICAgICAgICBpZiAoY2xlYW5lZC50cmltKCkpIHtcbiAgICAgICAgICAgIHRyYW5zZm9ybWVkLnB1c2goY2xlYW5lZCk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRyYW5zZm9ybWVkLnB1c2goYXJnKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgXG4gICAgICByZXR1cm4gdHJhbnNmb3JtZWQ7XG4gICAgfVxuXG4gICAgdmFyIGV2ZW50U291cmNlID0gbmV3IEV2ZW50U291cmNlKCcvX190c2QvY29uc29sZS1waXBlL3NzZScpO1xuICAgIFxuICAgIGV2ZW50U291cmNlLm9ubWVzc2FnZSA9IGZ1bmN0aW9uKGV2ZW50KSB7XG4gICAgICB0cnkge1xuICAgICAgICB2YXIgZGF0YSA9IEpTT04ucGFyc2UoZXZlbnQuZGF0YSk7XG4gICAgICAgIGlmIChkYXRhLmVudHJpZXMpIHtcbiAgICAgICAgICBmb3IgKHZhciBtID0gMDsgbSA8IGRhdGEuZW50cmllcy5sZW5ndGg7IG0rKykge1xuICAgICAgICAgICAgdmFyIGVudHJ5ID0gZGF0YS5lbnRyaWVzW21dO1xuICAgICAgICAgICAgdmFyIHRyYW5zZm9ybWVkQXJncyA9IHRyYW5zZm9ybVNlcnZlckxvZ0FyZ3MoZW50cnkuYXJncyk7XG4gICAgICAgICAgICB2YXIgcHJlZml4ID0gJyVjW1NlcnZlcl0lYyc7XG4gICAgICAgICAgICB2YXIgcHJlZml4U3R5bGUgPSAnY29sb3I6ICM5MzMzZWE7IGZvbnQtd2VpZ2h0OiBib2xkOyc7XG4gICAgICAgICAgICB2YXIgcmVzZXRTdHlsZSA9ICdjb2xvcjogaW5oZXJpdDsnO1xuICAgICAgICAgICAgdmFyIGxvZ01ldGhvZCA9IG9yaWdpbmFsQ29uc29sZVtlbnRyeS5sZXZlbF0gfHwgb3JpZ2luYWxDb25zb2xlLmxvZztcbiAgICAgICAgICAgIGxvZ01ldGhvZC5hcHBseShjb25zb2xlLCBbcHJlZml4LCBwcmVmaXhTdHlsZSwgcmVzZXRTdHlsZV0uY29uY2F0KHRyYW5zZm9ybWVkQXJncykpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIC8vIFN3YWxsb3cgZXJyb3JzICBcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgZXZlbnRTb3VyY2Uub25lcnJvciA9IGZ1bmN0aW9uKCkge1xuICAgICAgLy8gU3dhbGxvdyBlcnJvcnMgIFxuICAgIH07XG5cbiAgICAvLyBGbHVzaCBvbiBwYWdlIHVubG9hZFxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdiZWZvcmV1bmxvYWQnLCBmbHVzaEJhdGNoKTtcbiAgfVxufSkoKTtcblxuaW1wb3J0IFJlYWN0RE9NIGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XHJcbmltcG9ydCBcImxkcnMvcmVhY3QvUmluZzIuY3NzXCI7XHJcbmltcG9ydCB7IFJvdXRlclByb3ZpZGVyIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1yb3V0ZXJcIjtcclxuaW1wb3J0IHsgZ2V0Um91dGVyIH0gZnJvbSBcIiMvcm91dGVyXCI7XHJcbmltcG9ydCBcIiMvc3R5bGVzLmNzc1wiO1xyXG5cclxuY29uc3Qgcm91dGVyID0gZ2V0Um91dGVyKCk7XHJcbmNvbnN0IHJvb3RFbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2FwcCcpO1xyXG5cclxuaWYgKCFyb290RWxlbWVudCkge1xyXG5cdHRocm93IG5ldyBFcnJvcignUm9vdCBlbGVtZW50ICNhcHAgd2FzIG5vdCBmb3VuZC4nKTtcclxufVxyXG5cclxuaWYgKCFyb290RWxlbWVudC5pbm5lckhUTUwpIHtcclxuXHRjb25zdCByb290ID0gUmVhY3RET00uY3JlYXRlUm9vdChyb290RWxlbWVudCk7XHJcblx0cm9vdC5yZW5kZXIoPFJvdXRlclByb3ZpZGVyIHJvdXRlcj17cm91dGVyfSAvPik7XHJcbn1cclxuIl19