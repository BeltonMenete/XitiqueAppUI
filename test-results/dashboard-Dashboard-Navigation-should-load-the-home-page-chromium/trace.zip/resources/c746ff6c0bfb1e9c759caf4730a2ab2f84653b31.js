//#region node_modules/.pnpm/@tanstack+router-devtools-c_eeb630569bc32923f9271a08ac50f834/node_modules/@tanstack/router-devtools-core/dist/context-De2EB1AA.js
var sharedConfig = {
	context: void 0,
	registry: void 0,
	effects: void 0,
	done: false,
	getContextId() {
		return getContextId(this.context.count);
	},
	getNextContextId() {
		return getContextId(this.context.count++);
	}
};
function getContextId(count) {
	const num = String(count), len = num.length - 1;
	return sharedConfig.context.id + (len ? String.fromCharCode(96 + len) : "") + num;
}
function setHydrateContext(context) {
	sharedConfig.context = context;
}
function nextHydrateContext() {
	return {
		...sharedConfig.context,
		id: sharedConfig.getNextContextId(),
		count: 0
	};
}
var equalFn = (a, b) => a === b;
var $PROXY = Symbol("solid-proxy");
var SUPPORTS_PROXY = typeof Proxy === "function";
var $TRACK = Symbol("solid-track");
var signalOptions = { equals: equalFn };
var ERROR = null;
var runEffects = runQueue;
var STALE = 1;
var PENDING = 2;
var UNOWNED = {
	owned: null,
	cleanups: null,
	context: null,
	owner: null
};
var NO_INIT = {};
var Owner = null;
var Transition = null;
var Scheduler = null;
var ExternalSourceConfig = null;
var Listener = null;
var Updates = null;
var Effects = null;
var ExecCount = 0;
function createRoot(fn, detachedOwner) {
	const listener = Listener, owner = Owner, unowned = fn.length === 0, current = detachedOwner === void 0 ? owner : detachedOwner, root = unowned ? UNOWNED : {
		owned: null,
		cleanups: null,
		context: current ? current.context : null,
		owner: current
	}, updateFn = unowned ? fn : () => fn(() => untrack(() => cleanNode(root)));
	Owner = root;
	Listener = null;
	try {
		return runUpdates(updateFn, true);
	} finally {
		Listener = listener;
		Owner = owner;
	}
}
function createSignal(value, options) {
	options = options ? Object.assign({}, signalOptions, options) : signalOptions;
	const s = {
		value,
		observers: null,
		observerSlots: null,
		comparator: options.equals || void 0
	};
	const setter = (value) => {
		if (typeof value === "function") if (Transition && Transition.running && Transition.sources.has(s)) value = value(s.tValue);
		else value = value(s.value);
		return writeSignal(s, value);
	};
	return [readSignal.bind(s), setter];
}
function createComputed(fn, value, options) {
	const c = createComputation(fn, value, true, STALE);
	if (Scheduler && Transition && Transition.running) Updates.push(c);
	else updateComputation(c);
}
function createRenderEffect(fn, value, options) {
	const c = createComputation(fn, value, false, STALE);
	if (Scheduler && Transition && Transition.running) Updates.push(c);
	else updateComputation(c);
}
function createEffect(fn, value, options) {
	runEffects = runUserEffects;
	const c = createComputation(fn, value, false, STALE), s = SuspenseContext && useContext(SuspenseContext);
	if (s) c.suspense = s;
	if (!options || !options.render) c.user = true;
	Effects ? Effects.push(c) : updateComputation(c);
}
function createMemo(fn, value, options) {
	options = options ? Object.assign({}, signalOptions, options) : signalOptions;
	const c = createComputation(fn, value, true, 0);
	c.observers = null;
	c.observerSlots = null;
	c.comparator = options.equals || void 0;
	if (Scheduler && Transition && Transition.running) {
		c.tState = STALE;
		Updates.push(c);
	} else updateComputation(c);
	return readSignal.bind(c);
}
function isPromise(v) {
	return v && typeof v === "object" && "then" in v;
}
function createResource(pSource, pFetcher, pOptions) {
	let source;
	let fetcher;
	let options;
	if (typeof pFetcher === "function") {
		source = pSource;
		fetcher = pFetcher;
		options = pOptions || {};
	} else {
		source = true;
		fetcher = pSource;
		options = pFetcher || {};
	}
	let pr = null, initP = NO_INIT, id = null, loadedUnderTransition = false, scheduled = false, resolved = "initialValue" in options, dynamic = typeof source === "function" && createMemo(source);
	const contexts = /* @__PURE__ */ new Set(), [value, setValue] = (options.storage || createSignal)(options.initialValue), [error, setError] = createSignal(void 0), [track, trigger] = createSignal(void 0, { equals: false }), [state, setState] = createSignal(resolved ? "ready" : "unresolved");
	if (sharedConfig.context) {
		id = sharedConfig.getNextContextId();
		if (options.ssrLoadFrom === "initial") initP = options.initialValue;
		else if (sharedConfig.load && sharedConfig.has(id)) initP = sharedConfig.load(id);
	}
	function loadEnd(p, v, error, key) {
		if (pr === p) {
			pr = null;
			key !== void 0 && (resolved = true);
			if ((p === initP || v === initP) && options.onHydrated) queueMicrotask(() => options.onHydrated(key, { value: v }));
			initP = NO_INIT;
			if (Transition && p && loadedUnderTransition) {
				Transition.promises.delete(p);
				loadedUnderTransition = false;
				runUpdates(() => {
					Transition.running = true;
					completeLoad(v, error);
				}, false);
			} else completeLoad(v, error);
		}
		return v;
	}
	function completeLoad(v, err) {
		runUpdates(() => {
			if (err === void 0) setValue(() => v);
			setState(err !== void 0 ? "errored" : resolved ? "ready" : "unresolved");
			setError(err);
			for (const c of contexts.keys()) c.decrement();
			contexts.clear();
		}, false);
	}
	function read() {
		const c = SuspenseContext && useContext(SuspenseContext), v = value(), err = error();
		if (err !== void 0 && !pr) throw err;
		if (Listener && !Listener.user && c) createComputed(() => {
			track();
			if (pr) {
				if (c.resolved && Transition && loadedUnderTransition) Transition.promises.add(pr);
				else if (!contexts.has(c)) {
					c.increment();
					contexts.add(c);
				}
			}
		});
		return v;
	}
	function load(refetching = true) {
		if (refetching !== false && scheduled) return;
		scheduled = false;
		const lookup = dynamic ? dynamic() : source;
		loadedUnderTransition = Transition && Transition.running;
		if (lookup == null || lookup === false) {
			loadEnd(pr, untrack(value));
			return;
		}
		if (Transition && pr) Transition.promises.delete(pr);
		let error;
		const p = initP !== NO_INIT ? initP : untrack(() => {
			try {
				return fetcher(lookup, {
					value: value(),
					refetching
				});
			} catch (fetcherError) {
				error = fetcherError;
			}
		});
		if (error !== void 0) {
			loadEnd(pr, void 0, castError(error), lookup);
			return;
		} else if (!isPromise(p)) {
			loadEnd(pr, p, void 0, lookup);
			return p;
		}
		pr = p;
		if ("v" in p) {
			if (p.s === 1) loadEnd(pr, p.v, void 0, lookup);
			else loadEnd(pr, void 0, castError(p.v), lookup);
			return p;
		}
		scheduled = true;
		queueMicrotask(() => scheduled = false);
		runUpdates(() => {
			setState(resolved ? "refreshing" : "pending");
			trigger();
		}, false);
		return p.then((v) => loadEnd(p, v, void 0, lookup), (e) => loadEnd(p, void 0, castError(e), lookup));
	}
	Object.defineProperties(read, {
		state: { get: () => state() },
		error: { get: () => error() },
		loading: { get() {
			const s = state();
			return s === "pending" || s === "refreshing";
		} },
		latest: { get() {
			if (!resolved) return read();
			const err = error();
			if (err && !pr) throw err;
			return value();
		} }
	});
	let owner = Owner;
	if (dynamic) createComputed(() => (owner = Owner, load(false)));
	else load(false);
	return [read, {
		refetch: (info) => runWithOwner(owner, () => load(info)),
		mutate: setValue
	}];
}
function untrack(fn) {
	if (!ExternalSourceConfig && Listener === null) return fn();
	const listener = Listener;
	Listener = null;
	try {
		if (ExternalSourceConfig) return ExternalSourceConfig.untrack(fn);
		return fn();
	} finally {
		Listener = listener;
	}
}
function onCleanup(fn) {
	if (Owner === null);
	else if (Owner.cleanups === null) Owner.cleanups = [fn];
	else Owner.cleanups.push(fn);
	return fn;
}
function runWithOwner(o, fn) {
	const prev = Owner;
	const prevListener = Listener;
	Owner = o;
	Listener = null;
	try {
		return runUpdates(fn, true);
	} catch (err) {
		handleError(err);
	} finally {
		Owner = prev;
		Listener = prevListener;
	}
}
function startTransition(fn) {
	if (Transition && Transition.running) {
		fn();
		return Transition.done;
	}
	const l = Listener;
	const o = Owner;
	return Promise.resolve().then(() => {
		Listener = l;
		Owner = o;
		let t;
		if (Scheduler || SuspenseContext) {
			t = Transition || (Transition = {
				sources: /* @__PURE__ */ new Set(),
				effects: [],
				promises: /* @__PURE__ */ new Set(),
				disposed: /* @__PURE__ */ new Set(),
				queue: /* @__PURE__ */ new Set(),
				running: true
			});
			t.done || (t.done = new Promise((res) => t.resolve = res));
			t.running = true;
		}
		runUpdates(fn, false);
		Listener = Owner = null;
		return t ? t.done : void 0;
	});
}
var [transPending, setTransPending] = /* @__PURE__ */ createSignal(false);
function createContext(defaultValue, options) {
	const id = Symbol("context");
	return {
		id,
		Provider: createProvider(id),
		defaultValue
	};
}
function useContext(context) {
	let value;
	return Owner && Owner.context && (value = Owner.context[context.id]) !== void 0 ? value : context.defaultValue;
}
function children(fn) {
	const children = createMemo(fn);
	const memo = createMemo(() => resolveChildren(children()));
	memo.toArray = () => {
		const c = memo();
		return Array.isArray(c) ? c : c != null ? [c] : [];
	};
	return memo;
}
var SuspenseContext;
function readSignal() {
	const runningTransition = Transition && Transition.running;
	if (this.sources && (runningTransition ? this.tState : this.state)) if ((runningTransition ? this.tState : this.state) === STALE) updateComputation(this);
	else {
		const updates = Updates;
		Updates = null;
		runUpdates(() => lookUpstream(this), false);
		Updates = updates;
	}
	if (Listener) {
		const sSlot = this.observers ? this.observers.length : 0;
		if (!Listener.sources) {
			Listener.sources = [this];
			Listener.sourceSlots = [sSlot];
		} else {
			Listener.sources.push(this);
			Listener.sourceSlots.push(sSlot);
		}
		if (!this.observers) {
			this.observers = [Listener];
			this.observerSlots = [Listener.sources.length - 1];
		} else {
			this.observers.push(Listener);
			this.observerSlots.push(Listener.sources.length - 1);
		}
	}
	if (runningTransition && Transition.sources.has(this)) return this.tValue;
	return this.value;
}
function writeSignal(node, value, isComp) {
	let current = Transition && Transition.running && Transition.sources.has(node) ? node.tValue : node.value;
	if (!node.comparator || !node.comparator(current, value)) {
		if (Transition) {
			const TransitionRunning = Transition.running;
			if (TransitionRunning || !isComp && Transition.sources.has(node)) {
				Transition.sources.add(node);
				node.tValue = value;
			}
			if (!TransitionRunning) node.value = value;
		} else node.value = value;
		if (node.observers && node.observers.length) runUpdates(() => {
			for (let i = 0; i < node.observers.length; i += 1) {
				const o = node.observers[i];
				const TransitionRunning = Transition && Transition.running;
				if (TransitionRunning && Transition.disposed.has(o)) continue;
				if (TransitionRunning ? !o.tState : !o.state) {
					if (o.pure) Updates.push(o);
					else Effects.push(o);
					if (o.observers) markDownstream(o);
				}
				if (!TransitionRunning) o.state = STALE;
				else o.tState = STALE;
			}
			if (Updates.length > 1e6) {
				Updates = [];
				throw new Error();
			}
		}, false);
	}
	return value;
}
function updateComputation(node) {
	if (!node.fn) return;
	cleanNode(node);
	const time = ExecCount;
	runComputation(node, Transition && Transition.running && Transition.sources.has(node) ? node.tValue : node.value, time);
	if (Transition && !Transition.running && Transition.sources.has(node)) queueMicrotask(() => {
		runUpdates(() => {
			Transition && (Transition.running = true);
			Listener = Owner = node;
			runComputation(node, node.tValue, time);
			Listener = Owner = null;
		}, false);
	});
}
function runComputation(node, value, time) {
	let nextValue;
	const owner = Owner, listener = Listener;
	Listener = Owner = node;
	try {
		nextValue = node.fn(value);
	} catch (err) {
		if (node.pure) if (Transition && Transition.running) {
			node.tState = STALE;
			node.tOwned && node.tOwned.forEach(cleanNode);
			node.tOwned = void 0;
		} else {
			node.state = STALE;
			node.owned && node.owned.forEach(cleanNode);
			node.owned = null;
		}
		node.updatedAt = time + 1;
		return handleError(err);
	} finally {
		Listener = listener;
		Owner = owner;
	}
	if (!node.updatedAt || node.updatedAt <= time) {
		if (node.updatedAt != null && "observers" in node) writeSignal(node, nextValue, true);
		else if (Transition && Transition.running && node.pure) {
			if (!Transition.sources.has(node)) node.value = nextValue;
			Transition.sources.add(node);
			node.tValue = nextValue;
		} else node.value = nextValue;
		node.updatedAt = time;
	}
}
function createComputation(fn, init, pure, state = STALE, options) {
	const c = {
		fn,
		state,
		updatedAt: null,
		owned: null,
		sources: null,
		sourceSlots: null,
		cleanups: null,
		value: init,
		owner: Owner,
		context: Owner ? Owner.context : null,
		pure
	};
	if (Transition && Transition.running) {
		c.state = 0;
		c.tState = state;
	}
	if (Owner === null);
	else if (Owner !== UNOWNED) if (Transition && Transition.running && Owner.pure) if (!Owner.tOwned) Owner.tOwned = [c];
	else Owner.tOwned.push(c);
	else if (!Owner.owned) Owner.owned = [c];
	else Owner.owned.push(c);
	if (ExternalSourceConfig && c.fn) {
		const sourceFn = c.fn;
		const [track, trigger] = createSignal(void 0, { equals: false });
		const ordinary = ExternalSourceConfig.factory(sourceFn, trigger);
		onCleanup(() => ordinary.dispose());
		let inTransition;
		const triggerInTransition = () => startTransition(trigger).then(() => {
			if (inTransition) {
				inTransition.dispose();
				inTransition = void 0;
			}
		});
		c.fn = (x) => {
			track();
			if (Transition && Transition.running) {
				if (!inTransition) inTransition = ExternalSourceConfig.factory(sourceFn, triggerInTransition);
				return inTransition.track(x);
			}
			return ordinary.track(x);
		};
	}
	return c;
}
function runTop(node) {
	const runningTransition = Transition && Transition.running;
	if ((runningTransition ? node.tState : node.state) === 0) return;
	if ((runningTransition ? node.tState : node.state) === PENDING) return lookUpstream(node);
	if (node.suspense && untrack(node.suspense.inFallback)) return node.suspense.effects.push(node);
	const ancestors = [node];
	while ((node = node.owner) && (!node.updatedAt || node.updatedAt < ExecCount)) {
		if (runningTransition && Transition.disposed.has(node)) return;
		if (runningTransition ? node.tState : node.state) ancestors.push(node);
	}
	for (let i = ancestors.length - 1; i >= 0; i--) {
		node = ancestors[i];
		if (runningTransition) {
			let top = node, prev = ancestors[i + 1];
			while ((top = top.owner) && top !== prev) if (Transition.disposed.has(top)) return;
		}
		if ((runningTransition ? node.tState : node.state) === STALE) updateComputation(node);
		else if ((runningTransition ? node.tState : node.state) === PENDING) {
			const updates = Updates;
			Updates = null;
			runUpdates(() => lookUpstream(node, ancestors[0]), false);
			Updates = updates;
		}
	}
}
function runUpdates(fn, init) {
	if (Updates) return fn();
	let wait = false;
	if (!init) Updates = [];
	if (Effects) wait = true;
	else Effects = [];
	ExecCount++;
	try {
		const res = fn();
		completeUpdates(wait);
		return res;
	} catch (err) {
		if (!wait) Effects = null;
		Updates = null;
		handleError(err);
	}
}
function completeUpdates(wait) {
	if (Updates) {
		if (Scheduler && Transition && Transition.running) scheduleQueue(Updates);
		else runQueue(Updates);
		Updates = null;
	}
	if (wait) return;
	let res;
	if (Transition) {
		if (!Transition.promises.size && !Transition.queue.size) {
			const sources = Transition.sources;
			const disposed = Transition.disposed;
			Effects.push.apply(Effects, Transition.effects);
			res = Transition.resolve;
			for (const e of Effects) {
				"tState" in e && (e.state = e.tState);
				delete e.tState;
			}
			Transition = null;
			runUpdates(() => {
				for (const d of disposed) cleanNode(d);
				for (const v of sources) {
					v.value = v.tValue;
					if (v.owned) for (let i = 0, len = v.owned.length; i < len; i++) cleanNode(v.owned[i]);
					if (v.tOwned) v.owned = v.tOwned;
					delete v.tValue;
					delete v.tOwned;
					v.tState = 0;
				}
				setTransPending(false);
			}, false);
		} else if (Transition.running) {
			Transition.running = false;
			Transition.effects.push.apply(Transition.effects, Effects);
			Effects = null;
			setTransPending(true);
			return;
		}
	}
	const e = Effects;
	Effects = null;
	if (e.length) runUpdates(() => runEffects(e), false);
	if (res) res();
}
function runQueue(queue) {
	for (let i = 0; i < queue.length; i++) runTop(queue[i]);
}
function scheduleQueue(queue) {
	for (let i = 0; i < queue.length; i++) {
		const item = queue[i];
		const tasks = Transition.queue;
		if (!tasks.has(item)) {
			tasks.add(item);
			Scheduler(() => {
				tasks.delete(item);
				runUpdates(() => {
					Transition.running = true;
					runTop(item);
				}, false);
				Transition && (Transition.running = false);
			});
		}
	}
}
function runUserEffects(queue) {
	let i, userLength = 0;
	for (i = 0; i < queue.length; i++) {
		const e = queue[i];
		if (!e.user) runTop(e);
		else queue[userLength++] = e;
	}
	if (sharedConfig.context) {
		if (sharedConfig.count) {
			sharedConfig.effects || (sharedConfig.effects = []);
			sharedConfig.effects.push(...queue.slice(0, userLength));
			return;
		}
		setHydrateContext();
	}
	if (sharedConfig.effects && (sharedConfig.done || !sharedConfig.count)) {
		queue = [...sharedConfig.effects, ...queue];
		userLength += sharedConfig.effects.length;
		delete sharedConfig.effects;
	}
	for (i = 0; i < userLength; i++) runTop(queue[i]);
}
function lookUpstream(node, ignore) {
	const runningTransition = Transition && Transition.running;
	if (runningTransition) node.tState = 0;
	else node.state = 0;
	for (let i = 0; i < node.sources.length; i += 1) {
		const source = node.sources[i];
		if (source.sources) {
			const state = runningTransition ? source.tState : source.state;
			if (state === STALE) {
				if (source !== ignore && (!source.updatedAt || source.updatedAt < ExecCount)) runTop(source);
			} else if (state === PENDING) lookUpstream(source, ignore);
		}
	}
}
function markDownstream(node) {
	const runningTransition = Transition && Transition.running;
	for (let i = 0; i < node.observers.length; i += 1) {
		const o = node.observers[i];
		if (runningTransition ? !o.tState : !o.state) {
			if (runningTransition) o.tState = PENDING;
			else o.state = PENDING;
			if (o.pure) Updates.push(o);
			else Effects.push(o);
			o.observers && markDownstream(o);
		}
	}
}
function cleanNode(node) {
	let i;
	if (node.sources) while (node.sources.length) {
		const source = node.sources.pop(), index = node.sourceSlots.pop(), obs = source.observers;
		if (obs && obs.length) {
			const n = obs.pop(), s = source.observerSlots.pop();
			if (index < obs.length) {
				n.sourceSlots[s] = index;
				obs[index] = n;
				source.observerSlots[index] = s;
			}
		}
	}
	if (node.tOwned) {
		for (i = node.tOwned.length - 1; i >= 0; i--) cleanNode(node.tOwned[i]);
		delete node.tOwned;
	}
	if (Transition && Transition.running && node.pure) reset(node, true);
	else if (node.owned) {
		for (i = node.owned.length - 1; i >= 0; i--) cleanNode(node.owned[i]);
		node.owned = null;
	}
	if (node.cleanups) {
		for (i = node.cleanups.length - 1; i >= 0; i--) node.cleanups[i]();
		node.cleanups = null;
	}
	if (Transition && Transition.running) node.tState = 0;
	else node.state = 0;
}
function reset(node, top) {
	if (!top) {
		node.tState = 0;
		Transition.disposed.add(node);
	}
	if (node.owned) for (let i = 0; i < node.owned.length; i++) reset(node.owned[i]);
}
function castError(err) {
	if (err instanceof Error) return err;
	return new Error(typeof err === "string" ? err : "Unknown error", { cause: err });
}
function runErrors(err, fns, owner) {
	try {
		for (const f of fns) f(err);
	} catch (e) {
		handleError(e, owner && owner.owner || null);
	}
}
function handleError(err, owner = Owner) {
	const fns = ERROR && owner && owner.context && owner.context[ERROR];
	const error = castError(err);
	if (!fns) throw error;
	if (Effects) Effects.push({
		fn() {
			runErrors(error, fns, owner);
		},
		state: STALE
	});
	else runErrors(error, fns, owner);
}
function resolveChildren(children) {
	if (typeof children === "function" && !children.length) return resolveChildren(children());
	if (Array.isArray(children)) {
		const results = [];
		for (let i = 0; i < children.length; i++) {
			const result = resolveChildren(children[i]);
			Array.isArray(result) ? results.push.apply(results, result) : results.push(result);
		}
		return results;
	}
	return children;
}
function createProvider(id, options) {
	return function provider(props) {
		let res;
		createRenderEffect(() => res = untrack(() => {
			Owner.context = {
				...Owner.context,
				[id]: props.value
			};
			return children(() => props.children);
		}), void 0);
		return res;
	};
}
var FALLBACK = Symbol("fallback");
function dispose(d) {
	for (let i = 0; i < d.length; i++) d[i]();
}
function mapArray(list, mapFn, options = {}) {
	let items = [], mapped = [], disposers = [], len = 0, indexes = mapFn.length > 1 ? [] : null;
	onCleanup(() => dispose(disposers));
	return () => {
		let newItems = list() || [], newLen = newItems.length, i, j;
		newItems[$TRACK];
		return untrack(() => {
			let newIndices, newIndicesNext, temp, tempdisposers, tempIndexes, start, end, newEnd, item;
			if (newLen === 0) {
				if (len !== 0) {
					dispose(disposers);
					disposers = [];
					items = [];
					mapped = [];
					len = 0;
					indexes && (indexes = []);
				}
				if (options.fallback) {
					items = [FALLBACK];
					mapped[0] = createRoot((disposer) => {
						disposers[0] = disposer;
						return options.fallback();
					});
					len = 1;
				}
			} else if (len === 0) {
				mapped = new Array(newLen);
				for (j = 0; j < newLen; j++) {
					items[j] = newItems[j];
					mapped[j] = createRoot(mapper);
				}
				len = newLen;
			} else {
				temp = new Array(newLen);
				tempdisposers = new Array(newLen);
				indexes && (tempIndexes = new Array(newLen));
				for (start = 0, end = Math.min(len, newLen); start < end && items[start] === newItems[start]; start++);
				for (end = len - 1, newEnd = newLen - 1; end >= start && newEnd >= start && items[end] === newItems[newEnd]; end--, newEnd--) {
					temp[newEnd] = mapped[end];
					tempdisposers[newEnd] = disposers[end];
					indexes && (tempIndexes[newEnd] = indexes[end]);
				}
				newIndices = /* @__PURE__ */ new Map();
				newIndicesNext = new Array(newEnd + 1);
				for (j = newEnd; j >= start; j--) {
					item = newItems[j];
					i = newIndices.get(item);
					newIndicesNext[j] = i === void 0 ? -1 : i;
					newIndices.set(item, j);
				}
				for (i = start; i <= end; i++) {
					item = items[i];
					j = newIndices.get(item);
					if (j !== void 0 && j !== -1) {
						temp[j] = mapped[i];
						tempdisposers[j] = disposers[i];
						indexes && (tempIndexes[j] = indexes[i]);
						j = newIndicesNext[j];
						newIndices.set(item, j);
					} else disposers[i]();
				}
				for (j = start; j < newLen; j++) if (j in temp) {
					mapped[j] = temp[j];
					disposers[j] = tempdisposers[j];
					if (indexes) {
						indexes[j] = tempIndexes[j];
						indexes[j](j);
					}
				} else mapped[j] = createRoot(mapper);
				mapped = mapped.slice(0, len = newLen);
				items = newItems.slice(0);
			}
			return mapped;
		});
		function mapper(disposer) {
			disposers[j] = disposer;
			if (indexes) {
				const [s, set] = createSignal(j);
				indexes[j] = set;
				return mapFn(newItems[j], s);
			}
			return mapFn(newItems[j]);
		}
	};
}
var hydrationEnabled = false;
function createComponent(Comp, props) {
	if (hydrationEnabled) {
		if (sharedConfig.context) {
			const c = sharedConfig.context;
			setHydrateContext(nextHydrateContext());
			const r = untrack(() => Comp(props || {}));
			setHydrateContext(c);
			return r;
		}
	}
	return untrack(() => Comp(props || {}));
}
function trueFn() {
	return true;
}
var propTraps = {
	get(_, property, receiver) {
		if (property === $PROXY) return receiver;
		return _.get(property);
	},
	has(_, property) {
		if (property === $PROXY) return true;
		return _.has(property);
	},
	set: trueFn,
	deleteProperty: trueFn,
	getOwnPropertyDescriptor(_, property) {
		return {
			configurable: true,
			enumerable: true,
			get() {
				return _.get(property);
			},
			set: trueFn,
			deleteProperty: trueFn
		};
	},
	ownKeys(_) {
		return _.keys();
	}
};
function resolveSource(s) {
	return !(s = typeof s === "function" ? s() : s) ? {} : s;
}
function resolveSources() {
	for (let i = 0, length = this.length; i < length; ++i) {
		const v = this[i]();
		if (v !== void 0) return v;
	}
}
function mergeProps(...sources) {
	let proxy = false;
	for (let i = 0; i < sources.length; i++) {
		const s = sources[i];
		proxy = proxy || !!s && $PROXY in s;
		sources[i] = typeof s === "function" ? (proxy = true, createMemo(s)) : s;
	}
	if (SUPPORTS_PROXY && proxy) return new Proxy({
		get(property) {
			for (let i = sources.length - 1; i >= 0; i--) {
				const v = resolveSource(sources[i])[property];
				if (v !== void 0) return v;
			}
		},
		has(property) {
			for (let i = sources.length - 1; i >= 0; i--) if (property in resolveSource(sources[i])) return true;
			return false;
		},
		keys() {
			const keys = [];
			for (let i = 0; i < sources.length; i++) keys.push(...Object.keys(resolveSource(sources[i])));
			return [...new Set(keys)];
		}
	}, propTraps);
	const sourcesMap = {};
	const defined = Object.create(null);
	for (let i = sources.length - 1; i >= 0; i--) {
		const source = sources[i];
		if (!source) continue;
		const sourceKeys = Object.getOwnPropertyNames(source);
		for (let i = sourceKeys.length - 1; i >= 0; i--) {
			const key = sourceKeys[i];
			if (key === "__proto__" || key === "constructor") continue;
			const desc = Object.getOwnPropertyDescriptor(source, key);
			if (!defined[key]) defined[key] = desc.get ? {
				enumerable: true,
				configurable: true,
				get: resolveSources.bind(sourcesMap[key] = [desc.get.bind(source)])
			} : desc.value !== void 0 ? desc : void 0;
			else {
				const sources = sourcesMap[key];
				if (sources) {
					if (desc.get) sources.push(desc.get.bind(source));
					else if (desc.value !== void 0) sources.push(() => desc.value);
				}
			}
		}
	}
	const target = {};
	const definedKeys = Object.keys(defined);
	for (let i = definedKeys.length - 1; i >= 0; i--) {
		const key = definedKeys[i], desc = defined[key];
		if (desc && desc.get) Object.defineProperty(target, key, desc);
		else target[key] = desc ? desc.value : void 0;
	}
	return target;
}
function splitProps(props, ...keys) {
	const len = keys.length;
	if (SUPPORTS_PROXY && $PROXY in props) {
		const blocked = len > 1 ? keys.flat() : keys[0];
		const res = keys.map((k) => {
			return new Proxy({
				get(property) {
					return k.includes(property) ? props[property] : void 0;
				},
				has(property) {
					return k.includes(property) && property in props;
				},
				keys() {
					return k.filter((property) => property in props);
				}
			}, propTraps);
		});
		res.push(new Proxy({
			get(property) {
				return blocked.includes(property) ? void 0 : props[property];
			},
			has(property) {
				return blocked.includes(property) ? false : property in props;
			},
			keys() {
				return Object.keys(props).filter((k) => !blocked.includes(k));
			}
		}, propTraps));
		return res;
	}
	const objects = [];
	for (let i = 0; i <= len; i++) objects[i] = {};
	for (const propName of Object.getOwnPropertyNames(props)) {
		let keyIndex = len;
		for (let i = 0; i < keys.length; i++) if (keys[i].includes(propName)) {
			keyIndex = i;
			break;
		}
		const desc = Object.getOwnPropertyDescriptor(props, propName);
		!desc.get && !desc.set && desc.enumerable && desc.writable && desc.configurable ? objects[keyIndex][propName] = desc.value : Object.defineProperty(objects[keyIndex], propName, desc);
	}
	return objects;
}
function lazy(fn) {
	let comp;
	let p;
	const wrap = (props) => {
		const ctx = sharedConfig.context;
		if (ctx) {
			const [s, set] = createSignal();
			sharedConfig.count || (sharedConfig.count = 0);
			sharedConfig.count++;
			(p || (p = fn())).then((mod) => {
				!sharedConfig.done && setHydrateContext(ctx);
				sharedConfig.count--;
				set(() => mod.default);
				setHydrateContext();
			});
			comp = s;
		} else if (!comp) {
			const [s] = createResource(() => (p || (p = fn())).then((mod) => mod.default));
			comp = s;
		}
		let Comp;
		return createMemo(() => (Comp = comp()) ? untrack(() => {
			if (!ctx || sharedConfig.done) return Comp(props);
			const c = sharedConfig.context;
			setHydrateContext(ctx);
			const r = Comp(props);
			setHydrateContext(c);
			return r;
		}) : "");
	};
	wrap.preload = () => p || ((p = fn()).then((mod) => comp = () => mod.default), p);
	return wrap;
}
var counter = 0;
function createUniqueId() {
	return sharedConfig.context ? sharedConfig.getNextContextId() : `cl-${counter++}`;
}
var narrowedError = (name) => `Stale read from <${name}>.`;
function For(props) {
	const fallback = "fallback" in props && { fallback: () => props.fallback };
	return createMemo(mapArray(() => props.each, props.children, fallback || void 0));
}
function Show(props) {
	const keyed = props.keyed;
	const conditionValue = createMemo(() => props.when, void 0, void 0);
	const condition = keyed ? conditionValue : createMemo(conditionValue, void 0, { equals: (a, b) => !a === !b });
	return createMemo(() => {
		const c = condition();
		if (c) {
			const child = props.children;
			return typeof child === "function" && child.length > 0 ? untrack(() => child(keyed ? c : () => {
				if (!untrack(condition)) throw narrowedError("Show");
				return conditionValue();
			})) : child;
		}
		return props.fallback;
	}, void 0, void 0);
}
function Switch(props) {
	const chs = children(() => props.children);
	const switchFunc = createMemo(() => {
		const ch = chs();
		const mps = Array.isArray(ch) ? ch : [ch];
		let func = () => void 0;
		for (let i = 0; i < mps.length; i++) {
			const index = i;
			const mp = mps[i];
			const prevFunc = func;
			const conditionValue = createMemo(() => prevFunc() ? void 0 : mp.when, void 0, void 0);
			const condition = mp.keyed ? conditionValue : createMemo(conditionValue, void 0, { equals: (a, b) => !a === !b });
			func = () => prevFunc() || (condition() ? [
				index,
				conditionValue,
				mp
			] : void 0);
		}
		return func;
	});
	return createMemo(() => {
		const sel = switchFunc()();
		if (!sel) return props.fallback;
		const [index, conditionValue, mp] = sel;
		const child = mp.children;
		return typeof child === "function" && child.length > 0 ? untrack(() => child(mp.keyed ? conditionValue() : () => {
			if (untrack(switchFunc)()?.[0] !== index) throw narrowedError("Match");
			return conditionValue();
		})) : child;
	}, void 0, void 0);
}
function Match(props) {
	return props;
}
var Properties = /* @__PURE__ */ new Set([
	"className",
	"value",
	"readOnly",
	"noValidate",
	"formNoValidate",
	"isMap",
	"noModule",
	"playsInline",
	"adAuctionHeaders",
	"allowFullscreen",
	"browsingTopics",
	"defaultChecked",
	"defaultMuted",
	"defaultSelected",
	"disablePictureInPicture",
	"disableRemotePlayback",
	"preservesPitch",
	"shadowRootClonable",
	"shadowRootCustomElementRegistry",
	"shadowRootDelegatesFocus",
	"shadowRootSerializable",
	"sharedStorageWritable",
	...[
		"allowfullscreen",
		"async",
		"alpha",
		"autofocus",
		"autoplay",
		"checked",
		"controls",
		"default",
		"disabled",
		"formnovalidate",
		"hidden",
		"indeterminate",
		"inert",
		"ismap",
		"loop",
		"multiple",
		"muted",
		"nomodule",
		"novalidate",
		"open",
		"playsinline",
		"readonly",
		"required",
		"reversed",
		"seamless",
		"selected",
		"adauctionheaders",
		"browsingtopics",
		"credentialless",
		"defaultchecked",
		"defaultmuted",
		"defaultselected",
		"defer",
		"disablepictureinpicture",
		"disableremoteplayback",
		"preservespitch",
		"shadowrootclonable",
		"shadowrootcustomelementregistry",
		"shadowrootdelegatesfocus",
		"shadowrootserializable",
		"sharedstoragewritable"
	]
]);
var ChildProperties = /* @__PURE__ */ new Set([
	"innerHTML",
	"textContent",
	"innerText",
	"children"
]);
var Aliases = /* @__PURE__ */ Object.assign(Object.create(null), {
	className: "class",
	htmlFor: "for"
});
var PropAliases = /* @__PURE__ */ Object.assign(Object.create(null), {
	class: "className",
	novalidate: {
		$: "noValidate",
		FORM: 1
	},
	formnovalidate: {
		$: "formNoValidate",
		BUTTON: 1,
		INPUT: 1
	},
	ismap: {
		$: "isMap",
		IMG: 1
	},
	nomodule: {
		$: "noModule",
		SCRIPT: 1
	},
	playsinline: {
		$: "playsInline",
		VIDEO: 1
	},
	readonly: {
		$: "readOnly",
		INPUT: 1,
		TEXTAREA: 1
	},
	adauctionheaders: {
		$: "adAuctionHeaders",
		IFRAME: 1
	},
	allowfullscreen: {
		$: "allowFullscreen",
		IFRAME: 1
	},
	browsingtopics: {
		$: "browsingTopics",
		IMG: 1
	},
	defaultchecked: {
		$: "defaultChecked",
		INPUT: 1
	},
	defaultmuted: {
		$: "defaultMuted",
		AUDIO: 1,
		VIDEO: 1
	},
	defaultselected: {
		$: "defaultSelected",
		OPTION: 1
	},
	disablepictureinpicture: {
		$: "disablePictureInPicture",
		VIDEO: 1
	},
	disableremoteplayback: {
		$: "disableRemotePlayback",
		AUDIO: 1,
		VIDEO: 1
	},
	preservespitch: {
		$: "preservesPitch",
		AUDIO: 1,
		VIDEO: 1
	},
	shadowrootclonable: {
		$: "shadowRootClonable",
		TEMPLATE: 1
	},
	shadowrootdelegatesfocus: {
		$: "shadowRootDelegatesFocus",
		TEMPLATE: 1
	},
	shadowrootserializable: {
		$: "shadowRootSerializable",
		TEMPLATE: 1
	},
	sharedstoragewritable: {
		$: "sharedStorageWritable",
		IFRAME: 1,
		IMG: 1
	}
});
function getPropAlias(prop, tagName) {
	const a = PropAliases[prop];
	return typeof a === "object" ? a[tagName] ? a["$"] : void 0 : a;
}
var DelegatedEvents = /* @__PURE__ */ new Set([
	"beforeinput",
	"click",
	"dblclick",
	"contextmenu",
	"focusin",
	"focusout",
	"input",
	"keydown",
	"keyup",
	"mousedown",
	"mousemove",
	"mouseout",
	"mouseover",
	"mouseup",
	"pointerdown",
	"pointermove",
	"pointerout",
	"pointerover",
	"pointerup",
	"touchend",
	"touchmove",
	"touchstart"
]);
var SVGElements = /* @__PURE__ */ new Set([
	"altGlyph",
	"altGlyphDef",
	"altGlyphItem",
	"animate",
	"animateColor",
	"animateMotion",
	"animateTransform",
	"circle",
	"clipPath",
	"color-profile",
	"cursor",
	"defs",
	"desc",
	"ellipse",
	"feBlend",
	"feColorMatrix",
	"feComponentTransfer",
	"feComposite",
	"feConvolveMatrix",
	"feDiffuseLighting",
	"feDisplacementMap",
	"feDistantLight",
	"feDropShadow",
	"feFlood",
	"feFuncA",
	"feFuncB",
	"feFuncG",
	"feFuncR",
	"feGaussianBlur",
	"feImage",
	"feMerge",
	"feMergeNode",
	"feMorphology",
	"feOffset",
	"fePointLight",
	"feSpecularLighting",
	"feSpotLight",
	"feTile",
	"feTurbulence",
	"filter",
	"font",
	"font-face",
	"font-face-format",
	"font-face-name",
	"font-face-src",
	"font-face-uri",
	"foreignObject",
	"g",
	"glyph",
	"glyphRef",
	"hkern",
	"image",
	"line",
	"linearGradient",
	"marker",
	"mask",
	"metadata",
	"missing-glyph",
	"mpath",
	"path",
	"pattern",
	"polygon",
	"polyline",
	"radialGradient",
	"rect",
	"set",
	"stop",
	"svg",
	"switch",
	"symbol",
	"text",
	"textPath",
	"tref",
	"tspan",
	"use",
	"view",
	"vkern"
]);
var SVGNamespace = {
	xlink: "http://www.w3.org/1999/xlink",
	xml: "http://www.w3.org/XML/1998/namespace"
};
var memo = (fn) => createMemo(() => fn());
function reconcileArrays(parentNode, a, b) {
	let bLength = b.length, aEnd = a.length, bEnd = bLength, aStart = 0, bStart = 0, after = a[aEnd - 1].nextSibling, map = null;
	while (aStart < aEnd || bStart < bEnd) {
		if (a[aStart] === b[bStart]) {
			aStart++;
			bStart++;
			continue;
		}
		while (a[aEnd - 1] === b[bEnd - 1]) {
			aEnd--;
			bEnd--;
		}
		if (aEnd === aStart) {
			const node = bEnd < bLength ? bStart ? b[bStart - 1].nextSibling : b[bEnd - bStart] : after;
			while (bStart < bEnd) parentNode.insertBefore(b[bStart++], node);
		} else if (bEnd === bStart) while (aStart < aEnd) {
			if (!map || !map.has(a[aStart])) a[aStart].remove();
			aStart++;
		}
		else if (a[aStart] === b[bEnd - 1] && b[bStart] === a[aEnd - 1]) {
			const node = a[--aEnd].nextSibling;
			parentNode.insertBefore(b[bStart++], a[aStart++].nextSibling);
			parentNode.insertBefore(b[--bEnd], node);
			a[aEnd] = b[bEnd];
		} else {
			if (!map) {
				map = /* @__PURE__ */ new Map();
				let i = bStart;
				while (i < bEnd) map.set(b[i], i++);
			}
			const index = map.get(a[aStart]);
			if (index != null) if (bStart < index && index < bEnd) {
				let i = aStart, sequence = 1, t;
				while (++i < aEnd && i < bEnd) {
					if ((t = map.get(a[i])) == null || t !== index + sequence) break;
					sequence++;
				}
				if (sequence > index - bStart) {
					const node = a[aStart];
					while (bStart < index) parentNode.insertBefore(b[bStart++], node);
				} else parentNode.replaceChild(b[bStart++], a[aStart++]);
			} else aStart++;
			else a[aStart++].remove();
		}
	}
}
var $$EVENTS = "_$DX_DELEGATE";
function render(code, element, init, options = {}) {
	let disposer;
	createRoot((dispose) => {
		disposer = dispose;
		element === document ? code() : insert(element, code(), element.firstChild ? null : void 0, init);
	}, options.owner);
	return () => {
		disposer();
		element.textContent = "";
	};
}
function template(html, isImportNode, isSVG, isMathML) {
	let node;
	const create = () => {
		const t = isMathML ? document.createElementNS("http://www.w3.org/1998/Math/MathML", "template") : document.createElement("template");
		t.innerHTML = html;
		return isSVG ? t.content.firstChild.firstChild : isMathML ? t.firstChild : t.content.firstChild;
	};
	const fn = isImportNode ? () => untrack(() => document.importNode(node || (node = create()), true)) : () => (node || (node = create())).cloneNode(true);
	fn.cloneNode = fn;
	return fn;
}
function delegateEvents(eventNames, document = window.document) {
	const e = document[$$EVENTS] || (document[$$EVENTS] = /* @__PURE__ */ new Set());
	for (let i = 0, l = eventNames.length; i < l; i++) {
		const name = eventNames[i];
		if (!e.has(name)) {
			e.add(name);
			document.addEventListener(name, eventHandler);
		}
	}
}
function setAttribute(node, name, value) {
	if (isHydrating(node)) return;
	if (value == null) node.removeAttribute(name);
	else node.setAttribute(name, value);
}
function setAttributeNS(node, namespace, name, value) {
	if (isHydrating(node)) return;
	if (value == null) node.removeAttributeNS(namespace, name);
	else node.setAttributeNS(namespace, name, value);
}
function setBoolAttribute(node, name, value) {
	if (isHydrating(node)) return;
	value ? node.setAttribute(name, "") : node.removeAttribute(name);
}
function className(node, value) {
	if (isHydrating(node)) return;
	if (value == null) node.removeAttribute("class");
	else node.className = value;
}
function addEventListener(node, name, handler, delegate) {
	if (delegate) if (Array.isArray(handler)) {
		node[`$$${name}`] = handler[0];
		node[`$$${name}Data`] = handler[1];
	} else node[`$$${name}`] = handler;
	else if (Array.isArray(handler)) {
		const handlerFn = handler[0];
		node.addEventListener(name, handler[0] = (e) => handlerFn.call(node, handler[1], e));
	} else node.addEventListener(name, handler, typeof handler !== "function" && handler);
}
function classList(node, value, prev = {}) {
	const classKeys = Object.keys(value || {}), prevKeys = Object.keys(prev);
	let i, len;
	for (i = 0, len = prevKeys.length; i < len; i++) {
		const key = prevKeys[i];
		if (!key || key === "undefined" || value[key]) continue;
		toggleClassKey(node, key, false);
		delete prev[key];
	}
	for (i = 0, len = classKeys.length; i < len; i++) {
		const key = classKeys[i], classValue = !!value[key];
		if (!key || key === "undefined" || prev[key] === classValue || !classValue) continue;
		toggleClassKey(node, key, true);
		prev[key] = classValue;
	}
	return prev;
}
function style(node, value, prev) {
	if (!value) return prev ? setAttribute(node, "style") : value;
	const nodeStyle = node.style;
	if (typeof value === "string") return nodeStyle.cssText = value;
	typeof prev === "string" && (nodeStyle.cssText = prev = void 0);
	prev || (prev = {});
	value || (value = {});
	let v, s;
	for (s in prev) {
		value[s] ?? nodeStyle.removeProperty(s);
		delete prev[s];
	}
	for (s in value) {
		v = value[s];
		if (v !== prev[s]) {
			nodeStyle.setProperty(s, v);
			prev[s] = v;
		}
	}
	return prev;
}
function spread(node, props = {}, isSVG, skipChildren) {
	const prevProps = {};
	if (!skipChildren) createRenderEffect(() => prevProps.children = insertExpression(node, props.children, prevProps.children));
	createRenderEffect(() => typeof props.ref === "function" && use(props.ref, node));
	createRenderEffect(() => assign(node, props, isSVG, true, prevProps, true));
	return prevProps;
}
function use(fn, element, arg) {
	return untrack(() => fn(element, arg));
}
function insert(parent, accessor, marker, initial) {
	if (marker !== void 0 && !initial) initial = [];
	if (typeof accessor !== "function") return insertExpression(parent, accessor, initial, marker);
	createRenderEffect((current) => insertExpression(parent, accessor(), current, marker), initial);
}
function assign(node, props, isSVG, skipChildren, prevProps = {}, skipRef = false) {
	props || (props = {});
	for (const prop in prevProps) if (!(prop in props)) {
		if (prop === "children") continue;
		prevProps[prop] = assignProp(node, prop, null, prevProps[prop], isSVG, skipRef, props);
	}
	for (const prop in props) {
		if (prop === "children") {
			if (!skipChildren) insertExpression(node, props.children);
			continue;
		}
		const value = props[prop];
		prevProps[prop] = assignProp(node, prop, value, prevProps[prop], isSVG, skipRef, props);
	}
}
function getNextElement(template) {
	let node, key;
	if (!isHydrating() || !(node = sharedConfig.registry.get(key = getHydrationKey()))) return template();
	if (sharedConfig.completed) sharedConfig.completed.add(node);
	sharedConfig.registry.delete(key);
	return node;
}
function isHydrating(node) {
	return !!sharedConfig.context && !sharedConfig.done && (!node || node.isConnected);
}
function toPropertyName(name) {
	return name.toLowerCase().replace(/-([a-z])/g, (_, w) => w.toUpperCase());
}
function toggleClassKey(node, key, value) {
	const classNames = key.trim().split(/\s+/);
	for (let i = 0, nameLen = classNames.length; i < nameLen; i++) node.classList.toggle(classNames[i], value);
}
function assignProp(node, prop, value, prev, isSVG, skipRef, props) {
	let isCE, isProp, isChildProp, propAlias, forceProp;
	if (prop === "style") return style(node, value, prev);
	if (prop === "classList") return classList(node, value, prev);
	if (value === prev) return prev;
	if (prop === "ref") {
		if (!skipRef) value(node);
	} else if (prop.slice(0, 3) === "on:") {
		const e = prop.slice(3);
		prev && node.removeEventListener(e, prev, typeof prev !== "function" && prev);
		value && node.addEventListener(e, value, typeof value !== "function" && value);
	} else if (prop.slice(0, 10) === "oncapture:") {
		const e = prop.slice(10);
		prev && node.removeEventListener(e, prev, true);
		value && node.addEventListener(e, value, true);
	} else if (prop.slice(0, 2) === "on") {
		const name = prop.slice(2).toLowerCase();
		const delegate = DelegatedEvents.has(name);
		if (!delegate && prev) {
			const h = Array.isArray(prev) ? prev[0] : prev;
			node.removeEventListener(name, h);
		}
		if (delegate || value) {
			addEventListener(node, name, value, delegate);
			delegate && delegateEvents([name]);
		}
	} else if (prop.slice(0, 5) === "attr:") setAttribute(node, prop.slice(5), value);
	else if (prop.slice(0, 5) === "bool:") setBoolAttribute(node, prop.slice(5), value);
	else if ((forceProp = prop.slice(0, 5) === "prop:") || (isChildProp = ChildProperties.has(prop)) || !isSVG && ((propAlias = getPropAlias(prop, node.tagName)) || (isProp = Properties.has(prop))) || (isCE = node.nodeName.includes("-") || "is" in props)) {
		if (forceProp) {
			prop = prop.slice(5);
			isProp = true;
		} else if (isHydrating(node)) return value;
		if (prop === "class" || prop === "className") className(node, value);
		else if (isCE && !isProp && !isChildProp) node[toPropertyName(prop)] = value;
		else node[propAlias || prop] = value;
	} else {
		const ns = isSVG && prop.indexOf(":") > -1 && SVGNamespace[prop.split(":")[0]];
		if (ns) setAttributeNS(node, ns, prop, value);
		else setAttribute(node, Aliases[prop] || prop, value);
	}
	return value;
}
function eventHandler(e) {
	if (sharedConfig.registry && sharedConfig.events) {
		if (sharedConfig.events.find(([el, ev]) => ev === e)) return;
	}
	let node = e.target;
	const key = `$$${e.type}`;
	const oriTarget = e.target;
	const oriCurrentTarget = e.currentTarget;
	const retarget = (value) => Object.defineProperty(e, "target", {
		configurable: true,
		value
	});
	const handleNode = () => {
		const handler = node[key];
		if (handler && !node.disabled) {
			const data = node[`${key}Data`];
			data !== void 0 ? handler.call(node, data, e) : handler.call(node, e);
			if (e.cancelBubble) return;
		}
		node.host && typeof node.host !== "string" && !node.host._$host && node.contains(e.target) && retarget(node.host);
		return true;
	};
	const walkUpTree = () => {
		while (handleNode() && (node = node._$host || node.parentNode || node.host));
	};
	Object.defineProperty(e, "currentTarget", {
		configurable: true,
		get() {
			return node || document;
		}
	});
	if (sharedConfig.registry && !sharedConfig.done) sharedConfig.done = _$HY.done = true;
	if (e.composedPath) {
		const path = e.composedPath();
		retarget(path[0]);
		for (let i = 0; i < path.length - 2; i++) {
			node = path[i];
			if (!handleNode()) break;
			if (node._$host) {
				node = node._$host;
				walkUpTree();
				break;
			}
			if (node.parentNode === oriCurrentTarget) break;
		}
	} else walkUpTree();
	retarget(oriTarget);
}
function insertExpression(parent, value, current, marker, unwrapArray) {
	const hydrating = isHydrating(parent);
	if (hydrating) {
		!current && (current = [...parent.childNodes]);
		let cleaned = [];
		for (let i = 0; i < current.length; i++) {
			const node = current[i];
			if (node.nodeType === 8 && node.data.slice(0, 2) === "!$") node.remove();
			else cleaned.push(node);
		}
		current = cleaned;
	}
	while (typeof current === "function") current = current();
	if (value === current) return current;
	const t = typeof value, multi = marker !== void 0;
	parent = multi && current[0] && current[0].parentNode || parent;
	if (t === "string" || t === "number") {
		if (hydrating) return current;
		if (t === "number") {
			value = value.toString();
			if (value === current) return current;
		}
		if (multi) {
			let node = current[0];
			if (node && node.nodeType === 3) node.data !== value && (node.data = value);
			else node = document.createTextNode(value);
			current = cleanChildren(parent, current, marker, node);
		} else if (current !== "" && typeof current === "string") current = parent.firstChild.data = value;
		else current = parent.textContent = value;
	} else if (value == null || t === "boolean") {
		if (hydrating) return current;
		current = cleanChildren(parent, current, marker);
	} else if (t === "function") {
		createRenderEffect(() => {
			let v = value();
			while (typeof v === "function") v = v();
			current = insertExpression(parent, v, current, marker);
		});
		return () => current;
	} else if (Array.isArray(value)) {
		const array = [];
		const currentArray = current && Array.isArray(current);
		if (normalizeIncomingArray(array, value, current, unwrapArray)) {
			createRenderEffect(() => current = insertExpression(parent, array, current, marker, true));
			return () => current;
		}
		if (hydrating) {
			if (!array.length) return current;
			if (marker === void 0) return current = [...parent.childNodes];
			let node = array[0];
			if (node.parentNode !== parent) return current;
			const nodes = [node];
			while ((node = node.nextSibling) !== marker) nodes.push(node);
			return current = nodes;
		}
		if (array.length === 0) {
			current = cleanChildren(parent, current, marker);
			if (multi) return current;
		} else if (currentArray) if (current.length === 0) appendNodes(parent, array, marker);
		else reconcileArrays(parent, current, array);
		else {
			current && cleanChildren(parent);
			appendNodes(parent, array);
		}
		current = array;
	} else if (value.nodeType) {
		if (hydrating && value.parentNode) return current = multi ? [value] : value;
		if (Array.isArray(current)) {
			if (multi) return current = cleanChildren(parent, current, marker, value);
			cleanChildren(parent, current, null, value);
		} else if (current == null || current === "" || !parent.firstChild) parent.appendChild(value);
		else parent.replaceChild(value, parent.firstChild);
		current = value;
	}
	return current;
}
function normalizeIncomingArray(normalized, array, current, unwrap) {
	let dynamic = false;
	for (let i = 0, len = array.length; i < len; i++) {
		let item = array[i], prev = current && current[normalized.length], t;
		if (item == null || item === true || item === false);
		else if ((t = typeof item) === "object" && item.nodeType) normalized.push(item);
		else if (Array.isArray(item)) dynamic = normalizeIncomingArray(normalized, item, prev) || dynamic;
		else if (t === "function") if (unwrap) {
			while (typeof item === "function") item = item();
			dynamic = normalizeIncomingArray(normalized, Array.isArray(item) ? item : [item], Array.isArray(prev) ? prev : [prev]) || dynamic;
		} else {
			normalized.push(item);
			dynamic = true;
		}
		else {
			const value = String(item);
			if (prev && prev.nodeType === 3 && prev.data === value) normalized.push(prev);
			else normalized.push(document.createTextNode(value));
		}
	}
	return dynamic;
}
function appendNodes(parent, array, marker = null) {
	for (let i = 0, len = array.length; i < len; i++) parent.insertBefore(array[i], marker);
}
function cleanChildren(parent, current, marker, replacement) {
	if (marker === void 0) return parent.textContent = "";
	const node = replacement || document.createTextNode("");
	if (current.length) {
		let inserted = false;
		for (let i = current.length - 1; i >= 0; i--) {
			const el = current[i];
			if (node !== el) {
				const isParent = el.parentNode === parent;
				if (!inserted && !i) isParent ? parent.replaceChild(node, el) : parent.insertBefore(node, marker);
				else isParent && el.remove();
			} else inserted = true;
		}
	} else parent.insertBefore(node, marker);
	return [node];
}
function getHydrationKey() {
	return sharedConfig.getNextContextId();
}
var SVG_NAMESPACE = "http://www.w3.org/2000/svg";
function createElement(tagName, isSVG = false, is = void 0) {
	return isSVG ? document.createElementNS(SVG_NAMESPACE, tagName) : document.createElement(tagName, { is });
}
function createDynamic(component, props) {
	const cached = createMemo(component);
	return createMemo(() => {
		const component = cached();
		switch (typeof component) {
			case "function": return untrack(() => component(props));
			case "string":
				const isSvg = SVGElements.has(component);
				const el = sharedConfig.context ? getNextElement() : createElement(component, isSvg, untrack(() => props.is));
				spread(el, props, isSvg);
				return el;
		}
	});
}
function Dynamic(props) {
	const [, others] = splitProps(props, ["component"]);
	return createDynamic(() => props.component, others);
}
var ShadowDomTargetContext = createContext(void 0);
var DevtoolsOnCloseContext = createContext(void 0);
var useDevtoolsOnClose = () => {
	const context = useContext(DevtoolsOnCloseContext);
	if (!context) throw new Error("useDevtoolsOnClose must be used within a TanStackRouterDevtools component");
	return context;
};
//#endregion
export { setAttribute as C, useContext as D, untrack as E, useDevtoolsOnClose as O, render as S, template as T, insert as _, ShadowDomTargetContext as a, mergeProps as b, addEventListener as c, createEffect as d, createMemo as f, delegateEvents as g, createUniqueId as h, Match as i, className as l, createSignal as m, Dynamic as n, Show as o, createRenderEffect as p, For as r, Switch as s, DevtoolsOnCloseContext as t, createComponent as u, lazy as v, spread as w, onCleanup as x, memo as y };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGV4dC1EZTJFQjFBQS1DVlVuc3hYZC5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi8ucG5wbS9AdGFuc3RhY2srcm91dGVyLWRldnRvb2xzLWNfZWViNjMwNTY5YmMzMjkyM2Y5MjcxYTA4YWM1MGY4MzQvbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yb3V0ZXItZGV2dG9vbHMtY29yZS9kaXN0L2NvbnRleHQtRGUyRUIxQUEuanMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zb2xpZC1qc0AxLjkuMTIvbm9kZV9tb2R1bGVzL3NvbGlkLWpzL2Rpc3Qvc29saWQuanNcbnZhciBzaGFyZWRDb25maWcgPSB7XG5cdGNvbnRleHQ6IHZvaWQgMCxcblx0cmVnaXN0cnk6IHZvaWQgMCxcblx0ZWZmZWN0czogdm9pZCAwLFxuXHRkb25lOiBmYWxzZSxcblx0Z2V0Q29udGV4dElkKCkge1xuXHRcdHJldHVybiBnZXRDb250ZXh0SWQodGhpcy5jb250ZXh0LmNvdW50KTtcblx0fSxcblx0Z2V0TmV4dENvbnRleHRJZCgpIHtcblx0XHRyZXR1cm4gZ2V0Q29udGV4dElkKHRoaXMuY29udGV4dC5jb3VudCsrKTtcblx0fVxufTtcbmZ1bmN0aW9uIGdldENvbnRleHRJZChjb3VudCkge1xuXHRjb25zdCBudW0gPSBTdHJpbmcoY291bnQpLCBsZW4gPSBudW0ubGVuZ3RoIC0gMTtcblx0cmV0dXJuIHNoYXJlZENvbmZpZy5jb250ZXh0LmlkICsgKGxlbiA/IFN0cmluZy5mcm9tQ2hhckNvZGUoOTYgKyBsZW4pIDogXCJcIikgKyBudW07XG59XG5mdW5jdGlvbiBzZXRIeWRyYXRlQ29udGV4dChjb250ZXh0KSB7XG5cdHNoYXJlZENvbmZpZy5jb250ZXh0ID0gY29udGV4dDtcbn1cbmZ1bmN0aW9uIG5leHRIeWRyYXRlQ29udGV4dCgpIHtcblx0cmV0dXJuIHtcblx0XHQuLi5zaGFyZWRDb25maWcuY29udGV4dCxcblx0XHRpZDogc2hhcmVkQ29uZmlnLmdldE5leHRDb250ZXh0SWQoKSxcblx0XHRjb3VudDogMFxuXHR9O1xufVxudmFyIGVxdWFsRm4gPSAoYSwgYikgPT4gYSA9PT0gYjtcbnZhciAkUFJPWFkgPSBTeW1ib2woXCJzb2xpZC1wcm94eVwiKTtcbnZhciBTVVBQT1JUU19QUk9YWSA9IHR5cGVvZiBQcm94eSA9PT0gXCJmdW5jdGlvblwiO1xudmFyICRUUkFDSyA9IFN5bWJvbChcInNvbGlkLXRyYWNrXCIpO1xudmFyIHNpZ25hbE9wdGlvbnMgPSB7IGVxdWFsczogZXF1YWxGbiB9O1xudmFyIEVSUk9SID0gbnVsbDtcbnZhciBydW5FZmZlY3RzID0gcnVuUXVldWU7XG52YXIgU1RBTEUgPSAxO1xudmFyIFBFTkRJTkcgPSAyO1xudmFyIFVOT1dORUQgPSB7XG5cdG93bmVkOiBudWxsLFxuXHRjbGVhbnVwczogbnVsbCxcblx0Y29udGV4dDogbnVsbCxcblx0b3duZXI6IG51bGxcbn07XG52YXIgTk9fSU5JVCA9IHt9O1xudmFyIE93bmVyID0gbnVsbDtcbnZhciBUcmFuc2l0aW9uID0gbnVsbDtcbnZhciBTY2hlZHVsZXIgPSBudWxsO1xudmFyIEV4dGVybmFsU291cmNlQ29uZmlnID0gbnVsbDtcbnZhciBMaXN0ZW5lciA9IG51bGw7XG52YXIgVXBkYXRlcyA9IG51bGw7XG52YXIgRWZmZWN0cyA9IG51bGw7XG52YXIgRXhlY0NvdW50ID0gMDtcbmZ1bmN0aW9uIGNyZWF0ZVJvb3QoZm4sIGRldGFjaGVkT3duZXIpIHtcblx0Y29uc3QgbGlzdGVuZXIgPSBMaXN0ZW5lciwgb3duZXIgPSBPd25lciwgdW5vd25lZCA9IGZuLmxlbmd0aCA9PT0gMCwgY3VycmVudCA9IGRldGFjaGVkT3duZXIgPT09IHZvaWQgMCA/IG93bmVyIDogZGV0YWNoZWRPd25lciwgcm9vdCA9IHVub3duZWQgPyBVTk9XTkVEIDoge1xuXHRcdG93bmVkOiBudWxsLFxuXHRcdGNsZWFudXBzOiBudWxsLFxuXHRcdGNvbnRleHQ6IGN1cnJlbnQgPyBjdXJyZW50LmNvbnRleHQgOiBudWxsLFxuXHRcdG93bmVyOiBjdXJyZW50XG5cdH0sIHVwZGF0ZUZuID0gdW5vd25lZCA/IGZuIDogKCkgPT4gZm4oKCkgPT4gdW50cmFjaygoKSA9PiBjbGVhbk5vZGUocm9vdCkpKTtcblx0T3duZXIgPSByb290O1xuXHRMaXN0ZW5lciA9IG51bGw7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIHJ1blVwZGF0ZXModXBkYXRlRm4sIHRydWUpO1xuXHR9IGZpbmFsbHkge1xuXHRcdExpc3RlbmVyID0gbGlzdGVuZXI7XG5cdFx0T3duZXIgPSBvd25lcjtcblx0fVxufVxuZnVuY3Rpb24gY3JlYXRlU2lnbmFsKHZhbHVlLCBvcHRpb25zKSB7XG5cdG9wdGlvbnMgPSBvcHRpb25zID8gT2JqZWN0LmFzc2lnbih7fSwgc2lnbmFsT3B0aW9ucywgb3B0aW9ucykgOiBzaWduYWxPcHRpb25zO1xuXHRjb25zdCBzID0ge1xuXHRcdHZhbHVlLFxuXHRcdG9ic2VydmVyczogbnVsbCxcblx0XHRvYnNlcnZlclNsb3RzOiBudWxsLFxuXHRcdGNvbXBhcmF0b3I6IG9wdGlvbnMuZXF1YWxzIHx8IHZvaWQgMFxuXHR9O1xuXHRjb25zdCBzZXR0ZXIgPSAodmFsdWUpID0+IHtcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCIpIGlmIChUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZyAmJiBUcmFuc2l0aW9uLnNvdXJjZXMuaGFzKHMpKSB2YWx1ZSA9IHZhbHVlKHMudFZhbHVlKTtcblx0XHRlbHNlIHZhbHVlID0gdmFsdWUocy52YWx1ZSk7XG5cdFx0cmV0dXJuIHdyaXRlU2lnbmFsKHMsIHZhbHVlKTtcblx0fTtcblx0cmV0dXJuIFtyZWFkU2lnbmFsLmJpbmQocyksIHNldHRlcl07XG59XG5mdW5jdGlvbiBjcmVhdGVDb21wdXRlZChmbiwgdmFsdWUsIG9wdGlvbnMpIHtcblx0Y29uc3QgYyA9IGNyZWF0ZUNvbXB1dGF0aW9uKGZuLCB2YWx1ZSwgdHJ1ZSwgU1RBTEUpO1xuXHRpZiAoU2NoZWR1bGVyICYmIFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nKSBVcGRhdGVzLnB1c2goYyk7XG5cdGVsc2UgdXBkYXRlQ29tcHV0YXRpb24oYyk7XG59XG5mdW5jdGlvbiBjcmVhdGVSZW5kZXJFZmZlY3QoZm4sIHZhbHVlLCBvcHRpb25zKSB7XG5cdGNvbnN0IGMgPSBjcmVhdGVDb21wdXRhdGlvbihmbiwgdmFsdWUsIGZhbHNlLCBTVEFMRSk7XG5cdGlmIChTY2hlZHVsZXIgJiYgVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmcpIFVwZGF0ZXMucHVzaChjKTtcblx0ZWxzZSB1cGRhdGVDb21wdXRhdGlvbihjKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUVmZmVjdChmbiwgdmFsdWUsIG9wdGlvbnMpIHtcblx0cnVuRWZmZWN0cyA9IHJ1blVzZXJFZmZlY3RzO1xuXHRjb25zdCBjID0gY3JlYXRlQ29tcHV0YXRpb24oZm4sIHZhbHVlLCBmYWxzZSwgU1RBTEUpLCBzID0gU3VzcGVuc2VDb250ZXh0ICYmIHVzZUNvbnRleHQoU3VzcGVuc2VDb250ZXh0KTtcblx0aWYgKHMpIGMuc3VzcGVuc2UgPSBzO1xuXHRpZiAoIW9wdGlvbnMgfHwgIW9wdGlvbnMucmVuZGVyKSBjLnVzZXIgPSB0cnVlO1xuXHRFZmZlY3RzID8gRWZmZWN0cy5wdXNoKGMpIDogdXBkYXRlQ29tcHV0YXRpb24oYyk7XG59XG5mdW5jdGlvbiBjcmVhdGVNZW1vKGZuLCB2YWx1ZSwgb3B0aW9ucykge1xuXHRvcHRpb25zID0gb3B0aW9ucyA/IE9iamVjdC5hc3NpZ24oe30sIHNpZ25hbE9wdGlvbnMsIG9wdGlvbnMpIDogc2lnbmFsT3B0aW9ucztcblx0Y29uc3QgYyA9IGNyZWF0ZUNvbXB1dGF0aW9uKGZuLCB2YWx1ZSwgdHJ1ZSwgMCk7XG5cdGMub2JzZXJ2ZXJzID0gbnVsbDtcblx0Yy5vYnNlcnZlclNsb3RzID0gbnVsbDtcblx0Yy5jb21wYXJhdG9yID0gb3B0aW9ucy5lcXVhbHMgfHwgdm9pZCAwO1xuXHRpZiAoU2NoZWR1bGVyICYmIFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nKSB7XG5cdFx0Yy50U3RhdGUgPSBTVEFMRTtcblx0XHRVcGRhdGVzLnB1c2goYyk7XG5cdH0gZWxzZSB1cGRhdGVDb21wdXRhdGlvbihjKTtcblx0cmV0dXJuIHJlYWRTaWduYWwuYmluZChjKTtcbn1cbmZ1bmN0aW9uIGlzUHJvbWlzZSh2KSB7XG5cdHJldHVybiB2ICYmIHR5cGVvZiB2ID09PSBcIm9iamVjdFwiICYmIFwidGhlblwiIGluIHY7XG59XG5mdW5jdGlvbiBjcmVhdGVSZXNvdXJjZShwU291cmNlLCBwRmV0Y2hlciwgcE9wdGlvbnMpIHtcblx0bGV0IHNvdXJjZTtcblx0bGV0IGZldGNoZXI7XG5cdGxldCBvcHRpb25zO1xuXHRpZiAodHlwZW9mIHBGZXRjaGVyID09PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRzb3VyY2UgPSBwU291cmNlO1xuXHRcdGZldGNoZXIgPSBwRmV0Y2hlcjtcblx0XHRvcHRpb25zID0gcE9wdGlvbnMgfHwge307XG5cdH0gZWxzZSB7XG5cdFx0c291cmNlID0gdHJ1ZTtcblx0XHRmZXRjaGVyID0gcFNvdXJjZTtcblx0XHRvcHRpb25zID0gcEZldGNoZXIgfHwge307XG5cdH1cblx0bGV0IHByID0gbnVsbCwgaW5pdFAgPSBOT19JTklULCBpZCA9IG51bGwsIGxvYWRlZFVuZGVyVHJhbnNpdGlvbiA9IGZhbHNlLCBzY2hlZHVsZWQgPSBmYWxzZSwgcmVzb2x2ZWQgPSBcImluaXRpYWxWYWx1ZVwiIGluIG9wdGlvbnMsIGR5bmFtaWMgPSB0eXBlb2Ygc291cmNlID09PSBcImZ1bmN0aW9uXCIgJiYgY3JlYXRlTWVtbyhzb3VyY2UpO1xuXHRjb25zdCBjb250ZXh0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksIFt2YWx1ZSwgc2V0VmFsdWVdID0gKG9wdGlvbnMuc3RvcmFnZSB8fCBjcmVhdGVTaWduYWwpKG9wdGlvbnMuaW5pdGlhbFZhbHVlKSwgW2Vycm9yLCBzZXRFcnJvcl0gPSBjcmVhdGVTaWduYWwodm9pZCAwKSwgW3RyYWNrLCB0cmlnZ2VyXSA9IGNyZWF0ZVNpZ25hbCh2b2lkIDAsIHsgZXF1YWxzOiBmYWxzZSB9KSwgW3N0YXRlLCBzZXRTdGF0ZV0gPSBjcmVhdGVTaWduYWwocmVzb2x2ZWQgPyBcInJlYWR5XCIgOiBcInVucmVzb2x2ZWRcIik7XG5cdGlmIChzaGFyZWRDb25maWcuY29udGV4dCkge1xuXHRcdGlkID0gc2hhcmVkQ29uZmlnLmdldE5leHRDb250ZXh0SWQoKTtcblx0XHRpZiAob3B0aW9ucy5zc3JMb2FkRnJvbSA9PT0gXCJpbml0aWFsXCIpIGluaXRQID0gb3B0aW9ucy5pbml0aWFsVmFsdWU7XG5cdFx0ZWxzZSBpZiAoc2hhcmVkQ29uZmlnLmxvYWQgJiYgc2hhcmVkQ29uZmlnLmhhcyhpZCkpIGluaXRQID0gc2hhcmVkQ29uZmlnLmxvYWQoaWQpO1xuXHR9XG5cdGZ1bmN0aW9uIGxvYWRFbmQocCwgdiwgZXJyb3IsIGtleSkge1xuXHRcdGlmIChwciA9PT0gcCkge1xuXHRcdFx0cHIgPSBudWxsO1xuXHRcdFx0a2V5ICE9PSB2b2lkIDAgJiYgKHJlc29sdmVkID0gdHJ1ZSk7XG5cdFx0XHRpZiAoKHAgPT09IGluaXRQIHx8IHYgPT09IGluaXRQKSAmJiBvcHRpb25zLm9uSHlkcmF0ZWQpIHF1ZXVlTWljcm90YXNrKCgpID0+IG9wdGlvbnMub25IeWRyYXRlZChrZXksIHsgdmFsdWU6IHYgfSkpO1xuXHRcdFx0aW5pdFAgPSBOT19JTklUO1xuXHRcdFx0aWYgKFRyYW5zaXRpb24gJiYgcCAmJiBsb2FkZWRVbmRlclRyYW5zaXRpb24pIHtcblx0XHRcdFx0VHJhbnNpdGlvbi5wcm9taXNlcy5kZWxldGUocCk7XG5cdFx0XHRcdGxvYWRlZFVuZGVyVHJhbnNpdGlvbiA9IGZhbHNlO1xuXHRcdFx0XHRydW5VcGRhdGVzKCgpID0+IHtcblx0XHRcdFx0XHRUcmFuc2l0aW9uLnJ1bm5pbmcgPSB0cnVlO1xuXHRcdFx0XHRcdGNvbXBsZXRlTG9hZCh2LCBlcnJvcik7XG5cdFx0XHRcdH0sIGZhbHNlKTtcblx0XHRcdH0gZWxzZSBjb21wbGV0ZUxvYWQodiwgZXJyb3IpO1xuXHRcdH1cblx0XHRyZXR1cm4gdjtcblx0fVxuXHRmdW5jdGlvbiBjb21wbGV0ZUxvYWQodiwgZXJyKSB7XG5cdFx0cnVuVXBkYXRlcygoKSA9PiB7XG5cdFx0XHRpZiAoZXJyID09PSB2b2lkIDApIHNldFZhbHVlKCgpID0+IHYpO1xuXHRcdFx0c2V0U3RhdGUoZXJyICE9PSB2b2lkIDAgPyBcImVycm9yZWRcIiA6IHJlc29sdmVkID8gXCJyZWFkeVwiIDogXCJ1bnJlc29sdmVkXCIpO1xuXHRcdFx0c2V0RXJyb3IoZXJyKTtcblx0XHRcdGZvciAoY29uc3QgYyBvZiBjb250ZXh0cy5rZXlzKCkpIGMuZGVjcmVtZW50KCk7XG5cdFx0XHRjb250ZXh0cy5jbGVhcigpO1xuXHRcdH0sIGZhbHNlKTtcblx0fVxuXHRmdW5jdGlvbiByZWFkKCkge1xuXHRcdGNvbnN0IGMgPSBTdXNwZW5zZUNvbnRleHQgJiYgdXNlQ29udGV4dChTdXNwZW5zZUNvbnRleHQpLCB2ID0gdmFsdWUoKSwgZXJyID0gZXJyb3IoKTtcblx0XHRpZiAoZXJyICE9PSB2b2lkIDAgJiYgIXByKSB0aHJvdyBlcnI7XG5cdFx0aWYgKExpc3RlbmVyICYmICFMaXN0ZW5lci51c2VyICYmIGMpIGNyZWF0ZUNvbXB1dGVkKCgpID0+IHtcblx0XHRcdHRyYWNrKCk7XG5cdFx0XHRpZiAocHIpIHtcblx0XHRcdFx0aWYgKGMucmVzb2x2ZWQgJiYgVHJhbnNpdGlvbiAmJiBsb2FkZWRVbmRlclRyYW5zaXRpb24pIFRyYW5zaXRpb24ucHJvbWlzZXMuYWRkKHByKTtcblx0XHRcdFx0ZWxzZSBpZiAoIWNvbnRleHRzLmhhcyhjKSkge1xuXHRcdFx0XHRcdGMuaW5jcmVtZW50KCk7XG5cdFx0XHRcdFx0Y29udGV4dHMuYWRkKGMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0cmV0dXJuIHY7XG5cdH1cblx0ZnVuY3Rpb24gbG9hZChyZWZldGNoaW5nID0gdHJ1ZSkge1xuXHRcdGlmIChyZWZldGNoaW5nICE9PSBmYWxzZSAmJiBzY2hlZHVsZWQpIHJldHVybjtcblx0XHRzY2hlZHVsZWQgPSBmYWxzZTtcblx0XHRjb25zdCBsb29rdXAgPSBkeW5hbWljID8gZHluYW1pYygpIDogc291cmNlO1xuXHRcdGxvYWRlZFVuZGVyVHJhbnNpdGlvbiA9IFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nO1xuXHRcdGlmIChsb29rdXAgPT0gbnVsbCB8fCBsb29rdXAgPT09IGZhbHNlKSB7XG5cdFx0XHRsb2FkRW5kKHByLCB1bnRyYWNrKHZhbHVlKSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChUcmFuc2l0aW9uICYmIHByKSBUcmFuc2l0aW9uLnByb21pc2VzLmRlbGV0ZShwcik7XG5cdFx0bGV0IGVycm9yO1xuXHRcdGNvbnN0IHAgPSBpbml0UCAhPT0gTk9fSU5JVCA/IGluaXRQIDogdW50cmFjaygoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRyZXR1cm4gZmV0Y2hlcihsb29rdXAsIHtcblx0XHRcdFx0XHR2YWx1ZTogdmFsdWUoKSxcblx0XHRcdFx0XHRyZWZldGNoaW5nXG5cdFx0XHRcdH0pO1xuXHRcdFx0fSBjYXRjaCAoZmV0Y2hlckVycm9yKSB7XG5cdFx0XHRcdGVycm9yID0gZmV0Y2hlckVycm9yO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGlmIChlcnJvciAhPT0gdm9pZCAwKSB7XG5cdFx0XHRsb2FkRW5kKHByLCB2b2lkIDAsIGNhc3RFcnJvcihlcnJvciksIGxvb2t1cCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fSBlbHNlIGlmICghaXNQcm9taXNlKHApKSB7XG5cdFx0XHRsb2FkRW5kKHByLCBwLCB2b2lkIDAsIGxvb2t1cCk7XG5cdFx0XHRyZXR1cm4gcDtcblx0XHR9XG5cdFx0cHIgPSBwO1xuXHRcdGlmIChcInZcIiBpbiBwKSB7XG5cdFx0XHRpZiAocC5zID09PSAxKSBsb2FkRW5kKHByLCBwLnYsIHZvaWQgMCwgbG9va3VwKTtcblx0XHRcdGVsc2UgbG9hZEVuZChwciwgdm9pZCAwLCBjYXN0RXJyb3IocC52KSwgbG9va3VwKTtcblx0XHRcdHJldHVybiBwO1xuXHRcdH1cblx0XHRzY2hlZHVsZWQgPSB0cnVlO1xuXHRcdHF1ZXVlTWljcm90YXNrKCgpID0+IHNjaGVkdWxlZCA9IGZhbHNlKTtcblx0XHRydW5VcGRhdGVzKCgpID0+IHtcblx0XHRcdHNldFN0YXRlKHJlc29sdmVkID8gXCJyZWZyZXNoaW5nXCIgOiBcInBlbmRpbmdcIik7XG5cdFx0XHR0cmlnZ2VyKCk7XG5cdFx0fSwgZmFsc2UpO1xuXHRcdHJldHVybiBwLnRoZW4oKHYpID0+IGxvYWRFbmQocCwgdiwgdm9pZCAwLCBsb29rdXApLCAoZSkgPT4gbG9hZEVuZChwLCB2b2lkIDAsIGNhc3RFcnJvcihlKSwgbG9va3VwKSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnRpZXMocmVhZCwge1xuXHRcdHN0YXRlOiB7IGdldDogKCkgPT4gc3RhdGUoKSB9LFxuXHRcdGVycm9yOiB7IGdldDogKCkgPT4gZXJyb3IoKSB9LFxuXHRcdGxvYWRpbmc6IHsgZ2V0KCkge1xuXHRcdFx0Y29uc3QgcyA9IHN0YXRlKCk7XG5cdFx0XHRyZXR1cm4gcyA9PT0gXCJwZW5kaW5nXCIgfHwgcyA9PT0gXCJyZWZyZXNoaW5nXCI7XG5cdFx0fSB9LFxuXHRcdGxhdGVzdDogeyBnZXQoKSB7XG5cdFx0XHRpZiAoIXJlc29sdmVkKSByZXR1cm4gcmVhZCgpO1xuXHRcdFx0Y29uc3QgZXJyID0gZXJyb3IoKTtcblx0XHRcdGlmIChlcnIgJiYgIXByKSB0aHJvdyBlcnI7XG5cdFx0XHRyZXR1cm4gdmFsdWUoKTtcblx0XHR9IH1cblx0fSk7XG5cdGxldCBvd25lciA9IE93bmVyO1xuXHRpZiAoZHluYW1pYykgY3JlYXRlQ29tcHV0ZWQoKCkgPT4gKG93bmVyID0gT3duZXIsIGxvYWQoZmFsc2UpKSk7XG5cdGVsc2UgbG9hZChmYWxzZSk7XG5cdHJldHVybiBbcmVhZCwge1xuXHRcdHJlZmV0Y2g6IChpbmZvKSA9PiBydW5XaXRoT3duZXIob3duZXIsICgpID0+IGxvYWQoaW5mbykpLFxuXHRcdG11dGF0ZTogc2V0VmFsdWVcblx0fV07XG59XG5mdW5jdGlvbiB1bnRyYWNrKGZuKSB7XG5cdGlmICghRXh0ZXJuYWxTb3VyY2VDb25maWcgJiYgTGlzdGVuZXIgPT09IG51bGwpIHJldHVybiBmbigpO1xuXHRjb25zdCBsaXN0ZW5lciA9IExpc3RlbmVyO1xuXHRMaXN0ZW5lciA9IG51bGw7XG5cdHRyeSB7XG5cdFx0aWYgKEV4dGVybmFsU291cmNlQ29uZmlnKSByZXR1cm4gRXh0ZXJuYWxTb3VyY2VDb25maWcudW50cmFjayhmbik7XG5cdFx0cmV0dXJuIGZuKCk7XG5cdH0gZmluYWxseSB7XG5cdFx0TGlzdGVuZXIgPSBsaXN0ZW5lcjtcblx0fVxufVxuZnVuY3Rpb24gb25DbGVhbnVwKGZuKSB7XG5cdGlmIChPd25lciA9PT0gbnVsbCk7XG5cdGVsc2UgaWYgKE93bmVyLmNsZWFudXBzID09PSBudWxsKSBPd25lci5jbGVhbnVwcyA9IFtmbl07XG5cdGVsc2UgT3duZXIuY2xlYW51cHMucHVzaChmbik7XG5cdHJldHVybiBmbjtcbn1cbmZ1bmN0aW9uIHJ1bldpdGhPd25lcihvLCBmbikge1xuXHRjb25zdCBwcmV2ID0gT3duZXI7XG5cdGNvbnN0IHByZXZMaXN0ZW5lciA9IExpc3RlbmVyO1xuXHRPd25lciA9IG87XG5cdExpc3RlbmVyID0gbnVsbDtcblx0dHJ5IHtcblx0XHRyZXR1cm4gcnVuVXBkYXRlcyhmbiwgdHJ1ZSk7XG5cdH0gY2F0Y2ggKGVycikge1xuXHRcdGhhbmRsZUVycm9yKGVycik7XG5cdH0gZmluYWxseSB7XG5cdFx0T3duZXIgPSBwcmV2O1xuXHRcdExpc3RlbmVyID0gcHJldkxpc3RlbmVyO1xuXHR9XG59XG5mdW5jdGlvbiBzdGFydFRyYW5zaXRpb24oZm4pIHtcblx0aWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nKSB7XG5cdFx0Zm4oKTtcblx0XHRyZXR1cm4gVHJhbnNpdGlvbi5kb25lO1xuXHR9XG5cdGNvbnN0IGwgPSBMaXN0ZW5lcjtcblx0Y29uc3QgbyA9IE93bmVyO1xuXHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiB7XG5cdFx0TGlzdGVuZXIgPSBsO1xuXHRcdE93bmVyID0gbztcblx0XHRsZXQgdDtcblx0XHRpZiAoU2NoZWR1bGVyIHx8IFN1c3BlbnNlQ29udGV4dCkge1xuXHRcdFx0dCA9IFRyYW5zaXRpb24gfHwgKFRyYW5zaXRpb24gPSB7XG5cdFx0XHRcdHNvdXJjZXM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG5cdFx0XHRcdGVmZmVjdHM6IFtdLFxuXHRcdFx0XHRwcm9taXNlczogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSxcblx0XHRcdFx0ZGlzcG9zZWQ6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG5cdFx0XHRcdHF1ZXVlOiAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpLFxuXHRcdFx0XHRydW5uaW5nOiB0cnVlXG5cdFx0XHR9KTtcblx0XHRcdHQuZG9uZSB8fCAodC5kb25lID0gbmV3IFByb21pc2UoKHJlcykgPT4gdC5yZXNvbHZlID0gcmVzKSk7XG5cdFx0XHR0LnJ1bm5pbmcgPSB0cnVlO1xuXHRcdH1cblx0XHRydW5VcGRhdGVzKGZuLCBmYWxzZSk7XG5cdFx0TGlzdGVuZXIgPSBPd25lciA9IG51bGw7XG5cdFx0cmV0dXJuIHQgPyB0LmRvbmUgOiB2b2lkIDA7XG5cdH0pO1xufVxudmFyIFt0cmFuc1BlbmRpbmcsIHNldFRyYW5zUGVuZGluZ10gPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlU2lnbmFsKGZhbHNlKTtcbmZ1bmN0aW9uIGNyZWF0ZUNvbnRleHQoZGVmYXVsdFZhbHVlLCBvcHRpb25zKSB7XG5cdGNvbnN0IGlkID0gU3ltYm9sKFwiY29udGV4dFwiKTtcblx0cmV0dXJuIHtcblx0XHRpZCxcblx0XHRQcm92aWRlcjogY3JlYXRlUHJvdmlkZXIoaWQpLFxuXHRcdGRlZmF1bHRWYWx1ZVxuXHR9O1xufVxuZnVuY3Rpb24gdXNlQ29udGV4dChjb250ZXh0KSB7XG5cdGxldCB2YWx1ZTtcblx0cmV0dXJuIE93bmVyICYmIE93bmVyLmNvbnRleHQgJiYgKHZhbHVlID0gT3duZXIuY29udGV4dFtjb250ZXh0LmlkXSkgIT09IHZvaWQgMCA/IHZhbHVlIDogY29udGV4dC5kZWZhdWx0VmFsdWU7XG59XG5mdW5jdGlvbiBjaGlsZHJlbihmbikge1xuXHRjb25zdCBjaGlsZHJlbiA9IGNyZWF0ZU1lbW8oZm4pO1xuXHRjb25zdCBtZW1vID0gY3JlYXRlTWVtbygoKSA9PiByZXNvbHZlQ2hpbGRyZW4oY2hpbGRyZW4oKSkpO1xuXHRtZW1vLnRvQXJyYXkgPSAoKSA9PiB7XG5cdFx0Y29uc3QgYyA9IG1lbW8oKTtcblx0XHRyZXR1cm4gQXJyYXkuaXNBcnJheShjKSA/IGMgOiBjICE9IG51bGwgPyBbY10gOiBbXTtcblx0fTtcblx0cmV0dXJuIG1lbW87XG59XG52YXIgU3VzcGVuc2VDb250ZXh0O1xuZnVuY3Rpb24gcmVhZFNpZ25hbCgpIHtcblx0Y29uc3QgcnVubmluZ1RyYW5zaXRpb24gPSBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZztcblx0aWYgKHRoaXMuc291cmNlcyAmJiAocnVubmluZ1RyYW5zaXRpb24gPyB0aGlzLnRTdGF0ZSA6IHRoaXMuc3RhdGUpKSBpZiAoKHJ1bm5pbmdUcmFuc2l0aW9uID8gdGhpcy50U3RhdGUgOiB0aGlzLnN0YXRlKSA9PT0gU1RBTEUpIHVwZGF0ZUNvbXB1dGF0aW9uKHRoaXMpO1xuXHRlbHNlIHtcblx0XHRjb25zdCB1cGRhdGVzID0gVXBkYXRlcztcblx0XHRVcGRhdGVzID0gbnVsbDtcblx0XHRydW5VcGRhdGVzKCgpID0+IGxvb2tVcHN0cmVhbSh0aGlzKSwgZmFsc2UpO1xuXHRcdFVwZGF0ZXMgPSB1cGRhdGVzO1xuXHR9XG5cdGlmIChMaXN0ZW5lcikge1xuXHRcdGNvbnN0IHNTbG90ID0gdGhpcy5vYnNlcnZlcnMgPyB0aGlzLm9ic2VydmVycy5sZW5ndGggOiAwO1xuXHRcdGlmICghTGlzdGVuZXIuc291cmNlcykge1xuXHRcdFx0TGlzdGVuZXIuc291cmNlcyA9IFt0aGlzXTtcblx0XHRcdExpc3RlbmVyLnNvdXJjZVNsb3RzID0gW3NTbG90XTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0TGlzdGVuZXIuc291cmNlcy5wdXNoKHRoaXMpO1xuXHRcdFx0TGlzdGVuZXIuc291cmNlU2xvdHMucHVzaChzU2xvdCk7XG5cdFx0fVxuXHRcdGlmICghdGhpcy5vYnNlcnZlcnMpIHtcblx0XHRcdHRoaXMub2JzZXJ2ZXJzID0gW0xpc3RlbmVyXTtcblx0XHRcdHRoaXMub2JzZXJ2ZXJTbG90cyA9IFtMaXN0ZW5lci5zb3VyY2VzLmxlbmd0aCAtIDFdO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHR0aGlzLm9ic2VydmVycy5wdXNoKExpc3RlbmVyKTtcblx0XHRcdHRoaXMub2JzZXJ2ZXJTbG90cy5wdXNoKExpc3RlbmVyLnNvdXJjZXMubGVuZ3RoIC0gMSk7XG5cdFx0fVxuXHR9XG5cdGlmIChydW5uaW5nVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnNvdXJjZXMuaGFzKHRoaXMpKSByZXR1cm4gdGhpcy50VmFsdWU7XG5cdHJldHVybiB0aGlzLnZhbHVlO1xufVxuZnVuY3Rpb24gd3JpdGVTaWduYWwobm9kZSwgdmFsdWUsIGlzQ29tcCkge1xuXHRsZXQgY3VycmVudCA9IFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nICYmIFRyYW5zaXRpb24uc291cmNlcy5oYXMobm9kZSkgPyBub2RlLnRWYWx1ZSA6IG5vZGUudmFsdWU7XG5cdGlmICghbm9kZS5jb21wYXJhdG9yIHx8ICFub2RlLmNvbXBhcmF0b3IoY3VycmVudCwgdmFsdWUpKSB7XG5cdFx0aWYgKFRyYW5zaXRpb24pIHtcblx0XHRcdGNvbnN0IFRyYW5zaXRpb25SdW5uaW5nID0gVHJhbnNpdGlvbi5ydW5uaW5nO1xuXHRcdFx0aWYgKFRyYW5zaXRpb25SdW5uaW5nIHx8ICFpc0NvbXAgJiYgVHJhbnNpdGlvbi5zb3VyY2VzLmhhcyhub2RlKSkge1xuXHRcdFx0XHRUcmFuc2l0aW9uLnNvdXJjZXMuYWRkKG5vZGUpO1xuXHRcdFx0XHRub2RlLnRWYWx1ZSA9IHZhbHVlO1xuXHRcdFx0fVxuXHRcdFx0aWYgKCFUcmFuc2l0aW9uUnVubmluZykgbm9kZS52YWx1ZSA9IHZhbHVlO1xuXHRcdH0gZWxzZSBub2RlLnZhbHVlID0gdmFsdWU7XG5cdFx0aWYgKG5vZGUub2JzZXJ2ZXJzICYmIG5vZGUub2JzZXJ2ZXJzLmxlbmd0aCkgcnVuVXBkYXRlcygoKSA9PiB7XG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IG5vZGUub2JzZXJ2ZXJzLmxlbmd0aDsgaSArPSAxKSB7XG5cdFx0XHRcdGNvbnN0IG8gPSBub2RlLm9ic2VydmVyc1tpXTtcblx0XHRcdFx0Y29uc3QgVHJhbnNpdGlvblJ1bm5pbmcgPSBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZztcblx0XHRcdFx0aWYgKFRyYW5zaXRpb25SdW5uaW5nICYmIFRyYW5zaXRpb24uZGlzcG9zZWQuaGFzKG8pKSBjb250aW51ZTtcblx0XHRcdFx0aWYgKFRyYW5zaXRpb25SdW5uaW5nID8gIW8udFN0YXRlIDogIW8uc3RhdGUpIHtcblx0XHRcdFx0XHRpZiAoby5wdXJlKSBVcGRhdGVzLnB1c2gobyk7XG5cdFx0XHRcdFx0ZWxzZSBFZmZlY3RzLnB1c2gobyk7XG5cdFx0XHRcdFx0aWYgKG8ub2JzZXJ2ZXJzKSBtYXJrRG93bnN0cmVhbShvKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIVRyYW5zaXRpb25SdW5uaW5nKSBvLnN0YXRlID0gU1RBTEU7XG5cdFx0XHRcdGVsc2Ugby50U3RhdGUgPSBTVEFMRTtcblx0XHRcdH1cblx0XHRcdGlmIChVcGRhdGVzLmxlbmd0aCA+IDFlNikge1xuXHRcdFx0XHRVcGRhdGVzID0gW107XG5cdFx0XHRcdHRocm93IG5ldyBFcnJvcigpO1xuXHRcdFx0fVxuXHRcdH0sIGZhbHNlKTtcblx0fVxuXHRyZXR1cm4gdmFsdWU7XG59XG5mdW5jdGlvbiB1cGRhdGVDb21wdXRhdGlvbihub2RlKSB7XG5cdGlmICghbm9kZS5mbikgcmV0dXJuO1xuXHRjbGVhbk5vZGUobm9kZSk7XG5cdGNvbnN0IHRpbWUgPSBFeGVjQ291bnQ7XG5cdHJ1bkNvbXB1dGF0aW9uKG5vZGUsIFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nICYmIFRyYW5zaXRpb24uc291cmNlcy5oYXMobm9kZSkgPyBub2RlLnRWYWx1ZSA6IG5vZGUudmFsdWUsIHRpbWUpO1xuXHRpZiAoVHJhbnNpdGlvbiAmJiAhVHJhbnNpdGlvbi5ydW5uaW5nICYmIFRyYW5zaXRpb24uc291cmNlcy5oYXMobm9kZSkpIHF1ZXVlTWljcm90YXNrKCgpID0+IHtcblx0XHRydW5VcGRhdGVzKCgpID0+IHtcblx0XHRcdFRyYW5zaXRpb24gJiYgKFRyYW5zaXRpb24ucnVubmluZyA9IHRydWUpO1xuXHRcdFx0TGlzdGVuZXIgPSBPd25lciA9IG5vZGU7XG5cdFx0XHRydW5Db21wdXRhdGlvbihub2RlLCBub2RlLnRWYWx1ZSwgdGltZSk7XG5cdFx0XHRMaXN0ZW5lciA9IE93bmVyID0gbnVsbDtcblx0XHR9LCBmYWxzZSk7XG5cdH0pO1xufVxuZnVuY3Rpb24gcnVuQ29tcHV0YXRpb24obm9kZSwgdmFsdWUsIHRpbWUpIHtcblx0bGV0IG5leHRWYWx1ZTtcblx0Y29uc3Qgb3duZXIgPSBPd25lciwgbGlzdGVuZXIgPSBMaXN0ZW5lcjtcblx0TGlzdGVuZXIgPSBPd25lciA9IG5vZGU7XG5cdHRyeSB7XG5cdFx0bmV4dFZhbHVlID0gbm9kZS5mbih2YWx1ZSk7XG5cdH0gY2F0Y2ggKGVycikge1xuXHRcdGlmIChub2RlLnB1cmUpIGlmIChUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZykge1xuXHRcdFx0bm9kZS50U3RhdGUgPSBTVEFMRTtcblx0XHRcdG5vZGUudE93bmVkICYmIG5vZGUudE93bmVkLmZvckVhY2goY2xlYW5Ob2RlKTtcblx0XHRcdG5vZGUudE93bmVkID0gdm9pZCAwO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRub2RlLnN0YXRlID0gU1RBTEU7XG5cdFx0XHRub2RlLm93bmVkICYmIG5vZGUub3duZWQuZm9yRWFjaChjbGVhbk5vZGUpO1xuXHRcdFx0bm9kZS5vd25lZCA9IG51bGw7XG5cdFx0fVxuXHRcdG5vZGUudXBkYXRlZEF0ID0gdGltZSArIDE7XG5cdFx0cmV0dXJuIGhhbmRsZUVycm9yKGVycik7XG5cdH0gZmluYWxseSB7XG5cdFx0TGlzdGVuZXIgPSBsaXN0ZW5lcjtcblx0XHRPd25lciA9IG93bmVyO1xuXHR9XG5cdGlmICghbm9kZS51cGRhdGVkQXQgfHwgbm9kZS51cGRhdGVkQXQgPD0gdGltZSkge1xuXHRcdGlmIChub2RlLnVwZGF0ZWRBdCAhPSBudWxsICYmIFwib2JzZXJ2ZXJzXCIgaW4gbm9kZSkgd3JpdGVTaWduYWwobm9kZSwgbmV4dFZhbHVlLCB0cnVlKTtcblx0XHRlbHNlIGlmIChUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZyAmJiBub2RlLnB1cmUpIHtcblx0XHRcdGlmICghVHJhbnNpdGlvbi5zb3VyY2VzLmhhcyhub2RlKSkgbm9kZS52YWx1ZSA9IG5leHRWYWx1ZTtcblx0XHRcdFRyYW5zaXRpb24uc291cmNlcy5hZGQobm9kZSk7XG5cdFx0XHRub2RlLnRWYWx1ZSA9IG5leHRWYWx1ZTtcblx0XHR9IGVsc2Ugbm9kZS52YWx1ZSA9IG5leHRWYWx1ZTtcblx0XHRub2RlLnVwZGF0ZWRBdCA9IHRpbWU7XG5cdH1cbn1cbmZ1bmN0aW9uIGNyZWF0ZUNvbXB1dGF0aW9uKGZuLCBpbml0LCBwdXJlLCBzdGF0ZSA9IFNUQUxFLCBvcHRpb25zKSB7XG5cdGNvbnN0IGMgPSB7XG5cdFx0Zm4sXG5cdFx0c3RhdGUsXG5cdFx0dXBkYXRlZEF0OiBudWxsLFxuXHRcdG93bmVkOiBudWxsLFxuXHRcdHNvdXJjZXM6IG51bGwsXG5cdFx0c291cmNlU2xvdHM6IG51bGwsXG5cdFx0Y2xlYW51cHM6IG51bGwsXG5cdFx0dmFsdWU6IGluaXQsXG5cdFx0b3duZXI6IE93bmVyLFxuXHRcdGNvbnRleHQ6IE93bmVyID8gT3duZXIuY29udGV4dCA6IG51bGwsXG5cdFx0cHVyZVxuXHR9O1xuXHRpZiAoVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmcpIHtcblx0XHRjLnN0YXRlID0gMDtcblx0XHRjLnRTdGF0ZSA9IHN0YXRlO1xuXHR9XG5cdGlmIChPd25lciA9PT0gbnVsbCk7XG5cdGVsc2UgaWYgKE93bmVyICE9PSBVTk9XTkVEKSBpZiAoVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmcgJiYgT3duZXIucHVyZSkgaWYgKCFPd25lci50T3duZWQpIE93bmVyLnRPd25lZCA9IFtjXTtcblx0ZWxzZSBPd25lci50T3duZWQucHVzaChjKTtcblx0ZWxzZSBpZiAoIU93bmVyLm93bmVkKSBPd25lci5vd25lZCA9IFtjXTtcblx0ZWxzZSBPd25lci5vd25lZC5wdXNoKGMpO1xuXHRpZiAoRXh0ZXJuYWxTb3VyY2VDb25maWcgJiYgYy5mbikge1xuXHRcdGNvbnN0IHNvdXJjZUZuID0gYy5mbjtcblx0XHRjb25zdCBbdHJhY2ssIHRyaWdnZXJdID0gY3JlYXRlU2lnbmFsKHZvaWQgMCwgeyBlcXVhbHM6IGZhbHNlIH0pO1xuXHRcdGNvbnN0IG9yZGluYXJ5ID0gRXh0ZXJuYWxTb3VyY2VDb25maWcuZmFjdG9yeShzb3VyY2VGbiwgdHJpZ2dlcik7XG5cdFx0b25DbGVhbnVwKCgpID0+IG9yZGluYXJ5LmRpc3Bvc2UoKSk7XG5cdFx0bGV0IGluVHJhbnNpdGlvbjtcblx0XHRjb25zdCB0cmlnZ2VySW5UcmFuc2l0aW9uID0gKCkgPT4gc3RhcnRUcmFuc2l0aW9uKHRyaWdnZXIpLnRoZW4oKCkgPT4ge1xuXHRcdFx0aWYgKGluVHJhbnNpdGlvbikge1xuXHRcdFx0XHRpblRyYW5zaXRpb24uZGlzcG9zZSgpO1xuXHRcdFx0XHRpblRyYW5zaXRpb24gPSB2b2lkIDA7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0Yy5mbiA9ICh4KSA9PiB7XG5cdFx0XHR0cmFjaygpO1xuXHRcdFx0aWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nKSB7XG5cdFx0XHRcdGlmICghaW5UcmFuc2l0aW9uKSBpblRyYW5zaXRpb24gPSBFeHRlcm5hbFNvdXJjZUNvbmZpZy5mYWN0b3J5KHNvdXJjZUZuLCB0cmlnZ2VySW5UcmFuc2l0aW9uKTtcblx0XHRcdFx0cmV0dXJuIGluVHJhbnNpdGlvbi50cmFjayh4KTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBvcmRpbmFyeS50cmFjayh4KTtcblx0XHR9O1xuXHR9XG5cdHJldHVybiBjO1xufVxuZnVuY3Rpb24gcnVuVG9wKG5vZGUpIHtcblx0Y29uc3QgcnVubmluZ1RyYW5zaXRpb24gPSBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZztcblx0aWYgKChydW5uaW5nVHJhbnNpdGlvbiA/IG5vZGUudFN0YXRlIDogbm9kZS5zdGF0ZSkgPT09IDApIHJldHVybjtcblx0aWYgKChydW5uaW5nVHJhbnNpdGlvbiA/IG5vZGUudFN0YXRlIDogbm9kZS5zdGF0ZSkgPT09IFBFTkRJTkcpIHJldHVybiBsb29rVXBzdHJlYW0obm9kZSk7XG5cdGlmIChub2RlLnN1c3BlbnNlICYmIHVudHJhY2sobm9kZS5zdXNwZW5zZS5pbkZhbGxiYWNrKSkgcmV0dXJuIG5vZGUuc3VzcGVuc2UuZWZmZWN0cy5wdXNoKG5vZGUpO1xuXHRjb25zdCBhbmNlc3RvcnMgPSBbbm9kZV07XG5cdHdoaWxlICgobm9kZSA9IG5vZGUub3duZXIpICYmICghbm9kZS51cGRhdGVkQXQgfHwgbm9kZS51cGRhdGVkQXQgPCBFeGVjQ291bnQpKSB7XG5cdFx0aWYgKHJ1bm5pbmdUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24uZGlzcG9zZWQuaGFzKG5vZGUpKSByZXR1cm47XG5cdFx0aWYgKHJ1bm5pbmdUcmFuc2l0aW9uID8gbm9kZS50U3RhdGUgOiBub2RlLnN0YXRlKSBhbmNlc3RvcnMucHVzaChub2RlKTtcblx0fVxuXHRmb3IgKGxldCBpID0gYW5jZXN0b3JzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0bm9kZSA9IGFuY2VzdG9yc1tpXTtcblx0XHRpZiAocnVubmluZ1RyYW5zaXRpb24pIHtcblx0XHRcdGxldCB0b3AgPSBub2RlLCBwcmV2ID0gYW5jZXN0b3JzW2kgKyAxXTtcblx0XHRcdHdoaWxlICgodG9wID0gdG9wLm93bmVyKSAmJiB0b3AgIT09IHByZXYpIGlmIChUcmFuc2l0aW9uLmRpc3Bvc2VkLmhhcyh0b3ApKSByZXR1cm47XG5cdFx0fVxuXHRcdGlmICgocnVubmluZ1RyYW5zaXRpb24gPyBub2RlLnRTdGF0ZSA6IG5vZGUuc3RhdGUpID09PSBTVEFMRSkgdXBkYXRlQ29tcHV0YXRpb24obm9kZSk7XG5cdFx0ZWxzZSBpZiAoKHJ1bm5pbmdUcmFuc2l0aW9uID8gbm9kZS50U3RhdGUgOiBub2RlLnN0YXRlKSA9PT0gUEVORElORykge1xuXHRcdFx0Y29uc3QgdXBkYXRlcyA9IFVwZGF0ZXM7XG5cdFx0XHRVcGRhdGVzID0gbnVsbDtcblx0XHRcdHJ1blVwZGF0ZXMoKCkgPT4gbG9va1Vwc3RyZWFtKG5vZGUsIGFuY2VzdG9yc1swXSksIGZhbHNlKTtcblx0XHRcdFVwZGF0ZXMgPSB1cGRhdGVzO1xuXHRcdH1cblx0fVxufVxuZnVuY3Rpb24gcnVuVXBkYXRlcyhmbiwgaW5pdCkge1xuXHRpZiAoVXBkYXRlcykgcmV0dXJuIGZuKCk7XG5cdGxldCB3YWl0ID0gZmFsc2U7XG5cdGlmICghaW5pdCkgVXBkYXRlcyA9IFtdO1xuXHRpZiAoRWZmZWN0cykgd2FpdCA9IHRydWU7XG5cdGVsc2UgRWZmZWN0cyA9IFtdO1xuXHRFeGVjQ291bnQrKztcblx0dHJ5IHtcblx0XHRjb25zdCByZXMgPSBmbigpO1xuXHRcdGNvbXBsZXRlVXBkYXRlcyh3YWl0KTtcblx0XHRyZXR1cm4gcmVzO1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRpZiAoIXdhaXQpIEVmZmVjdHMgPSBudWxsO1xuXHRcdFVwZGF0ZXMgPSBudWxsO1xuXHRcdGhhbmRsZUVycm9yKGVycik7XG5cdH1cbn1cbmZ1bmN0aW9uIGNvbXBsZXRlVXBkYXRlcyh3YWl0KSB7XG5cdGlmIChVcGRhdGVzKSB7XG5cdFx0aWYgKFNjaGVkdWxlciAmJiBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZykgc2NoZWR1bGVRdWV1ZShVcGRhdGVzKTtcblx0XHRlbHNlIHJ1blF1ZXVlKFVwZGF0ZXMpO1xuXHRcdFVwZGF0ZXMgPSBudWxsO1xuXHR9XG5cdGlmICh3YWl0KSByZXR1cm47XG5cdGxldCByZXM7XG5cdGlmIChUcmFuc2l0aW9uKSB7XG5cdFx0aWYgKCFUcmFuc2l0aW9uLnByb21pc2VzLnNpemUgJiYgIVRyYW5zaXRpb24ucXVldWUuc2l6ZSkge1xuXHRcdFx0Y29uc3Qgc291cmNlcyA9IFRyYW5zaXRpb24uc291cmNlcztcblx0XHRcdGNvbnN0IGRpc3Bvc2VkID0gVHJhbnNpdGlvbi5kaXNwb3NlZDtcblx0XHRcdEVmZmVjdHMucHVzaC5hcHBseShFZmZlY3RzLCBUcmFuc2l0aW9uLmVmZmVjdHMpO1xuXHRcdFx0cmVzID0gVHJhbnNpdGlvbi5yZXNvbHZlO1xuXHRcdFx0Zm9yIChjb25zdCBlIG9mIEVmZmVjdHMpIHtcblx0XHRcdFx0XCJ0U3RhdGVcIiBpbiBlICYmIChlLnN0YXRlID0gZS50U3RhdGUpO1xuXHRcdFx0XHRkZWxldGUgZS50U3RhdGU7XG5cdFx0XHR9XG5cdFx0XHRUcmFuc2l0aW9uID0gbnVsbDtcblx0XHRcdHJ1blVwZGF0ZXMoKCkgPT4ge1xuXHRcdFx0XHRmb3IgKGNvbnN0IGQgb2YgZGlzcG9zZWQpIGNsZWFuTm9kZShkKTtcblx0XHRcdFx0Zm9yIChjb25zdCB2IG9mIHNvdXJjZXMpIHtcblx0XHRcdFx0XHR2LnZhbHVlID0gdi50VmFsdWU7XG5cdFx0XHRcdFx0aWYgKHYub3duZWQpIGZvciAobGV0IGkgPSAwLCBsZW4gPSB2Lm93bmVkLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSBjbGVhbk5vZGUodi5vd25lZFtpXSk7XG5cdFx0XHRcdFx0aWYgKHYudE93bmVkKSB2Lm93bmVkID0gdi50T3duZWQ7XG5cdFx0XHRcdFx0ZGVsZXRlIHYudFZhbHVlO1xuXHRcdFx0XHRcdGRlbGV0ZSB2LnRPd25lZDtcblx0XHRcdFx0XHR2LnRTdGF0ZSA9IDA7XG5cdFx0XHRcdH1cblx0XHRcdFx0c2V0VHJhbnNQZW5kaW5nKGZhbHNlKTtcblx0XHRcdH0sIGZhbHNlKTtcblx0XHR9IGVsc2UgaWYgKFRyYW5zaXRpb24ucnVubmluZykge1xuXHRcdFx0VHJhbnNpdGlvbi5ydW5uaW5nID0gZmFsc2U7XG5cdFx0XHRUcmFuc2l0aW9uLmVmZmVjdHMucHVzaC5hcHBseShUcmFuc2l0aW9uLmVmZmVjdHMsIEVmZmVjdHMpO1xuXHRcdFx0RWZmZWN0cyA9IG51bGw7XG5cdFx0XHRzZXRUcmFuc1BlbmRpbmcodHJ1ZSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHR9XG5cdGNvbnN0IGUgPSBFZmZlY3RzO1xuXHRFZmZlY3RzID0gbnVsbDtcblx0aWYgKGUubGVuZ3RoKSBydW5VcGRhdGVzKCgpID0+IHJ1bkVmZmVjdHMoZSksIGZhbHNlKTtcblx0aWYgKHJlcykgcmVzKCk7XG59XG5mdW5jdGlvbiBydW5RdWV1ZShxdWV1ZSkge1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IHF1ZXVlLmxlbmd0aDsgaSsrKSBydW5Ub3AocXVldWVbaV0pO1xufVxuZnVuY3Rpb24gc2NoZWR1bGVRdWV1ZShxdWV1ZSkge1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IHF1ZXVlLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3QgaXRlbSA9IHF1ZXVlW2ldO1xuXHRcdGNvbnN0IHRhc2tzID0gVHJhbnNpdGlvbi5xdWV1ZTtcblx0XHRpZiAoIXRhc2tzLmhhcyhpdGVtKSkge1xuXHRcdFx0dGFza3MuYWRkKGl0ZW0pO1xuXHRcdFx0U2NoZWR1bGVyKCgpID0+IHtcblx0XHRcdFx0dGFza3MuZGVsZXRlKGl0ZW0pO1xuXHRcdFx0XHRydW5VcGRhdGVzKCgpID0+IHtcblx0XHRcdFx0XHRUcmFuc2l0aW9uLnJ1bm5pbmcgPSB0cnVlO1xuXHRcdFx0XHRcdHJ1blRvcChpdGVtKTtcblx0XHRcdFx0fSwgZmFsc2UpO1xuXHRcdFx0XHRUcmFuc2l0aW9uICYmIChUcmFuc2l0aW9uLnJ1bm5pbmcgPSBmYWxzZSk7XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cbn1cbmZ1bmN0aW9uIHJ1blVzZXJFZmZlY3RzKHF1ZXVlKSB7XG5cdGxldCBpLCB1c2VyTGVuZ3RoID0gMDtcblx0Zm9yIChpID0gMDsgaSA8IHF1ZXVlLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3QgZSA9IHF1ZXVlW2ldO1xuXHRcdGlmICghZS51c2VyKSBydW5Ub3AoZSk7XG5cdFx0ZWxzZSBxdWV1ZVt1c2VyTGVuZ3RoKytdID0gZTtcblx0fVxuXHRpZiAoc2hhcmVkQ29uZmlnLmNvbnRleHQpIHtcblx0XHRpZiAoc2hhcmVkQ29uZmlnLmNvdW50KSB7XG5cdFx0XHRzaGFyZWRDb25maWcuZWZmZWN0cyB8fCAoc2hhcmVkQ29uZmlnLmVmZmVjdHMgPSBbXSk7XG5cdFx0XHRzaGFyZWRDb25maWcuZWZmZWN0cy5wdXNoKC4uLnF1ZXVlLnNsaWNlKDAsIHVzZXJMZW5ndGgpKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0c2V0SHlkcmF0ZUNvbnRleHQoKTtcblx0fVxuXHRpZiAoc2hhcmVkQ29uZmlnLmVmZmVjdHMgJiYgKHNoYXJlZENvbmZpZy5kb25lIHx8ICFzaGFyZWRDb25maWcuY291bnQpKSB7XG5cdFx0cXVldWUgPSBbLi4uc2hhcmVkQ29uZmlnLmVmZmVjdHMsIC4uLnF1ZXVlXTtcblx0XHR1c2VyTGVuZ3RoICs9IHNoYXJlZENvbmZpZy5lZmZlY3RzLmxlbmd0aDtcblx0XHRkZWxldGUgc2hhcmVkQ29uZmlnLmVmZmVjdHM7XG5cdH1cblx0Zm9yIChpID0gMDsgaSA8IHVzZXJMZW5ndGg7IGkrKykgcnVuVG9wKHF1ZXVlW2ldKTtcbn1cbmZ1bmN0aW9uIGxvb2tVcHN0cmVhbShub2RlLCBpZ25vcmUpIHtcblx0Y29uc3QgcnVubmluZ1RyYW5zaXRpb24gPSBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZztcblx0aWYgKHJ1bm5pbmdUcmFuc2l0aW9uKSBub2RlLnRTdGF0ZSA9IDA7XG5cdGVsc2Ugbm9kZS5zdGF0ZSA9IDA7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgbm9kZS5zb3VyY2VzLmxlbmd0aDsgaSArPSAxKSB7XG5cdFx0Y29uc3Qgc291cmNlID0gbm9kZS5zb3VyY2VzW2ldO1xuXHRcdGlmIChzb3VyY2Uuc291cmNlcykge1xuXHRcdFx0Y29uc3Qgc3RhdGUgPSBydW5uaW5nVHJhbnNpdGlvbiA/IHNvdXJjZS50U3RhdGUgOiBzb3VyY2Uuc3RhdGU7XG5cdFx0XHRpZiAoc3RhdGUgPT09IFNUQUxFKSB7XG5cdFx0XHRcdGlmIChzb3VyY2UgIT09IGlnbm9yZSAmJiAoIXNvdXJjZS51cGRhdGVkQXQgfHwgc291cmNlLnVwZGF0ZWRBdCA8IEV4ZWNDb3VudCkpIHJ1blRvcChzb3VyY2UpO1xuXHRcdFx0fSBlbHNlIGlmIChzdGF0ZSA9PT0gUEVORElORykgbG9va1Vwc3RyZWFtKHNvdXJjZSwgaWdub3JlKTtcblx0XHR9XG5cdH1cbn1cbmZ1bmN0aW9uIG1hcmtEb3duc3RyZWFtKG5vZGUpIHtcblx0Y29uc3QgcnVubmluZ1RyYW5zaXRpb24gPSBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZztcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBub2RlLm9ic2VydmVycy5sZW5ndGg7IGkgKz0gMSkge1xuXHRcdGNvbnN0IG8gPSBub2RlLm9ic2VydmVyc1tpXTtcblx0XHRpZiAocnVubmluZ1RyYW5zaXRpb24gPyAhby50U3RhdGUgOiAhby5zdGF0ZSkge1xuXHRcdFx0aWYgKHJ1bm5pbmdUcmFuc2l0aW9uKSBvLnRTdGF0ZSA9IFBFTkRJTkc7XG5cdFx0XHRlbHNlIG8uc3RhdGUgPSBQRU5ESU5HO1xuXHRcdFx0aWYgKG8ucHVyZSkgVXBkYXRlcy5wdXNoKG8pO1xuXHRcdFx0ZWxzZSBFZmZlY3RzLnB1c2gobyk7XG5cdFx0XHRvLm9ic2VydmVycyAmJiBtYXJrRG93bnN0cmVhbShvKTtcblx0XHR9XG5cdH1cbn1cbmZ1bmN0aW9uIGNsZWFuTm9kZShub2RlKSB7XG5cdGxldCBpO1xuXHRpZiAobm9kZS5zb3VyY2VzKSB3aGlsZSAobm9kZS5zb3VyY2VzLmxlbmd0aCkge1xuXHRcdGNvbnN0IHNvdXJjZSA9IG5vZGUuc291cmNlcy5wb3AoKSwgaW5kZXggPSBub2RlLnNvdXJjZVNsb3RzLnBvcCgpLCBvYnMgPSBzb3VyY2Uub2JzZXJ2ZXJzO1xuXHRcdGlmIChvYnMgJiYgb2JzLmxlbmd0aCkge1xuXHRcdFx0Y29uc3QgbiA9IG9icy5wb3AoKSwgcyA9IHNvdXJjZS5vYnNlcnZlclNsb3RzLnBvcCgpO1xuXHRcdFx0aWYgKGluZGV4IDwgb2JzLmxlbmd0aCkge1xuXHRcdFx0XHRuLnNvdXJjZVNsb3RzW3NdID0gaW5kZXg7XG5cdFx0XHRcdG9ic1tpbmRleF0gPSBuO1xuXHRcdFx0XHRzb3VyY2Uub2JzZXJ2ZXJTbG90c1tpbmRleF0gPSBzO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRpZiAobm9kZS50T3duZWQpIHtcblx0XHRmb3IgKGkgPSBub2RlLnRPd25lZC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgY2xlYW5Ob2RlKG5vZGUudE93bmVkW2ldKTtcblx0XHRkZWxldGUgbm9kZS50T3duZWQ7XG5cdH1cblx0aWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nICYmIG5vZGUucHVyZSkgcmVzZXQobm9kZSwgdHJ1ZSk7XG5cdGVsc2UgaWYgKG5vZGUub3duZWQpIHtcblx0XHRmb3IgKGkgPSBub2RlLm93bmVkLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBjbGVhbk5vZGUobm9kZS5vd25lZFtpXSk7XG5cdFx0bm9kZS5vd25lZCA9IG51bGw7XG5cdH1cblx0aWYgKG5vZGUuY2xlYW51cHMpIHtcblx0XHRmb3IgKGkgPSBub2RlLmNsZWFudXBzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBub2RlLmNsZWFudXBzW2ldKCk7XG5cdFx0bm9kZS5jbGVhbnVwcyA9IG51bGw7XG5cdH1cblx0aWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nKSBub2RlLnRTdGF0ZSA9IDA7XG5cdGVsc2Ugbm9kZS5zdGF0ZSA9IDA7XG59XG5mdW5jdGlvbiByZXNldChub2RlLCB0b3ApIHtcblx0aWYgKCF0b3ApIHtcblx0XHRub2RlLnRTdGF0ZSA9IDA7XG5cdFx0VHJhbnNpdGlvbi5kaXNwb3NlZC5hZGQobm9kZSk7XG5cdH1cblx0aWYgKG5vZGUub3duZWQpIGZvciAobGV0IGkgPSAwOyBpIDwgbm9kZS5vd25lZC5sZW5ndGg7IGkrKykgcmVzZXQobm9kZS5vd25lZFtpXSk7XG59XG5mdW5jdGlvbiBjYXN0RXJyb3IoZXJyKSB7XG5cdGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikgcmV0dXJuIGVycjtcblx0cmV0dXJuIG5ldyBFcnJvcih0eXBlb2YgZXJyID09PSBcInN0cmluZ1wiID8gZXJyIDogXCJVbmtub3duIGVycm9yXCIsIHsgY2F1c2U6IGVyciB9KTtcbn1cbmZ1bmN0aW9uIHJ1bkVycm9ycyhlcnIsIGZucywgb3duZXIpIHtcblx0dHJ5IHtcblx0XHRmb3IgKGNvbnN0IGYgb2YgZm5zKSBmKGVycik7XG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRoYW5kbGVFcnJvcihlLCBvd25lciAmJiBvd25lci5vd25lciB8fCBudWxsKTtcblx0fVxufVxuZnVuY3Rpb24gaGFuZGxlRXJyb3IoZXJyLCBvd25lciA9IE93bmVyKSB7XG5cdGNvbnN0IGZucyA9IEVSUk9SICYmIG93bmVyICYmIG93bmVyLmNvbnRleHQgJiYgb3duZXIuY29udGV4dFtFUlJPUl07XG5cdGNvbnN0IGVycm9yID0gY2FzdEVycm9yKGVycik7XG5cdGlmICghZm5zKSB0aHJvdyBlcnJvcjtcblx0aWYgKEVmZmVjdHMpIEVmZmVjdHMucHVzaCh7XG5cdFx0Zm4oKSB7XG5cdFx0XHRydW5FcnJvcnMoZXJyb3IsIGZucywgb3duZXIpO1xuXHRcdH0sXG5cdFx0c3RhdGU6IFNUQUxFXG5cdH0pO1xuXHRlbHNlIHJ1bkVycm9ycyhlcnJvciwgZm5zLCBvd25lcik7XG59XG5mdW5jdGlvbiByZXNvbHZlQ2hpbGRyZW4oY2hpbGRyZW4pIHtcblx0aWYgKHR5cGVvZiBjaGlsZHJlbiA9PT0gXCJmdW5jdGlvblwiICYmICFjaGlsZHJlbi5sZW5ndGgpIHJldHVybiByZXNvbHZlQ2hpbGRyZW4oY2hpbGRyZW4oKSk7XG5cdGlmIChBcnJheS5pc0FycmF5KGNoaWxkcmVuKSkge1xuXHRcdGNvbnN0IHJlc3VsdHMgPSBbXTtcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRjb25zdCByZXN1bHQgPSByZXNvbHZlQ2hpbGRyZW4oY2hpbGRyZW5baV0pO1xuXHRcdFx0QXJyYXkuaXNBcnJheShyZXN1bHQpID8gcmVzdWx0cy5wdXNoLmFwcGx5KHJlc3VsdHMsIHJlc3VsdCkgOiByZXN1bHRzLnB1c2gocmVzdWx0KTtcblx0XHR9XG5cdFx0cmV0dXJuIHJlc3VsdHM7XG5cdH1cblx0cmV0dXJuIGNoaWxkcmVuO1xufVxuZnVuY3Rpb24gY3JlYXRlUHJvdmlkZXIoaWQsIG9wdGlvbnMpIHtcblx0cmV0dXJuIGZ1bmN0aW9uIHByb3ZpZGVyKHByb3BzKSB7XG5cdFx0bGV0IHJlcztcblx0XHRjcmVhdGVSZW5kZXJFZmZlY3QoKCkgPT4gcmVzID0gdW50cmFjaygoKSA9PiB7XG5cdFx0XHRPd25lci5jb250ZXh0ID0ge1xuXHRcdFx0XHQuLi5Pd25lci5jb250ZXh0LFxuXHRcdFx0XHRbaWRdOiBwcm9wcy52YWx1ZVxuXHRcdFx0fTtcblx0XHRcdHJldHVybiBjaGlsZHJlbigoKSA9PiBwcm9wcy5jaGlsZHJlbik7XG5cdFx0fSksIHZvaWQgMCk7XG5cdFx0cmV0dXJuIHJlcztcblx0fTtcbn1cbnZhciBGQUxMQkFDSyA9IFN5bWJvbChcImZhbGxiYWNrXCIpO1xuZnVuY3Rpb24gZGlzcG9zZShkKSB7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgZC5sZW5ndGg7IGkrKykgZFtpXSgpO1xufVxuZnVuY3Rpb24gbWFwQXJyYXkobGlzdCwgbWFwRm4sIG9wdGlvbnMgPSB7fSkge1xuXHRsZXQgaXRlbXMgPSBbXSwgbWFwcGVkID0gW10sIGRpc3Bvc2VycyA9IFtdLCBsZW4gPSAwLCBpbmRleGVzID0gbWFwRm4ubGVuZ3RoID4gMSA/IFtdIDogbnVsbDtcblx0b25DbGVhbnVwKCgpID0+IGRpc3Bvc2UoZGlzcG9zZXJzKSk7XG5cdHJldHVybiAoKSA9PiB7XG5cdFx0bGV0IG5ld0l0ZW1zID0gbGlzdCgpIHx8IFtdLCBuZXdMZW4gPSBuZXdJdGVtcy5sZW5ndGgsIGksIGo7XG5cdFx0bmV3SXRlbXNbJFRSQUNLXTtcblx0XHRyZXR1cm4gdW50cmFjaygoKSA9PiB7XG5cdFx0XHRsZXQgbmV3SW5kaWNlcywgbmV3SW5kaWNlc05leHQsIHRlbXAsIHRlbXBkaXNwb3NlcnMsIHRlbXBJbmRleGVzLCBzdGFydCwgZW5kLCBuZXdFbmQsIGl0ZW07XG5cdFx0XHRpZiAobmV3TGVuID09PSAwKSB7XG5cdFx0XHRcdGlmIChsZW4gIT09IDApIHtcblx0XHRcdFx0XHRkaXNwb3NlKGRpc3Bvc2Vycyk7XG5cdFx0XHRcdFx0ZGlzcG9zZXJzID0gW107XG5cdFx0XHRcdFx0aXRlbXMgPSBbXTtcblx0XHRcdFx0XHRtYXBwZWQgPSBbXTtcblx0XHRcdFx0XHRsZW4gPSAwO1xuXHRcdFx0XHRcdGluZGV4ZXMgJiYgKGluZGV4ZXMgPSBbXSk7XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKG9wdGlvbnMuZmFsbGJhY2spIHtcblx0XHRcdFx0XHRpdGVtcyA9IFtGQUxMQkFDS107XG5cdFx0XHRcdFx0bWFwcGVkWzBdID0gY3JlYXRlUm9vdCgoZGlzcG9zZXIpID0+IHtcblx0XHRcdFx0XHRcdGRpc3Bvc2Vyc1swXSA9IGRpc3Bvc2VyO1xuXHRcdFx0XHRcdFx0cmV0dXJuIG9wdGlvbnMuZmFsbGJhY2soKTtcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRsZW4gPSAxO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgaWYgKGxlbiA9PT0gMCkge1xuXHRcdFx0XHRtYXBwZWQgPSBuZXcgQXJyYXkobmV3TGVuKTtcblx0XHRcdFx0Zm9yIChqID0gMDsgaiA8IG5ld0xlbjsgaisrKSB7XG5cdFx0XHRcdFx0aXRlbXNbal0gPSBuZXdJdGVtc1tqXTtcblx0XHRcdFx0XHRtYXBwZWRbal0gPSBjcmVhdGVSb290KG1hcHBlcik7XG5cdFx0XHRcdH1cblx0XHRcdFx0bGVuID0gbmV3TGVuO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0dGVtcCA9IG5ldyBBcnJheShuZXdMZW4pO1xuXHRcdFx0XHR0ZW1wZGlzcG9zZXJzID0gbmV3IEFycmF5KG5ld0xlbik7XG5cdFx0XHRcdGluZGV4ZXMgJiYgKHRlbXBJbmRleGVzID0gbmV3IEFycmF5KG5ld0xlbikpO1xuXHRcdFx0XHRmb3IgKHN0YXJ0ID0gMCwgZW5kID0gTWF0aC5taW4obGVuLCBuZXdMZW4pOyBzdGFydCA8IGVuZCAmJiBpdGVtc1tzdGFydF0gPT09IG5ld0l0ZW1zW3N0YXJ0XTsgc3RhcnQrKyk7XG5cdFx0XHRcdGZvciAoZW5kID0gbGVuIC0gMSwgbmV3RW5kID0gbmV3TGVuIC0gMTsgZW5kID49IHN0YXJ0ICYmIG5ld0VuZCA+PSBzdGFydCAmJiBpdGVtc1tlbmRdID09PSBuZXdJdGVtc1tuZXdFbmRdOyBlbmQtLSwgbmV3RW5kLS0pIHtcblx0XHRcdFx0XHR0ZW1wW25ld0VuZF0gPSBtYXBwZWRbZW5kXTtcblx0XHRcdFx0XHR0ZW1wZGlzcG9zZXJzW25ld0VuZF0gPSBkaXNwb3NlcnNbZW5kXTtcblx0XHRcdFx0XHRpbmRleGVzICYmICh0ZW1wSW5kZXhlc1tuZXdFbmRdID0gaW5kZXhlc1tlbmRdKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRuZXdJbmRpY2VzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRcdFx0bmV3SW5kaWNlc05leHQgPSBuZXcgQXJyYXkobmV3RW5kICsgMSk7XG5cdFx0XHRcdGZvciAoaiA9IG5ld0VuZDsgaiA+PSBzdGFydDsgai0tKSB7XG5cdFx0XHRcdFx0aXRlbSA9IG5ld0l0ZW1zW2pdO1xuXHRcdFx0XHRcdGkgPSBuZXdJbmRpY2VzLmdldChpdGVtKTtcblx0XHRcdFx0XHRuZXdJbmRpY2VzTmV4dFtqXSA9IGkgPT09IHZvaWQgMCA/IC0xIDogaTtcblx0XHRcdFx0XHRuZXdJbmRpY2VzLnNldChpdGVtLCBqKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRmb3IgKGkgPSBzdGFydDsgaSA8PSBlbmQ7IGkrKykge1xuXHRcdFx0XHRcdGl0ZW0gPSBpdGVtc1tpXTtcblx0XHRcdFx0XHRqID0gbmV3SW5kaWNlcy5nZXQoaXRlbSk7XG5cdFx0XHRcdFx0aWYgKGogIT09IHZvaWQgMCAmJiBqICE9PSAtMSkge1xuXHRcdFx0XHRcdFx0dGVtcFtqXSA9IG1hcHBlZFtpXTtcblx0XHRcdFx0XHRcdHRlbXBkaXNwb3NlcnNbal0gPSBkaXNwb3NlcnNbaV07XG5cdFx0XHRcdFx0XHRpbmRleGVzICYmICh0ZW1wSW5kZXhlc1tqXSA9IGluZGV4ZXNbaV0pO1xuXHRcdFx0XHRcdFx0aiA9IG5ld0luZGljZXNOZXh0W2pdO1xuXHRcdFx0XHRcdFx0bmV3SW5kaWNlcy5zZXQoaXRlbSwgaik7XG5cdFx0XHRcdFx0fSBlbHNlIGRpc3Bvc2Vyc1tpXSgpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGZvciAoaiA9IHN0YXJ0OyBqIDwgbmV3TGVuOyBqKyspIGlmIChqIGluIHRlbXApIHtcblx0XHRcdFx0XHRtYXBwZWRbal0gPSB0ZW1wW2pdO1xuXHRcdFx0XHRcdGRpc3Bvc2Vyc1tqXSA9IHRlbXBkaXNwb3NlcnNbal07XG5cdFx0XHRcdFx0aWYgKGluZGV4ZXMpIHtcblx0XHRcdFx0XHRcdGluZGV4ZXNbal0gPSB0ZW1wSW5kZXhlc1tqXTtcblx0XHRcdFx0XHRcdGluZGV4ZXNbal0oaik7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9IGVsc2UgbWFwcGVkW2pdID0gY3JlYXRlUm9vdChtYXBwZXIpO1xuXHRcdFx0XHRtYXBwZWQgPSBtYXBwZWQuc2xpY2UoMCwgbGVuID0gbmV3TGVuKTtcblx0XHRcdFx0aXRlbXMgPSBuZXdJdGVtcy5zbGljZSgwKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBtYXBwZWQ7XG5cdFx0fSk7XG5cdFx0ZnVuY3Rpb24gbWFwcGVyKGRpc3Bvc2VyKSB7XG5cdFx0XHRkaXNwb3NlcnNbal0gPSBkaXNwb3Nlcjtcblx0XHRcdGlmIChpbmRleGVzKSB7XG5cdFx0XHRcdGNvbnN0IFtzLCBzZXRdID0gY3JlYXRlU2lnbmFsKGopO1xuXHRcdFx0XHRpbmRleGVzW2pdID0gc2V0O1xuXHRcdFx0XHRyZXR1cm4gbWFwRm4obmV3SXRlbXNbal0sIHMpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIG1hcEZuKG5ld0l0ZW1zW2pdKTtcblx0XHR9XG5cdH07XG59XG52YXIgaHlkcmF0aW9uRW5hYmxlZCA9IGZhbHNlO1xuZnVuY3Rpb24gY3JlYXRlQ29tcG9uZW50KENvbXAsIHByb3BzKSB7XG5cdGlmIChoeWRyYXRpb25FbmFibGVkKSB7XG5cdFx0aWYgKHNoYXJlZENvbmZpZy5jb250ZXh0KSB7XG5cdFx0XHRjb25zdCBjID0gc2hhcmVkQ29uZmlnLmNvbnRleHQ7XG5cdFx0XHRzZXRIeWRyYXRlQ29udGV4dChuZXh0SHlkcmF0ZUNvbnRleHQoKSk7XG5cdFx0XHRjb25zdCByID0gdW50cmFjaygoKSA9PiBDb21wKHByb3BzIHx8IHt9KSk7XG5cdFx0XHRzZXRIeWRyYXRlQ29udGV4dChjKTtcblx0XHRcdHJldHVybiByO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gdW50cmFjaygoKSA9PiBDb21wKHByb3BzIHx8IHt9KSk7XG59XG5mdW5jdGlvbiB0cnVlRm4oKSB7XG5cdHJldHVybiB0cnVlO1xufVxudmFyIHByb3BUcmFwcyA9IHtcblx0Z2V0KF8sIHByb3BlcnR5LCByZWNlaXZlcikge1xuXHRcdGlmIChwcm9wZXJ0eSA9PT0gJFBST1hZKSByZXR1cm4gcmVjZWl2ZXI7XG5cdFx0cmV0dXJuIF8uZ2V0KHByb3BlcnR5KTtcblx0fSxcblx0aGFzKF8sIHByb3BlcnR5KSB7XG5cdFx0aWYgKHByb3BlcnR5ID09PSAkUFJPWFkpIHJldHVybiB0cnVlO1xuXHRcdHJldHVybiBfLmhhcyhwcm9wZXJ0eSk7XG5cdH0sXG5cdHNldDogdHJ1ZUZuLFxuXHRkZWxldGVQcm9wZXJ0eTogdHJ1ZUZuLFxuXHRnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoXywgcHJvcGVydHkpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0Y29uZmlndXJhYmxlOiB0cnVlLFxuXHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdGdldCgpIHtcblx0XHRcdFx0cmV0dXJuIF8uZ2V0KHByb3BlcnR5KTtcblx0XHRcdH0sXG5cdFx0XHRzZXQ6IHRydWVGbixcblx0XHRcdGRlbGV0ZVByb3BlcnR5OiB0cnVlRm5cblx0XHR9O1xuXHR9LFxuXHRvd25LZXlzKF8pIHtcblx0XHRyZXR1cm4gXy5rZXlzKCk7XG5cdH1cbn07XG5mdW5jdGlvbiByZXNvbHZlU291cmNlKHMpIHtcblx0cmV0dXJuICEocyA9IHR5cGVvZiBzID09PSBcImZ1bmN0aW9uXCIgPyBzKCkgOiBzKSA/IHt9IDogcztcbn1cbmZ1bmN0aW9uIHJlc29sdmVTb3VyY2VzKCkge1xuXHRmb3IgKGxldCBpID0gMCwgbGVuZ3RoID0gdGhpcy5sZW5ndGg7IGkgPCBsZW5ndGg7ICsraSkge1xuXHRcdGNvbnN0IHYgPSB0aGlzW2ldKCk7XG5cdFx0aWYgKHYgIT09IHZvaWQgMCkgcmV0dXJuIHY7XG5cdH1cbn1cbmZ1bmN0aW9uIG1lcmdlUHJvcHMoLi4uc291cmNlcykge1xuXHRsZXQgcHJveHkgPSBmYWxzZTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBzb3VyY2VzLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3QgcyA9IHNvdXJjZXNbaV07XG5cdFx0cHJveHkgPSBwcm94eSB8fCAhIXMgJiYgJFBST1hZIGluIHM7XG5cdFx0c291cmNlc1tpXSA9IHR5cGVvZiBzID09PSBcImZ1bmN0aW9uXCIgPyAocHJveHkgPSB0cnVlLCBjcmVhdGVNZW1vKHMpKSA6IHM7XG5cdH1cblx0aWYgKFNVUFBPUlRTX1BST1hZICYmIHByb3h5KSByZXR1cm4gbmV3IFByb3h5KHtcblx0XHRnZXQocHJvcGVydHkpIHtcblx0XHRcdGZvciAobGV0IGkgPSBzb3VyY2VzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRcdGNvbnN0IHYgPSByZXNvbHZlU291cmNlKHNvdXJjZXNbaV0pW3Byb3BlcnR5XTtcblx0XHRcdFx0aWYgKHYgIT09IHZvaWQgMCkgcmV0dXJuIHY7XG5cdFx0XHR9XG5cdFx0fSxcblx0XHRoYXMocHJvcGVydHkpIHtcblx0XHRcdGZvciAobGV0IGkgPSBzb3VyY2VzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBpZiAocHJvcGVydHkgaW4gcmVzb2x2ZVNvdXJjZShzb3VyY2VzW2ldKSkgcmV0dXJuIHRydWU7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fSxcblx0XHRrZXlzKCkge1xuXHRcdFx0Y29uc3Qga2V5cyA9IFtdO1xuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBzb3VyY2VzLmxlbmd0aDsgaSsrKSBrZXlzLnB1c2goLi4uT2JqZWN0LmtleXMocmVzb2x2ZVNvdXJjZShzb3VyY2VzW2ldKSkpO1xuXHRcdFx0cmV0dXJuIFsuLi5uZXcgU2V0KGtleXMpXTtcblx0XHR9XG5cdH0sIHByb3BUcmFwcyk7XG5cdGNvbnN0IHNvdXJjZXNNYXAgPSB7fTtcblx0Y29uc3QgZGVmaW5lZCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG5cdGZvciAobGV0IGkgPSBzb3VyY2VzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0Y29uc3Qgc291cmNlID0gc291cmNlc1tpXTtcblx0XHRpZiAoIXNvdXJjZSkgY29udGludWU7XG5cdFx0Y29uc3Qgc291cmNlS2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHNvdXJjZSk7XG5cdFx0Zm9yIChsZXQgaSA9IHNvdXJjZUtleXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcblx0XHRcdGNvbnN0IGtleSA9IHNvdXJjZUtleXNbaV07XG5cdFx0XHRpZiAoa2V5ID09PSBcIl9fcHJvdG9fX1wiIHx8IGtleSA9PT0gXCJjb25zdHJ1Y3RvclwiKSBjb250aW51ZTtcblx0XHRcdGNvbnN0IGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHNvdXJjZSwga2V5KTtcblx0XHRcdGlmICghZGVmaW5lZFtrZXldKSBkZWZpbmVkW2tleV0gPSBkZXNjLmdldCA/IHtcblx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdFx0Y29uZmlndXJhYmxlOiB0cnVlLFxuXHRcdFx0XHRnZXQ6IHJlc29sdmVTb3VyY2VzLmJpbmQoc291cmNlc01hcFtrZXldID0gW2Rlc2MuZ2V0LmJpbmQoc291cmNlKV0pXG5cdFx0XHR9IDogZGVzYy52YWx1ZSAhPT0gdm9pZCAwID8gZGVzYyA6IHZvaWQgMDtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRjb25zdCBzb3VyY2VzID0gc291cmNlc01hcFtrZXldO1xuXHRcdFx0XHRpZiAoc291cmNlcykge1xuXHRcdFx0XHRcdGlmIChkZXNjLmdldCkgc291cmNlcy5wdXNoKGRlc2MuZ2V0LmJpbmQoc291cmNlKSk7XG5cdFx0XHRcdFx0ZWxzZSBpZiAoZGVzYy52YWx1ZSAhPT0gdm9pZCAwKSBzb3VyY2VzLnB1c2goKCkgPT4gZGVzYy52YWx1ZSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH1cblx0Y29uc3QgdGFyZ2V0ID0ge307XG5cdGNvbnN0IGRlZmluZWRLZXlzID0gT2JqZWN0LmtleXMoZGVmaW5lZCk7XG5cdGZvciAobGV0IGkgPSBkZWZpbmVkS2V5cy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdGNvbnN0IGtleSA9IGRlZmluZWRLZXlzW2ldLCBkZXNjID0gZGVmaW5lZFtrZXldO1xuXHRcdGlmIChkZXNjICYmIGRlc2MuZ2V0KSBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIGRlc2MpO1xuXHRcdGVsc2UgdGFyZ2V0W2tleV0gPSBkZXNjID8gZGVzYy52YWx1ZSA6IHZvaWQgMDtcblx0fVxuXHRyZXR1cm4gdGFyZ2V0O1xufVxuZnVuY3Rpb24gc3BsaXRQcm9wcyhwcm9wcywgLi4ua2V5cykge1xuXHRjb25zdCBsZW4gPSBrZXlzLmxlbmd0aDtcblx0aWYgKFNVUFBPUlRTX1BST1hZICYmICRQUk9YWSBpbiBwcm9wcykge1xuXHRcdGNvbnN0IGJsb2NrZWQgPSBsZW4gPiAxID8ga2V5cy5mbGF0KCkgOiBrZXlzWzBdO1xuXHRcdGNvbnN0IHJlcyA9IGtleXMubWFwKChrKSA9PiB7XG5cdFx0XHRyZXR1cm4gbmV3IFByb3h5KHtcblx0XHRcdFx0Z2V0KHByb3BlcnR5KSB7XG5cdFx0XHRcdFx0cmV0dXJuIGsuaW5jbHVkZXMocHJvcGVydHkpID8gcHJvcHNbcHJvcGVydHldIDogdm9pZCAwO1xuXHRcdFx0XHR9LFxuXHRcdFx0XHRoYXMocHJvcGVydHkpIHtcblx0XHRcdFx0XHRyZXR1cm4gay5pbmNsdWRlcyhwcm9wZXJ0eSkgJiYgcHJvcGVydHkgaW4gcHJvcHM7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdGtleXMoKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGsuZmlsdGVyKChwcm9wZXJ0eSkgPT4gcHJvcGVydHkgaW4gcHJvcHMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9LCBwcm9wVHJhcHMpO1xuXHRcdH0pO1xuXHRcdHJlcy5wdXNoKG5ldyBQcm94eSh7XG5cdFx0XHRnZXQocHJvcGVydHkpIHtcblx0XHRcdFx0cmV0dXJuIGJsb2NrZWQuaW5jbHVkZXMocHJvcGVydHkpID8gdm9pZCAwIDogcHJvcHNbcHJvcGVydHldO1xuXHRcdFx0fSxcblx0XHRcdGhhcyhwcm9wZXJ0eSkge1xuXHRcdFx0XHRyZXR1cm4gYmxvY2tlZC5pbmNsdWRlcyhwcm9wZXJ0eSkgPyBmYWxzZSA6IHByb3BlcnR5IGluIHByb3BzO1xuXHRcdFx0fSxcblx0XHRcdGtleXMoKSB7XG5cdFx0XHRcdHJldHVybiBPYmplY3Qua2V5cyhwcm9wcykuZmlsdGVyKChrKSA9PiAhYmxvY2tlZC5pbmNsdWRlcyhrKSk7XG5cdFx0XHR9XG5cdFx0fSwgcHJvcFRyYXBzKSk7XG5cdFx0cmV0dXJuIHJlcztcblx0fVxuXHRjb25zdCBvYmplY3RzID0gW107XG5cdGZvciAobGV0IGkgPSAwOyBpIDw9IGxlbjsgaSsrKSBvYmplY3RzW2ldID0ge307XG5cdGZvciAoY29uc3QgcHJvcE5hbWUgb2YgT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMocHJvcHMpKSB7XG5cdFx0bGV0IGtleUluZGV4ID0gbGVuO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7IGkrKykgaWYgKGtleXNbaV0uaW5jbHVkZXMocHJvcE5hbWUpKSB7XG5cdFx0XHRrZXlJbmRleCA9IGk7XG5cdFx0XHRicmVhaztcblx0XHR9XG5cdFx0Y29uc3QgZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IocHJvcHMsIHByb3BOYW1lKTtcblx0XHQhZGVzYy5nZXQgJiYgIWRlc2Muc2V0ICYmIGRlc2MuZW51bWVyYWJsZSAmJiBkZXNjLndyaXRhYmxlICYmIGRlc2MuY29uZmlndXJhYmxlID8gb2JqZWN0c1trZXlJbmRleF1bcHJvcE5hbWVdID0gZGVzYy52YWx1ZSA6IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmplY3RzW2tleUluZGV4XSwgcHJvcE5hbWUsIGRlc2MpO1xuXHR9XG5cdHJldHVybiBvYmplY3RzO1xufVxuZnVuY3Rpb24gbGF6eShmbikge1xuXHRsZXQgY29tcDtcblx0bGV0IHA7XG5cdGNvbnN0IHdyYXAgPSAocHJvcHMpID0+IHtcblx0XHRjb25zdCBjdHggPSBzaGFyZWRDb25maWcuY29udGV4dDtcblx0XHRpZiAoY3R4KSB7XG5cdFx0XHRjb25zdCBbcywgc2V0XSA9IGNyZWF0ZVNpZ25hbCgpO1xuXHRcdFx0c2hhcmVkQ29uZmlnLmNvdW50IHx8IChzaGFyZWRDb25maWcuY291bnQgPSAwKTtcblx0XHRcdHNoYXJlZENvbmZpZy5jb3VudCsrO1xuXHRcdFx0KHAgfHwgKHAgPSBmbigpKSkudGhlbigobW9kKSA9PiB7XG5cdFx0XHRcdCFzaGFyZWRDb25maWcuZG9uZSAmJiBzZXRIeWRyYXRlQ29udGV4dChjdHgpO1xuXHRcdFx0XHRzaGFyZWRDb25maWcuY291bnQtLTtcblx0XHRcdFx0c2V0KCgpID0+IG1vZC5kZWZhdWx0KTtcblx0XHRcdFx0c2V0SHlkcmF0ZUNvbnRleHQoKTtcblx0XHRcdH0pO1xuXHRcdFx0Y29tcCA9IHM7XG5cdFx0fSBlbHNlIGlmICghY29tcCkge1xuXHRcdFx0Y29uc3QgW3NdID0gY3JlYXRlUmVzb3VyY2UoKCkgPT4gKHAgfHwgKHAgPSBmbigpKSkudGhlbigobW9kKSA9PiBtb2QuZGVmYXVsdCkpO1xuXHRcdFx0Y29tcCA9IHM7XG5cdFx0fVxuXHRcdGxldCBDb21wO1xuXHRcdHJldHVybiBjcmVhdGVNZW1vKCgpID0+IChDb21wID0gY29tcCgpKSA/IHVudHJhY2soKCkgPT4ge1xuXHRcdFx0aWYgKCFjdHggfHwgc2hhcmVkQ29uZmlnLmRvbmUpIHJldHVybiBDb21wKHByb3BzKTtcblx0XHRcdGNvbnN0IGMgPSBzaGFyZWRDb25maWcuY29udGV4dDtcblx0XHRcdHNldEh5ZHJhdGVDb250ZXh0KGN0eCk7XG5cdFx0XHRjb25zdCByID0gQ29tcChwcm9wcyk7XG5cdFx0XHRzZXRIeWRyYXRlQ29udGV4dChjKTtcblx0XHRcdHJldHVybiByO1xuXHRcdH0pIDogXCJcIik7XG5cdH07XG5cdHdyYXAucHJlbG9hZCA9ICgpID0+IHAgfHwgKChwID0gZm4oKSkudGhlbigobW9kKSA9PiBjb21wID0gKCkgPT4gbW9kLmRlZmF1bHQpLCBwKTtcblx0cmV0dXJuIHdyYXA7XG59XG52YXIgY291bnRlciA9IDA7XG5mdW5jdGlvbiBjcmVhdGVVbmlxdWVJZCgpIHtcblx0cmV0dXJuIHNoYXJlZENvbmZpZy5jb250ZXh0ID8gc2hhcmVkQ29uZmlnLmdldE5leHRDb250ZXh0SWQoKSA6IGBjbC0ke2NvdW50ZXIrK31gO1xufVxudmFyIG5hcnJvd2VkRXJyb3IgPSAobmFtZSkgPT4gYFN0YWxlIHJlYWQgZnJvbSA8JHtuYW1lfT4uYDtcbmZ1bmN0aW9uIEZvcihwcm9wcykge1xuXHRjb25zdCBmYWxsYmFjayA9IFwiZmFsbGJhY2tcIiBpbiBwcm9wcyAmJiB7IGZhbGxiYWNrOiAoKSA9PiBwcm9wcy5mYWxsYmFjayB9O1xuXHRyZXR1cm4gY3JlYXRlTWVtbyhtYXBBcnJheSgoKSA9PiBwcm9wcy5lYWNoLCBwcm9wcy5jaGlsZHJlbiwgZmFsbGJhY2sgfHwgdm9pZCAwKSk7XG59XG5mdW5jdGlvbiBTaG93KHByb3BzKSB7XG5cdGNvbnN0IGtleWVkID0gcHJvcHMua2V5ZWQ7XG5cdGNvbnN0IGNvbmRpdGlvblZhbHVlID0gY3JlYXRlTWVtbygoKSA9PiBwcm9wcy53aGVuLCB2b2lkIDAsIHZvaWQgMCk7XG5cdGNvbnN0IGNvbmRpdGlvbiA9IGtleWVkID8gY29uZGl0aW9uVmFsdWUgOiBjcmVhdGVNZW1vKGNvbmRpdGlvblZhbHVlLCB2b2lkIDAsIHsgZXF1YWxzOiAoYSwgYikgPT4gIWEgPT09ICFiIH0pO1xuXHRyZXR1cm4gY3JlYXRlTWVtbygoKSA9PiB7XG5cdFx0Y29uc3QgYyA9IGNvbmRpdGlvbigpO1xuXHRcdGlmIChjKSB7XG5cdFx0XHRjb25zdCBjaGlsZCA9IHByb3BzLmNoaWxkcmVuO1xuXHRcdFx0cmV0dXJuIHR5cGVvZiBjaGlsZCA9PT0gXCJmdW5jdGlvblwiICYmIGNoaWxkLmxlbmd0aCA+IDAgPyB1bnRyYWNrKCgpID0+IGNoaWxkKGtleWVkID8gYyA6ICgpID0+IHtcblx0XHRcdFx0aWYgKCF1bnRyYWNrKGNvbmRpdGlvbikpIHRocm93IG5hcnJvd2VkRXJyb3IoXCJTaG93XCIpO1xuXHRcdFx0XHRyZXR1cm4gY29uZGl0aW9uVmFsdWUoKTtcblx0XHRcdH0pKSA6IGNoaWxkO1xuXHRcdH1cblx0XHRyZXR1cm4gcHJvcHMuZmFsbGJhY2s7XG5cdH0sIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIFN3aXRjaChwcm9wcykge1xuXHRjb25zdCBjaHMgPSBjaGlsZHJlbigoKSA9PiBwcm9wcy5jaGlsZHJlbik7XG5cdGNvbnN0IHN3aXRjaEZ1bmMgPSBjcmVhdGVNZW1vKCgpID0+IHtcblx0XHRjb25zdCBjaCA9IGNocygpO1xuXHRcdGNvbnN0IG1wcyA9IEFycmF5LmlzQXJyYXkoY2gpID8gY2ggOiBbY2hdO1xuXHRcdGxldCBmdW5jID0gKCkgPT4gdm9pZCAwO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgbXBzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRjb25zdCBpbmRleCA9IGk7XG5cdFx0XHRjb25zdCBtcCA9IG1wc1tpXTtcblx0XHRcdGNvbnN0IHByZXZGdW5jID0gZnVuYztcblx0XHRcdGNvbnN0IGNvbmRpdGlvblZhbHVlID0gY3JlYXRlTWVtbygoKSA9PiBwcmV2RnVuYygpID8gdm9pZCAwIDogbXAud2hlbiwgdm9pZCAwLCB2b2lkIDApO1xuXHRcdFx0Y29uc3QgY29uZGl0aW9uID0gbXAua2V5ZWQgPyBjb25kaXRpb25WYWx1ZSA6IGNyZWF0ZU1lbW8oY29uZGl0aW9uVmFsdWUsIHZvaWQgMCwgeyBlcXVhbHM6IChhLCBiKSA9PiAhYSA9PT0gIWIgfSk7XG5cdFx0XHRmdW5jID0gKCkgPT4gcHJldkZ1bmMoKSB8fCAoY29uZGl0aW9uKCkgPyBbXG5cdFx0XHRcdGluZGV4LFxuXHRcdFx0XHRjb25kaXRpb25WYWx1ZSxcblx0XHRcdFx0bXBcblx0XHRcdF0gOiB2b2lkIDApO1xuXHRcdH1cblx0XHRyZXR1cm4gZnVuYztcblx0fSk7XG5cdHJldHVybiBjcmVhdGVNZW1vKCgpID0+IHtcblx0XHRjb25zdCBzZWwgPSBzd2l0Y2hGdW5jKCkoKTtcblx0XHRpZiAoIXNlbCkgcmV0dXJuIHByb3BzLmZhbGxiYWNrO1xuXHRcdGNvbnN0IFtpbmRleCwgY29uZGl0aW9uVmFsdWUsIG1wXSA9IHNlbDtcblx0XHRjb25zdCBjaGlsZCA9IG1wLmNoaWxkcmVuO1xuXHRcdHJldHVybiB0eXBlb2YgY2hpbGQgPT09IFwiZnVuY3Rpb25cIiAmJiBjaGlsZC5sZW5ndGggPiAwID8gdW50cmFjaygoKSA9PiBjaGlsZChtcC5rZXllZCA/IGNvbmRpdGlvblZhbHVlKCkgOiAoKSA9PiB7XG5cdFx0XHRpZiAodW50cmFjayhzd2l0Y2hGdW5jKSgpPy5bMF0gIT09IGluZGV4KSB0aHJvdyBuYXJyb3dlZEVycm9yKFwiTWF0Y2hcIik7XG5cdFx0XHRyZXR1cm4gY29uZGl0aW9uVmFsdWUoKTtcblx0XHR9KSkgOiBjaGlsZDtcblx0fSwgdm9pZCAwLCB2b2lkIDApO1xufVxuZnVuY3Rpb24gTWF0Y2gocHJvcHMpIHtcblx0cmV0dXJuIHByb3BzO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NvbGlkLWpzQDEuOS4xMi9ub2RlX21vZHVsZXMvc29saWQtanMvd2ViL2Rpc3Qvd2ViLmpzXG52YXIgUHJvcGVydGllcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtcblx0XCJjbGFzc05hbWVcIixcblx0XCJ2YWx1ZVwiLFxuXHRcInJlYWRPbmx5XCIsXG5cdFwibm9WYWxpZGF0ZVwiLFxuXHRcImZvcm1Ob1ZhbGlkYXRlXCIsXG5cdFwiaXNNYXBcIixcblx0XCJub01vZHVsZVwiLFxuXHRcInBsYXlzSW5saW5lXCIsXG5cdFwiYWRBdWN0aW9uSGVhZGVyc1wiLFxuXHRcImFsbG93RnVsbHNjcmVlblwiLFxuXHRcImJyb3dzaW5nVG9waWNzXCIsXG5cdFwiZGVmYXVsdENoZWNrZWRcIixcblx0XCJkZWZhdWx0TXV0ZWRcIixcblx0XCJkZWZhdWx0U2VsZWN0ZWRcIixcblx0XCJkaXNhYmxlUGljdHVyZUluUGljdHVyZVwiLFxuXHRcImRpc2FibGVSZW1vdGVQbGF5YmFja1wiLFxuXHRcInByZXNlcnZlc1BpdGNoXCIsXG5cdFwic2hhZG93Um9vdENsb25hYmxlXCIsXG5cdFwic2hhZG93Um9vdEN1c3RvbUVsZW1lbnRSZWdpc3RyeVwiLFxuXHRcInNoYWRvd1Jvb3REZWxlZ2F0ZXNGb2N1c1wiLFxuXHRcInNoYWRvd1Jvb3RTZXJpYWxpemFibGVcIixcblx0XCJzaGFyZWRTdG9yYWdlV3JpdGFibGVcIixcblx0Li4uW1xuXHRcdFwiYWxsb3dmdWxsc2NyZWVuXCIsXG5cdFx0XCJhc3luY1wiLFxuXHRcdFwiYWxwaGFcIixcblx0XHRcImF1dG9mb2N1c1wiLFxuXHRcdFwiYXV0b3BsYXlcIixcblx0XHRcImNoZWNrZWRcIixcblx0XHRcImNvbnRyb2xzXCIsXG5cdFx0XCJkZWZhdWx0XCIsXG5cdFx0XCJkaXNhYmxlZFwiLFxuXHRcdFwiZm9ybW5vdmFsaWRhdGVcIixcblx0XHRcImhpZGRlblwiLFxuXHRcdFwiaW5kZXRlcm1pbmF0ZVwiLFxuXHRcdFwiaW5lcnRcIixcblx0XHRcImlzbWFwXCIsXG5cdFx0XCJsb29wXCIsXG5cdFx0XCJtdWx0aXBsZVwiLFxuXHRcdFwibXV0ZWRcIixcblx0XHRcIm5vbW9kdWxlXCIsXG5cdFx0XCJub3ZhbGlkYXRlXCIsXG5cdFx0XCJvcGVuXCIsXG5cdFx0XCJwbGF5c2lubGluZVwiLFxuXHRcdFwicmVhZG9ubHlcIixcblx0XHRcInJlcXVpcmVkXCIsXG5cdFx0XCJyZXZlcnNlZFwiLFxuXHRcdFwic2VhbWxlc3NcIixcblx0XHRcInNlbGVjdGVkXCIsXG5cdFx0XCJhZGF1Y3Rpb25oZWFkZXJzXCIsXG5cdFx0XCJicm93c2luZ3RvcGljc1wiLFxuXHRcdFwiY3JlZGVudGlhbGxlc3NcIixcblx0XHRcImRlZmF1bHRjaGVja2VkXCIsXG5cdFx0XCJkZWZhdWx0bXV0ZWRcIixcblx0XHRcImRlZmF1bHRzZWxlY3RlZFwiLFxuXHRcdFwiZGVmZXJcIixcblx0XHRcImRpc2FibGVwaWN0dXJlaW5waWN0dXJlXCIsXG5cdFx0XCJkaXNhYmxlcmVtb3RlcGxheWJhY2tcIixcblx0XHRcInByZXNlcnZlc3BpdGNoXCIsXG5cdFx0XCJzaGFkb3dyb290Y2xvbmFibGVcIixcblx0XHRcInNoYWRvd3Jvb3RjdXN0b21lbGVtZW50cmVnaXN0cnlcIixcblx0XHRcInNoYWRvd3Jvb3RkZWxlZ2F0ZXNmb2N1c1wiLFxuXHRcdFwic2hhZG93cm9vdHNlcmlhbGl6YWJsZVwiLFxuXHRcdFwic2hhcmVkc3RvcmFnZXdyaXRhYmxlXCJcblx0XVxuXSk7XG52YXIgQ2hpbGRQcm9wZXJ0aWVzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW1xuXHRcImlubmVySFRNTFwiLFxuXHRcInRleHRDb250ZW50XCIsXG5cdFwiaW5uZXJUZXh0XCIsXG5cdFwiY2hpbGRyZW5cIlxuXSk7XG52YXIgQWxpYXNlcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuYXNzaWduKE9iamVjdC5jcmVhdGUobnVsbCksIHtcblx0Y2xhc3NOYW1lOiBcImNsYXNzXCIsXG5cdGh0bWxGb3I6IFwiZm9yXCJcbn0pO1xudmFyIFByb3BBbGlhc2VzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5hc3NpZ24oT2JqZWN0LmNyZWF0ZShudWxsKSwge1xuXHRjbGFzczogXCJjbGFzc05hbWVcIixcblx0bm92YWxpZGF0ZToge1xuXHRcdCQ6IFwibm9WYWxpZGF0ZVwiLFxuXHRcdEZPUk06IDFcblx0fSxcblx0Zm9ybW5vdmFsaWRhdGU6IHtcblx0XHQkOiBcImZvcm1Ob1ZhbGlkYXRlXCIsXG5cdFx0QlVUVE9OOiAxLFxuXHRcdElOUFVUOiAxXG5cdH0sXG5cdGlzbWFwOiB7XG5cdFx0JDogXCJpc01hcFwiLFxuXHRcdElNRzogMVxuXHR9LFxuXHRub21vZHVsZToge1xuXHRcdCQ6IFwibm9Nb2R1bGVcIixcblx0XHRTQ1JJUFQ6IDFcblx0fSxcblx0cGxheXNpbmxpbmU6IHtcblx0XHQkOiBcInBsYXlzSW5saW5lXCIsXG5cdFx0VklERU86IDFcblx0fSxcblx0cmVhZG9ubHk6IHtcblx0XHQkOiBcInJlYWRPbmx5XCIsXG5cdFx0SU5QVVQ6IDEsXG5cdFx0VEVYVEFSRUE6IDFcblx0fSxcblx0YWRhdWN0aW9uaGVhZGVyczoge1xuXHRcdCQ6IFwiYWRBdWN0aW9uSGVhZGVyc1wiLFxuXHRcdElGUkFNRTogMVxuXHR9LFxuXHRhbGxvd2Z1bGxzY3JlZW46IHtcblx0XHQkOiBcImFsbG93RnVsbHNjcmVlblwiLFxuXHRcdElGUkFNRTogMVxuXHR9LFxuXHRicm93c2luZ3RvcGljczoge1xuXHRcdCQ6IFwiYnJvd3NpbmdUb3BpY3NcIixcblx0XHRJTUc6IDFcblx0fSxcblx0ZGVmYXVsdGNoZWNrZWQ6IHtcblx0XHQkOiBcImRlZmF1bHRDaGVja2VkXCIsXG5cdFx0SU5QVVQ6IDFcblx0fSxcblx0ZGVmYXVsdG11dGVkOiB7XG5cdFx0JDogXCJkZWZhdWx0TXV0ZWRcIixcblx0XHRBVURJTzogMSxcblx0XHRWSURFTzogMVxuXHR9LFxuXHRkZWZhdWx0c2VsZWN0ZWQ6IHtcblx0XHQkOiBcImRlZmF1bHRTZWxlY3RlZFwiLFxuXHRcdE9QVElPTjogMVxuXHR9LFxuXHRkaXNhYmxlcGljdHVyZWlucGljdHVyZToge1xuXHRcdCQ6IFwiZGlzYWJsZVBpY3R1cmVJblBpY3R1cmVcIixcblx0XHRWSURFTzogMVxuXHR9LFxuXHRkaXNhYmxlcmVtb3RlcGxheWJhY2s6IHtcblx0XHQkOiBcImRpc2FibGVSZW1vdGVQbGF5YmFja1wiLFxuXHRcdEFVRElPOiAxLFxuXHRcdFZJREVPOiAxXG5cdH0sXG5cdHByZXNlcnZlc3BpdGNoOiB7XG5cdFx0JDogXCJwcmVzZXJ2ZXNQaXRjaFwiLFxuXHRcdEFVRElPOiAxLFxuXHRcdFZJREVPOiAxXG5cdH0sXG5cdHNoYWRvd3Jvb3RjbG9uYWJsZToge1xuXHRcdCQ6IFwic2hhZG93Um9vdENsb25hYmxlXCIsXG5cdFx0VEVNUExBVEU6IDFcblx0fSxcblx0c2hhZG93cm9vdGRlbGVnYXRlc2ZvY3VzOiB7XG5cdFx0JDogXCJzaGFkb3dSb290RGVsZWdhdGVzRm9jdXNcIixcblx0XHRURU1QTEFURTogMVxuXHR9LFxuXHRzaGFkb3dyb290c2VyaWFsaXphYmxlOiB7XG5cdFx0JDogXCJzaGFkb3dSb290U2VyaWFsaXphYmxlXCIsXG5cdFx0VEVNUExBVEU6IDFcblx0fSxcblx0c2hhcmVkc3RvcmFnZXdyaXRhYmxlOiB7XG5cdFx0JDogXCJzaGFyZWRTdG9yYWdlV3JpdGFibGVcIixcblx0XHRJRlJBTUU6IDEsXG5cdFx0SU1HOiAxXG5cdH1cbn0pO1xuZnVuY3Rpb24gZ2V0UHJvcEFsaWFzKHByb3AsIHRhZ05hbWUpIHtcblx0Y29uc3QgYSA9IFByb3BBbGlhc2VzW3Byb3BdO1xuXHRyZXR1cm4gdHlwZW9mIGEgPT09IFwib2JqZWN0XCIgPyBhW3RhZ05hbWVdID8gYVtcIiRcIl0gOiB2b2lkIDAgOiBhO1xufVxudmFyIERlbGVnYXRlZEV2ZW50cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtcblx0XCJiZWZvcmVpbnB1dFwiLFxuXHRcImNsaWNrXCIsXG5cdFwiZGJsY2xpY2tcIixcblx0XCJjb250ZXh0bWVudVwiLFxuXHRcImZvY3VzaW5cIixcblx0XCJmb2N1c291dFwiLFxuXHRcImlucHV0XCIsXG5cdFwia2V5ZG93blwiLFxuXHRcImtleXVwXCIsXG5cdFwibW91c2Vkb3duXCIsXG5cdFwibW91c2Vtb3ZlXCIsXG5cdFwibW91c2VvdXRcIixcblx0XCJtb3VzZW92ZXJcIixcblx0XCJtb3VzZXVwXCIsXG5cdFwicG9pbnRlcmRvd25cIixcblx0XCJwb2ludGVybW92ZVwiLFxuXHRcInBvaW50ZXJvdXRcIixcblx0XCJwb2ludGVyb3ZlclwiLFxuXHRcInBvaW50ZXJ1cFwiLFxuXHRcInRvdWNoZW5kXCIsXG5cdFwidG91Y2htb3ZlXCIsXG5cdFwidG91Y2hzdGFydFwiXG5dKTtcbnZhciBTVkdFbGVtZW50cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtcblx0XCJhbHRHbHlwaFwiLFxuXHRcImFsdEdseXBoRGVmXCIsXG5cdFwiYWx0R2x5cGhJdGVtXCIsXG5cdFwiYW5pbWF0ZVwiLFxuXHRcImFuaW1hdGVDb2xvclwiLFxuXHRcImFuaW1hdGVNb3Rpb25cIixcblx0XCJhbmltYXRlVHJhbnNmb3JtXCIsXG5cdFwiY2lyY2xlXCIsXG5cdFwiY2xpcFBhdGhcIixcblx0XCJjb2xvci1wcm9maWxlXCIsXG5cdFwiY3Vyc29yXCIsXG5cdFwiZGVmc1wiLFxuXHRcImRlc2NcIixcblx0XCJlbGxpcHNlXCIsXG5cdFwiZmVCbGVuZFwiLFxuXHRcImZlQ29sb3JNYXRyaXhcIixcblx0XCJmZUNvbXBvbmVudFRyYW5zZmVyXCIsXG5cdFwiZmVDb21wb3NpdGVcIixcblx0XCJmZUNvbnZvbHZlTWF0cml4XCIsXG5cdFwiZmVEaWZmdXNlTGlnaHRpbmdcIixcblx0XCJmZURpc3BsYWNlbWVudE1hcFwiLFxuXHRcImZlRGlzdGFudExpZ2h0XCIsXG5cdFwiZmVEcm9wU2hhZG93XCIsXG5cdFwiZmVGbG9vZFwiLFxuXHRcImZlRnVuY0FcIixcblx0XCJmZUZ1bmNCXCIsXG5cdFwiZmVGdW5jR1wiLFxuXHRcImZlRnVuY1JcIixcblx0XCJmZUdhdXNzaWFuQmx1clwiLFxuXHRcImZlSW1hZ2VcIixcblx0XCJmZU1lcmdlXCIsXG5cdFwiZmVNZXJnZU5vZGVcIixcblx0XCJmZU1vcnBob2xvZ3lcIixcblx0XCJmZU9mZnNldFwiLFxuXHRcImZlUG9pbnRMaWdodFwiLFxuXHRcImZlU3BlY3VsYXJMaWdodGluZ1wiLFxuXHRcImZlU3BvdExpZ2h0XCIsXG5cdFwiZmVUaWxlXCIsXG5cdFwiZmVUdXJidWxlbmNlXCIsXG5cdFwiZmlsdGVyXCIsXG5cdFwiZm9udFwiLFxuXHRcImZvbnQtZmFjZVwiLFxuXHRcImZvbnQtZmFjZS1mb3JtYXRcIixcblx0XCJmb250LWZhY2UtbmFtZVwiLFxuXHRcImZvbnQtZmFjZS1zcmNcIixcblx0XCJmb250LWZhY2UtdXJpXCIsXG5cdFwiZm9yZWlnbk9iamVjdFwiLFxuXHRcImdcIixcblx0XCJnbHlwaFwiLFxuXHRcImdseXBoUmVmXCIsXG5cdFwiaGtlcm5cIixcblx0XCJpbWFnZVwiLFxuXHRcImxpbmVcIixcblx0XCJsaW5lYXJHcmFkaWVudFwiLFxuXHRcIm1hcmtlclwiLFxuXHRcIm1hc2tcIixcblx0XCJtZXRhZGF0YVwiLFxuXHRcIm1pc3NpbmctZ2x5cGhcIixcblx0XCJtcGF0aFwiLFxuXHRcInBhdGhcIixcblx0XCJwYXR0ZXJuXCIsXG5cdFwicG9seWdvblwiLFxuXHRcInBvbHlsaW5lXCIsXG5cdFwicmFkaWFsR3JhZGllbnRcIixcblx0XCJyZWN0XCIsXG5cdFwic2V0XCIsXG5cdFwic3RvcFwiLFxuXHRcInN2Z1wiLFxuXHRcInN3aXRjaFwiLFxuXHRcInN5bWJvbFwiLFxuXHRcInRleHRcIixcblx0XCJ0ZXh0UGF0aFwiLFxuXHRcInRyZWZcIixcblx0XCJ0c3BhblwiLFxuXHRcInVzZVwiLFxuXHRcInZpZXdcIixcblx0XCJ2a2VyblwiXG5dKTtcbnZhciBTVkdOYW1lc3BhY2UgPSB7XG5cdHhsaW5rOiBcImh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmtcIixcblx0eG1sOiBcImh0dHA6Ly93d3cudzMub3JnL1hNTC8xOTk4L25hbWVzcGFjZVwiXG59O1xudmFyIG1lbW8gPSAoZm4pID0+IGNyZWF0ZU1lbW8oKCkgPT4gZm4oKSk7XG5mdW5jdGlvbiByZWNvbmNpbGVBcnJheXMocGFyZW50Tm9kZSwgYSwgYikge1xuXHRsZXQgYkxlbmd0aCA9IGIubGVuZ3RoLCBhRW5kID0gYS5sZW5ndGgsIGJFbmQgPSBiTGVuZ3RoLCBhU3RhcnQgPSAwLCBiU3RhcnQgPSAwLCBhZnRlciA9IGFbYUVuZCAtIDFdLm5leHRTaWJsaW5nLCBtYXAgPSBudWxsO1xuXHR3aGlsZSAoYVN0YXJ0IDwgYUVuZCB8fCBiU3RhcnQgPCBiRW5kKSB7XG5cdFx0aWYgKGFbYVN0YXJ0XSA9PT0gYltiU3RhcnRdKSB7XG5cdFx0XHRhU3RhcnQrKztcblx0XHRcdGJTdGFydCsrO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdHdoaWxlIChhW2FFbmQgLSAxXSA9PT0gYltiRW5kIC0gMV0pIHtcblx0XHRcdGFFbmQtLTtcblx0XHRcdGJFbmQtLTtcblx0XHR9XG5cdFx0aWYgKGFFbmQgPT09IGFTdGFydCkge1xuXHRcdFx0Y29uc3Qgbm9kZSA9IGJFbmQgPCBiTGVuZ3RoID8gYlN0YXJ0ID8gYltiU3RhcnQgLSAxXS5uZXh0U2libGluZyA6IGJbYkVuZCAtIGJTdGFydF0gOiBhZnRlcjtcblx0XHRcdHdoaWxlIChiU3RhcnQgPCBiRW5kKSBwYXJlbnROb2RlLmluc2VydEJlZm9yZShiW2JTdGFydCsrXSwgbm9kZSk7XG5cdFx0fSBlbHNlIGlmIChiRW5kID09PSBiU3RhcnQpIHdoaWxlIChhU3RhcnQgPCBhRW5kKSB7XG5cdFx0XHRpZiAoIW1hcCB8fCAhbWFwLmhhcyhhW2FTdGFydF0pKSBhW2FTdGFydF0ucmVtb3ZlKCk7XG5cdFx0XHRhU3RhcnQrKztcblx0XHR9XG5cdFx0ZWxzZSBpZiAoYVthU3RhcnRdID09PSBiW2JFbmQgLSAxXSAmJiBiW2JTdGFydF0gPT09IGFbYUVuZCAtIDFdKSB7XG5cdFx0XHRjb25zdCBub2RlID0gYVstLWFFbmRdLm5leHRTaWJsaW5nO1xuXHRcdFx0cGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoYltiU3RhcnQrK10sIGFbYVN0YXJ0KytdLm5leHRTaWJsaW5nKTtcblx0XHRcdHBhcmVudE5vZGUuaW5zZXJ0QmVmb3JlKGJbLS1iRW5kXSwgbm9kZSk7XG5cdFx0XHRhW2FFbmRdID0gYltiRW5kXTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0aWYgKCFtYXApIHtcblx0XHRcdFx0bWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRcdFx0bGV0IGkgPSBiU3RhcnQ7XG5cdFx0XHRcdHdoaWxlIChpIDwgYkVuZCkgbWFwLnNldChiW2ldLCBpKyspO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgaW5kZXggPSBtYXAuZ2V0KGFbYVN0YXJ0XSk7XG5cdFx0XHRpZiAoaW5kZXggIT0gbnVsbCkgaWYgKGJTdGFydCA8IGluZGV4ICYmIGluZGV4IDwgYkVuZCkge1xuXHRcdFx0XHRsZXQgaSA9IGFTdGFydCwgc2VxdWVuY2UgPSAxLCB0O1xuXHRcdFx0XHR3aGlsZSAoKytpIDwgYUVuZCAmJiBpIDwgYkVuZCkge1xuXHRcdFx0XHRcdGlmICgodCA9IG1hcC5nZXQoYVtpXSkpID09IG51bGwgfHwgdCAhPT0gaW5kZXggKyBzZXF1ZW5jZSkgYnJlYWs7XG5cdFx0XHRcdFx0c2VxdWVuY2UrKztcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoc2VxdWVuY2UgPiBpbmRleCAtIGJTdGFydCkge1xuXHRcdFx0XHRcdGNvbnN0IG5vZGUgPSBhW2FTdGFydF07XG5cdFx0XHRcdFx0d2hpbGUgKGJTdGFydCA8IGluZGV4KSBwYXJlbnROb2RlLmluc2VydEJlZm9yZShiW2JTdGFydCsrXSwgbm9kZSk7XG5cdFx0XHRcdH0gZWxzZSBwYXJlbnROb2RlLnJlcGxhY2VDaGlsZChiW2JTdGFydCsrXSwgYVthU3RhcnQrK10pO1xuXHRcdFx0fSBlbHNlIGFTdGFydCsrO1xuXHRcdFx0ZWxzZSBhW2FTdGFydCsrXS5yZW1vdmUoKTtcblx0XHR9XG5cdH1cbn1cbnZhciAkJEVWRU5UUyA9IFwiXyREWF9ERUxFR0FURVwiO1xuZnVuY3Rpb24gcmVuZGVyKGNvZGUsIGVsZW1lbnQsIGluaXQsIG9wdGlvbnMgPSB7fSkge1xuXHRsZXQgZGlzcG9zZXI7XG5cdGNyZWF0ZVJvb3QoKGRpc3Bvc2UpID0+IHtcblx0XHRkaXNwb3NlciA9IGRpc3Bvc2U7XG5cdFx0ZWxlbWVudCA9PT0gZG9jdW1lbnQgPyBjb2RlKCkgOiBpbnNlcnQoZWxlbWVudCwgY29kZSgpLCBlbGVtZW50LmZpcnN0Q2hpbGQgPyBudWxsIDogdm9pZCAwLCBpbml0KTtcblx0fSwgb3B0aW9ucy5vd25lcik7XG5cdHJldHVybiAoKSA9PiB7XG5cdFx0ZGlzcG9zZXIoKTtcblx0XHRlbGVtZW50LnRleHRDb250ZW50ID0gXCJcIjtcblx0fTtcbn1cbmZ1bmN0aW9uIHRlbXBsYXRlKGh0bWwsIGlzSW1wb3J0Tm9kZSwgaXNTVkcsIGlzTWF0aE1MKSB7XG5cdGxldCBub2RlO1xuXHRjb25zdCBjcmVhdGUgPSAoKSA9PiB7XG5cdFx0Y29uc3QgdCA9IGlzTWF0aE1MID8gZG9jdW1lbnQuY3JlYXRlRWxlbWVudE5TKFwiaHR0cDovL3d3dy53My5vcmcvMTk5OC9NYXRoL01hdGhNTFwiLCBcInRlbXBsYXRlXCIpIDogZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInRlbXBsYXRlXCIpO1xuXHRcdHQuaW5uZXJIVE1MID0gaHRtbDtcblx0XHRyZXR1cm4gaXNTVkcgPyB0LmNvbnRlbnQuZmlyc3RDaGlsZC5maXJzdENoaWxkIDogaXNNYXRoTUwgPyB0LmZpcnN0Q2hpbGQgOiB0LmNvbnRlbnQuZmlyc3RDaGlsZDtcblx0fTtcblx0Y29uc3QgZm4gPSBpc0ltcG9ydE5vZGUgPyAoKSA9PiB1bnRyYWNrKCgpID0+IGRvY3VtZW50LmltcG9ydE5vZGUobm9kZSB8fCAobm9kZSA9IGNyZWF0ZSgpKSwgdHJ1ZSkpIDogKCkgPT4gKG5vZGUgfHwgKG5vZGUgPSBjcmVhdGUoKSkpLmNsb25lTm9kZSh0cnVlKTtcblx0Zm4uY2xvbmVOb2RlID0gZm47XG5cdHJldHVybiBmbjtcbn1cbmZ1bmN0aW9uIGRlbGVnYXRlRXZlbnRzKGV2ZW50TmFtZXMsIGRvY3VtZW50ID0gd2luZG93LmRvY3VtZW50KSB7XG5cdGNvbnN0IGUgPSBkb2N1bWVudFskJEVWRU5UU10gfHwgKGRvY3VtZW50WyQkRVZFTlRTXSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCkpO1xuXHRmb3IgKGxldCBpID0gMCwgbCA9IGV2ZW50TmFtZXMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG5cdFx0Y29uc3QgbmFtZSA9IGV2ZW50TmFtZXNbaV07XG5cdFx0aWYgKCFlLmhhcyhuYW1lKSkge1xuXHRcdFx0ZS5hZGQobmFtZSk7XG5cdFx0XHRkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKG5hbWUsIGV2ZW50SGFuZGxlcik7XG5cdFx0fVxuXHR9XG59XG5mdW5jdGlvbiBzZXRBdHRyaWJ1dGUobm9kZSwgbmFtZSwgdmFsdWUpIHtcblx0aWYgKGlzSHlkcmF0aW5nKG5vZGUpKSByZXR1cm47XG5cdGlmICh2YWx1ZSA9PSBudWxsKSBub2RlLnJlbW92ZUF0dHJpYnV0ZShuYW1lKTtcblx0ZWxzZSBub2RlLnNldEF0dHJpYnV0ZShuYW1lLCB2YWx1ZSk7XG59XG5mdW5jdGlvbiBzZXRBdHRyaWJ1dGVOUyhub2RlLCBuYW1lc3BhY2UsIG5hbWUsIHZhbHVlKSB7XG5cdGlmIChpc0h5ZHJhdGluZyhub2RlKSkgcmV0dXJuO1xuXHRpZiAodmFsdWUgPT0gbnVsbCkgbm9kZS5yZW1vdmVBdHRyaWJ1dGVOUyhuYW1lc3BhY2UsIG5hbWUpO1xuXHRlbHNlIG5vZGUuc2V0QXR0cmlidXRlTlMobmFtZXNwYWNlLCBuYW1lLCB2YWx1ZSk7XG59XG5mdW5jdGlvbiBzZXRCb29sQXR0cmlidXRlKG5vZGUsIG5hbWUsIHZhbHVlKSB7XG5cdGlmIChpc0h5ZHJhdGluZyhub2RlKSkgcmV0dXJuO1xuXHR2YWx1ZSA/IG5vZGUuc2V0QXR0cmlidXRlKG5hbWUsIFwiXCIpIDogbm9kZS5yZW1vdmVBdHRyaWJ1dGUobmFtZSk7XG59XG5mdW5jdGlvbiBjbGFzc05hbWUobm9kZSwgdmFsdWUpIHtcblx0aWYgKGlzSHlkcmF0aW5nKG5vZGUpKSByZXR1cm47XG5cdGlmICh2YWx1ZSA9PSBudWxsKSBub2RlLnJlbW92ZUF0dHJpYnV0ZShcImNsYXNzXCIpO1xuXHRlbHNlIG5vZGUuY2xhc3NOYW1lID0gdmFsdWU7XG59XG5mdW5jdGlvbiBhZGRFdmVudExpc3RlbmVyKG5vZGUsIG5hbWUsIGhhbmRsZXIsIGRlbGVnYXRlKSB7XG5cdGlmIChkZWxlZ2F0ZSkgaWYgKEFycmF5LmlzQXJyYXkoaGFuZGxlcikpIHtcblx0XHRub2RlW2AkJCR7bmFtZX1gXSA9IGhhbmRsZXJbMF07XG5cdFx0bm9kZVtgJCQke25hbWV9RGF0YWBdID0gaGFuZGxlclsxXTtcblx0fSBlbHNlIG5vZGVbYCQkJHtuYW1lfWBdID0gaGFuZGxlcjtcblx0ZWxzZSBpZiAoQXJyYXkuaXNBcnJheShoYW5kbGVyKSkge1xuXHRcdGNvbnN0IGhhbmRsZXJGbiA9IGhhbmRsZXJbMF07XG5cdFx0bm9kZS5hZGRFdmVudExpc3RlbmVyKG5hbWUsIGhhbmRsZXJbMF0gPSAoZSkgPT4gaGFuZGxlckZuLmNhbGwobm9kZSwgaGFuZGxlclsxXSwgZSkpO1xuXHR9IGVsc2Ugbm9kZS5hZGRFdmVudExpc3RlbmVyKG5hbWUsIGhhbmRsZXIsIHR5cGVvZiBoYW5kbGVyICE9PSBcImZ1bmN0aW9uXCIgJiYgaGFuZGxlcik7XG59XG5mdW5jdGlvbiBjbGFzc0xpc3Qobm9kZSwgdmFsdWUsIHByZXYgPSB7fSkge1xuXHRjb25zdCBjbGFzc0tleXMgPSBPYmplY3Qua2V5cyh2YWx1ZSB8fCB7fSksIHByZXZLZXlzID0gT2JqZWN0LmtleXMocHJldik7XG5cdGxldCBpLCBsZW47XG5cdGZvciAoaSA9IDAsIGxlbiA9IHByZXZLZXlzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5ID0gcHJldktleXNbaV07XG5cdFx0aWYgKCFrZXkgfHwga2V5ID09PSBcInVuZGVmaW5lZFwiIHx8IHZhbHVlW2tleV0pIGNvbnRpbnVlO1xuXHRcdHRvZ2dsZUNsYXNzS2V5KG5vZGUsIGtleSwgZmFsc2UpO1xuXHRcdGRlbGV0ZSBwcmV2W2tleV07XG5cdH1cblx0Zm9yIChpID0gMCwgbGVuID0gY2xhc3NLZXlzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5ID0gY2xhc3NLZXlzW2ldLCBjbGFzc1ZhbHVlID0gISF2YWx1ZVtrZXldO1xuXHRcdGlmICgha2V5IHx8IGtleSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBwcmV2W2tleV0gPT09IGNsYXNzVmFsdWUgfHwgIWNsYXNzVmFsdWUpIGNvbnRpbnVlO1xuXHRcdHRvZ2dsZUNsYXNzS2V5KG5vZGUsIGtleSwgdHJ1ZSk7XG5cdFx0cHJldltrZXldID0gY2xhc3NWYWx1ZTtcblx0fVxuXHRyZXR1cm4gcHJldjtcbn1cbmZ1bmN0aW9uIHN0eWxlKG5vZGUsIHZhbHVlLCBwcmV2KSB7XG5cdGlmICghdmFsdWUpIHJldHVybiBwcmV2ID8gc2V0QXR0cmlidXRlKG5vZGUsIFwic3R5bGVcIikgOiB2YWx1ZTtcblx0Y29uc3Qgbm9kZVN0eWxlID0gbm9kZS5zdHlsZTtcblx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIG5vZGVTdHlsZS5jc3NUZXh0ID0gdmFsdWU7XG5cdHR5cGVvZiBwcmV2ID09PSBcInN0cmluZ1wiICYmIChub2RlU3R5bGUuY3NzVGV4dCA9IHByZXYgPSB2b2lkIDApO1xuXHRwcmV2IHx8IChwcmV2ID0ge30pO1xuXHR2YWx1ZSB8fCAodmFsdWUgPSB7fSk7XG5cdGxldCB2LCBzO1xuXHRmb3IgKHMgaW4gcHJldikge1xuXHRcdHZhbHVlW3NdID8/IG5vZGVTdHlsZS5yZW1vdmVQcm9wZXJ0eShzKTtcblx0XHRkZWxldGUgcHJldltzXTtcblx0fVxuXHRmb3IgKHMgaW4gdmFsdWUpIHtcblx0XHR2ID0gdmFsdWVbc107XG5cdFx0aWYgKHYgIT09IHByZXZbc10pIHtcblx0XHRcdG5vZGVTdHlsZS5zZXRQcm9wZXJ0eShzLCB2KTtcblx0XHRcdHByZXZbc10gPSB2O1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gcHJldjtcbn1cbmZ1bmN0aW9uIHNwcmVhZChub2RlLCBwcm9wcyA9IHt9LCBpc1NWRywgc2tpcENoaWxkcmVuKSB7XG5cdGNvbnN0IHByZXZQcm9wcyA9IHt9O1xuXHRpZiAoIXNraXBDaGlsZHJlbikgY3JlYXRlUmVuZGVyRWZmZWN0KCgpID0+IHByZXZQcm9wcy5jaGlsZHJlbiA9IGluc2VydEV4cHJlc3Npb24obm9kZSwgcHJvcHMuY2hpbGRyZW4sIHByZXZQcm9wcy5jaGlsZHJlbikpO1xuXHRjcmVhdGVSZW5kZXJFZmZlY3QoKCkgPT4gdHlwZW9mIHByb3BzLnJlZiA9PT0gXCJmdW5jdGlvblwiICYmIHVzZShwcm9wcy5yZWYsIG5vZGUpKTtcblx0Y3JlYXRlUmVuZGVyRWZmZWN0KCgpID0+IGFzc2lnbihub2RlLCBwcm9wcywgaXNTVkcsIHRydWUsIHByZXZQcm9wcywgdHJ1ZSkpO1xuXHRyZXR1cm4gcHJldlByb3BzO1xufVxuZnVuY3Rpb24gdXNlKGZuLCBlbGVtZW50LCBhcmcpIHtcblx0cmV0dXJuIHVudHJhY2soKCkgPT4gZm4oZWxlbWVudCwgYXJnKSk7XG59XG5mdW5jdGlvbiBpbnNlcnQocGFyZW50LCBhY2Nlc3NvciwgbWFya2VyLCBpbml0aWFsKSB7XG5cdGlmIChtYXJrZXIgIT09IHZvaWQgMCAmJiAhaW5pdGlhbCkgaW5pdGlhbCA9IFtdO1xuXHRpZiAodHlwZW9mIGFjY2Vzc29yICE9PSBcImZ1bmN0aW9uXCIpIHJldHVybiBpbnNlcnRFeHByZXNzaW9uKHBhcmVudCwgYWNjZXNzb3IsIGluaXRpYWwsIG1hcmtlcik7XG5cdGNyZWF0ZVJlbmRlckVmZmVjdCgoY3VycmVudCkgPT4gaW5zZXJ0RXhwcmVzc2lvbihwYXJlbnQsIGFjY2Vzc29yKCksIGN1cnJlbnQsIG1hcmtlciksIGluaXRpYWwpO1xufVxuZnVuY3Rpb24gYXNzaWduKG5vZGUsIHByb3BzLCBpc1NWRywgc2tpcENoaWxkcmVuLCBwcmV2UHJvcHMgPSB7fSwgc2tpcFJlZiA9IGZhbHNlKSB7XG5cdHByb3BzIHx8IChwcm9wcyA9IHt9KTtcblx0Zm9yIChjb25zdCBwcm9wIGluIHByZXZQcm9wcykgaWYgKCEocHJvcCBpbiBwcm9wcykpIHtcblx0XHRpZiAocHJvcCA9PT0gXCJjaGlsZHJlblwiKSBjb250aW51ZTtcblx0XHRwcmV2UHJvcHNbcHJvcF0gPSBhc3NpZ25Qcm9wKG5vZGUsIHByb3AsIG51bGwsIHByZXZQcm9wc1twcm9wXSwgaXNTVkcsIHNraXBSZWYsIHByb3BzKTtcblx0fVxuXHRmb3IgKGNvbnN0IHByb3AgaW4gcHJvcHMpIHtcblx0XHRpZiAocHJvcCA9PT0gXCJjaGlsZHJlblwiKSB7XG5cdFx0XHRpZiAoIXNraXBDaGlsZHJlbikgaW5zZXJ0RXhwcmVzc2lvbihub2RlLCBwcm9wcy5jaGlsZHJlbik7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0Y29uc3QgdmFsdWUgPSBwcm9wc1twcm9wXTtcblx0XHRwcmV2UHJvcHNbcHJvcF0gPSBhc3NpZ25Qcm9wKG5vZGUsIHByb3AsIHZhbHVlLCBwcmV2UHJvcHNbcHJvcF0sIGlzU1ZHLCBza2lwUmVmLCBwcm9wcyk7XG5cdH1cbn1cbmZ1bmN0aW9uIGdldE5leHRFbGVtZW50KHRlbXBsYXRlKSB7XG5cdGxldCBub2RlLCBrZXk7XG5cdGlmICghaXNIeWRyYXRpbmcoKSB8fCAhKG5vZGUgPSBzaGFyZWRDb25maWcucmVnaXN0cnkuZ2V0KGtleSA9IGdldEh5ZHJhdGlvbktleSgpKSkpIHJldHVybiB0ZW1wbGF0ZSgpO1xuXHRpZiAoc2hhcmVkQ29uZmlnLmNvbXBsZXRlZCkgc2hhcmVkQ29uZmlnLmNvbXBsZXRlZC5hZGQobm9kZSk7XG5cdHNoYXJlZENvbmZpZy5yZWdpc3RyeS5kZWxldGUoa2V5KTtcblx0cmV0dXJuIG5vZGU7XG59XG5mdW5jdGlvbiBpc0h5ZHJhdGluZyhub2RlKSB7XG5cdHJldHVybiAhIXNoYXJlZENvbmZpZy5jb250ZXh0ICYmICFzaGFyZWRDb25maWcuZG9uZSAmJiAoIW5vZGUgfHwgbm9kZS5pc0Nvbm5lY3RlZCk7XG59XG5mdW5jdGlvbiB0b1Byb3BlcnR5TmFtZShuYW1lKSB7XG5cdHJldHVybiBuYW1lLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvLShbYS16XSkvZywgKF8sIHcpID0+IHcudG9VcHBlckNhc2UoKSk7XG59XG5mdW5jdGlvbiB0b2dnbGVDbGFzc0tleShub2RlLCBrZXksIHZhbHVlKSB7XG5cdGNvbnN0IGNsYXNzTmFtZXMgPSBrZXkudHJpbSgpLnNwbGl0KC9cXHMrLyk7XG5cdGZvciAobGV0IGkgPSAwLCBuYW1lTGVuID0gY2xhc3NOYW1lcy5sZW5ndGg7IGkgPCBuYW1lTGVuOyBpKyspIG5vZGUuY2xhc3NMaXN0LnRvZ2dsZShjbGFzc05hbWVzW2ldLCB2YWx1ZSk7XG59XG5mdW5jdGlvbiBhc3NpZ25Qcm9wKG5vZGUsIHByb3AsIHZhbHVlLCBwcmV2LCBpc1NWRywgc2tpcFJlZiwgcHJvcHMpIHtcblx0bGV0IGlzQ0UsIGlzUHJvcCwgaXNDaGlsZFByb3AsIHByb3BBbGlhcywgZm9yY2VQcm9wO1xuXHRpZiAocHJvcCA9PT0gXCJzdHlsZVwiKSByZXR1cm4gc3R5bGUobm9kZSwgdmFsdWUsIHByZXYpO1xuXHRpZiAocHJvcCA9PT0gXCJjbGFzc0xpc3RcIikgcmV0dXJuIGNsYXNzTGlzdChub2RlLCB2YWx1ZSwgcHJldik7XG5cdGlmICh2YWx1ZSA9PT0gcHJldikgcmV0dXJuIHByZXY7XG5cdGlmIChwcm9wID09PSBcInJlZlwiKSB7XG5cdFx0aWYgKCFza2lwUmVmKSB2YWx1ZShub2RlKTtcblx0fSBlbHNlIGlmIChwcm9wLnNsaWNlKDAsIDMpID09PSBcIm9uOlwiKSB7XG5cdFx0Y29uc3QgZSA9IHByb3Auc2xpY2UoMyk7XG5cdFx0cHJldiAmJiBub2RlLnJlbW92ZUV2ZW50TGlzdGVuZXIoZSwgcHJldiwgdHlwZW9mIHByZXYgIT09IFwiZnVuY3Rpb25cIiAmJiBwcmV2KTtcblx0XHR2YWx1ZSAmJiBub2RlLmFkZEV2ZW50TGlzdGVuZXIoZSwgdmFsdWUsIHR5cGVvZiB2YWx1ZSAhPT0gXCJmdW5jdGlvblwiICYmIHZhbHVlKTtcblx0fSBlbHNlIGlmIChwcm9wLnNsaWNlKDAsIDEwKSA9PT0gXCJvbmNhcHR1cmU6XCIpIHtcblx0XHRjb25zdCBlID0gcHJvcC5zbGljZSgxMCk7XG5cdFx0cHJldiAmJiBub2RlLnJlbW92ZUV2ZW50TGlzdGVuZXIoZSwgcHJldiwgdHJ1ZSk7XG5cdFx0dmFsdWUgJiYgbm9kZS5hZGRFdmVudExpc3RlbmVyKGUsIHZhbHVlLCB0cnVlKTtcblx0fSBlbHNlIGlmIChwcm9wLnNsaWNlKDAsIDIpID09PSBcIm9uXCIpIHtcblx0XHRjb25zdCBuYW1lID0gcHJvcC5zbGljZSgyKS50b0xvd2VyQ2FzZSgpO1xuXHRcdGNvbnN0IGRlbGVnYXRlID0gRGVsZWdhdGVkRXZlbnRzLmhhcyhuYW1lKTtcblx0XHRpZiAoIWRlbGVnYXRlICYmIHByZXYpIHtcblx0XHRcdGNvbnN0IGggPSBBcnJheS5pc0FycmF5KHByZXYpID8gcHJldlswXSA6IHByZXY7XG5cdFx0XHRub2RlLnJlbW92ZUV2ZW50TGlzdGVuZXIobmFtZSwgaCk7XG5cdFx0fVxuXHRcdGlmIChkZWxlZ2F0ZSB8fCB2YWx1ZSkge1xuXHRcdFx0YWRkRXZlbnRMaXN0ZW5lcihub2RlLCBuYW1lLCB2YWx1ZSwgZGVsZWdhdGUpO1xuXHRcdFx0ZGVsZWdhdGUgJiYgZGVsZWdhdGVFdmVudHMoW25hbWVdKTtcblx0XHR9XG5cdH0gZWxzZSBpZiAocHJvcC5zbGljZSgwLCA1KSA9PT0gXCJhdHRyOlwiKSBzZXRBdHRyaWJ1dGUobm9kZSwgcHJvcC5zbGljZSg1KSwgdmFsdWUpO1xuXHRlbHNlIGlmIChwcm9wLnNsaWNlKDAsIDUpID09PSBcImJvb2w6XCIpIHNldEJvb2xBdHRyaWJ1dGUobm9kZSwgcHJvcC5zbGljZSg1KSwgdmFsdWUpO1xuXHRlbHNlIGlmICgoZm9yY2VQcm9wID0gcHJvcC5zbGljZSgwLCA1KSA9PT0gXCJwcm9wOlwiKSB8fCAoaXNDaGlsZFByb3AgPSBDaGlsZFByb3BlcnRpZXMuaGFzKHByb3ApKSB8fCAhaXNTVkcgJiYgKChwcm9wQWxpYXMgPSBnZXRQcm9wQWxpYXMocHJvcCwgbm9kZS50YWdOYW1lKSkgfHwgKGlzUHJvcCA9IFByb3BlcnRpZXMuaGFzKHByb3ApKSkgfHwgKGlzQ0UgPSBub2RlLm5vZGVOYW1lLmluY2x1ZGVzKFwiLVwiKSB8fCBcImlzXCIgaW4gcHJvcHMpKSB7XG5cdFx0aWYgKGZvcmNlUHJvcCkge1xuXHRcdFx0cHJvcCA9IHByb3Auc2xpY2UoNSk7XG5cdFx0XHRpc1Byb3AgPSB0cnVlO1xuXHRcdH0gZWxzZSBpZiAoaXNIeWRyYXRpbmcobm9kZSkpIHJldHVybiB2YWx1ZTtcblx0XHRpZiAocHJvcCA9PT0gXCJjbGFzc1wiIHx8IHByb3AgPT09IFwiY2xhc3NOYW1lXCIpIGNsYXNzTmFtZShub2RlLCB2YWx1ZSk7XG5cdFx0ZWxzZSBpZiAoaXNDRSAmJiAhaXNQcm9wICYmICFpc0NoaWxkUHJvcCkgbm9kZVt0b1Byb3BlcnR5TmFtZShwcm9wKV0gPSB2YWx1ZTtcblx0XHRlbHNlIG5vZGVbcHJvcEFsaWFzIHx8IHByb3BdID0gdmFsdWU7XG5cdH0gZWxzZSB7XG5cdFx0Y29uc3QgbnMgPSBpc1NWRyAmJiBwcm9wLmluZGV4T2YoXCI6XCIpID4gLTEgJiYgU1ZHTmFtZXNwYWNlW3Byb3Auc3BsaXQoXCI6XCIpWzBdXTtcblx0XHRpZiAobnMpIHNldEF0dHJpYnV0ZU5TKG5vZGUsIG5zLCBwcm9wLCB2YWx1ZSk7XG5cdFx0ZWxzZSBzZXRBdHRyaWJ1dGUobm9kZSwgQWxpYXNlc1twcm9wXSB8fCBwcm9wLCB2YWx1ZSk7XG5cdH1cblx0cmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gZXZlbnRIYW5kbGVyKGUpIHtcblx0aWYgKHNoYXJlZENvbmZpZy5yZWdpc3RyeSAmJiBzaGFyZWRDb25maWcuZXZlbnRzKSB7XG5cdFx0aWYgKHNoYXJlZENvbmZpZy5ldmVudHMuZmluZCgoW2VsLCBldl0pID0+IGV2ID09PSBlKSkgcmV0dXJuO1xuXHR9XG5cdGxldCBub2RlID0gZS50YXJnZXQ7XG5cdGNvbnN0IGtleSA9IGAkJCR7ZS50eXBlfWA7XG5cdGNvbnN0IG9yaVRhcmdldCA9IGUudGFyZ2V0O1xuXHRjb25zdCBvcmlDdXJyZW50VGFyZ2V0ID0gZS5jdXJyZW50VGFyZ2V0O1xuXHRjb25zdCByZXRhcmdldCA9ICh2YWx1ZSkgPT4gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIFwidGFyZ2V0XCIsIHtcblx0XHRjb25maWd1cmFibGU6IHRydWUsXG5cdFx0dmFsdWVcblx0fSk7XG5cdGNvbnN0IGhhbmRsZU5vZGUgPSAoKSA9PiB7XG5cdFx0Y29uc3QgaGFuZGxlciA9IG5vZGVba2V5XTtcblx0XHRpZiAoaGFuZGxlciAmJiAhbm9kZS5kaXNhYmxlZCkge1xuXHRcdFx0Y29uc3QgZGF0YSA9IG5vZGVbYCR7a2V5fURhdGFgXTtcblx0XHRcdGRhdGEgIT09IHZvaWQgMCA/IGhhbmRsZXIuY2FsbChub2RlLCBkYXRhLCBlKSA6IGhhbmRsZXIuY2FsbChub2RlLCBlKTtcblx0XHRcdGlmIChlLmNhbmNlbEJ1YmJsZSkgcmV0dXJuO1xuXHRcdH1cblx0XHRub2RlLmhvc3QgJiYgdHlwZW9mIG5vZGUuaG9zdCAhPT0gXCJzdHJpbmdcIiAmJiAhbm9kZS5ob3N0Ll8kaG9zdCAmJiBub2RlLmNvbnRhaW5zKGUudGFyZ2V0KSAmJiByZXRhcmdldChub2RlLmhvc3QpO1xuXHRcdHJldHVybiB0cnVlO1xuXHR9O1xuXHRjb25zdCB3YWxrVXBUcmVlID0gKCkgPT4ge1xuXHRcdHdoaWxlIChoYW5kbGVOb2RlKCkgJiYgKG5vZGUgPSBub2RlLl8kaG9zdCB8fCBub2RlLnBhcmVudE5vZGUgfHwgbm9kZS5ob3N0KSk7XG5cdH07XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCBcImN1cnJlbnRUYXJnZXRcIiwge1xuXHRcdGNvbmZpZ3VyYWJsZTogdHJ1ZSxcblx0XHRnZXQoKSB7XG5cdFx0XHRyZXR1cm4gbm9kZSB8fCBkb2N1bWVudDtcblx0XHR9XG5cdH0pO1xuXHRpZiAoc2hhcmVkQ29uZmlnLnJlZ2lzdHJ5ICYmICFzaGFyZWRDb25maWcuZG9uZSkgc2hhcmVkQ29uZmlnLmRvbmUgPSBfJEhZLmRvbmUgPSB0cnVlO1xuXHRpZiAoZS5jb21wb3NlZFBhdGgpIHtcblx0XHRjb25zdCBwYXRoID0gZS5jb21wb3NlZFBhdGgoKTtcblx0XHRyZXRhcmdldChwYXRoWzBdKTtcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IHBhdGgubGVuZ3RoIC0gMjsgaSsrKSB7XG5cdFx0XHRub2RlID0gcGF0aFtpXTtcblx0XHRcdGlmICghaGFuZGxlTm9kZSgpKSBicmVhaztcblx0XHRcdGlmIChub2RlLl8kaG9zdCkge1xuXHRcdFx0XHRub2RlID0gbm9kZS5fJGhvc3Q7XG5cdFx0XHRcdHdhbGtVcFRyZWUoKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cdFx0XHRpZiAobm9kZS5wYXJlbnROb2RlID09PSBvcmlDdXJyZW50VGFyZ2V0KSBicmVhaztcblx0XHR9XG5cdH0gZWxzZSB3YWxrVXBUcmVlKCk7XG5cdHJldGFyZ2V0KG9yaVRhcmdldCk7XG59XG5mdW5jdGlvbiBpbnNlcnRFeHByZXNzaW9uKHBhcmVudCwgdmFsdWUsIGN1cnJlbnQsIG1hcmtlciwgdW53cmFwQXJyYXkpIHtcblx0Y29uc3QgaHlkcmF0aW5nID0gaXNIeWRyYXRpbmcocGFyZW50KTtcblx0aWYgKGh5ZHJhdGluZykge1xuXHRcdCFjdXJyZW50ICYmIChjdXJyZW50ID0gWy4uLnBhcmVudC5jaGlsZE5vZGVzXSk7XG5cdFx0bGV0IGNsZWFuZWQgPSBbXTtcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGN1cnJlbnQubGVuZ3RoOyBpKyspIHtcblx0XHRcdGNvbnN0IG5vZGUgPSBjdXJyZW50W2ldO1xuXHRcdFx0aWYgKG5vZGUubm9kZVR5cGUgPT09IDggJiYgbm9kZS5kYXRhLnNsaWNlKDAsIDIpID09PSBcIiEkXCIpIG5vZGUucmVtb3ZlKCk7XG5cdFx0XHRlbHNlIGNsZWFuZWQucHVzaChub2RlKTtcblx0XHR9XG5cdFx0Y3VycmVudCA9IGNsZWFuZWQ7XG5cdH1cblx0d2hpbGUgKHR5cGVvZiBjdXJyZW50ID09PSBcImZ1bmN0aW9uXCIpIGN1cnJlbnQgPSBjdXJyZW50KCk7XG5cdGlmICh2YWx1ZSA9PT0gY3VycmVudCkgcmV0dXJuIGN1cnJlbnQ7XG5cdGNvbnN0IHQgPSB0eXBlb2YgdmFsdWUsIG11bHRpID0gbWFya2VyICE9PSB2b2lkIDA7XG5cdHBhcmVudCA9IG11bHRpICYmIGN1cnJlbnRbMF0gJiYgY3VycmVudFswXS5wYXJlbnROb2RlIHx8IHBhcmVudDtcblx0aWYgKHQgPT09IFwic3RyaW5nXCIgfHwgdCA9PT0gXCJudW1iZXJcIikge1xuXHRcdGlmIChoeWRyYXRpbmcpIHJldHVybiBjdXJyZW50O1xuXHRcdGlmICh0ID09PSBcIm51bWJlclwiKSB7XG5cdFx0XHR2YWx1ZSA9IHZhbHVlLnRvU3RyaW5nKCk7XG5cdFx0XHRpZiAodmFsdWUgPT09IGN1cnJlbnQpIHJldHVybiBjdXJyZW50O1xuXHRcdH1cblx0XHRpZiAobXVsdGkpIHtcblx0XHRcdGxldCBub2RlID0gY3VycmVudFswXTtcblx0XHRcdGlmIChub2RlICYmIG5vZGUubm9kZVR5cGUgPT09IDMpIG5vZGUuZGF0YSAhPT0gdmFsdWUgJiYgKG5vZGUuZGF0YSA9IHZhbHVlKTtcblx0XHRcdGVsc2Ugbm9kZSA9IGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKHZhbHVlKTtcblx0XHRcdGN1cnJlbnQgPSBjbGVhbkNoaWxkcmVuKHBhcmVudCwgY3VycmVudCwgbWFya2VyLCBub2RlKTtcblx0XHR9IGVsc2UgaWYgKGN1cnJlbnQgIT09IFwiXCIgJiYgdHlwZW9mIGN1cnJlbnQgPT09IFwic3RyaW5nXCIpIGN1cnJlbnQgPSBwYXJlbnQuZmlyc3RDaGlsZC5kYXRhID0gdmFsdWU7XG5cdFx0ZWxzZSBjdXJyZW50ID0gcGFyZW50LnRleHRDb250ZW50ID0gdmFsdWU7XG5cdH0gZWxzZSBpZiAodmFsdWUgPT0gbnVsbCB8fCB0ID09PSBcImJvb2xlYW5cIikge1xuXHRcdGlmIChoeWRyYXRpbmcpIHJldHVybiBjdXJyZW50O1xuXHRcdGN1cnJlbnQgPSBjbGVhbkNoaWxkcmVuKHBhcmVudCwgY3VycmVudCwgbWFya2VyKTtcblx0fSBlbHNlIGlmICh0ID09PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRjcmVhdGVSZW5kZXJFZmZlY3QoKCkgPT4ge1xuXHRcdFx0bGV0IHYgPSB2YWx1ZSgpO1xuXHRcdFx0d2hpbGUgKHR5cGVvZiB2ID09PSBcImZ1bmN0aW9uXCIpIHYgPSB2KCk7XG5cdFx0XHRjdXJyZW50ID0gaW5zZXJ0RXhwcmVzc2lvbihwYXJlbnQsIHYsIGN1cnJlbnQsIG1hcmtlcik7XG5cdFx0fSk7XG5cdFx0cmV0dXJuICgpID0+IGN1cnJlbnQ7XG5cdH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcblx0XHRjb25zdCBhcnJheSA9IFtdO1xuXHRcdGNvbnN0IGN1cnJlbnRBcnJheSA9IGN1cnJlbnQgJiYgQXJyYXkuaXNBcnJheShjdXJyZW50KTtcblx0XHRpZiAobm9ybWFsaXplSW5jb21pbmdBcnJheShhcnJheSwgdmFsdWUsIGN1cnJlbnQsIHVud3JhcEFycmF5KSkge1xuXHRcdFx0Y3JlYXRlUmVuZGVyRWZmZWN0KCgpID0+IGN1cnJlbnQgPSBpbnNlcnRFeHByZXNzaW9uKHBhcmVudCwgYXJyYXksIGN1cnJlbnQsIG1hcmtlciwgdHJ1ZSkpO1xuXHRcdFx0cmV0dXJuICgpID0+IGN1cnJlbnQ7XG5cdFx0fVxuXHRcdGlmIChoeWRyYXRpbmcpIHtcblx0XHRcdGlmICghYXJyYXkubGVuZ3RoKSByZXR1cm4gY3VycmVudDtcblx0XHRcdGlmIChtYXJrZXIgPT09IHZvaWQgMCkgcmV0dXJuIGN1cnJlbnQgPSBbLi4ucGFyZW50LmNoaWxkTm9kZXNdO1xuXHRcdFx0bGV0IG5vZGUgPSBhcnJheVswXTtcblx0XHRcdGlmIChub2RlLnBhcmVudE5vZGUgIT09IHBhcmVudCkgcmV0dXJuIGN1cnJlbnQ7XG5cdFx0XHRjb25zdCBub2RlcyA9IFtub2RlXTtcblx0XHRcdHdoaWxlICgobm9kZSA9IG5vZGUubmV4dFNpYmxpbmcpICE9PSBtYXJrZXIpIG5vZGVzLnB1c2gobm9kZSk7XG5cdFx0XHRyZXR1cm4gY3VycmVudCA9IG5vZGVzO1xuXHRcdH1cblx0XHRpZiAoYXJyYXkubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRjdXJyZW50ID0gY2xlYW5DaGlsZHJlbihwYXJlbnQsIGN1cnJlbnQsIG1hcmtlcik7XG5cdFx0XHRpZiAobXVsdGkpIHJldHVybiBjdXJyZW50O1xuXHRcdH0gZWxzZSBpZiAoY3VycmVudEFycmF5KSBpZiAoY3VycmVudC5sZW5ndGggPT09IDApIGFwcGVuZE5vZGVzKHBhcmVudCwgYXJyYXksIG1hcmtlcik7XG5cdFx0ZWxzZSByZWNvbmNpbGVBcnJheXMocGFyZW50LCBjdXJyZW50LCBhcnJheSk7XG5cdFx0ZWxzZSB7XG5cdFx0XHRjdXJyZW50ICYmIGNsZWFuQ2hpbGRyZW4ocGFyZW50KTtcblx0XHRcdGFwcGVuZE5vZGVzKHBhcmVudCwgYXJyYXkpO1xuXHRcdH1cblx0XHRjdXJyZW50ID0gYXJyYXk7XG5cdH0gZWxzZSBpZiAodmFsdWUubm9kZVR5cGUpIHtcblx0XHRpZiAoaHlkcmF0aW5nICYmIHZhbHVlLnBhcmVudE5vZGUpIHJldHVybiBjdXJyZW50ID0gbXVsdGkgPyBbdmFsdWVdIDogdmFsdWU7XG5cdFx0aWYgKEFycmF5LmlzQXJyYXkoY3VycmVudCkpIHtcblx0XHRcdGlmIChtdWx0aSkgcmV0dXJuIGN1cnJlbnQgPSBjbGVhbkNoaWxkcmVuKHBhcmVudCwgY3VycmVudCwgbWFya2VyLCB2YWx1ZSk7XG5cdFx0XHRjbGVhbkNoaWxkcmVuKHBhcmVudCwgY3VycmVudCwgbnVsbCwgdmFsdWUpO1xuXHRcdH0gZWxzZSBpZiAoY3VycmVudCA9PSBudWxsIHx8IGN1cnJlbnQgPT09IFwiXCIgfHwgIXBhcmVudC5maXJzdENoaWxkKSBwYXJlbnQuYXBwZW5kQ2hpbGQodmFsdWUpO1xuXHRcdGVsc2UgcGFyZW50LnJlcGxhY2VDaGlsZCh2YWx1ZSwgcGFyZW50LmZpcnN0Q2hpbGQpO1xuXHRcdGN1cnJlbnQgPSB2YWx1ZTtcblx0fVxuXHRyZXR1cm4gY3VycmVudDtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZUluY29taW5nQXJyYXkobm9ybWFsaXplZCwgYXJyYXksIGN1cnJlbnQsIHVud3JhcCkge1xuXHRsZXQgZHluYW1pYyA9IGZhbHNlO1xuXHRmb3IgKGxldCBpID0gMCwgbGVuID0gYXJyYXkubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcblx0XHRsZXQgaXRlbSA9IGFycmF5W2ldLCBwcmV2ID0gY3VycmVudCAmJiBjdXJyZW50W25vcm1hbGl6ZWQubGVuZ3RoXSwgdDtcblx0XHRpZiAoaXRlbSA9PSBudWxsIHx8IGl0ZW0gPT09IHRydWUgfHwgaXRlbSA9PT0gZmFsc2UpO1xuXHRcdGVsc2UgaWYgKCh0ID0gdHlwZW9mIGl0ZW0pID09PSBcIm9iamVjdFwiICYmIGl0ZW0ubm9kZVR5cGUpIG5vcm1hbGl6ZWQucHVzaChpdGVtKTtcblx0XHRlbHNlIGlmIChBcnJheS5pc0FycmF5KGl0ZW0pKSBkeW5hbWljID0gbm9ybWFsaXplSW5jb21pbmdBcnJheShub3JtYWxpemVkLCBpdGVtLCBwcmV2KSB8fCBkeW5hbWljO1xuXHRcdGVsc2UgaWYgKHQgPT09IFwiZnVuY3Rpb25cIikgaWYgKHVud3JhcCkge1xuXHRcdFx0d2hpbGUgKHR5cGVvZiBpdGVtID09PSBcImZ1bmN0aW9uXCIpIGl0ZW0gPSBpdGVtKCk7XG5cdFx0XHRkeW5hbWljID0gbm9ybWFsaXplSW5jb21pbmdBcnJheShub3JtYWxpemVkLCBBcnJheS5pc0FycmF5KGl0ZW0pID8gaXRlbSA6IFtpdGVtXSwgQXJyYXkuaXNBcnJheShwcmV2KSA/IHByZXYgOiBbcHJldl0pIHx8IGR5bmFtaWM7XG5cdFx0fSBlbHNlIHtcblx0XHRcdG5vcm1hbGl6ZWQucHVzaChpdGVtKTtcblx0XHRcdGR5bmFtaWMgPSB0cnVlO1xuXHRcdH1cblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IHZhbHVlID0gU3RyaW5nKGl0ZW0pO1xuXHRcdFx0aWYgKHByZXYgJiYgcHJldi5ub2RlVHlwZSA9PT0gMyAmJiBwcmV2LmRhdGEgPT09IHZhbHVlKSBub3JtYWxpemVkLnB1c2gocHJldik7XG5cdFx0XHRlbHNlIG5vcm1hbGl6ZWQucHVzaChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZSh2YWx1ZSkpO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gZHluYW1pYztcbn1cbmZ1bmN0aW9uIGFwcGVuZE5vZGVzKHBhcmVudCwgYXJyYXksIG1hcmtlciA9IG51bGwpIHtcblx0Zm9yIChsZXQgaSA9IDAsIGxlbiA9IGFycmF5Lmxlbmd0aDsgaSA8IGxlbjsgaSsrKSBwYXJlbnQuaW5zZXJ0QmVmb3JlKGFycmF5W2ldLCBtYXJrZXIpO1xufVxuZnVuY3Rpb24gY2xlYW5DaGlsZHJlbihwYXJlbnQsIGN1cnJlbnQsIG1hcmtlciwgcmVwbGFjZW1lbnQpIHtcblx0aWYgKG1hcmtlciA9PT0gdm9pZCAwKSByZXR1cm4gcGFyZW50LnRleHRDb250ZW50ID0gXCJcIjtcblx0Y29uc3Qgbm9kZSA9IHJlcGxhY2VtZW50IHx8IGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKFwiXCIpO1xuXHRpZiAoY3VycmVudC5sZW5ndGgpIHtcblx0XHRsZXQgaW5zZXJ0ZWQgPSBmYWxzZTtcblx0XHRmb3IgKGxldCBpID0gY3VycmVudC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0Y29uc3QgZWwgPSBjdXJyZW50W2ldO1xuXHRcdFx0aWYgKG5vZGUgIT09IGVsKSB7XG5cdFx0XHRcdGNvbnN0IGlzUGFyZW50ID0gZWwucGFyZW50Tm9kZSA9PT0gcGFyZW50O1xuXHRcdFx0XHRpZiAoIWluc2VydGVkICYmICFpKSBpc1BhcmVudCA/IHBhcmVudC5yZXBsYWNlQ2hpbGQobm9kZSwgZWwpIDogcGFyZW50Lmluc2VydEJlZm9yZShub2RlLCBtYXJrZXIpO1xuXHRcdFx0XHRlbHNlIGlzUGFyZW50ICYmIGVsLnJlbW92ZSgpO1xuXHRcdFx0fSBlbHNlIGluc2VydGVkID0gdHJ1ZTtcblx0XHR9XG5cdH0gZWxzZSBwYXJlbnQuaW5zZXJ0QmVmb3JlKG5vZGUsIG1hcmtlcik7XG5cdHJldHVybiBbbm9kZV07XG59XG5mdW5jdGlvbiBnZXRIeWRyYXRpb25LZXkoKSB7XG5cdHJldHVybiBzaGFyZWRDb25maWcuZ2V0TmV4dENvbnRleHRJZCgpO1xufVxudmFyIFNWR19OQU1FU1BBQ0UgPSBcImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI7XG5mdW5jdGlvbiBjcmVhdGVFbGVtZW50KHRhZ05hbWUsIGlzU1ZHID0gZmFsc2UsIGlzID0gdm9pZCAwKSB7XG5cdHJldHVybiBpc1NWRyA/IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnROUyhTVkdfTkFNRVNQQUNFLCB0YWdOYW1lKSA6IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnTmFtZSwgeyBpcyB9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUR5bmFtaWMoY29tcG9uZW50LCBwcm9wcykge1xuXHRjb25zdCBjYWNoZWQgPSBjcmVhdGVNZW1vKGNvbXBvbmVudCk7XG5cdHJldHVybiBjcmVhdGVNZW1vKCgpID0+IHtcblx0XHRjb25zdCBjb21wb25lbnQgPSBjYWNoZWQoKTtcblx0XHRzd2l0Y2ggKHR5cGVvZiBjb21wb25lbnQpIHtcblx0XHRcdGNhc2UgXCJmdW5jdGlvblwiOiByZXR1cm4gdW50cmFjaygoKSA9PiBjb21wb25lbnQocHJvcHMpKTtcblx0XHRcdGNhc2UgXCJzdHJpbmdcIjpcblx0XHRcdFx0Y29uc3QgaXNTdmcgPSBTVkdFbGVtZW50cy5oYXMoY29tcG9uZW50KTtcblx0XHRcdFx0Y29uc3QgZWwgPSBzaGFyZWRDb25maWcuY29udGV4dCA/IGdldE5leHRFbGVtZW50KCkgOiBjcmVhdGVFbGVtZW50KGNvbXBvbmVudCwgaXNTdmcsIHVudHJhY2soKCkgPT4gcHJvcHMuaXMpKTtcblx0XHRcdFx0c3ByZWFkKGVsLCBwcm9wcywgaXNTdmcpO1xuXHRcdFx0XHRyZXR1cm4gZWw7XG5cdFx0fVxuXHR9KTtcbn1cbmZ1bmN0aW9uIER5bmFtaWMocHJvcHMpIHtcblx0Y29uc3QgWywgb3RoZXJzXSA9IHNwbGl0UHJvcHMocHJvcHMsIFtcImNvbXBvbmVudFwiXSk7XG5cdHJldHVybiBjcmVhdGVEeW5hbWljKCgpID0+IHByb3BzLmNvbXBvbmVudCwgb3RoZXJzKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb250ZXh0LnRzXG52YXIgU2hhZG93RG9tVGFyZ2V0Q29udGV4dCA9IGNyZWF0ZUNvbnRleHQodm9pZCAwKTtcbnZhciBEZXZ0b29sc09uQ2xvc2VDb250ZXh0ID0gY3JlYXRlQ29udGV4dCh2b2lkIDApO1xudmFyIHVzZURldnRvb2xzT25DbG9zZSA9ICgpID0+IHtcblx0Y29uc3QgY29udGV4dCA9IHVzZUNvbnRleHQoRGV2dG9vbHNPbkNsb3NlQ29udGV4dCk7XG5cdGlmICghY29udGV4dCkgdGhyb3cgbmV3IEVycm9yKFwidXNlRGV2dG9vbHNPbkNsb3NlIG11c3QgYmUgdXNlZCB3aXRoaW4gYSBUYW5TdGFja1JvdXRlckRldnRvb2xzIGNvbXBvbmVudFwiKTtcblx0cmV0dXJuIGNvbnRleHQ7XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjcmVhdGVVbmlxdWVJZCBhcyBDLCB1bnRyYWNrIGFzIEQsIG9uQ2xlYW51cCBhcyBFLCB1c2VDb250ZXh0IGFzIE8sIGNyZWF0ZVNpZ25hbCBhcyBTLCBtZXJnZVByb3BzIGFzIFQsIFN3aXRjaCBhcyBfLCBhZGRFdmVudExpc3RlbmVyIGFzIGEsIGNyZWF0ZU1lbW8gYXMgYiwgaW5zZXJ0IGFzIGMsIHNldEF0dHJpYnV0ZSBhcyBkLCBzcHJlYWQgYXMgZiwgU2hvdyBhcyBnLCBNYXRjaCBhcyBoLCBEeW5hbWljIGFzIGksIG1lbW8gYXMgbCwgRm9yIGFzIG0sIFNoYWRvd0RvbVRhcmdldENvbnRleHQgYXMgbiwgY2xhc3NOYW1lIGFzIG8sIHRlbXBsYXRlIGFzIHAsIHVzZURldnRvb2xzT25DbG9zZSBhcyByLCBkZWxlZ2F0ZUV2ZW50cyBhcyBzLCBEZXZ0b29sc09uQ2xvc2VDb250ZXh0IGFzIHQsIHJlbmRlciBhcyB1LCBjcmVhdGVDb21wb25lbnQgYXMgdiwgbGF6eSBhcyB3LCBjcmVhdGVSZW5kZXJFZmZlY3QgYXMgeCwgY3JlYXRlRWZmZWN0IGFzIHkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29udGV4dC1EZTJFQjFBQS5qcy5tYXAiXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdLCJtYXBwaW5ncyI6IjtBQUNBLElBQUksZUFBZTtDQUNsQixTQUFTLEtBQUs7Q0FDZCxVQUFVLEtBQUs7Q0FDZixTQUFTLEtBQUs7Q0FDZCxNQUFNO0NBQ04sZUFBZTtFQUNkLE9BQU8sYUFBYSxLQUFLLFFBQVEsS0FBSztDQUN2QztDQUNBLG1CQUFtQjtFQUNsQixPQUFPLGFBQWEsS0FBSyxRQUFRLE9BQU87Q0FDekM7QUFDRDtBQUNBLFNBQVMsYUFBYSxPQUFPO0NBQzVCLE1BQU0sTUFBTSxPQUFPLEtBQUssR0FBRyxNQUFNLElBQUksU0FBUztDQUM5QyxPQUFPLGFBQWEsUUFBUSxNQUFNLE1BQU0sT0FBTyxhQUFhLEtBQUssR0FBRyxJQUFJLE1BQU07QUFDL0U7QUFDQSxTQUFTLGtCQUFrQixTQUFTO0NBQ25DLGFBQWEsVUFBVTtBQUN4QjtBQUNBLFNBQVMscUJBQXFCO0NBQzdCLE9BQU87RUFDTixHQUFHLGFBQWE7RUFDaEIsSUFBSSxhQUFhLGlCQUFpQjtFQUNsQyxPQUFPO0NBQ1I7QUFDRDtBQUNBLElBQUksV0FBVyxHQUFHLE1BQU0sTUFBTTtBQUM5QixJQUFJLFNBQVMsT0FBTyxhQUFhO0FBQ2pDLElBQUksaUJBQWlCLE9BQU8sVUFBVTtBQUN0QyxJQUFJLFNBQVMsT0FBTyxhQUFhO0FBQ2pDLElBQUksZ0JBQWdCLEVBQUUsUUFBUSxRQUFRO0FBQ3RDLElBQUksUUFBUTtBQUNaLElBQUksYUFBYTtBQUNqQixJQUFJLFFBQVE7QUFDWixJQUFJLFVBQVU7QUFDZCxJQUFJLFVBQVU7Q0FDYixPQUFPO0NBQ1AsVUFBVTtDQUNWLFNBQVM7Q0FDVCxPQUFPO0FBQ1I7QUFDQSxJQUFJLFVBQVUsQ0FBQztBQUNmLElBQUksUUFBUTtBQUNaLElBQUksYUFBYTtBQUNqQixJQUFJLFlBQVk7QUFDaEIsSUFBSSx1QkFBdUI7QUFDM0IsSUFBSSxXQUFXO0FBQ2YsSUFBSSxVQUFVO0FBQ2QsSUFBSSxVQUFVO0FBQ2QsSUFBSSxZQUFZO0FBQ2hCLFNBQVMsV0FBVyxJQUFJLGVBQWU7Q0FDdEMsTUFBTSxXQUFXLFVBQVUsUUFBUSxPQUFPLFVBQVUsR0FBRyxXQUFXLEdBQUcsVUFBVSxrQkFBa0IsS0FBSyxJQUFJLFFBQVEsZUFBZSxPQUFPLFVBQVUsVUFBVTtFQUMzSixPQUFPO0VBQ1AsVUFBVTtFQUNWLFNBQVMsVUFBVSxRQUFRLFVBQVU7RUFDckMsT0FBTztDQUNSLEdBQUcsV0FBVyxVQUFVLFdBQVcsU0FBUyxjQUFjLFVBQVUsSUFBSSxDQUFDLENBQUM7Q0FDMUUsUUFBUTtDQUNSLFdBQVc7Q0FDWCxJQUFJO0VBQ0gsT0FBTyxXQUFXLFVBQVUsSUFBSTtDQUNqQyxVQUFVO0VBQ1QsV0FBVztFQUNYLFFBQVE7Q0FDVDtBQUNEO0FBQ0EsU0FBUyxhQUFhLE9BQU8sU0FBUztDQUNyQyxVQUFVLFVBQVUsT0FBTyxPQUFPLENBQUMsR0FBRyxlQUFlLE9BQU8sSUFBSTtDQUNoRSxNQUFNLElBQUk7RUFDVDtFQUNBLFdBQVc7RUFDWCxlQUFlO0VBQ2YsWUFBWSxRQUFRLFVBQVUsS0FBSztDQUNwQztDQUNBLE1BQU0sVUFBVSxVQUFVO0VBQ3pCLElBQUksT0FBTyxVQUFVLFlBQVksSUFBSSxjQUFjLFdBQVcsV0FBVyxXQUFXLFFBQVEsSUFBSSxDQUFDLEdBQUcsUUFBUSxNQUFNLEVBQUUsTUFBTTtPQUNySCxRQUFRLE1BQU0sRUFBRSxLQUFLO0VBQzFCLE9BQU8sWUFBWSxHQUFHLEtBQUs7Q0FDNUI7Q0FDQSxPQUFPLENBQUMsV0FBVyxLQUFLLENBQUMsR0FBRyxNQUFNO0FBQ25DO0FBQ0EsU0FBUyxlQUFlLElBQUksT0FBTyxTQUFTO0NBQzNDLE1BQU0sSUFBSSxrQkFBa0IsSUFBSSxPQUFPLE1BQU0sS0FBSztDQUNsRCxJQUFJLGFBQWEsY0FBYyxXQUFXLFNBQVMsUUFBUSxLQUFLLENBQUM7TUFDNUQsa0JBQWtCLENBQUM7QUFDekI7QUFDQSxTQUFTLG1CQUFtQixJQUFJLE9BQU8sU0FBUztDQUMvQyxNQUFNLElBQUksa0JBQWtCLElBQUksT0FBTyxPQUFPLEtBQUs7Q0FDbkQsSUFBSSxhQUFhLGNBQWMsV0FBVyxTQUFTLFFBQVEsS0FBSyxDQUFDO01BQzVELGtCQUFrQixDQUFDO0FBQ3pCO0FBQ0EsU0FBUyxhQUFhLElBQUksT0FBTyxTQUFTO0NBQ3pDLGFBQWE7Q0FDYixNQUFNLElBQUksa0JBQWtCLElBQUksT0FBTyxPQUFPLEtBQUssR0FBRyxJQUFJLG1CQUFtQixXQUFXLGVBQWU7Q0FDdkcsSUFBSSxHQUFHLEVBQUUsV0FBVztDQUNwQixJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsUUFBUSxFQUFFLE9BQU87Q0FDMUMsVUFBVSxRQUFRLEtBQUssQ0FBQyxJQUFJLGtCQUFrQixDQUFDO0FBQ2hEO0FBQ0EsU0FBUyxXQUFXLElBQUksT0FBTyxTQUFTO0NBQ3ZDLFVBQVUsVUFBVSxPQUFPLE9BQU8sQ0FBQyxHQUFHLGVBQWUsT0FBTyxJQUFJO0NBQ2hFLE1BQU0sSUFBSSxrQkFBa0IsSUFBSSxPQUFPLE1BQU0sQ0FBQztDQUM5QyxFQUFFLFlBQVk7Q0FDZCxFQUFFLGdCQUFnQjtDQUNsQixFQUFFLGFBQWEsUUFBUSxVQUFVLEtBQUs7Q0FDdEMsSUFBSSxhQUFhLGNBQWMsV0FBVyxTQUFTO0VBQ2xELEVBQUUsU0FBUztFQUNYLFFBQVEsS0FBSyxDQUFDO0NBQ2YsT0FBTyxrQkFBa0IsQ0FBQztDQUMxQixPQUFPLFdBQVcsS0FBSyxDQUFDO0FBQ3pCO0FBQ0EsU0FBUyxVQUFVLEdBQUc7Q0FDckIsT0FBTyxLQUFLLE9BQU8sTUFBTSxZQUFZLFVBQVU7QUFDaEQ7QUFDQSxTQUFTLGVBQWUsU0FBUyxVQUFVLFVBQVU7Q0FDcEQsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxPQUFPLGFBQWEsWUFBWTtFQUNuQyxTQUFTO0VBQ1QsVUFBVTtFQUNWLFVBQVUsWUFBWSxDQUFDO0NBQ3hCLE9BQU87RUFDTixTQUFTO0VBQ1QsVUFBVTtFQUNWLFVBQVUsWUFBWSxDQUFDO0NBQ3hCO0NBQ0EsSUFBSSxLQUFLLE1BQU0sUUFBUSxTQUFTLEtBQUssTUFBTSx3QkFBd0IsT0FBTyxZQUFZLE9BQU8sV0FBVyxrQkFBa0IsU0FBUyxVQUFVLE9BQU8sV0FBVyxjQUFjLFdBQVcsTUFBTTtDQUM5TCxNQUFNLDJCQUEyQixJQUFJLElBQUksR0FBRyxDQUFDLE9BQU8sYUFBYSxRQUFRLFdBQVcsYUFBQSxDQUFjLFFBQVEsWUFBWSxHQUFHLENBQUMsT0FBTyxZQUFZLGFBQWEsS0FBSyxDQUFDLEdBQUcsQ0FBQyxPQUFPLFdBQVcsYUFBYSxLQUFLLEdBQUcsRUFBRSxRQUFRLE1BQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxZQUFZLGFBQWEsV0FBVyxVQUFVLFlBQVk7Q0FDalMsSUFBSSxhQUFhLFNBQVM7RUFDekIsS0FBSyxhQUFhLGlCQUFpQjtFQUNuQyxJQUFJLFFBQVEsZ0JBQWdCLFdBQVcsUUFBUSxRQUFRO09BQ2xELElBQUksYUFBYSxRQUFRLGFBQWEsSUFBSSxFQUFFLEdBQUcsUUFBUSxhQUFhLEtBQUssRUFBRTtDQUNqRjtDQUNBLFNBQVMsUUFBUSxHQUFHLEdBQUcsT0FBTyxLQUFLO0VBQ2xDLElBQUksT0FBTyxHQUFHO0dBQ2IsS0FBSztHQUNMLFFBQVEsS0FBSyxNQUFNLFdBQVc7R0FDOUIsS0FBSyxNQUFNLFNBQVMsTUFBTSxVQUFVLFFBQVEsWUFBWSxxQkFBcUIsUUFBUSxXQUFXLEtBQUssRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDO0dBQ2xILFFBQVE7R0FDUixJQUFJLGNBQWMsS0FBSyx1QkFBdUI7SUFDN0MsV0FBVyxTQUFTLE9BQU8sQ0FBQztJQUM1Qix3QkFBd0I7SUFDeEIsaUJBQWlCO0tBQ2hCLFdBQVcsVUFBVTtLQUNyQixhQUFhLEdBQUcsS0FBSztJQUN0QixHQUFHLEtBQUs7R0FDVCxPQUFPLGFBQWEsR0FBRyxLQUFLO0VBQzdCO0VBQ0EsT0FBTztDQUNSO0NBQ0EsU0FBUyxhQUFhLEdBQUcsS0FBSztFQUM3QixpQkFBaUI7R0FDaEIsSUFBSSxRQUFRLEtBQUssR0FBRyxlQUFlLENBQUM7R0FDcEMsU0FBUyxRQUFRLEtBQUssSUFBSSxZQUFZLFdBQVcsVUFBVSxZQUFZO0dBQ3ZFLFNBQVMsR0FBRztHQUNaLEtBQUssTUFBTSxLQUFLLFNBQVMsS0FBSyxHQUFHLEVBQUUsVUFBVTtHQUM3QyxTQUFTLE1BQU07RUFDaEIsR0FBRyxLQUFLO0NBQ1Q7Q0FDQSxTQUFTLE9BQU87RUFDZixNQUFNLElBQUksbUJBQW1CLFdBQVcsZUFBZSxHQUFHLElBQUksTUFBTSxHQUFHLE1BQU0sTUFBTTtFQUNuRixJQUFJLFFBQVEsS0FBSyxLQUFLLENBQUMsSUFBSSxNQUFNO0VBQ2pDLElBQUksWUFBWSxDQUFDLFNBQVMsUUFBUSxHQUFHLHFCQUFxQjtHQUN6RCxNQUFNO0dBQ04sSUFBSSxJQUFJO0lBQ1AsSUFBSSxFQUFFLFlBQVksY0FBYyx1QkFBdUIsV0FBVyxTQUFTLElBQUksRUFBRTtTQUM1RSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsR0FBRztLQUMxQixFQUFFLFVBQVU7S0FDWixTQUFTLElBQUksQ0FBQztJQUNmO0dBQ0Q7RUFDRCxDQUFDO0VBQ0QsT0FBTztDQUNSO0NBQ0EsU0FBUyxLQUFLLGFBQWEsTUFBTTtFQUNoQyxJQUFJLGVBQWUsU0FBUyxXQUFXO0VBQ3ZDLFlBQVk7RUFDWixNQUFNLFNBQVMsVUFBVSxRQUFRLElBQUk7RUFDckMsd0JBQXdCLGNBQWMsV0FBVztFQUNqRCxJQUFJLFVBQVUsUUFBUSxXQUFXLE9BQU87R0FDdkMsUUFBUSxJQUFJLFFBQVEsS0FBSyxDQUFDO0dBQzFCO0VBQ0Q7RUFDQSxJQUFJLGNBQWMsSUFBSSxXQUFXLFNBQVMsT0FBTyxFQUFFO0VBQ25ELElBQUk7RUFDSixNQUFNLElBQUksVUFBVSxVQUFVLFFBQVEsY0FBYztHQUNuRCxJQUFJO0lBQ0gsT0FBTyxRQUFRLFFBQVE7S0FDdEIsT0FBTyxNQUFNO0tBQ2I7SUFDRCxDQUFDO0dBQ0YsU0FBUyxjQUFjO0lBQ3RCLFFBQVE7R0FDVDtFQUNELENBQUM7RUFDRCxJQUFJLFVBQVUsS0FBSyxHQUFHO0dBQ3JCLFFBQVEsSUFBSSxLQUFLLEdBQUcsVUFBVSxLQUFLLEdBQUcsTUFBTTtHQUM1QztFQUNELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHO0dBQ3pCLFFBQVEsSUFBSSxHQUFHLEtBQUssR0FBRyxNQUFNO0dBQzdCLE9BQU87RUFDUjtFQUNBLEtBQUs7RUFDTCxJQUFJLE9BQU8sR0FBRztHQUNiLElBQUksRUFBRSxNQUFNLEdBQUcsUUFBUSxJQUFJLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtRQUN6QyxRQUFRLElBQUksS0FBSyxHQUFHLFVBQVUsRUFBRSxDQUFDLEdBQUcsTUFBTTtHQUMvQyxPQUFPO0VBQ1I7RUFDQSxZQUFZO0VBQ1oscUJBQXFCLFlBQVksS0FBSztFQUN0QyxpQkFBaUI7R0FDaEIsU0FBUyxXQUFXLGVBQWUsU0FBUztHQUM1QyxRQUFRO0VBQ1QsR0FBRyxLQUFLO0VBQ1IsT0FBTyxFQUFFLE1BQU0sTUFBTSxRQUFRLEdBQUcsR0FBRyxLQUFLLEdBQUcsTUFBTSxJQUFJLE1BQU0sUUFBUSxHQUFHLEtBQUssR0FBRyxVQUFVLENBQUMsR0FBRyxNQUFNLENBQUM7Q0FDcEc7Q0FDQSxPQUFPLGlCQUFpQixNQUFNO0VBQzdCLE9BQU8sRUFBRSxXQUFXLE1BQU0sRUFBRTtFQUM1QixPQUFPLEVBQUUsV0FBVyxNQUFNLEVBQUU7RUFDNUIsU0FBUyxFQUFFLE1BQU07R0FDaEIsTUFBTSxJQUFJLE1BQU07R0FDaEIsT0FBTyxNQUFNLGFBQWEsTUFBTTtFQUNqQyxFQUFFO0VBQ0YsUUFBUSxFQUFFLE1BQU07R0FDZixJQUFJLENBQUMsVUFBVSxPQUFPLEtBQUs7R0FDM0IsTUFBTSxNQUFNLE1BQU07R0FDbEIsSUFBSSxPQUFPLENBQUMsSUFBSSxNQUFNO0dBQ3RCLE9BQU8sTUFBTTtFQUNkLEVBQUU7Q0FDSCxDQUFDO0NBQ0QsSUFBSSxRQUFRO0NBQ1osSUFBSSxTQUFTLHNCQUFzQixRQUFRLE9BQU8sS0FBSyxLQUFLLEVBQUU7TUFDekQsS0FBSyxLQUFLO0NBQ2YsT0FBTyxDQUFDLE1BQU07RUFDYixVQUFVLFNBQVMsYUFBYSxhQUFhLEtBQUssSUFBSSxDQUFDO0VBQ3ZELFFBQVE7Q0FDVCxDQUFDO0FBQ0Y7QUFDQSxTQUFTLFFBQVEsSUFBSTtDQUNwQixJQUFJLENBQUMsd0JBQXdCLGFBQWEsTUFBTSxPQUFPLEdBQUc7Q0FDMUQsTUFBTSxXQUFXO0NBQ2pCLFdBQVc7Q0FDWCxJQUFJO0VBQ0gsSUFBSSxzQkFBc0IsT0FBTyxxQkFBcUIsUUFBUSxFQUFFO0VBQ2hFLE9BQU8sR0FBRztDQUNYLFVBQVU7RUFDVCxXQUFXO0NBQ1o7QUFDRDtBQUNBLFNBQVMsVUFBVSxJQUFJO0NBQ3RCLElBQUksVUFBVTtNQUNULElBQUksTUFBTSxhQUFhLE1BQU0sTUFBTSxXQUFXLENBQUMsRUFBRTtNQUNqRCxNQUFNLFNBQVMsS0FBSyxFQUFFO0NBQzNCLE9BQU87QUFDUjtBQUNBLFNBQVMsYUFBYSxHQUFHLElBQUk7Q0FDNUIsTUFBTSxPQUFPO0NBQ2IsTUFBTSxlQUFlO0NBQ3JCLFFBQVE7Q0FDUixXQUFXO0NBQ1gsSUFBSTtFQUNILE9BQU8sV0FBVyxJQUFJLElBQUk7Q0FDM0IsU0FBUyxLQUFLO0VBQ2IsWUFBWSxHQUFHO0NBQ2hCLFVBQVU7RUFDVCxRQUFRO0VBQ1IsV0FBVztDQUNaO0FBQ0Q7QUFDQSxTQUFTLGdCQUFnQixJQUFJO0NBQzVCLElBQUksY0FBYyxXQUFXLFNBQVM7RUFDckMsR0FBRztFQUNILE9BQU8sV0FBVztDQUNuQjtDQUNBLE1BQU0sSUFBSTtDQUNWLE1BQU0sSUFBSTtDQUNWLE9BQU8sUUFBUSxRQUFRLENBQUMsQ0FBQyxXQUFXO0VBQ25DLFdBQVc7RUFDWCxRQUFRO0VBQ1IsSUFBSTtFQUNKLElBQUksYUFBYSxpQkFBaUI7R0FDakMsSUFBSSxlQUFlLGFBQWE7SUFDL0IseUJBQXlCLElBQUksSUFBSTtJQUNqQyxTQUFTLENBQUM7SUFDViwwQkFBMEIsSUFBSSxJQUFJO0lBQ2xDLDBCQUEwQixJQUFJLElBQUk7SUFDbEMsdUJBQXVCLElBQUksSUFBSTtJQUMvQixTQUFTO0dBQ1Y7R0FDQSxFQUFFLFNBQVMsRUFBRSxPQUFPLElBQUksU0FBUyxRQUFRLEVBQUUsVUFBVSxHQUFHO0dBQ3hELEVBQUUsVUFBVTtFQUNiO0VBQ0EsV0FBVyxJQUFJLEtBQUs7RUFDcEIsV0FBVyxRQUFRO0VBQ25CLE9BQU8sSUFBSSxFQUFFLE9BQU8sS0FBSztDQUMxQixDQUFDO0FBQ0Y7QUFDQSxJQUFJLENBQUMsY0FBYyxtQkFBbUMsNkJBQWEsS0FBSztBQUN4RSxTQUFTLGNBQWMsY0FBYyxTQUFTO0NBQzdDLE1BQU0sS0FBSyxPQUFPLFNBQVM7Q0FDM0IsT0FBTztFQUNOO0VBQ0EsVUFBVSxlQUFlLEVBQUU7RUFDM0I7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxXQUFXLFNBQVM7Q0FDNUIsSUFBSTtDQUNKLE9BQU8sU0FBUyxNQUFNLFlBQVksUUFBUSxNQUFNLFFBQVEsUUFBUSxTQUFTLEtBQUssSUFBSSxRQUFRLFFBQVE7QUFDbkc7QUFDQSxTQUFTLFNBQVMsSUFBSTtDQUNyQixNQUFNLFdBQVcsV0FBVyxFQUFFO0NBQzlCLE1BQU0sT0FBTyxpQkFBaUIsZ0JBQWdCLFNBQVMsQ0FBQyxDQUFDO0NBQ3pELEtBQUssZ0JBQWdCO0VBQ3BCLE1BQU0sSUFBSSxLQUFLO0VBQ2YsT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLElBQUksS0FBSyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUM7Q0FDbEQ7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxJQUFJO0FBQ0osU0FBUyxhQUFhO0NBQ3JCLE1BQU0sb0JBQW9CLGNBQWMsV0FBVztDQUNuRCxJQUFJLEtBQUssWUFBWSxvQkFBb0IsS0FBSyxTQUFTLEtBQUssUUFBUSxLQUFLLG9CQUFvQixLQUFLLFNBQVMsS0FBSyxXQUFXLE9BQU8sa0JBQWtCLElBQUk7TUFDbko7RUFDSixNQUFNLFVBQVU7RUFDaEIsVUFBVTtFQUNWLGlCQUFpQixhQUFhLElBQUksR0FBRyxLQUFLO0VBQzFDLFVBQVU7Q0FDWDtDQUNBLElBQUksVUFBVTtFQUNiLE1BQU0sUUFBUSxLQUFLLFlBQVksS0FBSyxVQUFVLFNBQVM7RUFDdkQsSUFBSSxDQUFDLFNBQVMsU0FBUztHQUN0QixTQUFTLFVBQVUsQ0FBQyxJQUFJO0dBQ3hCLFNBQVMsY0FBYyxDQUFDLEtBQUs7RUFDOUIsT0FBTztHQUNOLFNBQVMsUUFBUSxLQUFLLElBQUk7R0FDMUIsU0FBUyxZQUFZLEtBQUssS0FBSztFQUNoQztFQUNBLElBQUksQ0FBQyxLQUFLLFdBQVc7R0FDcEIsS0FBSyxZQUFZLENBQUMsUUFBUTtHQUMxQixLQUFLLGdCQUFnQixDQUFDLFNBQVMsUUFBUSxTQUFTLENBQUM7RUFDbEQsT0FBTztHQUNOLEtBQUssVUFBVSxLQUFLLFFBQVE7R0FDNUIsS0FBSyxjQUFjLEtBQUssU0FBUyxRQUFRLFNBQVMsQ0FBQztFQUNwRDtDQUNEO0NBQ0EsSUFBSSxxQkFBcUIsV0FBVyxRQUFRLElBQUksSUFBSSxHQUFHLE9BQU8sS0FBSztDQUNuRSxPQUFPLEtBQUs7QUFDYjtBQUNBLFNBQVMsWUFBWSxNQUFNLE9BQU8sUUFBUTtDQUN6QyxJQUFJLFVBQVUsY0FBYyxXQUFXLFdBQVcsV0FBVyxRQUFRLElBQUksSUFBSSxJQUFJLEtBQUssU0FBUyxLQUFLO0NBQ3BHLElBQUksQ0FBQyxLQUFLLGNBQWMsQ0FBQyxLQUFLLFdBQVcsU0FBUyxLQUFLLEdBQUc7RUFDekQsSUFBSSxZQUFZO0dBQ2YsTUFBTSxvQkFBb0IsV0FBVztHQUNyQyxJQUFJLHFCQUFxQixDQUFDLFVBQVUsV0FBVyxRQUFRLElBQUksSUFBSSxHQUFHO0lBQ2pFLFdBQVcsUUFBUSxJQUFJLElBQUk7SUFDM0IsS0FBSyxTQUFTO0dBQ2Y7R0FDQSxJQUFJLENBQUMsbUJBQW1CLEtBQUssUUFBUTtFQUN0QyxPQUFPLEtBQUssUUFBUTtFQUNwQixJQUFJLEtBQUssYUFBYSxLQUFLLFVBQVUsUUFBUSxpQkFBaUI7R0FDN0QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssVUFBVSxRQUFRLEtBQUssR0FBRztJQUNsRCxNQUFNLElBQUksS0FBSyxVQUFVO0lBQ3pCLE1BQU0sb0JBQW9CLGNBQWMsV0FBVztJQUNuRCxJQUFJLHFCQUFxQixXQUFXLFNBQVMsSUFBSSxDQUFDLEdBQUc7SUFDckQsSUFBSSxvQkFBb0IsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxFQUFFLE9BQU87S0FDN0MsSUFBSSxFQUFFLE1BQU0sUUFBUSxLQUFLLENBQUM7VUFDckIsUUFBUSxLQUFLLENBQUM7S0FDbkIsSUFBSSxFQUFFLFdBQVcsZUFBZSxDQUFDO0lBQ2xDO0lBQ0EsSUFBSSxDQUFDLG1CQUFtQixFQUFFLFFBQVE7U0FDN0IsRUFBRSxTQUFTO0dBQ2pCO0dBQ0EsSUFBSSxRQUFRLFNBQVMsS0FBSztJQUN6QixVQUFVLENBQUM7SUFDWCxNQUFNLElBQUksTUFBTTtHQUNqQjtFQUNELEdBQUcsS0FBSztDQUNUO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxrQkFBa0IsTUFBTTtDQUNoQyxJQUFJLENBQUMsS0FBSyxJQUFJO0NBQ2QsVUFBVSxJQUFJO0NBQ2QsTUFBTSxPQUFPO0NBQ2IsZUFBZSxNQUFNLGNBQWMsV0FBVyxXQUFXLFdBQVcsUUFBUSxJQUFJLElBQUksSUFBSSxLQUFLLFNBQVMsS0FBSyxPQUFPLElBQUk7Q0FDdEgsSUFBSSxjQUFjLENBQUMsV0FBVyxXQUFXLFdBQVcsUUFBUSxJQUFJLElBQUksR0FBRyxxQkFBcUI7RUFDM0YsaUJBQWlCO0dBQ2hCLGVBQWUsV0FBVyxVQUFVO0dBQ3BDLFdBQVcsUUFBUTtHQUNuQixlQUFlLE1BQU0sS0FBSyxRQUFRLElBQUk7R0FDdEMsV0FBVyxRQUFRO0VBQ3BCLEdBQUcsS0FBSztDQUNULENBQUM7QUFDRjtBQUNBLFNBQVMsZUFBZSxNQUFNLE9BQU8sTUFBTTtDQUMxQyxJQUFJO0NBQ0osTUFBTSxRQUFRLE9BQU8sV0FBVztDQUNoQyxXQUFXLFFBQVE7Q0FDbkIsSUFBSTtFQUNILFlBQVksS0FBSyxHQUFHLEtBQUs7Q0FDMUIsU0FBUyxLQUFLO0VBQ2IsSUFBSSxLQUFLLE1BQU0sSUFBSSxjQUFjLFdBQVcsU0FBUztHQUNwRCxLQUFLLFNBQVM7R0FDZCxLQUFLLFVBQVUsS0FBSyxPQUFPLFFBQVEsU0FBUztHQUM1QyxLQUFLLFNBQVMsS0FBSztFQUNwQixPQUFPO0dBQ04sS0FBSyxRQUFRO0dBQ2IsS0FBSyxTQUFTLEtBQUssTUFBTSxRQUFRLFNBQVM7R0FDMUMsS0FBSyxRQUFRO0VBQ2Q7RUFDQSxLQUFLLFlBQVksT0FBTztFQUN4QixPQUFPLFlBQVksR0FBRztDQUN2QixVQUFVO0VBQ1QsV0FBVztFQUNYLFFBQVE7Q0FDVDtDQUNBLElBQUksQ0FBQyxLQUFLLGFBQWEsS0FBSyxhQUFhLE1BQU07RUFDOUMsSUFBSSxLQUFLLGFBQWEsUUFBUSxlQUFlLE1BQU0sWUFBWSxNQUFNLFdBQVcsSUFBSTtPQUMvRSxJQUFJLGNBQWMsV0FBVyxXQUFXLEtBQUssTUFBTTtHQUN2RCxJQUFJLENBQUMsV0FBVyxRQUFRLElBQUksSUFBSSxHQUFHLEtBQUssUUFBUTtHQUNoRCxXQUFXLFFBQVEsSUFBSSxJQUFJO0dBQzNCLEtBQUssU0FBUztFQUNmLE9BQU8sS0FBSyxRQUFRO0VBQ3BCLEtBQUssWUFBWTtDQUNsQjtBQUNEO0FBQ0EsU0FBUyxrQkFBa0IsSUFBSSxNQUFNLE1BQU0sUUFBUSxPQUFPLFNBQVM7Q0FDbEUsTUFBTSxJQUFJO0VBQ1Q7RUFDQTtFQUNBLFdBQVc7RUFDWCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWE7RUFDYixVQUFVO0VBQ1YsT0FBTztFQUNQLE9BQU87RUFDUCxTQUFTLFFBQVEsTUFBTSxVQUFVO0VBQ2pDO0NBQ0Q7Q0FDQSxJQUFJLGNBQWMsV0FBVyxTQUFTO0VBQ3JDLEVBQUUsUUFBUTtFQUNWLEVBQUUsU0FBUztDQUNaO0NBQ0EsSUFBSSxVQUFVO01BQ1QsSUFBSSxVQUFVLFNBQVMsSUFBSSxjQUFjLFdBQVcsV0FBVyxNQUFNLE1BQU0sSUFBSSxDQUFDLE1BQU0sUUFBUSxNQUFNLFNBQVMsQ0FBQyxDQUFDO01BQy9HLE1BQU0sT0FBTyxLQUFLLENBQUM7TUFDbkIsSUFBSSxDQUFDLE1BQU0sT0FBTyxNQUFNLFFBQVEsQ0FBQyxDQUFDO01BQ2xDLE1BQU0sTUFBTSxLQUFLLENBQUM7Q0FDdkIsSUFBSSx3QkFBd0IsRUFBRSxJQUFJO0VBQ2pDLE1BQU0sV0FBVyxFQUFFO0VBQ25CLE1BQU0sQ0FBQyxPQUFPLFdBQVcsYUFBYSxLQUFLLEdBQUcsRUFBRSxRQUFRLE1BQU0sQ0FBQztFQUMvRCxNQUFNLFdBQVcscUJBQXFCLFFBQVEsVUFBVSxPQUFPO0VBQy9ELGdCQUFnQixTQUFTLFFBQVEsQ0FBQztFQUNsQyxJQUFJO0VBQ0osTUFBTSw0QkFBNEIsZ0JBQWdCLE9BQU8sQ0FBQyxDQUFDLFdBQVc7R0FDckUsSUFBSSxjQUFjO0lBQ2pCLGFBQWEsUUFBUTtJQUNyQixlQUFlLEtBQUs7R0FDckI7RUFDRCxDQUFDO0VBQ0QsRUFBRSxNQUFNLE1BQU07R0FDYixNQUFNO0dBQ04sSUFBSSxjQUFjLFdBQVcsU0FBUztJQUNyQyxJQUFJLENBQUMsY0FBYyxlQUFlLHFCQUFxQixRQUFRLFVBQVUsbUJBQW1CO0lBQzVGLE9BQU8sYUFBYSxNQUFNLENBQUM7R0FDNUI7R0FDQSxPQUFPLFNBQVMsTUFBTSxDQUFDO0VBQ3hCO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLE9BQU8sTUFBTTtDQUNyQixNQUFNLG9CQUFvQixjQUFjLFdBQVc7Q0FDbkQsS0FBSyxvQkFBb0IsS0FBSyxTQUFTLEtBQUssV0FBVyxHQUFHO0NBQzFELEtBQUssb0JBQW9CLEtBQUssU0FBUyxLQUFLLFdBQVcsU0FBUyxPQUFPLGFBQWEsSUFBSTtDQUN4RixJQUFJLEtBQUssWUFBWSxRQUFRLEtBQUssU0FBUyxVQUFVLEdBQUcsT0FBTyxLQUFLLFNBQVMsUUFBUSxLQUFLLElBQUk7Q0FDOUYsTUFBTSxZQUFZLENBQUMsSUFBSTtDQUN2QixRQUFRLE9BQU8sS0FBSyxXQUFXLENBQUMsS0FBSyxhQUFhLEtBQUssWUFBWSxZQUFZO0VBQzlFLElBQUkscUJBQXFCLFdBQVcsU0FBUyxJQUFJLElBQUksR0FBRztFQUN4RCxJQUFJLG9CQUFvQixLQUFLLFNBQVMsS0FBSyxPQUFPLFVBQVUsS0FBSyxJQUFJO0NBQ3RFO0NBQ0EsS0FBSyxJQUFJLElBQUksVUFBVSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7RUFDL0MsT0FBTyxVQUFVO0VBQ2pCLElBQUksbUJBQW1CO0dBQ3RCLElBQUksTUFBTSxNQUFNLE9BQU8sVUFBVSxJQUFJO0dBQ3JDLFFBQVEsTUFBTSxJQUFJLFVBQVUsUUFBUSxNQUFNLElBQUksV0FBVyxTQUFTLElBQUksR0FBRyxHQUFHO0VBQzdFO0VBQ0EsS0FBSyxvQkFBb0IsS0FBSyxTQUFTLEtBQUssV0FBVyxPQUFPLGtCQUFrQixJQUFJO09BQy9FLEtBQUssb0JBQW9CLEtBQUssU0FBUyxLQUFLLFdBQVcsU0FBUztHQUNwRSxNQUFNLFVBQVU7R0FDaEIsVUFBVTtHQUNWLGlCQUFpQixhQUFhLE1BQU0sVUFBVSxFQUFFLEdBQUcsS0FBSztHQUN4RCxVQUFVO0VBQ1g7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxXQUFXLElBQUksTUFBTTtDQUM3QixJQUFJLFNBQVMsT0FBTyxHQUFHO0NBQ3ZCLElBQUksT0FBTztDQUNYLElBQUksQ0FBQyxNQUFNLFVBQVUsQ0FBQztDQUN0QixJQUFJLFNBQVMsT0FBTztNQUNmLFVBQVUsQ0FBQztDQUNoQjtDQUNBLElBQUk7RUFDSCxNQUFNLE1BQU0sR0FBRztFQUNmLGdCQUFnQixJQUFJO0VBQ3BCLE9BQU87Q0FDUixTQUFTLEtBQUs7RUFDYixJQUFJLENBQUMsTUFBTSxVQUFVO0VBQ3JCLFVBQVU7RUFDVixZQUFZLEdBQUc7Q0FDaEI7QUFDRDtBQUNBLFNBQVMsZ0JBQWdCLE1BQU07Q0FDOUIsSUFBSSxTQUFTO0VBQ1osSUFBSSxhQUFhLGNBQWMsV0FBVyxTQUFTLGNBQWMsT0FBTztPQUNuRSxTQUFTLE9BQU87RUFDckIsVUFBVTtDQUNYO0NBQ0EsSUFBSSxNQUFNO0NBQ1YsSUFBSTtDQUNKLElBQUksWUFBWTtFQUNmLElBQUksQ0FBQyxXQUFXLFNBQVMsUUFBUSxDQUFDLFdBQVcsTUFBTSxNQUFNO0dBQ3hELE1BQU0sVUFBVSxXQUFXO0dBQzNCLE1BQU0sV0FBVyxXQUFXO0dBQzVCLFFBQVEsS0FBSyxNQUFNLFNBQVMsV0FBVyxPQUFPO0dBQzlDLE1BQU0sV0FBVztHQUNqQixLQUFLLE1BQU0sS0FBSyxTQUFTO0lBQ3hCLFlBQVksTUFBTSxFQUFFLFFBQVEsRUFBRTtJQUM5QixPQUFPLEVBQUU7R0FDVjtHQUNBLGFBQWE7R0FDYixpQkFBaUI7SUFDaEIsS0FBSyxNQUFNLEtBQUssVUFBVSxVQUFVLENBQUM7SUFDckMsS0FBSyxNQUFNLEtBQUssU0FBUztLQUN4QixFQUFFLFFBQVEsRUFBRTtLQUNaLElBQUksRUFBRSxPQUFPLEtBQUssSUFBSSxJQUFJLEdBQUcsTUFBTSxFQUFFLE1BQU0sUUFBUSxJQUFJLEtBQUssS0FBSyxVQUFVLEVBQUUsTUFBTSxFQUFFO0tBQ3JGLElBQUksRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFO0tBQzFCLE9BQU8sRUFBRTtLQUNULE9BQU8sRUFBRTtLQUNULEVBQUUsU0FBUztJQUNaO0lBQ0EsZ0JBQWdCLEtBQUs7R0FDdEIsR0FBRyxLQUFLO0VBQ1QsT0FBTyxJQUFJLFdBQVcsU0FBUztHQUM5QixXQUFXLFVBQVU7R0FDckIsV0FBVyxRQUFRLEtBQUssTUFBTSxXQUFXLFNBQVMsT0FBTztHQUN6RCxVQUFVO0dBQ1YsZ0JBQWdCLElBQUk7R0FDcEI7RUFDRDtDQUNEO0NBQ0EsTUFBTSxJQUFJO0NBQ1YsVUFBVTtDQUNWLElBQUksRUFBRSxRQUFRLGlCQUFpQixXQUFXLENBQUMsR0FBRyxLQUFLO0NBQ25ELElBQUksS0FBSyxJQUFJO0FBQ2Q7QUFDQSxTQUFTLFNBQVMsT0FBTztDQUN4QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUssT0FBTyxNQUFNLEVBQUU7QUFDdkQ7QUFDQSxTQUFTLGNBQWMsT0FBTztDQUM3QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7RUFDdEMsTUFBTSxPQUFPLE1BQU07RUFDbkIsTUFBTSxRQUFRLFdBQVc7RUFDekIsSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLEdBQUc7R0FDckIsTUFBTSxJQUFJLElBQUk7R0FDZCxnQkFBZ0I7SUFDZixNQUFNLE9BQU8sSUFBSTtJQUNqQixpQkFBaUI7S0FDaEIsV0FBVyxVQUFVO0tBQ3JCLE9BQU8sSUFBSTtJQUNaLEdBQUcsS0FBSztJQUNSLGVBQWUsV0FBVyxVQUFVO0dBQ3JDLENBQUM7RUFDRjtDQUNEO0FBQ0Q7QUFDQSxTQUFTLGVBQWUsT0FBTztDQUM5QixJQUFJLEdBQUcsYUFBYTtDQUNwQixLQUFLLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0VBQ2xDLE1BQU0sSUFBSSxNQUFNO0VBQ2hCLElBQUksQ0FBQyxFQUFFLE1BQU0sT0FBTyxDQUFDO09BQ2hCLE1BQU0sZ0JBQWdCO0NBQzVCO0NBQ0EsSUFBSSxhQUFhLFNBQVM7RUFDekIsSUFBSSxhQUFhLE9BQU87R0FDdkIsYUFBYSxZQUFZLGFBQWEsVUFBVSxDQUFDO0dBQ2pELGFBQWEsUUFBUSxLQUFLLEdBQUcsTUFBTSxNQUFNLEdBQUcsVUFBVSxDQUFDO0dBQ3ZEO0VBQ0Q7RUFDQSxrQkFBa0I7Q0FDbkI7Q0FDQSxJQUFJLGFBQWEsWUFBWSxhQUFhLFFBQVEsQ0FBQyxhQUFhLFFBQVE7RUFDdkUsUUFBUSxDQUFDLEdBQUcsYUFBYSxTQUFTLEdBQUcsS0FBSztFQUMxQyxjQUFjLGFBQWEsUUFBUTtFQUNuQyxPQUFPLGFBQWE7Q0FDckI7Q0FDQSxLQUFLLElBQUksR0FBRyxJQUFJLFlBQVksS0FBSyxPQUFPLE1BQU0sRUFBRTtBQUNqRDtBQUNBLFNBQVMsYUFBYSxNQUFNLFFBQVE7Q0FDbkMsTUFBTSxvQkFBb0IsY0FBYyxXQUFXO0NBQ25ELElBQUksbUJBQW1CLEtBQUssU0FBUztNQUNoQyxLQUFLLFFBQVE7Q0FDbEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxRQUFRLEtBQUssR0FBRztFQUNoRCxNQUFNLFNBQVMsS0FBSyxRQUFRO0VBQzVCLElBQUksT0FBTyxTQUFTO0dBQ25CLE1BQU0sUUFBUSxvQkFBb0IsT0FBTyxTQUFTLE9BQU87R0FDekQsSUFBSSxVQUFVLE9BQ1Q7UUFBQSxXQUFXLFdBQVcsQ0FBQyxPQUFPLGFBQWEsT0FBTyxZQUFZLFlBQVksT0FBTyxNQUFNO0dBQUEsT0FDckYsSUFBSSxVQUFVLFNBQVMsYUFBYSxRQUFRLE1BQU07RUFDMUQ7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxlQUFlLE1BQU07Q0FDN0IsTUFBTSxvQkFBb0IsY0FBYyxXQUFXO0NBQ25ELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFVBQVUsUUFBUSxLQUFLLEdBQUc7RUFDbEQsTUFBTSxJQUFJLEtBQUssVUFBVTtFQUN6QixJQUFJLG9CQUFvQixDQUFDLEVBQUUsU0FBUyxDQUFDLEVBQUUsT0FBTztHQUM3QyxJQUFJLG1CQUFtQixFQUFFLFNBQVM7UUFDN0IsRUFBRSxRQUFRO0dBQ2YsSUFBSSxFQUFFLE1BQU0sUUFBUSxLQUFLLENBQUM7UUFDckIsUUFBUSxLQUFLLENBQUM7R0FDbkIsRUFBRSxhQUFhLGVBQWUsQ0FBQztFQUNoQztDQUNEO0FBQ0Q7QUFDQSxTQUFTLFVBQVUsTUFBTTtDQUN4QixJQUFJO0NBQ0osSUFBSSxLQUFLLFNBQVMsT0FBTyxLQUFLLFFBQVEsUUFBUTtFQUM3QyxNQUFNLFNBQVMsS0FBSyxRQUFRLElBQUksR0FBRyxRQUFRLEtBQUssWUFBWSxJQUFJLEdBQUcsTUFBTSxPQUFPO0VBQ2hGLElBQUksT0FBTyxJQUFJLFFBQVE7R0FDdEIsTUFBTSxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxjQUFjLElBQUk7R0FDbEQsSUFBSSxRQUFRLElBQUksUUFBUTtJQUN2QixFQUFFLFlBQVksS0FBSztJQUNuQixJQUFJLFNBQVM7SUFDYixPQUFPLGNBQWMsU0FBUztHQUMvQjtFQUNEO0NBQ0Q7Q0FDQSxJQUFJLEtBQUssUUFBUTtFQUNoQixLQUFLLElBQUksS0FBSyxPQUFPLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSyxVQUFVLEtBQUssT0FBTyxFQUFFO0VBQ3RFLE9BQU8sS0FBSztDQUNiO0NBQ0EsSUFBSSxjQUFjLFdBQVcsV0FBVyxLQUFLLE1BQU0sTUFBTSxNQUFNLElBQUk7TUFDOUQsSUFBSSxLQUFLLE9BQU87RUFDcEIsS0FBSyxJQUFJLEtBQUssTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUssVUFBVSxLQUFLLE1BQU0sRUFBRTtFQUNwRSxLQUFLLFFBQVE7Q0FDZDtDQUNBLElBQUksS0FBSyxVQUFVO0VBQ2xCLEtBQUssSUFBSSxLQUFLLFNBQVMsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLLEtBQUssU0FBUyxFQUFFLENBQUM7RUFDakUsS0FBSyxXQUFXO0NBQ2pCO0NBQ0EsSUFBSSxjQUFjLFdBQVcsU0FBUyxLQUFLLFNBQVM7TUFDL0MsS0FBSyxRQUFRO0FBQ25CO0FBQ0EsU0FBUyxNQUFNLE1BQU0sS0FBSztDQUN6QixJQUFJLENBQUMsS0FBSztFQUNULEtBQUssU0FBUztFQUNkLFdBQVcsU0FBUyxJQUFJLElBQUk7Q0FDN0I7Q0FDQSxJQUFJLEtBQUssT0FBTyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxNQUFNLFFBQVEsS0FBSyxNQUFNLEtBQUssTUFBTSxFQUFFO0FBQ2hGO0FBQ0EsU0FBUyxVQUFVLEtBQUs7Q0FDdkIsSUFBSSxlQUFlLE9BQU8sT0FBTztDQUNqQyxPQUFPLElBQUksTUFBTSxPQUFPLFFBQVEsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sSUFBSSxDQUFDO0FBQ2pGO0FBQ0EsU0FBUyxVQUFVLEtBQUssS0FBSyxPQUFPO0NBQ25DLElBQUk7RUFDSCxLQUFLLE1BQU0sS0FBSyxLQUFLLEVBQUUsR0FBRztDQUMzQixTQUFTLEdBQUc7RUFDWCxZQUFZLEdBQUcsU0FBUyxNQUFNLFNBQVMsSUFBSTtDQUM1QztBQUNEO0FBQ0EsU0FBUyxZQUFZLEtBQUssUUFBUSxPQUFPO0NBQ3hDLE1BQU0sTUFBTSxTQUFTLFNBQVMsTUFBTSxXQUFXLE1BQU0sUUFBUTtDQUM3RCxNQUFNLFFBQVEsVUFBVSxHQUFHO0NBQzNCLElBQUksQ0FBQyxLQUFLLE1BQU07Q0FDaEIsSUFBSSxTQUFTLFFBQVEsS0FBSztFQUN6QixLQUFLO0dBQ0osVUFBVSxPQUFPLEtBQUssS0FBSztFQUM1QjtFQUNBLE9BQU87Q0FDUixDQUFDO01BQ0ksVUFBVSxPQUFPLEtBQUssS0FBSztBQUNqQztBQUNBLFNBQVMsZ0JBQWdCLFVBQVU7Q0FDbEMsSUFBSSxPQUFPLGFBQWEsY0FBYyxDQUFDLFNBQVMsUUFBUSxPQUFPLGdCQUFnQixTQUFTLENBQUM7Q0FDekYsSUFBSSxNQUFNLFFBQVEsUUFBUSxHQUFHO0VBQzVCLE1BQU0sVUFBVSxDQUFDO0VBQ2pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztHQUN6QyxNQUFNLFNBQVMsZ0JBQWdCLFNBQVMsRUFBRTtHQUMxQyxNQUFNLFFBQVEsTUFBTSxJQUFJLFFBQVEsS0FBSyxNQUFNLFNBQVMsTUFBTSxJQUFJLFFBQVEsS0FBSyxNQUFNO0VBQ2xGO0VBQ0EsT0FBTztDQUNSO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxlQUFlLElBQUksU0FBUztDQUNwQyxPQUFPLFNBQVMsU0FBUyxPQUFPO0VBQy9CLElBQUk7RUFDSix5QkFBeUIsTUFBTSxjQUFjO0dBQzVDLE1BQU0sVUFBVTtJQUNmLEdBQUcsTUFBTTtLQUNSLEtBQUssTUFBTTtHQUNiO0dBQ0EsT0FBTyxlQUFlLE1BQU0sUUFBUTtFQUNyQyxDQUFDLEdBQUcsS0FBSyxDQUFDO0VBQ1YsT0FBTztDQUNSO0FBQ0Q7QUFDQSxJQUFJLFdBQVcsT0FBTyxVQUFVO0FBQ2hDLFNBQVMsUUFBUSxHQUFHO0NBQ25CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSyxFQUFFLEVBQUUsQ0FBQztBQUN6QztBQUNBLFNBQVMsU0FBUyxNQUFNLE9BQU8sVUFBVSxDQUFDLEdBQUc7Q0FDNUMsSUFBSSxRQUFRLENBQUMsR0FBRyxTQUFTLENBQUMsR0FBRyxZQUFZLENBQUMsR0FBRyxNQUFNLEdBQUcsVUFBVSxNQUFNLFNBQVMsSUFBSSxDQUFDLElBQUk7Q0FDeEYsZ0JBQWdCLFFBQVEsU0FBUyxDQUFDO0NBQ2xDLGFBQWE7RUFDWixJQUFJLFdBQVcsS0FBSyxLQUFLLENBQUMsR0FBRyxTQUFTLFNBQVMsUUFBUSxHQUFHO0VBQzFELFNBQVM7RUFDVCxPQUFPLGNBQWM7R0FDcEIsSUFBSSxZQUFZLGdCQUFnQixNQUFNLGVBQWUsYUFBYSxPQUFPLEtBQUssUUFBUTtHQUN0RixJQUFJLFdBQVcsR0FBRztJQUNqQixJQUFJLFFBQVEsR0FBRztLQUNkLFFBQVEsU0FBUztLQUNqQixZQUFZLENBQUM7S0FDYixRQUFRLENBQUM7S0FDVCxTQUFTLENBQUM7S0FDVixNQUFNO0tBQ04sWUFBWSxVQUFVLENBQUM7SUFDeEI7SUFDQSxJQUFJLFFBQVEsVUFBVTtLQUNyQixRQUFRLENBQUMsUUFBUTtLQUNqQixPQUFPLEtBQUssWUFBWSxhQUFhO01BQ3BDLFVBQVUsS0FBSztNQUNmLE9BQU8sUUFBUSxTQUFTO0tBQ3pCLENBQUM7S0FDRCxNQUFNO0lBQ1A7R0FDRCxPQUFPLElBQUksUUFBUSxHQUFHO0lBQ3JCLFNBQVMsSUFBSSxNQUFNLE1BQU07SUFDekIsS0FBSyxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUs7S0FDNUIsTUFBTSxLQUFLLFNBQVM7S0FDcEIsT0FBTyxLQUFLLFdBQVcsTUFBTTtJQUM5QjtJQUNBLE1BQU07R0FDUCxPQUFPO0lBQ04sT0FBTyxJQUFJLE1BQU0sTUFBTTtJQUN2QixnQkFBZ0IsSUFBSSxNQUFNLE1BQU07SUFDaEMsWUFBWSxjQUFjLElBQUksTUFBTSxNQUFNO0lBQzFDLEtBQUssUUFBUSxHQUFHLE1BQU0sS0FBSyxJQUFJLEtBQUssTUFBTSxHQUFHLFFBQVEsT0FBTyxNQUFNLFdBQVcsU0FBUyxRQUFRO0lBQzlGLEtBQUssTUFBTSxNQUFNLEdBQUcsU0FBUyxTQUFTLEdBQUcsT0FBTyxTQUFTLFVBQVUsU0FBUyxNQUFNLFNBQVMsU0FBUyxTQUFTLE9BQU8sVUFBVTtLQUM3SCxLQUFLLFVBQVUsT0FBTztLQUN0QixjQUFjLFVBQVUsVUFBVTtLQUNsQyxZQUFZLFlBQVksVUFBVSxRQUFRO0lBQzNDO0lBQ0EsNkJBQTZCLElBQUksSUFBSTtJQUNyQyxpQkFBaUIsSUFBSSxNQUFNLFNBQVMsQ0FBQztJQUNyQyxLQUFLLElBQUksUUFBUSxLQUFLLE9BQU8sS0FBSztLQUNqQyxPQUFPLFNBQVM7S0FDaEIsSUFBSSxXQUFXLElBQUksSUFBSTtLQUN2QixlQUFlLEtBQUssTUFBTSxLQUFLLElBQUksS0FBSztLQUN4QyxXQUFXLElBQUksTUFBTSxDQUFDO0lBQ3ZCO0lBQ0EsS0FBSyxJQUFJLE9BQU8sS0FBSyxLQUFLLEtBQUs7S0FDOUIsT0FBTyxNQUFNO0tBQ2IsSUFBSSxXQUFXLElBQUksSUFBSTtLQUN2QixJQUFJLE1BQU0sS0FBSyxLQUFLLE1BQU0sSUFBSTtNQUM3QixLQUFLLEtBQUssT0FBTztNQUNqQixjQUFjLEtBQUssVUFBVTtNQUM3QixZQUFZLFlBQVksS0FBSyxRQUFRO01BQ3JDLElBQUksZUFBZTtNQUNuQixXQUFXLElBQUksTUFBTSxDQUFDO0tBQ3ZCLE9BQU8sVUFBVSxFQUFFLENBQUM7SUFDckI7SUFDQSxLQUFLLElBQUksT0FBTyxJQUFJLFFBQVEsS0FBSyxJQUFJLEtBQUssTUFBTTtLQUMvQyxPQUFPLEtBQUssS0FBSztLQUNqQixVQUFVLEtBQUssY0FBYztLQUM3QixJQUFJLFNBQVM7TUFDWixRQUFRLEtBQUssWUFBWTtNQUN6QixRQUFRLEVBQUUsQ0FBQyxDQUFDO0tBQ2I7SUFDRCxPQUFPLE9BQU8sS0FBSyxXQUFXLE1BQU07SUFDcEMsU0FBUyxPQUFPLE1BQU0sR0FBRyxNQUFNLE1BQU07SUFDckMsUUFBUSxTQUFTLE1BQU0sQ0FBQztHQUN6QjtHQUNBLE9BQU87RUFDUixDQUFDO0VBQ0QsU0FBUyxPQUFPLFVBQVU7R0FDekIsVUFBVSxLQUFLO0dBQ2YsSUFBSSxTQUFTO0lBQ1osTUFBTSxDQUFDLEdBQUcsT0FBTyxhQUFhLENBQUM7SUFDL0IsUUFBUSxLQUFLO0lBQ2IsT0FBTyxNQUFNLFNBQVMsSUFBSSxDQUFDO0dBQzVCO0dBQ0EsT0FBTyxNQUFNLFNBQVMsRUFBRTtFQUN6QjtDQUNEO0FBQ0Q7QUFDQSxJQUFJLG1CQUFtQjtBQUN2QixTQUFTLGdCQUFnQixNQUFNLE9BQU87Q0FDckMsSUFBSSxrQkFDQztNQUFBLGFBQWEsU0FBUztHQUN6QixNQUFNLElBQUksYUFBYTtHQUN2QixrQkFBa0IsbUJBQW1CLENBQUM7R0FDdEMsTUFBTSxJQUFJLGNBQWMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO0dBQ3pDLGtCQUFrQixDQUFDO0dBQ25CLE9BQU87RUFDUjs7Q0FFRCxPQUFPLGNBQWMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDO0FBQ0EsU0FBUyxTQUFTO0NBQ2pCLE9BQU87QUFDUjtBQUNBLElBQUksWUFBWTtDQUNmLElBQUksR0FBRyxVQUFVLFVBQVU7RUFDMUIsSUFBSSxhQUFhLFFBQVEsT0FBTztFQUNoQyxPQUFPLEVBQUUsSUFBSSxRQUFRO0NBQ3RCO0NBQ0EsSUFBSSxHQUFHLFVBQVU7RUFDaEIsSUFBSSxhQUFhLFFBQVEsT0FBTztFQUNoQyxPQUFPLEVBQUUsSUFBSSxRQUFRO0NBQ3RCO0NBQ0EsS0FBSztDQUNMLGdCQUFnQjtDQUNoQix5QkFBeUIsR0FBRyxVQUFVO0VBQ3JDLE9BQU87R0FDTixjQUFjO0dBQ2QsWUFBWTtHQUNaLE1BQU07SUFDTCxPQUFPLEVBQUUsSUFBSSxRQUFRO0dBQ3RCO0dBQ0EsS0FBSztHQUNMLGdCQUFnQjtFQUNqQjtDQUNEO0NBQ0EsUUFBUSxHQUFHO0VBQ1YsT0FBTyxFQUFFLEtBQUs7Q0FDZjtBQUNEO0FBQ0EsU0FBUyxjQUFjLEdBQUc7Q0FDekIsT0FBTyxFQUFFLElBQUksT0FBTyxNQUFNLGFBQWEsRUFBRSxJQUFJLEtBQUssQ0FBQyxJQUFJO0FBQ3hEO0FBQ0EsU0FBUyxpQkFBaUI7Q0FDekIsS0FBSyxJQUFJLElBQUksR0FBRyxTQUFTLEtBQUssUUFBUSxJQUFJLFFBQVEsRUFBRSxHQUFHO0VBQ3RELE1BQU0sSUFBSSxLQUFLLEVBQUUsQ0FBQztFQUNsQixJQUFJLE1BQU0sS0FBSyxHQUFHLE9BQU87Q0FDMUI7QUFDRDtBQUNBLFNBQVMsV0FBVyxHQUFHLFNBQVM7Q0FDL0IsSUFBSSxRQUFRO0NBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO0VBQ3hDLE1BQU0sSUFBSSxRQUFRO0VBQ2xCLFFBQVEsU0FBUyxDQUFDLENBQUMsS0FBSyxVQUFVO0VBQ2xDLFFBQVEsS0FBSyxPQUFPLE1BQU0sY0FBYyxRQUFRLE1BQU0sV0FBVyxDQUFDLEtBQUs7Q0FDeEU7Q0FDQSxJQUFJLGtCQUFrQixPQUFPLE9BQU8sSUFBSSxNQUFNO0VBQzdDLElBQUksVUFBVTtHQUNiLEtBQUssSUFBSSxJQUFJLFFBQVEsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0lBQzdDLE1BQU0sSUFBSSxjQUFjLFFBQVEsRUFBRSxDQUFDLENBQUM7SUFDcEMsSUFBSSxNQUFNLEtBQUssR0FBRyxPQUFPO0dBQzFCO0VBQ0Q7RUFDQSxJQUFJLFVBQVU7R0FDYixLQUFLLElBQUksSUFBSSxRQUFRLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSyxJQUFJLFlBQVksY0FBYyxRQUFRLEVBQUUsR0FBRyxPQUFPO0dBQ2hHLE9BQU87RUFDUjtFQUNBLE9BQU87R0FDTixNQUFNLE9BQU8sQ0FBQztHQUNkLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSyxLQUFLLEtBQUssR0FBRyxPQUFPLEtBQUssY0FBYyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0dBQzVGLE9BQU8sQ0FBQyxHQUFHLElBQUksSUFBSSxJQUFJLENBQUM7RUFDekI7Q0FDRCxHQUFHLFNBQVM7Q0FDWixNQUFNLGFBQWEsQ0FBQztDQUNwQixNQUFNLFVBQVUsT0FBTyxPQUFPLElBQUk7Q0FDbEMsS0FBSyxJQUFJLElBQUksUUFBUSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7RUFDN0MsTUFBTSxTQUFTLFFBQVE7RUFDdkIsSUFBSSxDQUFDLFFBQVE7RUFDYixNQUFNLGFBQWEsT0FBTyxvQkFBb0IsTUFBTTtFQUNwRCxLQUFLLElBQUksSUFBSSxXQUFXLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztHQUNoRCxNQUFNLE1BQU0sV0FBVztHQUN2QixJQUFJLFFBQVEsZUFBZSxRQUFRLGVBQWU7R0FDbEQsTUFBTSxPQUFPLE9BQU8seUJBQXlCLFFBQVEsR0FBRztHQUN4RCxJQUFJLENBQUMsUUFBUSxNQUFNLFFBQVEsT0FBTyxLQUFLLE1BQU07SUFDNUMsWUFBWTtJQUNaLGNBQWM7SUFDZCxLQUFLLGVBQWUsS0FBSyxXQUFXLE9BQU8sQ0FBQyxLQUFLLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQztHQUNuRSxJQUFJLEtBQUssVUFBVSxLQUFLLElBQUksT0FBTyxLQUFLO1FBQ25DO0lBQ0osTUFBTSxVQUFVLFdBQVc7SUFDM0IsSUFBSSxTQUFTO0tBQ1osSUFBSSxLQUFLLEtBQUssUUFBUSxLQUFLLEtBQUssSUFBSSxLQUFLLE1BQU0sQ0FBQztVQUMzQyxJQUFJLEtBQUssVUFBVSxLQUFLLEdBQUcsUUFBUSxXQUFXLEtBQUssS0FBSztJQUM5RDtHQUNEO0VBQ0Q7Q0FDRDtDQUNBLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLE1BQU0sY0FBYyxPQUFPLEtBQUssT0FBTztDQUN2QyxLQUFLLElBQUksSUFBSSxZQUFZLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztFQUNqRCxNQUFNLE1BQU0sWUFBWSxJQUFJLE9BQU8sUUFBUTtFQUMzQyxJQUFJLFFBQVEsS0FBSyxLQUFLLE9BQU8sZUFBZSxRQUFRLEtBQUssSUFBSTtPQUN4RCxPQUFPLE9BQU8sT0FBTyxLQUFLLFFBQVEsS0FBSztDQUM3QztDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsV0FBVyxPQUFPLEdBQUcsTUFBTTtDQUNuQyxNQUFNLE1BQU0sS0FBSztDQUNqQixJQUFJLGtCQUFrQixVQUFVLE9BQU87RUFDdEMsTUFBTSxVQUFVLE1BQU0sSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLO0VBQzdDLE1BQU0sTUFBTSxLQUFLLEtBQUssTUFBTTtHQUMzQixPQUFPLElBQUksTUFBTTtJQUNoQixJQUFJLFVBQVU7S0FDYixPQUFPLEVBQUUsU0FBUyxRQUFRLElBQUksTUFBTSxZQUFZLEtBQUs7SUFDdEQ7SUFDQSxJQUFJLFVBQVU7S0FDYixPQUFPLEVBQUUsU0FBUyxRQUFRLEtBQUssWUFBWTtJQUM1QztJQUNBLE9BQU87S0FDTixPQUFPLEVBQUUsUUFBUSxhQUFhLFlBQVksS0FBSztJQUNoRDtHQUNELEdBQUcsU0FBUztFQUNiLENBQUM7RUFDRCxJQUFJLEtBQUssSUFBSSxNQUFNO0dBQ2xCLElBQUksVUFBVTtJQUNiLE9BQU8sUUFBUSxTQUFTLFFBQVEsSUFBSSxLQUFLLElBQUksTUFBTTtHQUNwRDtHQUNBLElBQUksVUFBVTtJQUNiLE9BQU8sUUFBUSxTQUFTLFFBQVEsSUFBSSxRQUFRLFlBQVk7R0FDekQ7R0FDQSxPQUFPO0lBQ04sT0FBTyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsUUFBUSxNQUFNLENBQUMsUUFBUSxTQUFTLENBQUMsQ0FBQztHQUM3RDtFQUNELEdBQUcsU0FBUyxDQUFDO0VBQ2IsT0FBTztDQUNSO0NBQ0EsTUFBTSxVQUFVLENBQUM7Q0FDakIsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLEtBQUssS0FBSyxRQUFRLEtBQUssQ0FBQztDQUM3QyxLQUFLLE1BQU0sWUFBWSxPQUFPLG9CQUFvQixLQUFLLEdBQUc7RUFDekQsSUFBSSxXQUFXO0VBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLLElBQUksS0FBSyxFQUFFLENBQUMsU0FBUyxRQUFRLEdBQUc7R0FDckUsV0FBVztHQUNYO0VBQ0Q7RUFDQSxNQUFNLE9BQU8sT0FBTyx5QkFBeUIsT0FBTyxRQUFRO0VBQzVELENBQUMsS0FBSyxPQUFPLENBQUMsS0FBSyxPQUFPLEtBQUssY0FBYyxLQUFLLFlBQVksS0FBSyxlQUFlLFFBQVEsU0FBUyxDQUFDLFlBQVksS0FBSyxRQUFRLE9BQU8sZUFBZSxRQUFRLFdBQVcsVUFBVSxJQUFJO0NBQ3JMO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxLQUFLLElBQUk7Q0FDakIsSUFBSTtDQUNKLElBQUk7Q0FDSixNQUFNLFFBQVEsVUFBVTtFQUN2QixNQUFNLE1BQU0sYUFBYTtFQUN6QixJQUFJLEtBQUs7R0FDUixNQUFNLENBQUMsR0FBRyxPQUFPLGFBQWE7R0FDOUIsYUFBYSxVQUFVLGFBQWEsUUFBUTtHQUM1QyxhQUFhO0dBQ2IsQ0FBQyxNQUFNLElBQUksR0FBRyxHQUFBLENBQUksTUFBTSxRQUFRO0lBQy9CLENBQUMsYUFBYSxRQUFRLGtCQUFrQixHQUFHO0lBQzNDLGFBQWE7SUFDYixVQUFVLElBQUksT0FBTztJQUNyQixrQkFBa0I7R0FDbkIsQ0FBQztHQUNELE9BQU87RUFDUixPQUFPLElBQUksQ0FBQyxNQUFNO0dBQ2pCLE1BQU0sQ0FBQyxLQUFLLHNCQUFzQixNQUFNLElBQUksR0FBRyxHQUFBLENBQUksTUFBTSxRQUFRLElBQUksT0FBTyxDQUFDO0dBQzdFLE9BQU87RUFDUjtFQUNBLElBQUk7RUFDSixPQUFPLGtCQUFrQixPQUFPLEtBQUssS0FBSyxjQUFjO0dBQ3ZELElBQUksQ0FBQyxPQUFPLGFBQWEsTUFBTSxPQUFPLEtBQUssS0FBSztHQUNoRCxNQUFNLElBQUksYUFBYTtHQUN2QixrQkFBa0IsR0FBRztHQUNyQixNQUFNLElBQUksS0FBSyxLQUFLO0dBQ3BCLGtCQUFrQixDQUFDO0dBQ25CLE9BQU87RUFDUixDQUFDLElBQUksRUFBRTtDQUNSO0NBQ0EsS0FBSyxnQkFBZ0IsT0FBTyxJQUFJLEdBQUcsRUFBQSxDQUFHLE1BQU0sUUFBUSxhQUFhLElBQUksT0FBTyxHQUFHO0NBQy9FLE9BQU87QUFDUjtBQUNBLElBQUksVUFBVTtBQUNkLFNBQVMsaUJBQWlCO0NBQ3pCLE9BQU8sYUFBYSxVQUFVLGFBQWEsaUJBQWlCLElBQUksTUFBTTtBQUN2RTtBQUNBLElBQUksaUJBQWlCLFNBQVMsb0JBQW9CLEtBQUs7QUFDdkQsU0FBUyxJQUFJLE9BQU87Q0FDbkIsTUFBTSxXQUFXLGNBQWMsU0FBUyxFQUFFLGdCQUFnQixNQUFNLFNBQVM7Q0FDekUsT0FBTyxXQUFXLGVBQWUsTUFBTSxNQUFNLE1BQU0sVUFBVSxZQUFZLEtBQUssQ0FBQyxDQUFDO0FBQ2pGO0FBQ0EsU0FBUyxLQUFLLE9BQU87Q0FDcEIsTUFBTSxRQUFRLE1BQU07Q0FDcEIsTUFBTSxpQkFBaUIsaUJBQWlCLE1BQU0sTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDO0NBQ2xFLE1BQU0sWUFBWSxRQUFRLGlCQUFpQixXQUFXLGdCQUFnQixLQUFLLEdBQUcsRUFBRSxTQUFTLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7Q0FDN0csT0FBTyxpQkFBaUI7RUFDdkIsTUFBTSxJQUFJLFVBQVU7RUFDcEIsSUFBSSxHQUFHO0dBQ04sTUFBTSxRQUFRLE1BQU07R0FDcEIsT0FBTyxPQUFPLFVBQVUsY0FBYyxNQUFNLFNBQVMsSUFBSSxjQUFjLE1BQU0sUUFBUSxVQUFVO0lBQzlGLElBQUksQ0FBQyxRQUFRLFNBQVMsR0FBRyxNQUFNLGNBQWMsTUFBTTtJQUNuRCxPQUFPLGVBQWU7R0FDdkIsQ0FBQyxDQUFDLElBQUk7RUFDUDtFQUNBLE9BQU8sTUFBTTtDQUNkLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztBQUNsQjtBQUNBLFNBQVMsT0FBTyxPQUFPO0NBQ3RCLE1BQU0sTUFBTSxlQUFlLE1BQU0sUUFBUTtDQUN6QyxNQUFNLGFBQWEsaUJBQWlCO0VBQ25DLE1BQU0sS0FBSyxJQUFJO0VBQ2YsTUFBTSxNQUFNLE1BQU0sUUFBUSxFQUFFLElBQUksS0FBSyxDQUFDLEVBQUU7RUFDeEMsSUFBSSxhQUFhLEtBQUs7RUFDdEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0dBQ3BDLE1BQU0sUUFBUTtHQUNkLE1BQU0sS0FBSyxJQUFJO0dBQ2YsTUFBTSxXQUFXO0dBQ2pCLE1BQU0saUJBQWlCLGlCQUFpQixTQUFTLElBQUksS0FBSyxJQUFJLEdBQUcsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDO0dBQ3JGLE1BQU0sWUFBWSxHQUFHLFFBQVEsaUJBQWlCLFdBQVcsZ0JBQWdCLEtBQUssR0FBRyxFQUFFLFNBQVMsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztHQUNoSCxhQUFhLFNBQVMsTUFBTSxVQUFVLElBQUk7SUFDekM7SUFDQTtJQUNBO0dBQ0QsSUFBSSxLQUFLO0VBQ1Y7RUFDQSxPQUFPO0NBQ1IsQ0FBQztDQUNELE9BQU8saUJBQWlCO0VBQ3ZCLE1BQU0sTUFBTSxXQUFXLENBQUMsQ0FBQztFQUN6QixJQUFJLENBQUMsS0FBSyxPQUFPLE1BQU07RUFDdkIsTUFBTSxDQUFDLE9BQU8sZ0JBQWdCLE1BQU07RUFDcEMsTUFBTSxRQUFRLEdBQUc7RUFDakIsT0FBTyxPQUFPLFVBQVUsY0FBYyxNQUFNLFNBQVMsSUFBSSxjQUFjLE1BQU0sR0FBRyxRQUFRLGVBQWUsVUFBVTtHQUNoSCxJQUFJLFFBQVEsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sT0FBTyxNQUFNLGNBQWMsT0FBTztHQUNyRSxPQUFPLGVBQWU7RUFDdkIsQ0FBQyxDQUFDLElBQUk7Q0FDUCxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7QUFDbEI7QUFDQSxTQUFTLE1BQU0sT0FBTztDQUNyQixPQUFPO0FBQ1I7QUFHQSxJQUFJLDZCQUE2QixJQUFJLElBQUk7Q0FDeEM7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNEO0FBQ0QsQ0FBQztBQUNELElBQUksa0NBQWtDLElBQUksSUFBSTtDQUM3QztDQUNBO0NBQ0E7Q0FDQTtBQUNELENBQUM7QUFDRCxJQUFJLFVBQTBCLHVCQUFPLE9BQU8sT0FBTyxPQUFPLElBQUksR0FBRztDQUNoRSxXQUFXO0NBQ1gsU0FBUztBQUNWLENBQUM7QUFDRCxJQUFJLGNBQThCLHVCQUFPLE9BQU8sT0FBTyxPQUFPLElBQUksR0FBRztDQUNwRSxPQUFPO0NBQ1AsWUFBWTtFQUNYLEdBQUc7RUFDSCxNQUFNO0NBQ1A7Q0FDQSxnQkFBZ0I7RUFDZixHQUFHO0VBQ0gsUUFBUTtFQUNSLE9BQU87Q0FDUjtDQUNBLE9BQU87RUFDTixHQUFHO0VBQ0gsS0FBSztDQUNOO0NBQ0EsVUFBVTtFQUNULEdBQUc7RUFDSCxRQUFRO0NBQ1Q7Q0FDQSxhQUFhO0VBQ1osR0FBRztFQUNILE9BQU87Q0FDUjtDQUNBLFVBQVU7RUFDVCxHQUFHO0VBQ0gsT0FBTztFQUNQLFVBQVU7Q0FDWDtDQUNBLGtCQUFrQjtFQUNqQixHQUFHO0VBQ0gsUUFBUTtDQUNUO0NBQ0EsaUJBQWlCO0VBQ2hCLEdBQUc7RUFDSCxRQUFRO0NBQ1Q7Q0FDQSxnQkFBZ0I7RUFDZixHQUFHO0VBQ0gsS0FBSztDQUNOO0NBQ0EsZ0JBQWdCO0VBQ2YsR0FBRztFQUNILE9BQU87Q0FDUjtDQUNBLGNBQWM7RUFDYixHQUFHO0VBQ0gsT0FBTztFQUNQLE9BQU87Q0FDUjtDQUNBLGlCQUFpQjtFQUNoQixHQUFHO0VBQ0gsUUFBUTtDQUNUO0NBQ0EseUJBQXlCO0VBQ3hCLEdBQUc7RUFDSCxPQUFPO0NBQ1I7Q0FDQSx1QkFBdUI7RUFDdEIsR0FBRztFQUNILE9BQU87RUFDUCxPQUFPO0NBQ1I7Q0FDQSxnQkFBZ0I7RUFDZixHQUFHO0VBQ0gsT0FBTztFQUNQLE9BQU87Q0FDUjtDQUNBLG9CQUFvQjtFQUNuQixHQUFHO0VBQ0gsVUFBVTtDQUNYO0NBQ0EsMEJBQTBCO0VBQ3pCLEdBQUc7RUFDSCxVQUFVO0NBQ1g7Q0FDQSx3QkFBd0I7RUFDdkIsR0FBRztFQUNILFVBQVU7Q0FDWDtDQUNBLHVCQUF1QjtFQUN0QixHQUFHO0VBQ0gsUUFBUTtFQUNSLEtBQUs7Q0FDTjtBQUNELENBQUM7QUFDRCxTQUFTLGFBQWEsTUFBTSxTQUFTO0NBQ3BDLE1BQU0sSUFBSSxZQUFZO0NBQ3RCLE9BQU8sT0FBTyxNQUFNLFdBQVcsRUFBRSxXQUFXLEVBQUUsT0FBTyxLQUFLLElBQUk7QUFDL0Q7QUFDQSxJQUFJLGtDQUFrQyxJQUFJLElBQUk7Q0FDN0M7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRCxDQUFDO0FBQ0QsSUFBSSw4QkFBOEIsSUFBSSxJQUFJO0NBQ3pDO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRCxDQUFDO0FBQ0QsSUFBSSxlQUFlO0NBQ2xCLE9BQU87Q0FDUCxLQUFLO0FBQ047QUFDQSxJQUFJLFFBQVEsT0FBTyxpQkFBaUIsR0FBRyxDQUFDO0FBQ3hDLFNBQVMsZ0JBQWdCLFlBQVksR0FBRyxHQUFHO0NBQzFDLElBQUksVUFBVSxFQUFFLFFBQVEsT0FBTyxFQUFFLFFBQVEsT0FBTyxTQUFTLFNBQVMsR0FBRyxTQUFTLEdBQUcsUUFBUSxFQUFFLE9BQU8sRUFBRSxDQUFDLGFBQWEsTUFBTTtDQUN4SCxPQUFPLFNBQVMsUUFBUSxTQUFTLE1BQU07RUFDdEMsSUFBSSxFQUFFLFlBQVksRUFBRSxTQUFTO0dBQzVCO0dBQ0E7R0FDQTtFQUNEO0VBQ0EsT0FBTyxFQUFFLE9BQU8sT0FBTyxFQUFFLE9BQU8sSUFBSTtHQUNuQztHQUNBO0VBQ0Q7RUFDQSxJQUFJLFNBQVMsUUFBUTtHQUNwQixNQUFNLE9BQU8sT0FBTyxVQUFVLFNBQVMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxjQUFjLEVBQUUsT0FBTyxVQUFVO0dBQ3RGLE9BQU8sU0FBUyxNQUFNLFdBQVcsYUFBYSxFQUFFLFdBQVcsSUFBSTtFQUNoRSxPQUFPLElBQUksU0FBUyxRQUFRLE9BQU8sU0FBUyxNQUFNO0dBQ2pELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLEVBQUUsT0FBTyxHQUFHLEVBQUUsT0FBTyxDQUFDLE9BQU87R0FDbEQ7RUFDRDtPQUNLLElBQUksRUFBRSxZQUFZLEVBQUUsT0FBTyxNQUFNLEVBQUUsWUFBWSxFQUFFLE9BQU8sSUFBSTtHQUNoRSxNQUFNLE9BQU8sRUFBRSxFQUFFLEtBQUssQ0FBQztHQUN2QixXQUFXLGFBQWEsRUFBRSxXQUFXLEVBQUUsU0FBUyxDQUFDLFdBQVc7R0FDNUQsV0FBVyxhQUFhLEVBQUUsRUFBRSxPQUFPLElBQUk7R0FDdkMsRUFBRSxRQUFRLEVBQUU7RUFDYixPQUFPO0dBQ04sSUFBSSxDQUFDLEtBQUs7SUFDVCxzQkFBc0IsSUFBSSxJQUFJO0lBQzlCLElBQUksSUFBSTtJQUNSLE9BQU8sSUFBSSxNQUFNLElBQUksSUFBSSxFQUFFLElBQUksR0FBRztHQUNuQztHQUNBLE1BQU0sUUFBUSxJQUFJLElBQUksRUFBRSxPQUFPO0dBQy9CLElBQUksU0FBUyxNQUFNLElBQUksU0FBUyxTQUFTLFFBQVEsTUFBTTtJQUN0RCxJQUFJLElBQUksUUFBUSxXQUFXLEdBQUc7SUFDOUIsT0FBTyxFQUFFLElBQUksUUFBUSxJQUFJLE1BQU07S0FDOUIsS0FBSyxJQUFJLElBQUksSUFBSSxFQUFFLEVBQUUsTUFBTSxRQUFRLE1BQU0sUUFBUSxVQUFVO0tBQzNEO0lBQ0Q7SUFDQSxJQUFJLFdBQVcsUUFBUSxRQUFRO0tBQzlCLE1BQU0sT0FBTyxFQUFFO0tBQ2YsT0FBTyxTQUFTLE9BQU8sV0FBVyxhQUFhLEVBQUUsV0FBVyxJQUFJO0lBQ2pFLE9BQU8sV0FBVyxhQUFhLEVBQUUsV0FBVyxFQUFFLFNBQVM7R0FDeEQsT0FBTztRQUNGLEVBQUUsU0FBUyxDQUFDLE9BQU87RUFDekI7Q0FDRDtBQUNEO0FBQ0EsSUFBSSxXQUFXO0FBQ2YsU0FBUyxPQUFPLE1BQU0sU0FBUyxNQUFNLFVBQVUsQ0FBQyxHQUFHO0NBQ2xELElBQUk7Q0FDSixZQUFZLFlBQVk7RUFDdkIsV0FBVztFQUNYLFlBQVksV0FBVyxLQUFLLElBQUksT0FBTyxTQUFTLEtBQUssR0FBRyxRQUFRLGFBQWEsT0FBTyxLQUFLLEdBQUcsSUFBSTtDQUNqRyxHQUFHLFFBQVEsS0FBSztDQUNoQixhQUFhO0VBQ1osU0FBUztFQUNULFFBQVEsY0FBYztDQUN2QjtBQUNEO0FBQ0EsU0FBUyxTQUFTLE1BQU0sY0FBYyxPQUFPLFVBQVU7Q0FDdEQsSUFBSTtDQUNKLE1BQU0sZUFBZTtFQUNwQixNQUFNLElBQUksV0FBVyxTQUFTLGdCQUFnQixzQ0FBc0MsVUFBVSxJQUFJLFNBQVMsY0FBYyxVQUFVO0VBQ25JLEVBQUUsWUFBWTtFQUNkLE9BQU8sUUFBUSxFQUFFLFFBQVEsV0FBVyxhQUFhLFdBQVcsRUFBRSxhQUFhLEVBQUUsUUFBUTtDQUN0RjtDQUNBLE1BQU0sS0FBSyxxQkFBcUIsY0FBYyxTQUFTLFdBQVcsU0FBUyxPQUFPLE9BQU8sSUFBSSxJQUFJLENBQUMsV0FBVyxTQUFTLE9BQU8sT0FBTyxHQUFBLENBQUksVUFBVSxJQUFJO0NBQ3RKLEdBQUcsWUFBWTtDQUNmLE9BQU87QUFDUjtBQUNBLFNBQVMsZUFBZSxZQUFZLFdBQVcsT0FBTyxVQUFVO0NBQy9ELE1BQU0sSUFBSSxTQUFTLGNBQWMsU0FBUyw0QkFBNEIsSUFBSSxJQUFJO0NBQzlFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsSUFBSSxHQUFHLEtBQUs7RUFDbEQsTUFBTSxPQUFPLFdBQVc7RUFDeEIsSUFBSSxDQUFDLEVBQUUsSUFBSSxJQUFJLEdBQUc7R0FDakIsRUFBRSxJQUFJLElBQUk7R0FDVixTQUFTLGlCQUFpQixNQUFNLFlBQVk7RUFDN0M7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxhQUFhLE1BQU0sTUFBTSxPQUFPO0NBQ3hDLElBQUksWUFBWSxJQUFJLEdBQUc7Q0FDdkIsSUFBSSxTQUFTLE1BQU0sS0FBSyxnQkFBZ0IsSUFBSTtNQUN2QyxLQUFLLGFBQWEsTUFBTSxLQUFLO0FBQ25DO0FBQ0EsU0FBUyxlQUFlLE1BQU0sV0FBVyxNQUFNLE9BQU87Q0FDckQsSUFBSSxZQUFZLElBQUksR0FBRztDQUN2QixJQUFJLFNBQVMsTUFBTSxLQUFLLGtCQUFrQixXQUFXLElBQUk7TUFDcEQsS0FBSyxlQUFlLFdBQVcsTUFBTSxLQUFLO0FBQ2hEO0FBQ0EsU0FBUyxpQkFBaUIsTUFBTSxNQUFNLE9BQU87Q0FDNUMsSUFBSSxZQUFZLElBQUksR0FBRztDQUN2QixRQUFRLEtBQUssYUFBYSxNQUFNLEVBQUUsSUFBSSxLQUFLLGdCQUFnQixJQUFJO0FBQ2hFO0FBQ0EsU0FBUyxVQUFVLE1BQU0sT0FBTztDQUMvQixJQUFJLFlBQVksSUFBSSxHQUFHO0NBQ3ZCLElBQUksU0FBUyxNQUFNLEtBQUssZ0JBQWdCLE9BQU87TUFDMUMsS0FBSyxZQUFZO0FBQ3ZCO0FBQ0EsU0FBUyxpQkFBaUIsTUFBTSxNQUFNLFNBQVMsVUFBVTtDQUN4RCxJQUFJLFVBQVUsSUFBSSxNQUFNLFFBQVEsT0FBTyxHQUFHO0VBQ3pDLEtBQUssS0FBSyxVQUFVLFFBQVE7RUFDNUIsS0FBSyxLQUFLLEtBQUssU0FBUyxRQUFRO0NBQ2pDLE9BQU8sS0FBSyxLQUFLLFVBQVU7TUFDdEIsSUFBSSxNQUFNLFFBQVEsT0FBTyxHQUFHO0VBQ2hDLE1BQU0sWUFBWSxRQUFRO0VBQzFCLEtBQUssaUJBQWlCLE1BQU0sUUFBUSxNQUFNLE1BQU0sVUFBVSxLQUFLLE1BQU0sUUFBUSxJQUFJLENBQUMsQ0FBQztDQUNwRixPQUFPLEtBQUssaUJBQWlCLE1BQU0sU0FBUyxPQUFPLFlBQVksY0FBYyxPQUFPO0FBQ3JGO0FBQ0EsU0FBUyxVQUFVLE1BQU0sT0FBTyxPQUFPLENBQUMsR0FBRztDQUMxQyxNQUFNLFlBQVksT0FBTyxLQUFLLFNBQVMsQ0FBQyxDQUFDLEdBQUcsV0FBVyxPQUFPLEtBQUssSUFBSTtDQUN2RSxJQUFJLEdBQUc7Q0FDUCxLQUFLLElBQUksR0FBRyxNQUFNLFNBQVMsUUFBUSxJQUFJLEtBQUssS0FBSztFQUNoRCxNQUFNLE1BQU0sU0FBUztFQUNyQixJQUFJLENBQUMsT0FBTyxRQUFRLGVBQWUsTUFBTSxNQUFNO0VBQy9DLGVBQWUsTUFBTSxLQUFLLEtBQUs7RUFDL0IsT0FBTyxLQUFLO0NBQ2I7Q0FDQSxLQUFLLElBQUksR0FBRyxNQUFNLFVBQVUsUUFBUSxJQUFJLEtBQUssS0FBSztFQUNqRCxNQUFNLE1BQU0sVUFBVSxJQUFJLGFBQWEsQ0FBQyxDQUFDLE1BQU07RUFDL0MsSUFBSSxDQUFDLE9BQU8sUUFBUSxlQUFlLEtBQUssU0FBUyxjQUFjLENBQUMsWUFBWTtFQUM1RSxlQUFlLE1BQU0sS0FBSyxJQUFJO0VBQzlCLEtBQUssT0FBTztDQUNiO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxNQUFNLE1BQU0sT0FBTyxNQUFNO0NBQ2pDLElBQUksQ0FBQyxPQUFPLE9BQU8sT0FBTyxhQUFhLE1BQU0sT0FBTyxJQUFJO0NBQ3hELE1BQU0sWUFBWSxLQUFLO0NBQ3ZCLElBQUksT0FBTyxVQUFVLFVBQVUsT0FBTyxVQUFVLFVBQVU7Q0FDMUQsT0FBTyxTQUFTLGFBQWEsVUFBVSxVQUFVLE9BQU8sS0FBSztDQUM3RCxTQUFTLE9BQU8sQ0FBQztDQUNqQixVQUFVLFFBQVEsQ0FBQztDQUNuQixJQUFJLEdBQUc7Q0FDUCxLQUFLLEtBQUssTUFBTTtFQUNmLE1BQU0sTUFBTSxVQUFVLGVBQWUsQ0FBQztFQUN0QyxPQUFPLEtBQUs7Q0FDYjtDQUNBLEtBQUssS0FBSyxPQUFPO0VBQ2hCLElBQUksTUFBTTtFQUNWLElBQUksTUFBTSxLQUFLLElBQUk7R0FDbEIsVUFBVSxZQUFZLEdBQUcsQ0FBQztHQUMxQixLQUFLLEtBQUs7RUFDWDtDQUNEO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxPQUFPLE1BQU0sUUFBUSxDQUFDLEdBQUcsT0FBTyxjQUFjO0NBQ3RELE1BQU0sWUFBWSxDQUFDO0NBQ25CLElBQUksQ0FBQyxjQUFjLHlCQUF5QixVQUFVLFdBQVcsaUJBQWlCLE1BQU0sTUFBTSxVQUFVLFVBQVUsUUFBUSxDQUFDO0NBQzNILHlCQUF5QixPQUFPLE1BQU0sUUFBUSxjQUFjLElBQUksTUFBTSxLQUFLLElBQUksQ0FBQztDQUNoRix5QkFBeUIsT0FBTyxNQUFNLE9BQU8sT0FBTyxNQUFNLFdBQVcsSUFBSSxDQUFDO0NBQzFFLE9BQU87QUFDUjtBQUNBLFNBQVMsSUFBSSxJQUFJLFNBQVMsS0FBSztDQUM5QixPQUFPLGNBQWMsR0FBRyxTQUFTLEdBQUcsQ0FBQztBQUN0QztBQUNBLFNBQVMsT0FBTyxRQUFRLFVBQVUsUUFBUSxTQUFTO0NBQ2xELElBQUksV0FBVyxLQUFLLEtBQUssQ0FBQyxTQUFTLFVBQVUsQ0FBQztDQUM5QyxJQUFJLE9BQU8sYUFBYSxZQUFZLE9BQU8saUJBQWlCLFFBQVEsVUFBVSxTQUFTLE1BQU07Q0FDN0Ysb0JBQW9CLFlBQVksaUJBQWlCLFFBQVEsU0FBUyxHQUFHLFNBQVMsTUFBTSxHQUFHLE9BQU87QUFDL0Y7QUFDQSxTQUFTLE9BQU8sTUFBTSxPQUFPLE9BQU8sY0FBYyxZQUFZLENBQUMsR0FBRyxVQUFVLE9BQU87Q0FDbEYsVUFBVSxRQUFRLENBQUM7Q0FDbkIsS0FBSyxNQUFNLFFBQVEsV0FBVyxJQUFJLEVBQUUsUUFBUSxRQUFRO0VBQ25ELElBQUksU0FBUyxZQUFZO0VBQ3pCLFVBQVUsUUFBUSxXQUFXLE1BQU0sTUFBTSxNQUFNLFVBQVUsT0FBTyxPQUFPLFNBQVMsS0FBSztDQUN0RjtDQUNBLEtBQUssTUFBTSxRQUFRLE9BQU87RUFDekIsSUFBSSxTQUFTLFlBQVk7R0FDeEIsSUFBSSxDQUFDLGNBQWMsaUJBQWlCLE1BQU0sTUFBTSxRQUFRO0dBQ3hEO0VBQ0Q7RUFDQSxNQUFNLFFBQVEsTUFBTTtFQUNwQixVQUFVLFFBQVEsV0FBVyxNQUFNLE1BQU0sT0FBTyxVQUFVLE9BQU8sT0FBTyxTQUFTLEtBQUs7Q0FDdkY7QUFDRDtBQUNBLFNBQVMsZUFBZSxVQUFVO0NBQ2pDLElBQUksTUFBTTtDQUNWLElBQUksQ0FBQyxZQUFZLEtBQUssRUFBRSxPQUFPLGFBQWEsU0FBUyxJQUFJLE1BQU0sZ0JBQWdCLENBQUMsSUFBSSxPQUFPLFNBQVM7Q0FDcEcsSUFBSSxhQUFhLFdBQVcsYUFBYSxVQUFVLElBQUksSUFBSTtDQUMzRCxhQUFhLFNBQVMsT0FBTyxHQUFHO0NBQ2hDLE9BQU87QUFDUjtBQUNBLFNBQVMsWUFBWSxNQUFNO0NBQzFCLE9BQU8sQ0FBQyxDQUFDLGFBQWEsV0FBVyxDQUFDLGFBQWEsU0FBUyxDQUFDLFFBQVEsS0FBSztBQUN2RTtBQUNBLFNBQVMsZUFBZSxNQUFNO0NBQzdCLE9BQU8sS0FBSyxZQUFZLENBQUMsQ0FBQyxRQUFRLGNBQWMsR0FBRyxNQUFNLEVBQUUsWUFBWSxDQUFDO0FBQ3pFO0FBQ0EsU0FBUyxlQUFlLE1BQU0sS0FBSyxPQUFPO0NBQ3pDLE1BQU0sYUFBYSxJQUFJLEtBQUssQ0FBQyxDQUFDLE1BQU0sS0FBSztDQUN6QyxLQUFLLElBQUksSUFBSSxHQUFHLFVBQVUsV0FBVyxRQUFRLElBQUksU0FBUyxLQUFLLEtBQUssVUFBVSxPQUFPLFdBQVcsSUFBSSxLQUFLO0FBQzFHO0FBQ0EsU0FBUyxXQUFXLE1BQU0sTUFBTSxPQUFPLE1BQU0sT0FBTyxTQUFTLE9BQU87Q0FDbkUsSUFBSSxNQUFNLFFBQVEsYUFBYSxXQUFXO0NBQzFDLElBQUksU0FBUyxTQUFTLE9BQU8sTUFBTSxNQUFNLE9BQU8sSUFBSTtDQUNwRCxJQUFJLFNBQVMsYUFBYSxPQUFPLFVBQVUsTUFBTSxPQUFPLElBQUk7Q0FDNUQsSUFBSSxVQUFVLE1BQU0sT0FBTztDQUMzQixJQUFJLFNBQVMsT0FDUjtNQUFBLENBQUMsU0FBUyxNQUFNLElBQUk7Q0FBQSxPQUNsQixJQUFJLEtBQUssTUFBTSxHQUFHLENBQUMsTUFBTSxPQUFPO0VBQ3RDLE1BQU0sSUFBSSxLQUFLLE1BQU0sQ0FBQztFQUN0QixRQUFRLEtBQUssb0JBQW9CLEdBQUcsTUFBTSxPQUFPLFNBQVMsY0FBYyxJQUFJO0VBQzVFLFNBQVMsS0FBSyxpQkFBaUIsR0FBRyxPQUFPLE9BQU8sVUFBVSxjQUFjLEtBQUs7Q0FDOUUsT0FBTyxJQUFJLEtBQUssTUFBTSxHQUFHLEVBQUUsTUFBTSxjQUFjO0VBQzlDLE1BQU0sSUFBSSxLQUFLLE1BQU0sRUFBRTtFQUN2QixRQUFRLEtBQUssb0JBQW9CLEdBQUcsTUFBTSxJQUFJO0VBQzlDLFNBQVMsS0FBSyxpQkFBaUIsR0FBRyxPQUFPLElBQUk7Q0FDOUMsT0FBTyxJQUFJLEtBQUssTUFBTSxHQUFHLENBQUMsTUFBTSxNQUFNO0VBQ3JDLE1BQU0sT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsWUFBWTtFQUN2QyxNQUFNLFdBQVcsZ0JBQWdCLElBQUksSUFBSTtFQUN6QyxJQUFJLENBQUMsWUFBWSxNQUFNO0dBQ3RCLE1BQU0sSUFBSSxNQUFNLFFBQVEsSUFBSSxJQUFJLEtBQUssS0FBSztHQUMxQyxLQUFLLG9CQUFvQixNQUFNLENBQUM7RUFDakM7RUFDQSxJQUFJLFlBQVksT0FBTztHQUN0QixpQkFBaUIsTUFBTSxNQUFNLE9BQU8sUUFBUTtHQUM1QyxZQUFZLGVBQWUsQ0FBQyxJQUFJLENBQUM7RUFDbEM7Q0FDRCxPQUFPLElBQUksS0FBSyxNQUFNLEdBQUcsQ0FBQyxNQUFNLFNBQVMsYUFBYSxNQUFNLEtBQUssTUFBTSxDQUFDLEdBQUcsS0FBSztNQUMzRSxJQUFJLEtBQUssTUFBTSxHQUFHLENBQUMsTUFBTSxTQUFTLGlCQUFpQixNQUFNLEtBQUssTUFBTSxDQUFDLEdBQUcsS0FBSztNQUM3RSxLQUFLLFlBQVksS0FBSyxNQUFNLEdBQUcsQ0FBQyxNQUFNLGFBQWEsY0FBYyxnQkFBZ0IsSUFBSSxJQUFJLE1BQU0sQ0FBQyxXQUFXLFlBQVksYUFBYSxNQUFNLEtBQUssT0FBTyxPQUFPLFNBQVMsV0FBVyxJQUFJLElBQUksUUFBUSxPQUFPLEtBQUssU0FBUyxTQUFTLEdBQUcsS0FBSyxRQUFRLFFBQVE7RUFDM1AsSUFBSSxXQUFXO0dBQ2QsT0FBTyxLQUFLLE1BQU0sQ0FBQztHQUNuQixTQUFTO0VBQ1YsT0FBTyxJQUFJLFlBQVksSUFBSSxHQUFHLE9BQU87RUFDckMsSUFBSSxTQUFTLFdBQVcsU0FBUyxhQUFhLFVBQVUsTUFBTSxLQUFLO09BQzlELElBQUksUUFBUSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEtBQUssZUFBZSxJQUFJLEtBQUs7T0FDbEUsS0FBSyxhQUFhLFFBQVE7Q0FDaEMsT0FBTztFQUNOLE1BQU0sS0FBSyxTQUFTLEtBQUssUUFBUSxHQUFHLElBQUksTUFBTSxhQUFhLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQztFQUMzRSxJQUFJLElBQUksZUFBZSxNQUFNLElBQUksTUFBTSxLQUFLO09BQ3ZDLGFBQWEsTUFBTSxRQUFRLFNBQVMsTUFBTSxLQUFLO0NBQ3JEO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxhQUFhLEdBQUc7Q0FDeEIsSUFBSSxhQUFhLFlBQVksYUFBYSxRQUNyQztNQUFBLGFBQWEsT0FBTyxNQUFNLENBQUMsSUFBSSxRQUFRLE9BQU8sQ0FBQyxHQUFHO0NBQUE7Q0FFdkQsSUFBSSxPQUFPLEVBQUU7Q0FDYixNQUFNLE1BQU0sS0FBSyxFQUFFO0NBQ25CLE1BQU0sWUFBWSxFQUFFO0NBQ3BCLE1BQU0sbUJBQW1CLEVBQUU7Q0FDM0IsTUFBTSxZQUFZLFVBQVUsT0FBTyxlQUFlLEdBQUcsVUFBVTtFQUM5RCxjQUFjO0VBQ2Q7Q0FDRCxDQUFDO0NBQ0QsTUFBTSxtQkFBbUI7RUFDeEIsTUFBTSxVQUFVLEtBQUs7RUFDckIsSUFBSSxXQUFXLENBQUMsS0FBSyxVQUFVO0dBQzlCLE1BQU0sT0FBTyxLQUFLLEdBQUcsSUFBSTtHQUN6QixTQUFTLEtBQUssSUFBSSxRQUFRLEtBQUssTUFBTSxNQUFNLENBQUMsSUFBSSxRQUFRLEtBQUssTUFBTSxDQUFDO0dBQ3BFLElBQUksRUFBRSxjQUFjO0VBQ3JCO0VBQ0EsS0FBSyxRQUFRLE9BQU8sS0FBSyxTQUFTLFlBQVksQ0FBQyxLQUFLLEtBQUssVUFBVSxLQUFLLFNBQVMsRUFBRSxNQUFNLEtBQUssU0FBUyxLQUFLLElBQUk7RUFDaEgsT0FBTztDQUNSO0NBQ0EsTUFBTSxtQkFBbUI7RUFDeEIsT0FBTyxXQUFXLE1BQU0sT0FBTyxLQUFLLFVBQVUsS0FBSyxjQUFjLEtBQUs7Q0FDdkU7Q0FDQSxPQUFPLGVBQWUsR0FBRyxpQkFBaUI7RUFDekMsY0FBYztFQUNkLE1BQU07R0FDTCxPQUFPLFFBQVE7RUFDaEI7Q0FDRCxDQUFDO0NBQ0QsSUFBSSxhQUFhLFlBQVksQ0FBQyxhQUFhLE1BQU0sYUFBYSxPQUFPLEtBQUssT0FBTztDQUNqRixJQUFJLEVBQUUsY0FBYztFQUNuQixNQUFNLE9BQU8sRUFBRSxhQUFhO0VBQzVCLFNBQVMsS0FBSyxFQUFFO0VBQ2hCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFNBQVMsR0FBRyxLQUFLO0dBQ3pDLE9BQU8sS0FBSztHQUNaLElBQUksQ0FBQyxXQUFXLEdBQUc7R0FDbkIsSUFBSSxLQUFLLFFBQVE7SUFDaEIsT0FBTyxLQUFLO0lBQ1osV0FBVztJQUNYO0dBQ0Q7R0FDQSxJQUFJLEtBQUssZUFBZSxrQkFBa0I7RUFDM0M7Q0FDRCxPQUFPLFdBQVc7Q0FDbEIsU0FBUyxTQUFTO0FBQ25CO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUSxPQUFPLFNBQVMsUUFBUSxhQUFhO0NBQ3RFLE1BQU0sWUFBWSxZQUFZLE1BQU07Q0FDcEMsSUFBSSxXQUFXO0VBQ2QsQ0FBQyxZQUFZLFVBQVUsQ0FBQyxHQUFHLE9BQU8sVUFBVTtFQUM1QyxJQUFJLFVBQVUsQ0FBQztFQUNmLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSztHQUN4QyxNQUFNLE9BQU8sUUFBUTtHQUNyQixJQUFJLEtBQUssYUFBYSxLQUFLLEtBQUssS0FBSyxNQUFNLEdBQUcsQ0FBQyxNQUFNLE1BQU0sS0FBSyxPQUFPO1FBQ2xFLFFBQVEsS0FBSyxJQUFJO0VBQ3ZCO0VBQ0EsVUFBVTtDQUNYO0NBQ0EsT0FBTyxPQUFPLFlBQVksWUFBWSxVQUFVLFFBQVE7Q0FDeEQsSUFBSSxVQUFVLFNBQVMsT0FBTztDQUM5QixNQUFNLElBQUksT0FBTyxPQUFPLFFBQVEsV0FBVyxLQUFLO0NBQ2hELFNBQVMsU0FBUyxRQUFRLE1BQU0sUUFBUSxFQUFFLENBQUMsY0FBYztDQUN6RCxJQUFJLE1BQU0sWUFBWSxNQUFNLFVBQVU7RUFDckMsSUFBSSxXQUFXLE9BQU87RUFDdEIsSUFBSSxNQUFNLFVBQVU7R0FDbkIsUUFBUSxNQUFNLFNBQVM7R0FDdkIsSUFBSSxVQUFVLFNBQVMsT0FBTztFQUMvQjtFQUNBLElBQUksT0FBTztHQUNWLElBQUksT0FBTyxRQUFRO0dBQ25CLElBQUksUUFBUSxLQUFLLGFBQWEsR0FBRyxLQUFLLFNBQVMsVUFBVSxLQUFLLE9BQU87UUFDaEUsT0FBTyxTQUFTLGVBQWUsS0FBSztHQUN6QyxVQUFVLGNBQWMsUUFBUSxTQUFTLFFBQVEsSUFBSTtFQUN0RCxPQUFPLElBQUksWUFBWSxNQUFNLE9BQU8sWUFBWSxVQUFVLFVBQVUsT0FBTyxXQUFXLE9BQU87T0FDeEYsVUFBVSxPQUFPLGNBQWM7Q0FDckMsT0FBTyxJQUFJLFNBQVMsUUFBUSxNQUFNLFdBQVc7RUFDNUMsSUFBSSxXQUFXLE9BQU87RUFDdEIsVUFBVSxjQUFjLFFBQVEsU0FBUyxNQUFNO0NBQ2hELE9BQU8sSUFBSSxNQUFNLFlBQVk7RUFDNUIseUJBQXlCO0dBQ3hCLElBQUksSUFBSSxNQUFNO0dBQ2QsT0FBTyxPQUFPLE1BQU0sWUFBWSxJQUFJLEVBQUU7R0FDdEMsVUFBVSxpQkFBaUIsUUFBUSxHQUFHLFNBQVMsTUFBTTtFQUN0RCxDQUFDO0VBQ0QsYUFBYTtDQUNkLE9BQU8sSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHO0VBQ2hDLE1BQU0sUUFBUSxDQUFDO0VBQ2YsTUFBTSxlQUFlLFdBQVcsTUFBTSxRQUFRLE9BQU87RUFDckQsSUFBSSx1QkFBdUIsT0FBTyxPQUFPLFNBQVMsV0FBVyxHQUFHO0dBQy9ELHlCQUF5QixVQUFVLGlCQUFpQixRQUFRLE9BQU8sU0FBUyxRQUFRLElBQUksQ0FBQztHQUN6RixhQUFhO0VBQ2Q7RUFDQSxJQUFJLFdBQVc7R0FDZCxJQUFJLENBQUMsTUFBTSxRQUFRLE9BQU87R0FDMUIsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPLFVBQVUsQ0FBQyxHQUFHLE9BQU8sVUFBVTtHQUM3RCxJQUFJLE9BQU8sTUFBTTtHQUNqQixJQUFJLEtBQUssZUFBZSxRQUFRLE9BQU87R0FDdkMsTUFBTSxRQUFRLENBQUMsSUFBSTtHQUNuQixRQUFRLE9BQU8sS0FBSyxpQkFBaUIsUUFBUSxNQUFNLEtBQUssSUFBSTtHQUM1RCxPQUFPLFVBQVU7RUFDbEI7RUFDQSxJQUFJLE1BQU0sV0FBVyxHQUFHO0dBQ3ZCLFVBQVUsY0FBYyxRQUFRLFNBQVMsTUFBTTtHQUMvQyxJQUFJLE9BQU8sT0FBTztFQUNuQixPQUFPLElBQUksY0FBYyxJQUFJLFFBQVEsV0FBVyxHQUFHLFlBQVksUUFBUSxPQUFPLE1BQU07T0FDL0UsZ0JBQWdCLFFBQVEsU0FBUyxLQUFLO09BQ3RDO0dBQ0osV0FBVyxjQUFjLE1BQU07R0FDL0IsWUFBWSxRQUFRLEtBQUs7RUFDMUI7RUFDQSxVQUFVO0NBQ1gsT0FBTyxJQUFJLE1BQU0sVUFBVTtFQUMxQixJQUFJLGFBQWEsTUFBTSxZQUFZLE9BQU8sVUFBVSxRQUFRLENBQUMsS0FBSyxJQUFJO0VBQ3RFLElBQUksTUFBTSxRQUFRLE9BQU8sR0FBRztHQUMzQixJQUFJLE9BQU8sT0FBTyxVQUFVLGNBQWMsUUFBUSxTQUFTLFFBQVEsS0FBSztHQUN4RSxjQUFjLFFBQVEsU0FBUyxNQUFNLEtBQUs7RUFDM0MsT0FBTyxJQUFJLFdBQVcsUUFBUSxZQUFZLE1BQU0sQ0FBQyxPQUFPLFlBQVksT0FBTyxZQUFZLEtBQUs7T0FDdkYsT0FBTyxhQUFhLE9BQU8sT0FBTyxVQUFVO0VBQ2pELFVBQVU7Q0FDWDtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsdUJBQXVCLFlBQVksT0FBTyxTQUFTLFFBQVE7Q0FDbkUsSUFBSSxVQUFVO0NBQ2QsS0FBSyxJQUFJLElBQUksR0FBRyxNQUFNLE1BQU0sUUFBUSxJQUFJLEtBQUssS0FBSztFQUNqRCxJQUFJLE9BQU8sTUFBTSxJQUFJLE9BQU8sV0FBVyxRQUFRLFdBQVcsU0FBUztFQUNuRSxJQUFJLFFBQVEsUUFBUSxTQUFTLFFBQVEsU0FBUztPQUN6QyxLQUFLLElBQUksT0FBTyxVQUFVLFlBQVksS0FBSyxVQUFVLFdBQVcsS0FBSyxJQUFJO09BQ3pFLElBQUksTUFBTSxRQUFRLElBQUksR0FBRyxVQUFVLHVCQUF1QixZQUFZLE1BQU0sSUFBSSxLQUFLO09BQ3JGLElBQUksTUFBTSxZQUFZLElBQUksUUFBUTtHQUN0QyxPQUFPLE9BQU8sU0FBUyxZQUFZLE9BQU8sS0FBSztHQUMvQyxVQUFVLHVCQUF1QixZQUFZLE1BQU0sUUFBUSxJQUFJLElBQUksT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLFFBQVEsSUFBSSxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSztFQUMzSCxPQUFPO0dBQ04sV0FBVyxLQUFLLElBQUk7R0FDcEIsVUFBVTtFQUNYO09BQ0s7R0FDSixNQUFNLFFBQVEsT0FBTyxJQUFJO0dBQ3pCLElBQUksUUFBUSxLQUFLLGFBQWEsS0FBSyxLQUFLLFNBQVMsT0FBTyxXQUFXLEtBQUssSUFBSTtRQUN2RSxXQUFXLEtBQUssU0FBUyxlQUFlLEtBQUssQ0FBQztFQUNwRDtDQUNEO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxZQUFZLFFBQVEsT0FBTyxTQUFTLE1BQU07Q0FDbEQsS0FBSyxJQUFJLElBQUksR0FBRyxNQUFNLE1BQU0sUUFBUSxJQUFJLEtBQUssS0FBSyxPQUFPLGFBQWEsTUFBTSxJQUFJLE1BQU07QUFDdkY7QUFDQSxTQUFTLGNBQWMsUUFBUSxTQUFTLFFBQVEsYUFBYTtDQUM1RCxJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU8sT0FBTyxjQUFjO0NBQ25ELE1BQU0sT0FBTyxlQUFlLFNBQVMsZUFBZSxFQUFFO0NBQ3RELElBQUksUUFBUSxRQUFRO0VBQ25CLElBQUksV0FBVztFQUNmLEtBQUssSUFBSSxJQUFJLFFBQVEsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQzdDLE1BQU0sS0FBSyxRQUFRO0dBQ25CLElBQUksU0FBUyxJQUFJO0lBQ2hCLE1BQU0sV0FBVyxHQUFHLGVBQWU7SUFDbkMsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLFdBQVcsT0FBTyxhQUFhLE1BQU0sRUFBRSxJQUFJLE9BQU8sYUFBYSxNQUFNLE1BQU07U0FDM0YsWUFBWSxHQUFHLE9BQU87R0FDNUIsT0FBTyxXQUFXO0VBQ25CO0NBQ0QsT0FBTyxPQUFPLGFBQWEsTUFBTSxNQUFNO0NBQ3ZDLE9BQU8sQ0FBQyxJQUFJO0FBQ2I7QUFDQSxTQUFTLGtCQUFrQjtDQUMxQixPQUFPLGFBQWEsaUJBQWlCO0FBQ3RDO0FBQ0EsSUFBSSxnQkFBZ0I7QUFDcEIsU0FBUyxjQUFjLFNBQVMsUUFBUSxPQUFPLEtBQUssS0FBSyxHQUFHO0NBQzNELE9BQU8sUUFBUSxTQUFTLGdCQUFnQixlQUFlLE9BQU8sSUFBSSxTQUFTLGNBQWMsU0FBUyxFQUFFLEdBQUcsQ0FBQztBQUN6RztBQUNBLFNBQVMsY0FBYyxXQUFXLE9BQU87Q0FDeEMsTUFBTSxTQUFTLFdBQVcsU0FBUztDQUNuQyxPQUFPLGlCQUFpQjtFQUN2QixNQUFNLFlBQVksT0FBTztFQUN6QixRQUFRLE9BQU8sV0FBZjtHQUNDLEtBQUssWUFBWSxPQUFPLGNBQWMsVUFBVSxLQUFLLENBQUM7R0FDdEQsS0FBSztJQUNKLE1BQU0sUUFBUSxZQUFZLElBQUksU0FBUztJQUN2QyxNQUFNLEtBQUssYUFBYSxVQUFVLGVBQWUsSUFBSSxjQUFjLFdBQVcsT0FBTyxjQUFjLE1BQU0sRUFBRSxDQUFDO0lBQzVHLE9BQU8sSUFBSSxPQUFPLEtBQUs7SUFDdkIsT0FBTztFQUNUO0NBQ0QsQ0FBQztBQUNGO0FBQ0EsU0FBUyxRQUFRLE9BQU87Q0FDdkIsTUFBTSxHQUFHLFVBQVUsV0FBVyxPQUFPLENBQUMsV0FBVyxDQUFDO0NBQ2xELE9BQU8sb0JBQW9CLE1BQU0sV0FBVyxNQUFNO0FBQ25EO0FBR0EsSUFBSSx5QkFBeUIsY0FBYyxLQUFLLENBQUM7QUFDakQsSUFBSSx5QkFBeUIsY0FBYyxLQUFLLENBQUM7QUFDakQsSUFBSSwyQkFBMkI7Q0FDOUIsTUFBTSxVQUFVLFdBQVcsc0JBQXNCO0NBQ2pELElBQUksQ0FBQyxTQUFTLE1BQU0sSUFBSSxNQUFNLDJFQUEyRTtDQUN6RyxPQUFPO0FBQ1IifQ==