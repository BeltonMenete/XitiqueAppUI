import { t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=03f72e91";
//#region node_modules/.pnpm/react@19.2.8/node_modules/react/cjs/react.development.js
/**
* @license React
* react.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_development = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function() {
		function defineDeprecationWarning(methodName, info) {
			Object.defineProperty(Component.prototype, methodName, { get: function() {
				console.warn("%s(...) is deprecated in plain JavaScript React classes. %s", info[0], info[1]);
			} });
		}
		function getIteratorFn(maybeIterable) {
			if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
			maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
			return "function" === typeof maybeIterable ? maybeIterable : null;
		}
		function warnNoop(publicInstance, callerName) {
			publicInstance = (publicInstance = publicInstance.constructor) && (publicInstance.displayName || publicInstance.name) || "ReactClass";
			var warningKey = publicInstance + "." + callerName;
			didWarnStateUpdateForUnmountedComponent[warningKey] || (console.error("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", callerName, publicInstance), didWarnStateUpdateForUnmountedComponent[warningKey] = !0);
		}
		function Component(props, context, updater) {
			this.props = props;
			this.context = context;
			this.refs = emptyObject;
			this.updater = updater || ReactNoopUpdateQueue;
		}
		function ComponentDummy() {}
		function PureComponent(props, context, updater) {
			this.props = props;
			this.context = context;
			this.refs = emptyObject;
			this.updater = updater || ReactNoopUpdateQueue;
		}
		function noop() {}
		function testStringCoercion(value) {
			return "" + value;
		}
		function checkKeyStringCoercion(value) {
			try {
				testStringCoercion(value);
				var JSCompiler_inline_result = !1;
			} catch (e) {
				JSCompiler_inline_result = !0;
			}
			if (JSCompiler_inline_result) {
				JSCompiler_inline_result = console;
				var JSCompiler_temp_const = JSCompiler_inline_result.error;
				var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
				JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
				return testStringCoercion(value);
			}
		}
		function getComponentNameFromType(type) {
			if (null == type) return null;
			if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
			if ("string" === typeof type) return type;
			switch (type) {
				case REACT_FRAGMENT_TYPE: return "Fragment";
				case REACT_PROFILER_TYPE: return "Profiler";
				case REACT_STRICT_MODE_TYPE: return "StrictMode";
				case REACT_SUSPENSE_TYPE: return "Suspense";
				case REACT_SUSPENSE_LIST_TYPE: return "SuspenseList";
				case REACT_ACTIVITY_TYPE: return "Activity";
			}
			if ("object" === typeof type) switch ("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof) {
				case REACT_PORTAL_TYPE: return "Portal";
				case REACT_CONTEXT_TYPE: return type.displayName || "Context";
				case REACT_CONSUMER_TYPE: return (type._context.displayName || "Context") + ".Consumer";
				case REACT_FORWARD_REF_TYPE:
					var innerType = type.render;
					type = type.displayName;
					type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
					return type;
				case REACT_MEMO_TYPE: return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
				case REACT_LAZY_TYPE:
					innerType = type._payload;
					type = type._init;
					try {
						return getComponentNameFromType(type(innerType));
					} catch (x) {}
			}
			return null;
		}
		function getTaskName(type) {
			if (type === REACT_FRAGMENT_TYPE) return "<>";
			if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
			try {
				var name = getComponentNameFromType(type);
				return name ? "<" + name + ">" : "<...>";
			} catch (x) {
				return "<...>";
			}
		}
		function getOwner() {
			var dispatcher = ReactSharedInternals.A;
			return null === dispatcher ? null : dispatcher.getOwner();
		}
		function UnknownOwner() {
			return Error("react-stack-top-frame");
		}
		function hasValidKey(config) {
			if (hasOwnProperty.call(config, "key")) {
				var getter = Object.getOwnPropertyDescriptor(config, "key").get;
				if (getter && getter.isReactWarning) return !1;
			}
			return void 0 !== config.key;
		}
		function defineKeyPropWarningGetter(props, displayName) {
			function warnAboutAccessingKey() {
				specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
			}
			warnAboutAccessingKey.isReactWarning = !0;
			Object.defineProperty(props, "key", {
				get: warnAboutAccessingKey,
				configurable: !0
			});
		}
		function elementRefGetterWithDeprecationWarning() {
			var componentName = getComponentNameFromType(this.type);
			didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
			componentName = this.props.ref;
			return void 0 !== componentName ? componentName : null;
		}
		function ReactElement(type, key, props, owner, debugStack, debugTask) {
			var refProp = props.ref;
			type = {
				$$typeof: REACT_ELEMENT_TYPE,
				type,
				key,
				props,
				_owner: owner
			};
			null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
				enumerable: !1,
				get: elementRefGetterWithDeprecationWarning
			}) : Object.defineProperty(type, "ref", {
				enumerable: !1,
				value: null
			});
			type._store = {};
			Object.defineProperty(type._store, "validated", {
				configurable: !1,
				enumerable: !1,
				writable: !0,
				value: 0
			});
			Object.defineProperty(type, "_debugInfo", {
				configurable: !1,
				enumerable: !1,
				writable: !0,
				value: null
			});
			Object.defineProperty(type, "_debugStack", {
				configurable: !1,
				enumerable: !1,
				writable: !0,
				value: debugStack
			});
			Object.defineProperty(type, "_debugTask", {
				configurable: !1,
				enumerable: !1,
				writable: !0,
				value: debugTask
			});
			Object.freeze && (Object.freeze(type.props), Object.freeze(type));
			return type;
		}
		function cloneAndReplaceKey(oldElement, newKey) {
			newKey = ReactElement(oldElement.type, newKey, oldElement.props, oldElement._owner, oldElement._debugStack, oldElement._debugTask);
			oldElement._store && (newKey._store.validated = oldElement._store.validated);
			return newKey;
		}
		function validateChildKeys(node) {
			isValidElement(node) ? node._store && (node._store.validated = 1) : "object" === typeof node && null !== node && node.$$typeof === REACT_LAZY_TYPE && ("fulfilled" === node._payload.status ? isValidElement(node._payload.value) && node._payload.value._store && (node._payload.value._store.validated = 1) : node._store && (node._store.validated = 1));
		}
		function isValidElement(object) {
			return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
		}
		function escape(key) {
			var escaperLookup = {
				"=": "=0",
				":": "=2"
			};
			return "$" + key.replace(/[=:]/g, function(match) {
				return escaperLookup[match];
			});
		}
		function getElementKey(element, index) {
			return "object" === typeof element && null !== element && null != element.key ? (checkKeyStringCoercion(element.key), escape("" + element.key)) : index.toString(36);
		}
		function resolveThenable(thenable) {
			switch (thenable.status) {
				case "fulfilled": return thenable.value;
				case "rejected": throw thenable.reason;
				default: switch ("string" === typeof thenable.status ? thenable.then(noop, noop) : (thenable.status = "pending", thenable.then(function(fulfilledValue) {
					"pending" === thenable.status && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
				}, function(error) {
					"pending" === thenable.status && (thenable.status = "rejected", thenable.reason = error);
				})), thenable.status) {
					case "fulfilled": return thenable.value;
					case "rejected": throw thenable.reason;
				}
			}
			throw thenable;
		}
		function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
			var type = typeof children;
			if ("undefined" === type || "boolean" === type) children = null;
			var invokeCallback = !1;
			if (null === children) invokeCallback = !0;
			else switch (type) {
				case "bigint":
				case "string":
				case "number":
					invokeCallback = !0;
					break;
				case "object": switch (children.$$typeof) {
					case REACT_ELEMENT_TYPE:
					case REACT_PORTAL_TYPE:
						invokeCallback = !0;
						break;
					case REACT_LAZY_TYPE: return invokeCallback = children._init, mapIntoArray(invokeCallback(children._payload), array, escapedPrefix, nameSoFar, callback);
				}
			}
			if (invokeCallback) {
				invokeCallback = children;
				callback = callback(invokeCallback);
				var childKey = "" === nameSoFar ? "." + getElementKey(invokeCallback, 0) : nameSoFar;
				isArrayImpl(callback) ? (escapedPrefix = "", null != childKey && (escapedPrefix = childKey.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function(c) {
					return c;
				})) : null != callback && (isValidElement(callback) && (null != callback.key && (invokeCallback && invokeCallback.key === callback.key || checkKeyStringCoercion(callback.key)), escapedPrefix = cloneAndReplaceKey(callback, escapedPrefix + (null == callback.key || invokeCallback && invokeCallback.key === callback.key ? "" : ("" + callback.key).replace(userProvidedKeyEscapeRegex, "$&/") + "/") + childKey), "" !== nameSoFar && null != invokeCallback && isValidElement(invokeCallback) && null == invokeCallback.key && invokeCallback._store && !invokeCallback._store.validated && (escapedPrefix._store.validated = 2), callback = escapedPrefix), array.push(callback));
				return 1;
			}
			invokeCallback = 0;
			childKey = "" === nameSoFar ? "." : nameSoFar + ":";
			if (isArrayImpl(children)) for (var i = 0; i < children.length; i++) nameSoFar = children[i], type = childKey + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);
			else if (i = getIteratorFn(children), "function" === typeof i) for (i === children.entries && (didWarnAboutMaps || console.warn("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), didWarnAboutMaps = !0), children = i.call(children), i = 0; !(nameSoFar = children.next()).done;) nameSoFar = nameSoFar.value, type = childKey + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);
			else if ("object" === type) {
				if ("function" === typeof children.then) return mapIntoArray(resolveThenable(children), array, escapedPrefix, nameSoFar, callback);
				array = String(children);
				throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === array ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead.");
			}
			return invokeCallback;
		}
		function mapChildren(children, func, context) {
			if (null == children) return children;
			var result = [], count = 0;
			mapIntoArray(children, result, "", "", function(child) {
				return func.call(context, child, count++);
			});
			return result;
		}
		function lazyInitializer(payload) {
			if (-1 === payload._status) {
				var ioInfo = payload._ioInfo;
				null != ioInfo && (ioInfo.start = ioInfo.end = performance.now());
				ioInfo = payload._result;
				var thenable = ioInfo();
				thenable.then(function(moduleObject) {
					if (0 === payload._status || -1 === payload._status) {
						payload._status = 1;
						payload._result = moduleObject;
						var _ioInfo = payload._ioInfo;
						null != _ioInfo && (_ioInfo.end = performance.now());
						void 0 === thenable.status && (thenable.status = "fulfilled", thenable.value = moduleObject);
					}
				}, function(error) {
					if (0 === payload._status || -1 === payload._status) {
						payload._status = 2;
						payload._result = error;
						var _ioInfo2 = payload._ioInfo;
						null != _ioInfo2 && (_ioInfo2.end = performance.now());
						void 0 === thenable.status && (thenable.status = "rejected", thenable.reason = error);
					}
				});
				ioInfo = payload._ioInfo;
				if (null != ioInfo) {
					ioInfo.value = thenable;
					var displayName = thenable.displayName;
					"string" === typeof displayName && (ioInfo.name = displayName);
				}
				-1 === payload._status && (payload._status = 0, payload._result = thenable);
			}
			if (1 === payload._status) return ioInfo = payload._result, void 0 === ioInfo && console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))\n\nDid you accidentally put curly braces around the import?", ioInfo), "default" in ioInfo || console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))", ioInfo), ioInfo.default;
			throw payload._result;
		}
		function resolveDispatcher() {
			var dispatcher = ReactSharedInternals.H;
			null === dispatcher && console.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.");
			return dispatcher;
		}
		function releaseAsyncTransition() {
			ReactSharedInternals.asyncTransitions--;
		}
		function enqueueTask(task) {
			if (null === enqueueTaskImpl) try {
				var requireString = ("require" + Math.random()).slice(0, 7);
				enqueueTaskImpl = (module && module[requireString]).call(module, "timers").setImmediate;
			} catch (_err) {
				enqueueTaskImpl = function(callback) {
					!1 === didWarnAboutMessageChannel && (didWarnAboutMessageChannel = !0, "undefined" === typeof MessageChannel && console.error("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));
					var channel = new MessageChannel();
					channel.port1.onmessage = callback;
					channel.port2.postMessage(void 0);
				};
			}
			return enqueueTaskImpl(task);
		}
		function aggregateErrors(errors) {
			return 1 < errors.length && "function" === typeof AggregateError ? new AggregateError(errors) : errors[0];
		}
		function popActScope(prevActQueue, prevActScopeDepth) {
			prevActScopeDepth !== actScopeDepth - 1 && console.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
			actScopeDepth = prevActScopeDepth;
		}
		function recursivelyFlushAsyncActWork(returnValue, resolve, reject) {
			var queue = ReactSharedInternals.actQueue;
			if (null !== queue) if (0 !== queue.length) try {
				flushActQueue(queue);
				enqueueTask(function() {
					return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
				});
				return;
			} catch (error) {
				ReactSharedInternals.thrownErrors.push(error);
			}
			else ReactSharedInternals.actQueue = null;
			0 < ReactSharedInternals.thrownErrors.length ? (queue = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(queue)) : resolve(returnValue);
		}
		function flushActQueue(queue) {
			if (!isFlushing) {
				isFlushing = !0;
				var i = 0;
				try {
					for (; i < queue.length; i++) {
						var callback = queue[i];
						do {
							ReactSharedInternals.didUsePromise = !1;
							var continuation = callback(!1);
							if (null !== continuation) {
								if (ReactSharedInternals.didUsePromise) {
									queue[i] = callback;
									queue.splice(0, i);
									return;
								}
								callback = continuation;
							} else break;
						} while (1);
					}
					queue.length = 0;
				} catch (error) {
					queue.splice(0, i + 1), ReactSharedInternals.thrownErrors.push(error);
				} finally {
					isFlushing = !1;
				}
			}
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), MAYBE_ITERATOR_SYMBOL = Symbol.iterator, didWarnStateUpdateForUnmountedComponent = {}, ReactNoopUpdateQueue = {
			isMounted: function() {
				return !1;
			},
			enqueueForceUpdate: function(publicInstance) {
				warnNoop(publicInstance, "forceUpdate");
			},
			enqueueReplaceState: function(publicInstance) {
				warnNoop(publicInstance, "replaceState");
			},
			enqueueSetState: function(publicInstance) {
				warnNoop(publicInstance, "setState");
			}
		}, assign = Object.assign, emptyObject = {};
		Object.freeze(emptyObject);
		Component.prototype.isReactComponent = {};
		Component.prototype.setState = function(partialState, callback) {
			if ("object" !== typeof partialState && "function" !== typeof partialState && null != partialState) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
			this.updater.enqueueSetState(this, partialState, callback, "setState");
		};
		Component.prototype.forceUpdate = function(callback) {
			this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
		};
		var deprecatedAPIs = {
			isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
			replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
		};
		for (fnName in deprecatedAPIs) deprecatedAPIs.hasOwnProperty(fnName) && defineDeprecationWarning(fnName, deprecatedAPIs[fnName]);
		ComponentDummy.prototype = Component.prototype;
		deprecatedAPIs = PureComponent.prototype = new ComponentDummy();
		deprecatedAPIs.constructor = PureComponent;
		assign(deprecatedAPIs, Component.prototype);
		deprecatedAPIs.isPureReactComponent = !0;
		var isArrayImpl = Array.isArray, REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), ReactSharedInternals = {
			H: null,
			A: null,
			T: null,
			S: null,
			actQueue: null,
			asyncTransitions: 0,
			isBatchingLegacy: !1,
			didScheduleLegacyUpdate: !1,
			didUsePromise: !1,
			thrownErrors: [],
			getCurrentStack: null,
			recentlyCreatedOwnerStacks: 0
		}, hasOwnProperty = Object.prototype.hasOwnProperty, createTask = console.createTask ? console.createTask : function() {
			return null;
		};
		deprecatedAPIs = { react_stack_bottom_frame: function(callStackForError) {
			return callStackForError();
		} };
		var specialPropKeyWarningShown, didWarnAboutOldJSXRuntime;
		var didWarnAboutElementRef = {};
		var unknownOwnerDebugStack = deprecatedAPIs.react_stack_bottom_frame.bind(deprecatedAPIs, UnknownOwner)();
		var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
		var didWarnAboutMaps = !1, userProvidedKeyEscapeRegex = /\/+/g, reportGlobalError = "function" === typeof reportError ? reportError : function(error) {
			if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
				var event = new window.ErrorEvent("error", {
					bubbles: !0,
					cancelable: !0,
					message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
					error
				});
				if (!window.dispatchEvent(event)) return;
			} else if ("object" === typeof process && "function" === typeof process.emit) {
				process.emit("uncaughtException", error);
				return;
			}
			console.error(error);
		}, didWarnAboutMessageChannel = !1, enqueueTaskImpl = null, actScopeDepth = 0, didWarnNoAwaitAct = !1, isFlushing = !1, queueSeveralMicrotasks = "function" === typeof queueMicrotask ? function(callback) {
			queueMicrotask(function() {
				return queueMicrotask(callback);
			});
		} : enqueueTask;
		deprecatedAPIs = Object.freeze({
			__proto__: null,
			c: function(size) {
				return resolveDispatcher().useMemoCache(size);
			}
		});
		var fnName = {
			map: mapChildren,
			forEach: function(children, forEachFunc, forEachContext) {
				mapChildren(children, function() {
					forEachFunc.apply(this, arguments);
				}, forEachContext);
			},
			count: function(children) {
				var n = 0;
				mapChildren(children, function() {
					n++;
				});
				return n;
			},
			toArray: function(children) {
				return mapChildren(children, function(child) {
					return child;
				}) || [];
			},
			only: function(children) {
				if (!isValidElement(children)) throw Error("React.Children.only expected to receive a single React element child.");
				return children;
			}
		};
		exports.Activity = REACT_ACTIVITY_TYPE;
		exports.Children = fnName;
		exports.Component = Component;
		exports.Fragment = REACT_FRAGMENT_TYPE;
		exports.Profiler = REACT_PROFILER_TYPE;
		exports.PureComponent = PureComponent;
		exports.StrictMode = REACT_STRICT_MODE_TYPE;
		exports.Suspense = REACT_SUSPENSE_TYPE;
		exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
		exports.__COMPILER_RUNTIME = deprecatedAPIs;
		exports.act = function(callback) {
			var prevActQueue = ReactSharedInternals.actQueue, prevActScopeDepth = actScopeDepth;
			actScopeDepth++;
			var queue = ReactSharedInternals.actQueue = null !== prevActQueue ? prevActQueue : [], didAwaitActCall = !1;
			try {
				var result = callback();
			} catch (error) {
				ReactSharedInternals.thrownErrors.push(error);
			}
			if (0 < ReactSharedInternals.thrownErrors.length) throw popActScope(prevActQueue, prevActScopeDepth), callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
			if (null !== result && "object" === typeof result && "function" === typeof result.then) {
				var thenable = result;
				queueSeveralMicrotasks(function() {
					didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"));
				});
				return { then: function(resolve, reject) {
					didAwaitActCall = !0;
					thenable.then(function(returnValue) {
						popActScope(prevActQueue, prevActScopeDepth);
						if (0 === prevActScopeDepth) {
							try {
								flushActQueue(queue), enqueueTask(function() {
									return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
								});
							} catch (error$0) {
								ReactSharedInternals.thrownErrors.push(error$0);
							}
							if (0 < ReactSharedInternals.thrownErrors.length) {
								var _thrownError = aggregateErrors(ReactSharedInternals.thrownErrors);
								ReactSharedInternals.thrownErrors.length = 0;
								reject(_thrownError);
							}
						} else resolve(returnValue);
					}, function(error) {
						popActScope(prevActQueue, prevActScopeDepth);
						0 < ReactSharedInternals.thrownErrors.length ? (error = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(error)) : reject(error);
					});
				} };
			}
			var returnValue$jscomp$0 = result;
			popActScope(prevActQueue, prevActScopeDepth);
			0 === prevActScopeDepth && (flushActQueue(queue), 0 !== queue.length && queueSeveralMicrotasks(function() {
				didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"));
			}), ReactSharedInternals.actQueue = null);
			if (0 < ReactSharedInternals.thrownErrors.length) throw callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
			return { then: function(resolve, reject) {
				didAwaitActCall = !0;
				0 === prevActScopeDepth ? (ReactSharedInternals.actQueue = queue, enqueueTask(function() {
					return recursivelyFlushAsyncActWork(returnValue$jscomp$0, resolve, reject);
				})) : resolve(returnValue$jscomp$0);
			} };
		};
		exports.cache = function(fn) {
			return function() {
				return fn.apply(null, arguments);
			};
		};
		exports.cacheSignal = function() {
			return null;
		};
		exports.captureOwnerStack = function() {
			var getCurrentStack = ReactSharedInternals.getCurrentStack;
			return null === getCurrentStack ? null : getCurrentStack();
		};
		exports.cloneElement = function(element, config, children) {
			if (null === element || void 0 === element) throw Error("The argument must be a React element, but you passed " + element + ".");
			var props = assign({}, element.props), key = element.key, owner = element._owner;
			if (null != config) {
				var JSCompiler_inline_result;
				a: {
					if (hasOwnProperty.call(config, "ref") && (JSCompiler_inline_result = Object.getOwnPropertyDescriptor(config, "ref").get) && JSCompiler_inline_result.isReactWarning) {
						JSCompiler_inline_result = !1;
						break a;
					}
					JSCompiler_inline_result = void 0 !== config.ref;
				}
				JSCompiler_inline_result && (owner = getOwner());
				hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key);
				for (propName in config) !hasOwnProperty.call(config, propName) || "key" === propName || "__self" === propName || "__source" === propName || "ref" === propName && void 0 === config.ref || (props[propName] = config[propName]);
			}
			var propName = arguments.length - 2;
			if (1 === propName) props.children = children;
			else if (1 < propName) {
				JSCompiler_inline_result = Array(propName);
				for (var i = 0; i < propName; i++) JSCompiler_inline_result[i] = arguments[i + 2];
				props.children = JSCompiler_inline_result;
			}
			props = ReactElement(element.type, key, props, owner, element._debugStack, element._debugTask);
			for (key = 2; key < arguments.length; key++) validateChildKeys(arguments[key]);
			return props;
		};
		exports.createContext = function(defaultValue) {
			defaultValue = {
				$$typeof: REACT_CONTEXT_TYPE,
				_currentValue: defaultValue,
				_currentValue2: defaultValue,
				_threadCount: 0,
				Provider: null,
				Consumer: null
			};
			defaultValue.Provider = defaultValue;
			defaultValue.Consumer = {
				$$typeof: REACT_CONSUMER_TYPE,
				_context: defaultValue
			};
			defaultValue._currentRenderer = null;
			defaultValue._currentRenderer2 = null;
			return defaultValue;
		};
		exports.createElement = function(type, config, children) {
			for (var i = 2; i < arguments.length; i++) validateChildKeys(arguments[i]);
			i = {};
			var key = null;
			if (null != config) for (propName in didWarnAboutOldJSXRuntime || !("__self" in config) || "key" in config || (didWarnAboutOldJSXRuntime = !0, console.warn("Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform")), hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key), config) hasOwnProperty.call(config, propName) && "key" !== propName && "__self" !== propName && "__source" !== propName && (i[propName] = config[propName]);
			var childrenLength = arguments.length - 2;
			if (1 === childrenLength) i.children = children;
			else if (1 < childrenLength) {
				for (var childArray = Array(childrenLength), _i = 0; _i < childrenLength; _i++) childArray[_i] = arguments[_i + 2];
				Object.freeze && Object.freeze(childArray);
				i.children = childArray;
			}
			if (type && type.defaultProps) for (propName in childrenLength = type.defaultProps, childrenLength) void 0 === i[propName] && (i[propName] = childrenLength[propName]);
			key && defineKeyPropWarningGetter(i, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
			var propName = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
			return ReactElement(type, key, i, getOwner(), propName ? Error("react-stack-top-frame") : unknownOwnerDebugStack, propName ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
		};
		exports.createRef = function() {
			var refObject = { current: null };
			Object.seal(refObject);
			return refObject;
		};
		exports.forwardRef = function(render) {
			null != render && render.$$typeof === REACT_MEMO_TYPE ? console.error("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).") : "function" !== typeof render ? console.error("forwardRef requires a render function but was given %s.", null === render ? "null" : typeof render) : 0 !== render.length && 2 !== render.length && console.error("forwardRef render functions accept exactly two parameters: props and ref. %s", 1 === render.length ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined.");
			null != render && null != render.defaultProps && console.error("forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?");
			var elementType = {
				$$typeof: REACT_FORWARD_REF_TYPE,
				render
			}, ownName;
			Object.defineProperty(elementType, "displayName", {
				enumerable: !1,
				configurable: !0,
				get: function() {
					return ownName;
				},
				set: function(name) {
					ownName = name;
					render.name || render.displayName || (Object.defineProperty(render, "name", { value: name }), render.displayName = name);
				}
			});
			return elementType;
		};
		exports.isValidElement = isValidElement;
		exports.lazy = function(ctor) {
			ctor = {
				_status: -1,
				_result: ctor
			};
			var lazyType = {
				$$typeof: REACT_LAZY_TYPE,
				_payload: ctor,
				_init: lazyInitializer
			}, ioInfo = {
				name: "lazy",
				start: -1,
				end: -1,
				value: null,
				owner: null,
				debugStack: Error("react-stack-top-frame"),
				debugTask: console.createTask ? console.createTask("lazy()") : null
			};
			ctor._ioInfo = ioInfo;
			lazyType._debugInfo = [{ awaited: ioInfo }];
			return lazyType;
		};
		exports.memo = function(type, compare) {
			type ?? console.error("memo: The first argument must be a component. Instead received: %s", null === type ? "null" : typeof type);
			compare = {
				$$typeof: REACT_MEMO_TYPE,
				type,
				compare: void 0 === compare ? null : compare
			};
			var ownName;
			Object.defineProperty(compare, "displayName", {
				enumerable: !1,
				configurable: !0,
				get: function() {
					return ownName;
				},
				set: function(name) {
					ownName = name;
					type.name || type.displayName || (Object.defineProperty(type, "name", { value: name }), type.displayName = name);
				}
			});
			return compare;
		};
		exports.startTransition = function(scope) {
			var prevTransition = ReactSharedInternals.T, currentTransition = {};
			currentTransition._updatedFibers = /* @__PURE__ */ new Set();
			ReactSharedInternals.T = currentTransition;
			try {
				var returnValue = scope(), onStartTransitionFinish = ReactSharedInternals.S;
				null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
				"object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && (ReactSharedInternals.asyncTransitions++, returnValue.then(releaseAsyncTransition, releaseAsyncTransition), returnValue.then(noop, reportGlobalError));
			} catch (error) {
				reportGlobalError(error);
			} finally {
				null === prevTransition && currentTransition._updatedFibers && (scope = currentTransition._updatedFibers.size, currentTransition._updatedFibers.clear(), 10 < scope && console.warn("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.")), null !== prevTransition && null !== currentTransition.types && (null !== prevTransition.types && prevTransition.types !== currentTransition.types && console.error("We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React."), prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
			}
		};
		exports.unstable_useCacheRefresh = function() {
			return resolveDispatcher().useCacheRefresh();
		};
		exports.use = function(usable) {
			return resolveDispatcher().use(usable);
		};
		exports.useActionState = function(action, initialState, permalink) {
			return resolveDispatcher().useActionState(action, initialState, permalink);
		};
		exports.useCallback = function(callback, deps) {
			return resolveDispatcher().useCallback(callback, deps);
		};
		exports.useContext = function(Context) {
			var dispatcher = resolveDispatcher();
			Context.$$typeof === REACT_CONSUMER_TYPE && console.error("Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?");
			return dispatcher.useContext(Context);
		};
		exports.useDebugValue = function(value, formatterFn) {
			return resolveDispatcher().useDebugValue(value, formatterFn);
		};
		exports.useDeferredValue = function(value, initialValue) {
			return resolveDispatcher().useDeferredValue(value, initialValue);
		};
		exports.useEffect = function(create, deps) {
			create ?? console.warn("React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?");
			return resolveDispatcher().useEffect(create, deps);
		};
		exports.useEffectEvent = function(callback) {
			return resolveDispatcher().useEffectEvent(callback);
		};
		exports.useId = function() {
			return resolveDispatcher().useId();
		};
		exports.useImperativeHandle = function(ref, create, deps) {
			return resolveDispatcher().useImperativeHandle(ref, create, deps);
		};
		exports.useInsertionEffect = function(create, deps) {
			create ?? console.warn("React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?");
			return resolveDispatcher().useInsertionEffect(create, deps);
		};
		exports.useLayoutEffect = function(create, deps) {
			create ?? console.warn("React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?");
			return resolveDispatcher().useLayoutEffect(create, deps);
		};
		exports.useMemo = function(create, deps) {
			return resolveDispatcher().useMemo(create, deps);
		};
		exports.useOptimistic = function(passthrough, reducer) {
			return resolveDispatcher().useOptimistic(passthrough, reducer);
		};
		exports.useReducer = function(reducer, initialArg, init) {
			return resolveDispatcher().useReducer(reducer, initialArg, init);
		};
		exports.useRef = function(initialValue) {
			return resolveDispatcher().useRef(initialValue);
		};
		exports.useState = function(initialState) {
			return resolveDispatcher().useState(initialState);
		};
		exports.useSyncExternalStore = function(subscribe, getSnapshot, getServerSnapshot) {
			return resolveDispatcher().useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
		};
		exports.useTransition = function() {
			return resolveDispatcher().useTransition();
		};
		exports.version = "19.2.8";
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
//#endregion
//#region node_modules/.pnpm/react@19.2.8/node_modules/react/index.js
var require_react = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_react_development();
}));
//#endregion
export default require_react();
export { require_react as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vLnBucG0vcmVhY3RAMTkuMi44L25vZGVfbW9kdWxlcy9yZWFjdC9janMvcmVhY3QuZGV2ZWxvcG1lbnQuanMiLCIuLi8uLi8ucG5wbS9yZWFjdEAxOS4yLjgvbm9kZV9tb2R1bGVzL3JlYWN0L2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2UgUmVhY3RcbiAqIHJlYWN0LmRldmVsb3BtZW50LmpzXG4gKlxuICogQ29weXJpZ2h0IChjKSBNZXRhIFBsYXRmb3JtcywgSW5jLiBhbmQgYWZmaWxpYXRlcy5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuXG5cInVzZSBzdHJpY3RcIjtcblwicHJvZHVjdGlvblwiICE9PSBwcm9jZXNzLmVudi5OT0RFX0VOViAmJlxuICAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIGRlZmluZURlcHJlY2F0aW9uV2FybmluZyhtZXRob2ROYW1lLCBpbmZvKSB7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoQ29tcG9uZW50LnByb3RvdHlwZSwgbWV0aG9kTmFtZSwge1xuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgICBcIiVzKC4uLikgaXMgZGVwcmVjYXRlZCBpbiBwbGFpbiBKYXZhU2NyaXB0IFJlYWN0IGNsYXNzZXMuICVzXCIsXG4gICAgICAgICAgICBpbmZvWzBdLFxuICAgICAgICAgICAgaW5mb1sxXVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRJdGVyYXRvckZuKG1heWJlSXRlcmFibGUpIHtcbiAgICAgIGlmIChudWxsID09PSBtYXliZUl0ZXJhYmxlIHx8IFwib2JqZWN0XCIgIT09IHR5cGVvZiBtYXliZUl0ZXJhYmxlKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIG1heWJlSXRlcmFibGUgPVxuICAgICAgICAoTUFZQkVfSVRFUkFUT1JfU1lNQk9MICYmIG1heWJlSXRlcmFibGVbTUFZQkVfSVRFUkFUT1JfU1lNQk9MXSkgfHxcbiAgICAgICAgbWF5YmVJdGVyYWJsZVtcIkBAaXRlcmF0b3JcIl07XG4gICAgICByZXR1cm4gXCJmdW5jdGlvblwiID09PSB0eXBlb2YgbWF5YmVJdGVyYWJsZSA/IG1heWJlSXRlcmFibGUgOiBudWxsO1xuICAgIH1cbiAgICBmdW5jdGlvbiB3YXJuTm9vcChwdWJsaWNJbnN0YW5jZSwgY2FsbGVyTmFtZSkge1xuICAgICAgcHVibGljSW5zdGFuY2UgPVxuICAgICAgICAoKHB1YmxpY0luc3RhbmNlID0gcHVibGljSW5zdGFuY2UuY29uc3RydWN0b3IpICYmXG4gICAgICAgICAgKHB1YmxpY0luc3RhbmNlLmRpc3BsYXlOYW1lIHx8IHB1YmxpY0luc3RhbmNlLm5hbWUpKSB8fFxuICAgICAgICBcIlJlYWN0Q2xhc3NcIjtcbiAgICAgIHZhciB3YXJuaW5nS2V5ID0gcHVibGljSW5zdGFuY2UgKyBcIi5cIiArIGNhbGxlck5hbWU7XG4gICAgICBkaWRXYXJuU3RhdGVVcGRhdGVGb3JVbm1vdW50ZWRDb21wb25lbnRbd2FybmluZ0tleV0gfHxcbiAgICAgICAgKGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgXCJDYW4ndCBjYWxsICVzIG9uIGEgY29tcG9uZW50IHRoYXQgaXMgbm90IHlldCBtb3VudGVkLiBUaGlzIGlzIGEgbm8tb3AsIGJ1dCBpdCBtaWdodCBpbmRpY2F0ZSBhIGJ1ZyBpbiB5b3VyIGFwcGxpY2F0aW9uLiBJbnN0ZWFkLCBhc3NpZ24gdG8gYHRoaXMuc3RhdGVgIGRpcmVjdGx5IG9yIGRlZmluZSBhIGBzdGF0ZSA9IHt9O2AgY2xhc3MgcHJvcGVydHkgd2l0aCB0aGUgZGVzaXJlZCBzdGF0ZSBpbiB0aGUgJXMgY29tcG9uZW50LlwiLFxuICAgICAgICAgIGNhbGxlck5hbWUsXG4gICAgICAgICAgcHVibGljSW5zdGFuY2VcbiAgICAgICAgKSxcbiAgICAgICAgKGRpZFdhcm5TdGF0ZVVwZGF0ZUZvclVubW91bnRlZENvbXBvbmVudFt3YXJuaW5nS2V5XSA9ICEwKSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIENvbXBvbmVudChwcm9wcywgY29udGV4dCwgdXBkYXRlcikge1xuICAgICAgdGhpcy5wcm9wcyA9IHByb3BzO1xuICAgICAgdGhpcy5jb250ZXh0ID0gY29udGV4dDtcbiAgICAgIHRoaXMucmVmcyA9IGVtcHR5T2JqZWN0O1xuICAgICAgdGhpcy51cGRhdGVyID0gdXBkYXRlciB8fCBSZWFjdE5vb3BVcGRhdGVRdWV1ZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gQ29tcG9uZW50RHVtbXkoKSB7fVxuICAgIGZ1bmN0aW9uIFB1cmVDb21wb25lbnQocHJvcHMsIGNvbnRleHQsIHVwZGF0ZXIpIHtcbiAgICAgIHRoaXMucHJvcHMgPSBwcm9wcztcbiAgICAgIHRoaXMuY29udGV4dCA9IGNvbnRleHQ7XG4gICAgICB0aGlzLnJlZnMgPSBlbXB0eU9iamVjdDtcbiAgICAgIHRoaXMudXBkYXRlciA9IHVwZGF0ZXIgfHwgUmVhY3ROb29wVXBkYXRlUXVldWU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIG5vb3AoKSB7fVxuICAgIGZ1bmN0aW9uIHRlc3RTdHJpbmdDb2VyY2lvbih2YWx1ZSkge1xuICAgICAgcmV0dXJuIFwiXCIgKyB2YWx1ZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gY2hlY2tLZXlTdHJpbmdDb2VyY2lvbih2YWx1ZSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdGVzdFN0cmluZ0NvZXJjaW9uKHZhbHVlKTtcbiAgICAgICAgdmFyIEpTQ29tcGlsZXJfaW5saW5lX3Jlc3VsdCA9ICExO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBKU0NvbXBpbGVyX2lubGluZV9yZXN1bHQgPSAhMDtcbiAgICAgIH1cbiAgICAgIGlmIChKU0NvbXBpbGVyX2lubGluZV9yZXN1bHQpIHtcbiAgICAgICAgSlNDb21waWxlcl9pbmxpbmVfcmVzdWx0ID0gY29uc29sZTtcbiAgICAgICAgdmFyIEpTQ29tcGlsZXJfdGVtcF9jb25zdCA9IEpTQ29tcGlsZXJfaW5saW5lX3Jlc3VsdC5lcnJvcjtcbiAgICAgICAgdmFyIEpTQ29tcGlsZXJfaW5saW5lX3Jlc3VsdCRqc2NvbXAkMCA9XG4gICAgICAgICAgKFwiZnVuY3Rpb25cIiA9PT0gdHlwZW9mIFN5bWJvbCAmJlxuICAgICAgICAgICAgU3ltYm9sLnRvU3RyaW5nVGFnICYmXG4gICAgICAgICAgICB2YWx1ZVtTeW1ib2wudG9TdHJpbmdUYWddKSB8fFxuICAgICAgICAgIHZhbHVlLmNvbnN0cnVjdG9yLm5hbWUgfHxcbiAgICAgICAgICBcIk9iamVjdFwiO1xuICAgICAgICBKU0NvbXBpbGVyX3RlbXBfY29uc3QuY2FsbChcbiAgICAgICAgICBKU0NvbXBpbGVyX2lubGluZV9yZXN1bHQsXG4gICAgICAgICAgXCJUaGUgcHJvdmlkZWQga2V5IGlzIGFuIHVuc3VwcG9ydGVkIHR5cGUgJXMuIFRoaXMgdmFsdWUgbXVzdCBiZSBjb2VyY2VkIHRvIGEgc3RyaW5nIGJlZm9yZSB1c2luZyBpdCBoZXJlLlwiLFxuICAgICAgICAgIEpTQ29tcGlsZXJfaW5saW5lX3Jlc3VsdCRqc2NvbXAkMFxuICAgICAgICApO1xuICAgICAgICByZXR1cm4gdGVzdFN0cmluZ0NvZXJjaW9uKHZhbHVlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0Q29tcG9uZW50TmFtZUZyb21UeXBlKHR5cGUpIHtcbiAgICAgIGlmIChudWxsID09IHR5cGUpIHJldHVybiBudWxsO1xuICAgICAgaWYgKFwiZnVuY3Rpb25cIiA9PT0gdHlwZW9mIHR5cGUpXG4gICAgICAgIHJldHVybiB0eXBlLiQkdHlwZW9mID09PSBSRUFDVF9DTElFTlRfUkVGRVJFTkNFXG4gICAgICAgICAgPyBudWxsXG4gICAgICAgICAgOiB0eXBlLmRpc3BsYXlOYW1lIHx8IHR5cGUubmFtZSB8fCBudWxsO1xuICAgICAgaWYgKFwic3RyaW5nXCIgPT09IHR5cGVvZiB0eXBlKSByZXR1cm4gdHlwZTtcbiAgICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgICBjYXNlIFJFQUNUX0ZSQUdNRU5UX1RZUEU6XG4gICAgICAgICAgcmV0dXJuIFwiRnJhZ21lbnRcIjtcbiAgICAgICAgY2FzZSBSRUFDVF9QUk9GSUxFUl9UWVBFOlxuICAgICAgICAgIHJldHVybiBcIlByb2ZpbGVyXCI7XG4gICAgICAgIGNhc2UgUkVBQ1RfU1RSSUNUX01PREVfVFlQRTpcbiAgICAgICAgICByZXR1cm4gXCJTdHJpY3RNb2RlXCI7XG4gICAgICAgIGNhc2UgUkVBQ1RfU1VTUEVOU0VfVFlQRTpcbiAgICAgICAgICByZXR1cm4gXCJTdXNwZW5zZVwiO1xuICAgICAgICBjYXNlIFJFQUNUX1NVU1BFTlNFX0xJU1RfVFlQRTpcbiAgICAgICAgICByZXR1cm4gXCJTdXNwZW5zZUxpc3RcIjtcbiAgICAgICAgY2FzZSBSRUFDVF9BQ1RJVklUWV9UWVBFOlxuICAgICAgICAgIHJldHVybiBcIkFjdGl2aXR5XCI7XG4gICAgICB9XG4gICAgICBpZiAoXCJvYmplY3RcIiA9PT0gdHlwZW9mIHR5cGUpXG4gICAgICAgIHN3aXRjaCAoXG4gICAgICAgICAgKFwibnVtYmVyXCIgPT09IHR5cGVvZiB0eXBlLnRhZyAmJlxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICAgICAgXCJSZWNlaXZlZCBhbiB1bmV4cGVjdGVkIG9iamVjdCBpbiBnZXRDb21wb25lbnROYW1lRnJvbVR5cGUoKS4gVGhpcyBpcyBsaWtlbHkgYSBidWcgaW4gUmVhY3QuIFBsZWFzZSBmaWxlIGFuIGlzc3VlLlwiXG4gICAgICAgICAgICApLFxuICAgICAgICAgIHR5cGUuJCR0eXBlb2YpXG4gICAgICAgICkge1xuICAgICAgICAgIGNhc2UgUkVBQ1RfUE9SVEFMX1RZUEU6XG4gICAgICAgICAgICByZXR1cm4gXCJQb3J0YWxcIjtcbiAgICAgICAgICBjYXNlIFJFQUNUX0NPTlRFWFRfVFlQRTpcbiAgICAgICAgICAgIHJldHVybiB0eXBlLmRpc3BsYXlOYW1lIHx8IFwiQ29udGV4dFwiO1xuICAgICAgICAgIGNhc2UgUkVBQ1RfQ09OU1VNRVJfVFlQRTpcbiAgICAgICAgICAgIHJldHVybiAodHlwZS5fY29udGV4dC5kaXNwbGF5TmFtZSB8fCBcIkNvbnRleHRcIikgKyBcIi5Db25zdW1lclwiO1xuICAgICAgICAgIGNhc2UgUkVBQ1RfRk9SV0FSRF9SRUZfVFlQRTpcbiAgICAgICAgICAgIHZhciBpbm5lclR5cGUgPSB0eXBlLnJlbmRlcjtcbiAgICAgICAgICAgIHR5cGUgPSB0eXBlLmRpc3BsYXlOYW1lO1xuICAgICAgICAgICAgdHlwZSB8fFxuICAgICAgICAgICAgICAoKHR5cGUgPSBpbm5lclR5cGUuZGlzcGxheU5hbWUgfHwgaW5uZXJUeXBlLm5hbWUgfHwgXCJcIiksXG4gICAgICAgICAgICAgICh0eXBlID0gXCJcIiAhPT0gdHlwZSA/IFwiRm9yd2FyZFJlZihcIiArIHR5cGUgKyBcIilcIiA6IFwiRm9yd2FyZFJlZlwiKSk7XG4gICAgICAgICAgICByZXR1cm4gdHlwZTtcbiAgICAgICAgICBjYXNlIFJFQUNUX01FTU9fVFlQRTpcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIChpbm5lclR5cGUgPSB0eXBlLmRpc3BsYXlOYW1lIHx8IG51bGwpLFxuICAgICAgICAgICAgICBudWxsICE9PSBpbm5lclR5cGVcbiAgICAgICAgICAgICAgICA/IGlubmVyVHlwZVxuICAgICAgICAgICAgICAgIDogZ2V0Q29tcG9uZW50TmFtZUZyb21UeXBlKHR5cGUudHlwZSkgfHwgXCJNZW1vXCJcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgY2FzZSBSRUFDVF9MQVpZX1RZUEU6XG4gICAgICAgICAgICBpbm5lclR5cGUgPSB0eXBlLl9wYXlsb2FkO1xuICAgICAgICAgICAgdHlwZSA9IHR5cGUuX2luaXQ7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICByZXR1cm4gZ2V0Q29tcG9uZW50TmFtZUZyb21UeXBlKHR5cGUoaW5uZXJUeXBlKSk7XG4gICAgICAgICAgICB9IGNhdGNoICh4KSB7fVxuICAgICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0VGFza05hbWUodHlwZSkge1xuICAgICAgaWYgKHR5cGUgPT09IFJFQUNUX0ZSQUdNRU5UX1RZUEUpIHJldHVybiBcIjw+XCI7XG4gICAgICBpZiAoXG4gICAgICAgIFwib2JqZWN0XCIgPT09IHR5cGVvZiB0eXBlICYmXG4gICAgICAgIG51bGwgIT09IHR5cGUgJiZcbiAgICAgICAgdHlwZS4kJHR5cGVvZiA9PT0gUkVBQ1RfTEFaWV9UWVBFXG4gICAgICApXG4gICAgICAgIHJldHVybiBcIjwuLi4+XCI7XG4gICAgICB0cnkge1xuICAgICAgICB2YXIgbmFtZSA9IGdldENvbXBvbmVudE5hbWVGcm9tVHlwZSh0eXBlKTtcbiAgICAgICAgcmV0dXJuIG5hbWUgPyBcIjxcIiArIG5hbWUgKyBcIj5cIiA6IFwiPC4uLj5cIjtcbiAgICAgIH0gY2F0Y2ggKHgpIHtcbiAgICAgICAgcmV0dXJuIFwiPC4uLj5cIjtcbiAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0T3duZXIoKSB7XG4gICAgICB2YXIgZGlzcGF0Y2hlciA9IFJlYWN0U2hhcmVkSW50ZXJuYWxzLkE7XG4gICAgICByZXR1cm4gbnVsbCA9PT0gZGlzcGF0Y2hlciA/IG51bGwgOiBkaXNwYXRjaGVyLmdldE93bmVyKCk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIFVua25vd25Pd25lcigpIHtcbiAgICAgIHJldHVybiBFcnJvcihcInJlYWN0LXN0YWNrLXRvcC1mcmFtZVwiKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaGFzVmFsaWRLZXkoY29uZmlnKSB7XG4gICAgICBpZiAoaGFzT3duUHJvcGVydHkuY2FsbChjb25maWcsIFwia2V5XCIpKSB7XG4gICAgICAgIHZhciBnZXR0ZXIgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGNvbmZpZywgXCJrZXlcIikuZ2V0O1xuICAgICAgICBpZiAoZ2V0dGVyICYmIGdldHRlci5pc1JlYWN0V2FybmluZykgcmV0dXJuICExO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHZvaWQgMCAhPT0gY29uZmlnLmtleTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZGVmaW5lS2V5UHJvcFdhcm5pbmdHZXR0ZXIocHJvcHMsIGRpc3BsYXlOYW1lKSB7XG4gICAgICBmdW5jdGlvbiB3YXJuQWJvdXRBY2Nlc3NpbmdLZXkoKSB7XG4gICAgICAgIHNwZWNpYWxQcm9wS2V5V2FybmluZ1Nob3duIHx8XG4gICAgICAgICAgKChzcGVjaWFsUHJvcEtleVdhcm5pbmdTaG93biA9ICEwKSxcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgICAgXCIlczogYGtleWAgaXMgbm90IGEgcHJvcC4gVHJ5aW5nIHRvIGFjY2VzcyBpdCB3aWxsIHJlc3VsdCBpbiBgdW5kZWZpbmVkYCBiZWluZyByZXR1cm5lZC4gSWYgeW91IG5lZWQgdG8gYWNjZXNzIHRoZSBzYW1lIHZhbHVlIHdpdGhpbiB0aGUgY2hpbGQgY29tcG9uZW50LCB5b3Ugc2hvdWxkIHBhc3MgaXQgYXMgYSBkaWZmZXJlbnQgcHJvcC4gKGh0dHBzOi8vcmVhY3QuZGV2L2xpbmsvc3BlY2lhbC1wcm9wcylcIixcbiAgICAgICAgICAgIGRpc3BsYXlOYW1lXG4gICAgICAgICAgKSk7XG4gICAgICB9XG4gICAgICB3YXJuQWJvdXRBY2Nlc3NpbmdLZXkuaXNSZWFjdFdhcm5pbmcgPSAhMDtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShwcm9wcywgXCJrZXlcIiwge1xuICAgICAgICBnZXQ6IHdhcm5BYm91dEFjY2Vzc2luZ0tleSxcbiAgICAgICAgY29uZmlndXJhYmxlOiAhMFxuICAgICAgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGVsZW1lbnRSZWZHZXR0ZXJXaXRoRGVwcmVjYXRpb25XYXJuaW5nKCkge1xuICAgICAgdmFyIGNvbXBvbmVudE5hbWUgPSBnZXRDb21wb25lbnROYW1lRnJvbVR5cGUodGhpcy50eXBlKTtcbiAgICAgIGRpZFdhcm5BYm91dEVsZW1lbnRSZWZbY29tcG9uZW50TmFtZV0gfHxcbiAgICAgICAgKChkaWRXYXJuQWJvdXRFbGVtZW50UmVmW2NvbXBvbmVudE5hbWVdID0gITApLFxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiQWNjZXNzaW5nIGVsZW1lbnQucmVmIHdhcyByZW1vdmVkIGluIFJlYWN0IDE5LiByZWYgaXMgbm93IGEgcmVndWxhciBwcm9wLiBJdCB3aWxsIGJlIHJlbW92ZWQgZnJvbSB0aGUgSlNYIEVsZW1lbnQgdHlwZSBpbiBhIGZ1dHVyZSByZWxlYXNlLlwiXG4gICAgICAgICkpO1xuICAgICAgY29tcG9uZW50TmFtZSA9IHRoaXMucHJvcHMucmVmO1xuICAgICAgcmV0dXJuIHZvaWQgMCAhPT0gY29tcG9uZW50TmFtZSA/IGNvbXBvbmVudE5hbWUgOiBudWxsO1xuICAgIH1cbiAgICBmdW5jdGlvbiBSZWFjdEVsZW1lbnQodHlwZSwga2V5LCBwcm9wcywgb3duZXIsIGRlYnVnU3RhY2ssIGRlYnVnVGFzaykge1xuICAgICAgdmFyIHJlZlByb3AgPSBwcm9wcy5yZWY7XG4gICAgICB0eXBlID0ge1xuICAgICAgICAkJHR5cGVvZjogUkVBQ1RfRUxFTUVOVF9UWVBFLFxuICAgICAgICB0eXBlOiB0eXBlLFxuICAgICAgICBrZXk6IGtleSxcbiAgICAgICAgcHJvcHM6IHByb3BzLFxuICAgICAgICBfb3duZXI6IG93bmVyXG4gICAgICB9O1xuICAgICAgbnVsbCAhPT0gKHZvaWQgMCAhPT0gcmVmUHJvcCA/IHJlZlByb3AgOiBudWxsKVxuICAgICAgICA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0eXBlLCBcInJlZlwiLCB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiAhMSxcbiAgICAgICAgICAgIGdldDogZWxlbWVudFJlZkdldHRlcldpdGhEZXByZWNhdGlvbldhcm5pbmdcbiAgICAgICAgICB9KVxuICAgICAgICA6IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0eXBlLCBcInJlZlwiLCB7IGVudW1lcmFibGU6ICExLCB2YWx1ZTogbnVsbCB9KTtcbiAgICAgIHR5cGUuX3N0b3JlID0ge307XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodHlwZS5fc3RvcmUsIFwidmFsaWRhdGVkXCIsIHtcbiAgICAgICAgY29uZmlndXJhYmxlOiAhMSxcbiAgICAgICAgZW51bWVyYWJsZTogITEsXG4gICAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgICAgdmFsdWU6IDBcbiAgICAgIH0pO1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHR5cGUsIFwiX2RlYnVnSW5mb1wiLCB7XG4gICAgICAgIGNvbmZpZ3VyYWJsZTogITEsXG4gICAgICAgIGVudW1lcmFibGU6ICExLFxuICAgICAgICB3cml0YWJsZTogITAsXG4gICAgICAgIHZhbHVlOiBudWxsXG4gICAgICB9KTtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0eXBlLCBcIl9kZWJ1Z1N0YWNrXCIsIHtcbiAgICAgICAgY29uZmlndXJhYmxlOiAhMSxcbiAgICAgICAgZW51bWVyYWJsZTogITEsXG4gICAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgICAgdmFsdWU6IGRlYnVnU3RhY2tcbiAgICAgIH0pO1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHR5cGUsIFwiX2RlYnVnVGFza1wiLCB7XG4gICAgICAgIGNvbmZpZ3VyYWJsZTogITEsXG4gICAgICAgIGVudW1lcmFibGU6ICExLFxuICAgICAgICB3cml0YWJsZTogITAsXG4gICAgICAgIHZhbHVlOiBkZWJ1Z1Rhc2tcbiAgICAgIH0pO1xuICAgICAgT2JqZWN0LmZyZWV6ZSAmJiAoT2JqZWN0LmZyZWV6ZSh0eXBlLnByb3BzKSwgT2JqZWN0LmZyZWV6ZSh0eXBlKSk7XG4gICAgICByZXR1cm4gdHlwZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gY2xvbmVBbmRSZXBsYWNlS2V5KG9sZEVsZW1lbnQsIG5ld0tleSkge1xuICAgICAgbmV3S2V5ID0gUmVhY3RFbGVtZW50KFxuICAgICAgICBvbGRFbGVtZW50LnR5cGUsXG4gICAgICAgIG5ld0tleSxcbiAgICAgICAgb2xkRWxlbWVudC5wcm9wcyxcbiAgICAgICAgb2xkRWxlbWVudC5fb3duZXIsXG4gICAgICAgIG9sZEVsZW1lbnQuX2RlYnVnU3RhY2ssXG4gICAgICAgIG9sZEVsZW1lbnQuX2RlYnVnVGFza1xuICAgICAgKTtcbiAgICAgIG9sZEVsZW1lbnQuX3N0b3JlICYmXG4gICAgICAgIChuZXdLZXkuX3N0b3JlLnZhbGlkYXRlZCA9IG9sZEVsZW1lbnQuX3N0b3JlLnZhbGlkYXRlZCk7XG4gICAgICByZXR1cm4gbmV3S2V5O1xuICAgIH1cbiAgICBmdW5jdGlvbiB2YWxpZGF0ZUNoaWxkS2V5cyhub2RlKSB7XG4gICAgICBpc1ZhbGlkRWxlbWVudChub2RlKVxuICAgICAgICA/IG5vZGUuX3N0b3JlICYmIChub2RlLl9zdG9yZS52YWxpZGF0ZWQgPSAxKVxuICAgICAgICA6IFwib2JqZWN0XCIgPT09IHR5cGVvZiBub2RlICYmXG4gICAgICAgICAgbnVsbCAhPT0gbm9kZSAmJlxuICAgICAgICAgIG5vZGUuJCR0eXBlb2YgPT09IFJFQUNUX0xBWllfVFlQRSAmJlxuICAgICAgICAgIChcImZ1bGZpbGxlZFwiID09PSBub2RlLl9wYXlsb2FkLnN0YXR1c1xuICAgICAgICAgICAgPyBpc1ZhbGlkRWxlbWVudChub2RlLl9wYXlsb2FkLnZhbHVlKSAmJlxuICAgICAgICAgICAgICBub2RlLl9wYXlsb2FkLnZhbHVlLl9zdG9yZSAmJlxuICAgICAgICAgICAgICAobm9kZS5fcGF5bG9hZC52YWx1ZS5fc3RvcmUudmFsaWRhdGVkID0gMSlcbiAgICAgICAgICAgIDogbm9kZS5fc3RvcmUgJiYgKG5vZGUuX3N0b3JlLnZhbGlkYXRlZCA9IDEpKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaXNWYWxpZEVsZW1lbnQob2JqZWN0KSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICBcIm9iamVjdFwiID09PSB0eXBlb2Ygb2JqZWN0ICYmXG4gICAgICAgIG51bGwgIT09IG9iamVjdCAmJlxuICAgICAgICBvYmplY3QuJCR0eXBlb2YgPT09IFJFQUNUX0VMRU1FTlRfVFlQRVxuICAgICAgKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZXNjYXBlKGtleSkge1xuICAgICAgdmFyIGVzY2FwZXJMb29rdXAgPSB7IFwiPVwiOiBcIj0wXCIsIFwiOlwiOiBcIj0yXCIgfTtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIFwiJFwiICtcbiAgICAgICAga2V5LnJlcGxhY2UoL1s9Ol0vZywgZnVuY3Rpb24gKG1hdGNoKSB7XG4gICAgICAgICAgcmV0dXJuIGVzY2FwZXJMb29rdXBbbWF0Y2hdO1xuICAgICAgICB9KVxuICAgICAgKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0RWxlbWVudEtleShlbGVtZW50LCBpbmRleCkge1xuICAgICAgcmV0dXJuIFwib2JqZWN0XCIgPT09IHR5cGVvZiBlbGVtZW50ICYmXG4gICAgICAgIG51bGwgIT09IGVsZW1lbnQgJiZcbiAgICAgICAgbnVsbCAhPSBlbGVtZW50LmtleVxuICAgICAgICA/IChjaGVja0tleVN0cmluZ0NvZXJjaW9uKGVsZW1lbnQua2V5KSwgZXNjYXBlKFwiXCIgKyBlbGVtZW50LmtleSkpXG4gICAgICAgIDogaW5kZXgudG9TdHJpbmcoMzYpO1xuICAgIH1cbiAgICBmdW5jdGlvbiByZXNvbHZlVGhlbmFibGUodGhlbmFibGUpIHtcbiAgICAgIHN3aXRjaCAodGhlbmFibGUuc3RhdHVzKSB7XG4gICAgICAgIGNhc2UgXCJmdWxmaWxsZWRcIjpcbiAgICAgICAgICByZXR1cm4gdGhlbmFibGUudmFsdWU7XG4gICAgICAgIGNhc2UgXCJyZWplY3RlZFwiOlxuICAgICAgICAgIHRocm93IHRoZW5hYmxlLnJlYXNvbjtcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICBzd2l0Y2ggKFxuICAgICAgICAgICAgKFwic3RyaW5nXCIgPT09IHR5cGVvZiB0aGVuYWJsZS5zdGF0dXNcbiAgICAgICAgICAgICAgPyB0aGVuYWJsZS50aGVuKG5vb3AsIG5vb3ApXG4gICAgICAgICAgICAgIDogKCh0aGVuYWJsZS5zdGF0dXMgPSBcInBlbmRpbmdcIiksXG4gICAgICAgICAgICAgICAgdGhlbmFibGUudGhlbihcbiAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIChmdWxmaWxsZWRWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICBcInBlbmRpbmdcIiA9PT0gdGhlbmFibGUuc3RhdHVzICYmXG4gICAgICAgICAgICAgICAgICAgICAgKCh0aGVuYWJsZS5zdGF0dXMgPSBcImZ1bGZpbGxlZFwiKSxcbiAgICAgICAgICAgICAgICAgICAgICAodGhlbmFibGUudmFsdWUgPSBmdWxmaWxsZWRWYWx1ZSkpO1xuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICBcInBlbmRpbmdcIiA9PT0gdGhlbmFibGUuc3RhdHVzICYmXG4gICAgICAgICAgICAgICAgICAgICAgKCh0aGVuYWJsZS5zdGF0dXMgPSBcInJlamVjdGVkXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICh0aGVuYWJsZS5yZWFzb24gPSBlcnJvcikpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICkpLFxuICAgICAgICAgICAgdGhlbmFibGUuc3RhdHVzKVxuICAgICAgICAgICkge1xuICAgICAgICAgICAgY2FzZSBcImZ1bGZpbGxlZFwiOlxuICAgICAgICAgICAgICByZXR1cm4gdGhlbmFibGUudmFsdWU7XG4gICAgICAgICAgICBjYXNlIFwicmVqZWN0ZWRcIjpcbiAgICAgICAgICAgICAgdGhyb3cgdGhlbmFibGUucmVhc29uO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRocm93IHRoZW5hYmxlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBtYXBJbnRvQXJyYXkoY2hpbGRyZW4sIGFycmF5LCBlc2NhcGVkUHJlZml4LCBuYW1lU29GYXIsIGNhbGxiYWNrKSB7XG4gICAgICB2YXIgdHlwZSA9IHR5cGVvZiBjaGlsZHJlbjtcbiAgICAgIGlmIChcInVuZGVmaW5lZFwiID09PSB0eXBlIHx8IFwiYm9vbGVhblwiID09PSB0eXBlKSBjaGlsZHJlbiA9IG51bGw7XG4gICAgICB2YXIgaW52b2tlQ2FsbGJhY2sgPSAhMTtcbiAgICAgIGlmIChudWxsID09PSBjaGlsZHJlbikgaW52b2tlQ2FsbGJhY2sgPSAhMDtcbiAgICAgIGVsc2VcbiAgICAgICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICAgICAgY2FzZSBcImJpZ2ludFwiOlxuICAgICAgICAgIGNhc2UgXCJzdHJpbmdcIjpcbiAgICAgICAgICBjYXNlIFwibnVtYmVyXCI6XG4gICAgICAgICAgICBpbnZva2VDYWxsYmFjayA9ICEwO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSBcIm9iamVjdFwiOlxuICAgICAgICAgICAgc3dpdGNoIChjaGlsZHJlbi4kJHR5cGVvZikge1xuICAgICAgICAgICAgICBjYXNlIFJFQUNUX0VMRU1FTlRfVFlQRTpcbiAgICAgICAgICAgICAgY2FzZSBSRUFDVF9QT1JUQUxfVFlQRTpcbiAgICAgICAgICAgICAgICBpbnZva2VDYWxsYmFjayA9ICEwO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICBjYXNlIFJFQUNUX0xBWllfVFlQRTpcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgKGludm9rZUNhbGxiYWNrID0gY2hpbGRyZW4uX2luaXQpLFxuICAgICAgICAgICAgICAgICAgbWFwSW50b0FycmF5KFxuICAgICAgICAgICAgICAgICAgICBpbnZva2VDYWxsYmFjayhjaGlsZHJlbi5fcGF5bG9hZCksXG4gICAgICAgICAgICAgICAgICAgIGFycmF5LFxuICAgICAgICAgICAgICAgICAgICBlc2NhcGVkUHJlZml4LFxuICAgICAgICAgICAgICAgICAgICBuYW1lU29GYXIsXG4gICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgaWYgKGludm9rZUNhbGxiYWNrKSB7XG4gICAgICAgIGludm9rZUNhbGxiYWNrID0gY2hpbGRyZW47XG4gICAgICAgIGNhbGxiYWNrID0gY2FsbGJhY2soaW52b2tlQ2FsbGJhY2spO1xuICAgICAgICB2YXIgY2hpbGRLZXkgPVxuICAgICAgICAgIFwiXCIgPT09IG5hbWVTb0ZhciA/IFwiLlwiICsgZ2V0RWxlbWVudEtleShpbnZva2VDYWxsYmFjaywgMCkgOiBuYW1lU29GYXI7XG4gICAgICAgIGlzQXJyYXlJbXBsKGNhbGxiYWNrKVxuICAgICAgICAgID8gKChlc2NhcGVkUHJlZml4ID0gXCJcIiksXG4gICAgICAgICAgICBudWxsICE9IGNoaWxkS2V5ICYmXG4gICAgICAgICAgICAgIChlc2NhcGVkUHJlZml4ID1cbiAgICAgICAgICAgICAgICBjaGlsZEtleS5yZXBsYWNlKHVzZXJQcm92aWRlZEtleUVzY2FwZVJlZ2V4LCBcIiQmL1wiKSArIFwiL1wiKSxcbiAgICAgICAgICAgIG1hcEludG9BcnJheShjYWxsYmFjaywgYXJyYXksIGVzY2FwZWRQcmVmaXgsIFwiXCIsIGZ1bmN0aW9uIChjKSB7XG4gICAgICAgICAgICAgIHJldHVybiBjO1xuICAgICAgICAgICAgfSkpXG4gICAgICAgICAgOiBudWxsICE9IGNhbGxiYWNrICYmXG4gICAgICAgICAgICAoaXNWYWxpZEVsZW1lbnQoY2FsbGJhY2spICYmXG4gICAgICAgICAgICAgIChudWxsICE9IGNhbGxiYWNrLmtleSAmJlxuICAgICAgICAgICAgICAgICgoaW52b2tlQ2FsbGJhY2sgJiYgaW52b2tlQ2FsbGJhY2sua2V5ID09PSBjYWxsYmFjay5rZXkpIHx8XG4gICAgICAgICAgICAgICAgICBjaGVja0tleVN0cmluZ0NvZXJjaW9uKGNhbGxiYWNrLmtleSkpLFxuICAgICAgICAgICAgICAoZXNjYXBlZFByZWZpeCA9IGNsb25lQW5kUmVwbGFjZUtleShcbiAgICAgICAgICAgICAgICBjYWxsYmFjayxcbiAgICAgICAgICAgICAgICBlc2NhcGVkUHJlZml4ICtcbiAgICAgICAgICAgICAgICAgIChudWxsID09IGNhbGxiYWNrLmtleSB8fFxuICAgICAgICAgICAgICAgICAgKGludm9rZUNhbGxiYWNrICYmIGludm9rZUNhbGxiYWNrLmtleSA9PT0gY2FsbGJhY2sua2V5KVxuICAgICAgICAgICAgICAgICAgICA/IFwiXCJcbiAgICAgICAgICAgICAgICAgICAgOiAoXCJcIiArIGNhbGxiYWNrLmtleSkucmVwbGFjZShcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJQcm92aWRlZEtleUVzY2FwZVJlZ2V4LFxuICAgICAgICAgICAgICAgICAgICAgICAgXCIkJi9cIlxuICAgICAgICAgICAgICAgICAgICAgICkgKyBcIi9cIikgK1xuICAgICAgICAgICAgICAgICAgY2hpbGRLZXlcbiAgICAgICAgICAgICAgKSksXG4gICAgICAgICAgICAgIFwiXCIgIT09IG5hbWVTb0ZhciAmJlxuICAgICAgICAgICAgICAgIG51bGwgIT0gaW52b2tlQ2FsbGJhY2sgJiZcbiAgICAgICAgICAgICAgICBpc1ZhbGlkRWxlbWVudChpbnZva2VDYWxsYmFjaykgJiZcbiAgICAgICAgICAgICAgICBudWxsID09IGludm9rZUNhbGxiYWNrLmtleSAmJlxuICAgICAgICAgICAgICAgIGludm9rZUNhbGxiYWNrLl9zdG9yZSAmJlxuICAgICAgICAgICAgICAgICFpbnZva2VDYWxsYmFjay5fc3RvcmUudmFsaWRhdGVkICYmXG4gICAgICAgICAgICAgICAgKGVzY2FwZWRQcmVmaXguX3N0b3JlLnZhbGlkYXRlZCA9IDIpLFxuICAgICAgICAgICAgICAoY2FsbGJhY2sgPSBlc2NhcGVkUHJlZml4KSksXG4gICAgICAgICAgICBhcnJheS5wdXNoKGNhbGxiYWNrKSk7XG4gICAgICAgIHJldHVybiAxO1xuICAgICAgfVxuICAgICAgaW52b2tlQ2FsbGJhY2sgPSAwO1xuICAgICAgY2hpbGRLZXkgPSBcIlwiID09PSBuYW1lU29GYXIgPyBcIi5cIiA6IG5hbWVTb0ZhciArIFwiOlwiO1xuICAgICAgaWYgKGlzQXJyYXlJbXBsKGNoaWxkcmVuKSlcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKylcbiAgICAgICAgICAobmFtZVNvRmFyID0gY2hpbGRyZW5baV0pLFxuICAgICAgICAgICAgKHR5cGUgPSBjaGlsZEtleSArIGdldEVsZW1lbnRLZXkobmFtZVNvRmFyLCBpKSksXG4gICAgICAgICAgICAoaW52b2tlQ2FsbGJhY2sgKz0gbWFwSW50b0FycmF5KFxuICAgICAgICAgICAgICBuYW1lU29GYXIsXG4gICAgICAgICAgICAgIGFycmF5LFxuICAgICAgICAgICAgICBlc2NhcGVkUHJlZml4LFxuICAgICAgICAgICAgICB0eXBlLFxuICAgICAgICAgICAgICBjYWxsYmFja1xuICAgICAgICAgICAgKSk7XG4gICAgICBlbHNlIGlmICgoKGkgPSBnZXRJdGVyYXRvckZuKGNoaWxkcmVuKSksIFwiZnVuY3Rpb25cIiA9PT0gdHlwZW9mIGkpKVxuICAgICAgICBmb3IgKFxuICAgICAgICAgIGkgPT09IGNoaWxkcmVuLmVudHJpZXMgJiZcbiAgICAgICAgICAgIChkaWRXYXJuQWJvdXRNYXBzIHx8XG4gICAgICAgICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAgICAgICBcIlVzaW5nIE1hcHMgYXMgY2hpbGRyZW4gaXMgbm90IHN1cHBvcnRlZC4gVXNlIGFuIGFycmF5IG9mIGtleWVkIFJlYWN0RWxlbWVudHMgaW5zdGVhZC5cIlxuICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgKGRpZFdhcm5BYm91dE1hcHMgPSAhMCkpLFxuICAgICAgICAgICAgY2hpbGRyZW4gPSBpLmNhbGwoY2hpbGRyZW4pLFxuICAgICAgICAgICAgaSA9IDA7XG4gICAgICAgICAgIShuYW1lU29GYXIgPSBjaGlsZHJlbi5uZXh0KCkpLmRvbmU7XG5cbiAgICAgICAgKVxuICAgICAgICAgIChuYW1lU29GYXIgPSBuYW1lU29GYXIudmFsdWUpLFxuICAgICAgICAgICAgKHR5cGUgPSBjaGlsZEtleSArIGdldEVsZW1lbnRLZXkobmFtZVNvRmFyLCBpKyspKSxcbiAgICAgICAgICAgIChpbnZva2VDYWxsYmFjayArPSBtYXBJbnRvQXJyYXkoXG4gICAgICAgICAgICAgIG5hbWVTb0ZhcixcbiAgICAgICAgICAgICAgYXJyYXksXG4gICAgICAgICAgICAgIGVzY2FwZWRQcmVmaXgsXG4gICAgICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgICAgIGNhbGxiYWNrXG4gICAgICAgICAgICApKTtcbiAgICAgIGVsc2UgaWYgKFwib2JqZWN0XCIgPT09IHR5cGUpIHtcbiAgICAgICAgaWYgKFwiZnVuY3Rpb25cIiA9PT0gdHlwZW9mIGNoaWxkcmVuLnRoZW4pXG4gICAgICAgICAgcmV0dXJuIG1hcEludG9BcnJheShcbiAgICAgICAgICAgIHJlc29sdmVUaGVuYWJsZShjaGlsZHJlbiksXG4gICAgICAgICAgICBhcnJheSxcbiAgICAgICAgICAgIGVzY2FwZWRQcmVmaXgsXG4gICAgICAgICAgICBuYW1lU29GYXIsXG4gICAgICAgICAgICBjYWxsYmFja1xuICAgICAgICAgICk7XG4gICAgICAgIGFycmF5ID0gU3RyaW5nKGNoaWxkcmVuKTtcbiAgICAgICAgdGhyb3cgRXJyb3IoXG4gICAgICAgICAgXCJPYmplY3RzIGFyZSBub3QgdmFsaWQgYXMgYSBSZWFjdCBjaGlsZCAoZm91bmQ6IFwiICtcbiAgICAgICAgICAgIChcIltvYmplY3QgT2JqZWN0XVwiID09PSBhcnJheVxuICAgICAgICAgICAgICA/IFwib2JqZWN0IHdpdGgga2V5cyB7XCIgKyBPYmplY3Qua2V5cyhjaGlsZHJlbikuam9pbihcIiwgXCIpICsgXCJ9XCJcbiAgICAgICAgICAgICAgOiBhcnJheSkgK1xuICAgICAgICAgICAgXCIpLiBJZiB5b3UgbWVhbnQgdG8gcmVuZGVyIGEgY29sbGVjdGlvbiBvZiBjaGlsZHJlbiwgdXNlIGFuIGFycmF5IGluc3RlYWQuXCJcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBpbnZva2VDYWxsYmFjaztcbiAgICB9XG4gICAgZnVuY3Rpb24gbWFwQ2hpbGRyZW4oY2hpbGRyZW4sIGZ1bmMsIGNvbnRleHQpIHtcbiAgICAgIGlmIChudWxsID09IGNoaWxkcmVuKSByZXR1cm4gY2hpbGRyZW47XG4gICAgICB2YXIgcmVzdWx0ID0gW10sXG4gICAgICAgIGNvdW50ID0gMDtcbiAgICAgIG1hcEludG9BcnJheShjaGlsZHJlbiwgcmVzdWx0LCBcIlwiLCBcIlwiLCBmdW5jdGlvbiAoY2hpbGQpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmMuY2FsbChjb250ZXh0LCBjaGlsZCwgY291bnQrKyk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGxhenlJbml0aWFsaXplcihwYXlsb2FkKSB7XG4gICAgICBpZiAoLTEgPT09IHBheWxvYWQuX3N0YXR1cykge1xuICAgICAgICB2YXIgaW9JbmZvID0gcGF5bG9hZC5faW9JbmZvO1xuICAgICAgICBudWxsICE9IGlvSW5mbyAmJiAoaW9JbmZvLnN0YXJ0ID0gaW9JbmZvLmVuZCA9IHBlcmZvcm1hbmNlLm5vdygpKTtcbiAgICAgICAgaW9JbmZvID0gcGF5bG9hZC5fcmVzdWx0O1xuICAgICAgICB2YXIgdGhlbmFibGUgPSBpb0luZm8oKTtcbiAgICAgICAgdGhlbmFibGUudGhlbihcbiAgICAgICAgICBmdW5jdGlvbiAobW9kdWxlT2JqZWN0KSB7XG4gICAgICAgICAgICBpZiAoMCA9PT0gcGF5bG9hZC5fc3RhdHVzIHx8IC0xID09PSBwYXlsb2FkLl9zdGF0dXMpIHtcbiAgICAgICAgICAgICAgcGF5bG9hZC5fc3RhdHVzID0gMTtcbiAgICAgICAgICAgICAgcGF5bG9hZC5fcmVzdWx0ID0gbW9kdWxlT2JqZWN0O1xuICAgICAgICAgICAgICB2YXIgX2lvSW5mbyA9IHBheWxvYWQuX2lvSW5mbztcbiAgICAgICAgICAgICAgbnVsbCAhPSBfaW9JbmZvICYmIChfaW9JbmZvLmVuZCA9IHBlcmZvcm1hbmNlLm5vdygpKTtcbiAgICAgICAgICAgICAgdm9pZCAwID09PSB0aGVuYWJsZS5zdGF0dXMgJiZcbiAgICAgICAgICAgICAgICAoKHRoZW5hYmxlLnN0YXR1cyA9IFwiZnVsZmlsbGVkXCIpLFxuICAgICAgICAgICAgICAgICh0aGVuYWJsZS52YWx1ZSA9IG1vZHVsZU9iamVjdCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgICAgICAgICBpZiAoMCA9PT0gcGF5bG9hZC5fc3RhdHVzIHx8IC0xID09PSBwYXlsb2FkLl9zdGF0dXMpIHtcbiAgICAgICAgICAgICAgcGF5bG9hZC5fc3RhdHVzID0gMjtcbiAgICAgICAgICAgICAgcGF5bG9hZC5fcmVzdWx0ID0gZXJyb3I7XG4gICAgICAgICAgICAgIHZhciBfaW9JbmZvMiA9IHBheWxvYWQuX2lvSW5mbztcbiAgICAgICAgICAgICAgbnVsbCAhPSBfaW9JbmZvMiAmJiAoX2lvSW5mbzIuZW5kID0gcGVyZm9ybWFuY2Uubm93KCkpO1xuICAgICAgICAgICAgICB2b2lkIDAgPT09IHRoZW5hYmxlLnN0YXR1cyAmJlxuICAgICAgICAgICAgICAgICgodGhlbmFibGUuc3RhdHVzID0gXCJyZWplY3RlZFwiKSwgKHRoZW5hYmxlLnJlYXNvbiA9IGVycm9yKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICBpb0luZm8gPSBwYXlsb2FkLl9pb0luZm87XG4gICAgICAgIGlmIChudWxsICE9IGlvSW5mbykge1xuICAgICAgICAgIGlvSW5mby52YWx1ZSA9IHRoZW5hYmxlO1xuICAgICAgICAgIHZhciBkaXNwbGF5TmFtZSA9IHRoZW5hYmxlLmRpc3BsYXlOYW1lO1xuICAgICAgICAgIFwic3RyaW5nXCIgPT09IHR5cGVvZiBkaXNwbGF5TmFtZSAmJiAoaW9JbmZvLm5hbWUgPSBkaXNwbGF5TmFtZSk7XG4gICAgICAgIH1cbiAgICAgICAgLTEgPT09IHBheWxvYWQuX3N0YXR1cyAmJlxuICAgICAgICAgICgocGF5bG9hZC5fc3RhdHVzID0gMCksIChwYXlsb2FkLl9yZXN1bHQgPSB0aGVuYWJsZSkpO1xuICAgICAgfVxuICAgICAgaWYgKDEgPT09IHBheWxvYWQuX3N0YXR1cylcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAoaW9JbmZvID0gcGF5bG9hZC5fcmVzdWx0KSxcbiAgICAgICAgICB2b2lkIDAgPT09IGlvSW5mbyAmJlxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICAgICAgXCJsYXp5OiBFeHBlY3RlZCB0aGUgcmVzdWx0IG9mIGEgZHluYW1pYyBpbXBvcnQoKSBjYWxsLiBJbnN0ZWFkIHJlY2VpdmVkOiAlc1xcblxcbllvdXIgY29kZSBzaG91bGQgbG9vayBsaWtlOiBcXG4gIGNvbnN0IE15Q29tcG9uZW50ID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4vTXlDb21wb25lbnQnKSlcXG5cXG5EaWQgeW91IGFjY2lkZW50YWxseSBwdXQgY3VybHkgYnJhY2VzIGFyb3VuZCB0aGUgaW1wb3J0P1wiLFxuICAgICAgICAgICAgICBpb0luZm9cbiAgICAgICAgICAgICksXG4gICAgICAgICAgXCJkZWZhdWx0XCIgaW4gaW9JbmZvIHx8XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgICAgICBcImxhenk6IEV4cGVjdGVkIHRoZSByZXN1bHQgb2YgYSBkeW5hbWljIGltcG9ydCgpIGNhbGwuIEluc3RlYWQgcmVjZWl2ZWQ6ICVzXFxuXFxuWW91ciBjb2RlIHNob3VsZCBsb29rIGxpa2U6IFxcbiAgY29uc3QgTXlDb21wb25lbnQgPSBsYXp5KCgpID0+IGltcG9ydCgnLi9NeUNvbXBvbmVudCcpKVwiLFxuICAgICAgICAgICAgICBpb0luZm9cbiAgICAgICAgICAgICksXG4gICAgICAgICAgaW9JbmZvLmRlZmF1bHRcbiAgICAgICAgKTtcbiAgICAgIHRocm93IHBheWxvYWQuX3Jlc3VsdDtcbiAgICB9XG4gICAgZnVuY3Rpb24gcmVzb2x2ZURpc3BhdGNoZXIoKSB7XG4gICAgICB2YXIgZGlzcGF0Y2hlciA9IFJlYWN0U2hhcmVkSW50ZXJuYWxzLkg7XG4gICAgICBudWxsID09PSBkaXNwYXRjaGVyICYmXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgXCJJbnZhbGlkIGhvb2sgY2FsbC4gSG9va3MgY2FuIG9ubHkgYmUgY2FsbGVkIGluc2lkZSBvZiB0aGUgYm9keSBvZiBhIGZ1bmN0aW9uIGNvbXBvbmVudC4gVGhpcyBjb3VsZCBoYXBwZW4gZm9yIG9uZSBvZiB0aGUgZm9sbG93aW5nIHJlYXNvbnM6XFxuMS4gWW91IG1pZ2h0IGhhdmUgbWlzbWF0Y2hpbmcgdmVyc2lvbnMgb2YgUmVhY3QgYW5kIHRoZSByZW5kZXJlciAoc3VjaCBhcyBSZWFjdCBET00pXFxuMi4gWW91IG1pZ2h0IGJlIGJyZWFraW5nIHRoZSBSdWxlcyBvZiBIb29rc1xcbjMuIFlvdSBtaWdodCBoYXZlIG1vcmUgdGhhbiBvbmUgY29weSBvZiBSZWFjdCBpbiB0aGUgc2FtZSBhcHBcXG5TZWUgaHR0cHM6Ly9yZWFjdC5kZXYvbGluay9pbnZhbGlkLWhvb2stY2FsbCBmb3IgdGlwcyBhYm91dCBob3cgdG8gZGVidWcgYW5kIGZpeCB0aGlzIHByb2JsZW0uXCJcbiAgICAgICAgKTtcbiAgICAgIHJldHVybiBkaXNwYXRjaGVyO1xuICAgIH1cbiAgICBmdW5jdGlvbiByZWxlYXNlQXN5bmNUcmFuc2l0aW9uKCkge1xuICAgICAgUmVhY3RTaGFyZWRJbnRlcm5hbHMuYXN5bmNUcmFuc2l0aW9ucy0tO1xuICAgIH1cbiAgICBmdW5jdGlvbiBlbnF1ZXVlVGFzayh0YXNrKSB7XG4gICAgICBpZiAobnVsbCA9PT0gZW5xdWV1ZVRhc2tJbXBsKVxuICAgICAgICB0cnkge1xuICAgICAgICAgIHZhciByZXF1aXJlU3RyaW5nID0gKFwicmVxdWlyZVwiICsgTWF0aC5yYW5kb20oKSkuc2xpY2UoMCwgNyk7XG4gICAgICAgICAgZW5xdWV1ZVRhc2tJbXBsID0gKG1vZHVsZSAmJiBtb2R1bGVbcmVxdWlyZVN0cmluZ10pLmNhbGwoXG4gICAgICAgICAgICBtb2R1bGUsXG4gICAgICAgICAgICBcInRpbWVyc1wiXG4gICAgICAgICAgKS5zZXRJbW1lZGlhdGU7XG4gICAgICAgIH0gY2F0Y2ggKF9lcnIpIHtcbiAgICAgICAgICBlbnF1ZXVlVGFza0ltcGwgPSBmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgICAgICAgICAgICExID09PSBkaWRXYXJuQWJvdXRNZXNzYWdlQ2hhbm5lbCAmJlxuICAgICAgICAgICAgICAoKGRpZFdhcm5BYm91dE1lc3NhZ2VDaGFubmVsID0gITApLFxuICAgICAgICAgICAgICBcInVuZGVmaW5lZFwiID09PSB0eXBlb2YgTWVzc2FnZUNoYW5uZWwgJiZcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgICAgICAgICAgXCJUaGlzIGJyb3dzZXIgZG9lcyBub3QgaGF2ZSBhIE1lc3NhZ2VDaGFubmVsIGltcGxlbWVudGF0aW9uLCBzbyBlbnF1ZXVpbmcgdGFza3MgdmlhIGF3YWl0IGFjdChhc3luYyAoKSA9PiAuLi4pIHdpbGwgZmFpbC4gUGxlYXNlIGZpbGUgYW4gaXNzdWUgYXQgaHR0cHM6Ly9naXRodWIuY29tL2ZhY2Vib29rL3JlYWN0L2lzc3VlcyBpZiB5b3UgZW5jb3VudGVyIHRoaXMgd2FybmluZy5cIlxuICAgICAgICAgICAgICAgICkpO1xuICAgICAgICAgICAgdmFyIGNoYW5uZWwgPSBuZXcgTWVzc2FnZUNoYW5uZWwoKTtcbiAgICAgICAgICAgIGNoYW5uZWwucG9ydDEub25tZXNzYWdlID0gY2FsbGJhY2s7XG4gICAgICAgICAgICBjaGFubmVsLnBvcnQyLnBvc3RNZXNzYWdlKHZvaWQgMCk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgcmV0dXJuIGVucXVldWVUYXNrSW1wbCh0YXNrKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gYWdncmVnYXRlRXJyb3JzKGVycm9ycykge1xuICAgICAgcmV0dXJuIDEgPCBlcnJvcnMubGVuZ3RoICYmIFwiZnVuY3Rpb25cIiA9PT0gdHlwZW9mIEFnZ3JlZ2F0ZUVycm9yXG4gICAgICAgID8gbmV3IEFnZ3JlZ2F0ZUVycm9yKGVycm9ycylcbiAgICAgICAgOiBlcnJvcnNbMF07XG4gICAgfVxuICAgIGZ1bmN0aW9uIHBvcEFjdFNjb3BlKHByZXZBY3RRdWV1ZSwgcHJldkFjdFNjb3BlRGVwdGgpIHtcbiAgICAgIHByZXZBY3RTY29wZURlcHRoICE9PSBhY3RTY29wZURlcHRoIC0gMSAmJlxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiWW91IHNlZW0gdG8gaGF2ZSBvdmVybGFwcGluZyBhY3QoKSBjYWxscywgdGhpcyBpcyBub3Qgc3VwcG9ydGVkLiBCZSBzdXJlIHRvIGF3YWl0IHByZXZpb3VzIGFjdCgpIGNhbGxzIGJlZm9yZSBtYWtpbmcgYSBuZXcgb25lLiBcIlxuICAgICAgICApO1xuICAgICAgYWN0U2NvcGVEZXB0aCA9IHByZXZBY3RTY29wZURlcHRoO1xuICAgIH1cbiAgICBmdW5jdGlvbiByZWN1cnNpdmVseUZsdXNoQXN5bmNBY3RXb3JrKHJldHVyblZhbHVlLCByZXNvbHZlLCByZWplY3QpIHtcbiAgICAgIHZhciBxdWV1ZSA9IFJlYWN0U2hhcmVkSW50ZXJuYWxzLmFjdFF1ZXVlO1xuICAgICAgaWYgKG51bGwgIT09IHF1ZXVlKVxuICAgICAgICBpZiAoMCAhPT0gcXVldWUubGVuZ3RoKVxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBmbHVzaEFjdFF1ZXVlKHF1ZXVlKTtcbiAgICAgICAgICAgIGVucXVldWVUYXNrKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHJlY3Vyc2l2ZWx5Rmx1c2hBc3luY0FjdFdvcmsocmV0dXJuVmFsdWUsIHJlc29sdmUsIHJlamVjdCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgUmVhY3RTaGFyZWRJbnRlcm5hbHMudGhyb3duRXJyb3JzLnB1c2goZXJyb3IpO1xuICAgICAgICAgIH1cbiAgICAgICAgZWxzZSBSZWFjdFNoYXJlZEludGVybmFscy5hY3RRdWV1ZSA9IG51bGw7XG4gICAgICAwIDwgUmVhY3RTaGFyZWRJbnRlcm5hbHMudGhyb3duRXJyb3JzLmxlbmd0aFxuICAgICAgICA/ICgocXVldWUgPSBhZ2dyZWdhdGVFcnJvcnMoUmVhY3RTaGFyZWRJbnRlcm5hbHMudGhyb3duRXJyb3JzKSksXG4gICAgICAgICAgKFJlYWN0U2hhcmVkSW50ZXJuYWxzLnRocm93bkVycm9ycy5sZW5ndGggPSAwKSxcbiAgICAgICAgICByZWplY3QocXVldWUpKVxuICAgICAgICA6IHJlc29sdmUocmV0dXJuVmFsdWUpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBmbHVzaEFjdFF1ZXVlKHF1ZXVlKSB7XG4gICAgICBpZiAoIWlzRmx1c2hpbmcpIHtcbiAgICAgICAgaXNGbHVzaGluZyA9ICEwO1xuICAgICAgICB2YXIgaSA9IDA7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgZm9yICg7IGkgPCBxdWV1ZS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdmFyIGNhbGxiYWNrID0gcXVldWVbaV07XG4gICAgICAgICAgICBkbyB7XG4gICAgICAgICAgICAgIFJlYWN0U2hhcmVkSW50ZXJuYWxzLmRpZFVzZVByb21pc2UgPSAhMTtcbiAgICAgICAgICAgICAgdmFyIGNvbnRpbnVhdGlvbiA9IGNhbGxiYWNrKCExKTtcbiAgICAgICAgICAgICAgaWYgKG51bGwgIT09IGNvbnRpbnVhdGlvbikge1xuICAgICAgICAgICAgICAgIGlmIChSZWFjdFNoYXJlZEludGVybmFscy5kaWRVc2VQcm9taXNlKSB7XG4gICAgICAgICAgICAgICAgICBxdWV1ZVtpXSA9IGNhbGxiYWNrO1xuICAgICAgICAgICAgICAgICAgcXVldWUuc3BsaWNlKDAsIGkpO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYWxsYmFjayA9IGNvbnRpbnVhdGlvbjtcbiAgICAgICAgICAgICAgfSBlbHNlIGJyZWFrO1xuICAgICAgICAgICAgfSB3aGlsZSAoMSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgcXVldWUuc3BsaWNlKDAsIGkgKyAxKSwgUmVhY3RTaGFyZWRJbnRlcm5hbHMudGhyb3duRXJyb3JzLnB1c2goZXJyb3IpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgIGlzRmx1c2hpbmcgPSAhMTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBcInVuZGVmaW5lZFwiICE9PSB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fICYmXG4gICAgICBcImZ1bmN0aW9uXCIgPT09XG4gICAgICAgIHR5cGVvZiBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0YXJ0ICYmXG4gICAgICBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0YXJ0KEVycm9yKCkpO1xuICAgIHZhciBSRUFDVF9FTEVNRU5UX1RZUEUgPSBTeW1ib2wuZm9yKFwicmVhY3QudHJhbnNpdGlvbmFsLmVsZW1lbnRcIiksXG4gICAgICBSRUFDVF9QT1JUQUxfVFlQRSA9IFN5bWJvbC5mb3IoXCJyZWFjdC5wb3J0YWxcIiksXG4gICAgICBSRUFDVF9GUkFHTUVOVF9UWVBFID0gU3ltYm9sLmZvcihcInJlYWN0LmZyYWdtZW50XCIpLFxuICAgICAgUkVBQ1RfU1RSSUNUX01PREVfVFlQRSA9IFN5bWJvbC5mb3IoXCJyZWFjdC5zdHJpY3RfbW9kZVwiKSxcbiAgICAgIFJFQUNUX1BST0ZJTEVSX1RZUEUgPSBTeW1ib2wuZm9yKFwicmVhY3QucHJvZmlsZXJcIiksXG4gICAgICBSRUFDVF9DT05TVU1FUl9UWVBFID0gU3ltYm9sLmZvcihcInJlYWN0LmNvbnN1bWVyXCIpLFxuICAgICAgUkVBQ1RfQ09OVEVYVF9UWVBFID0gU3ltYm9sLmZvcihcInJlYWN0LmNvbnRleHRcIiksXG4gICAgICBSRUFDVF9GT1JXQVJEX1JFRl9UWVBFID0gU3ltYm9sLmZvcihcInJlYWN0LmZvcndhcmRfcmVmXCIpLFxuICAgICAgUkVBQ1RfU1VTUEVOU0VfVFlQRSA9IFN5bWJvbC5mb3IoXCJyZWFjdC5zdXNwZW5zZVwiKSxcbiAgICAgIFJFQUNUX1NVU1BFTlNFX0xJU1RfVFlQRSA9IFN5bWJvbC5mb3IoXCJyZWFjdC5zdXNwZW5zZV9saXN0XCIpLFxuICAgICAgUkVBQ1RfTUVNT19UWVBFID0gU3ltYm9sLmZvcihcInJlYWN0Lm1lbW9cIiksXG4gICAgICBSRUFDVF9MQVpZX1RZUEUgPSBTeW1ib2wuZm9yKFwicmVhY3QubGF6eVwiKSxcbiAgICAgIFJFQUNUX0FDVElWSVRZX1RZUEUgPSBTeW1ib2wuZm9yKFwicmVhY3QuYWN0aXZpdHlcIiksXG4gICAgICBNQVlCRV9JVEVSQVRPUl9TWU1CT0wgPSBTeW1ib2wuaXRlcmF0b3IsXG4gICAgICBkaWRXYXJuU3RhdGVVcGRhdGVGb3JVbm1vdW50ZWRDb21wb25lbnQgPSB7fSxcbiAgICAgIFJlYWN0Tm9vcFVwZGF0ZVF1ZXVlID0ge1xuICAgICAgICBpc01vdW50ZWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICByZXR1cm4gITE7XG4gICAgICAgIH0sXG4gICAgICAgIGVucXVldWVGb3JjZVVwZGF0ZTogZnVuY3Rpb24gKHB1YmxpY0luc3RhbmNlKSB7XG4gICAgICAgICAgd2Fybk5vb3AocHVibGljSW5zdGFuY2UsIFwiZm9yY2VVcGRhdGVcIik7XG4gICAgICAgIH0sXG4gICAgICAgIGVucXVldWVSZXBsYWNlU3RhdGU6IGZ1bmN0aW9uIChwdWJsaWNJbnN0YW5jZSkge1xuICAgICAgICAgIHdhcm5Ob29wKHB1YmxpY0luc3RhbmNlLCBcInJlcGxhY2VTdGF0ZVwiKTtcbiAgICAgICAgfSxcbiAgICAgICAgZW5xdWV1ZVNldFN0YXRlOiBmdW5jdGlvbiAocHVibGljSW5zdGFuY2UpIHtcbiAgICAgICAgICB3YXJuTm9vcChwdWJsaWNJbnN0YW5jZSwgXCJzZXRTdGF0ZVwiKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIGFzc2lnbiA9IE9iamVjdC5hc3NpZ24sXG4gICAgICBlbXB0eU9iamVjdCA9IHt9O1xuICAgIE9iamVjdC5mcmVlemUoZW1wdHlPYmplY3QpO1xuICAgIENvbXBvbmVudC5wcm90b3R5cGUuaXNSZWFjdENvbXBvbmVudCA9IHt9O1xuICAgIENvbXBvbmVudC5wcm90b3R5cGUuc2V0U3RhdGUgPSBmdW5jdGlvbiAocGFydGlhbFN0YXRlLCBjYWxsYmFjaykge1xuICAgICAgaWYgKFxuICAgICAgICBcIm9iamVjdFwiICE9PSB0eXBlb2YgcGFydGlhbFN0YXRlICYmXG4gICAgICAgIFwiZnVuY3Rpb25cIiAhPT0gdHlwZW9mIHBhcnRpYWxTdGF0ZSAmJlxuICAgICAgICBudWxsICE9IHBhcnRpYWxTdGF0ZVxuICAgICAgKVxuICAgICAgICB0aHJvdyBFcnJvcihcbiAgICAgICAgICBcInRha2VzIGFuIG9iamVjdCBvZiBzdGF0ZSB2YXJpYWJsZXMgdG8gdXBkYXRlIG9yIGEgZnVuY3Rpb24gd2hpY2ggcmV0dXJucyBhbiBvYmplY3Qgb2Ygc3RhdGUgdmFyaWFibGVzLlwiXG4gICAgICAgICk7XG4gICAgICB0aGlzLnVwZGF0ZXIuZW5xdWV1ZVNldFN0YXRlKHRoaXMsIHBhcnRpYWxTdGF0ZSwgY2FsbGJhY2ssIFwic2V0U3RhdGVcIik7XG4gICAgfTtcbiAgICBDb21wb25lbnQucHJvdG90eXBlLmZvcmNlVXBkYXRlID0gZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gICAgICB0aGlzLnVwZGF0ZXIuZW5xdWV1ZUZvcmNlVXBkYXRlKHRoaXMsIGNhbGxiYWNrLCBcImZvcmNlVXBkYXRlXCIpO1xuICAgIH07XG4gICAgdmFyIGRlcHJlY2F0ZWRBUElzID0ge1xuICAgICAgaXNNb3VudGVkOiBbXG4gICAgICAgIFwiaXNNb3VudGVkXCIsXG4gICAgICAgIFwiSW5zdGVhZCwgbWFrZSBzdXJlIHRvIGNsZWFuIHVwIHN1YnNjcmlwdGlvbnMgYW5kIHBlbmRpbmcgcmVxdWVzdHMgaW4gY29tcG9uZW50V2lsbFVubW91bnQgdG8gcHJldmVudCBtZW1vcnkgbGVha3MuXCJcbiAgICAgIF0sXG4gICAgICByZXBsYWNlU3RhdGU6IFtcbiAgICAgICAgXCJyZXBsYWNlU3RhdGVcIixcbiAgICAgICAgXCJSZWZhY3RvciB5b3VyIGNvZGUgdG8gdXNlIHNldFN0YXRlIGluc3RlYWQgKHNlZSBodHRwczovL2dpdGh1Yi5jb20vZmFjZWJvb2svcmVhY3QvaXNzdWVzLzMyMzYpLlwiXG4gICAgICBdXG4gICAgfTtcbiAgICBmb3IgKGZuTmFtZSBpbiBkZXByZWNhdGVkQVBJcylcbiAgICAgIGRlcHJlY2F0ZWRBUElzLmhhc093blByb3BlcnR5KGZuTmFtZSkgJiZcbiAgICAgICAgZGVmaW5lRGVwcmVjYXRpb25XYXJuaW5nKGZuTmFtZSwgZGVwcmVjYXRlZEFQSXNbZm5OYW1lXSk7XG4gICAgQ29tcG9uZW50RHVtbXkucHJvdG90eXBlID0gQ29tcG9uZW50LnByb3RvdHlwZTtcbiAgICBkZXByZWNhdGVkQVBJcyA9IFB1cmVDb21wb25lbnQucHJvdG90eXBlID0gbmV3IENvbXBvbmVudER1bW15KCk7XG4gICAgZGVwcmVjYXRlZEFQSXMuY29uc3RydWN0b3IgPSBQdXJlQ29tcG9uZW50O1xuICAgIGFzc2lnbihkZXByZWNhdGVkQVBJcywgQ29tcG9uZW50LnByb3RvdHlwZSk7XG4gICAgZGVwcmVjYXRlZEFQSXMuaXNQdXJlUmVhY3RDb21wb25lbnQgPSAhMDtcbiAgICB2YXIgaXNBcnJheUltcGwgPSBBcnJheS5pc0FycmF5LFxuICAgICAgUkVBQ1RfQ0xJRU5UX1JFRkVSRU5DRSA9IFN5bWJvbC5mb3IoXCJyZWFjdC5jbGllbnQucmVmZXJlbmNlXCIpLFxuICAgICAgUmVhY3RTaGFyZWRJbnRlcm5hbHMgPSB7XG4gICAgICAgIEg6IG51bGwsXG4gICAgICAgIEE6IG51bGwsXG4gICAgICAgIFQ6IG51bGwsXG4gICAgICAgIFM6IG51bGwsXG4gICAgICAgIGFjdFF1ZXVlOiBudWxsLFxuICAgICAgICBhc3luY1RyYW5zaXRpb25zOiAwLFxuICAgICAgICBpc0JhdGNoaW5nTGVnYWN5OiAhMSxcbiAgICAgICAgZGlkU2NoZWR1bGVMZWdhY3lVcGRhdGU6ICExLFxuICAgICAgICBkaWRVc2VQcm9taXNlOiAhMSxcbiAgICAgICAgdGhyb3duRXJyb3JzOiBbXSxcbiAgICAgICAgZ2V0Q3VycmVudFN0YWNrOiBudWxsLFxuICAgICAgICByZWNlbnRseUNyZWF0ZWRPd25lclN0YWNrczogMFxuICAgICAgfSxcbiAgICAgIGhhc093blByb3BlcnR5ID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eSxcbiAgICAgIGNyZWF0ZVRhc2sgPSBjb25zb2xlLmNyZWF0ZVRhc2tcbiAgICAgICAgPyBjb25zb2xlLmNyZWF0ZVRhc2tcbiAgICAgICAgOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICB9O1xuICAgIGRlcHJlY2F0ZWRBUElzID0ge1xuICAgICAgcmVhY3Rfc3RhY2tfYm90dG9tX2ZyYW1lOiBmdW5jdGlvbiAoY2FsbFN0YWNrRm9yRXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIGNhbGxTdGFja0ZvckVycm9yKCk7XG4gICAgICB9XG4gICAgfTtcbiAgICB2YXIgc3BlY2lhbFByb3BLZXlXYXJuaW5nU2hvd24sIGRpZFdhcm5BYm91dE9sZEpTWFJ1bnRpbWU7XG4gICAgdmFyIGRpZFdhcm5BYm91dEVsZW1lbnRSZWYgPSB7fTtcbiAgICB2YXIgdW5rbm93bk93bmVyRGVidWdTdGFjayA9IGRlcHJlY2F0ZWRBUElzLnJlYWN0X3N0YWNrX2JvdHRvbV9mcmFtZS5iaW5kKFxuICAgICAgZGVwcmVjYXRlZEFQSXMsXG4gICAgICBVbmtub3duT3duZXJcbiAgICApKCk7XG4gICAgdmFyIHVua25vd25Pd25lckRlYnVnVGFzayA9IGNyZWF0ZVRhc2soZ2V0VGFza05hbWUoVW5rbm93bk93bmVyKSk7XG4gICAgdmFyIGRpZFdhcm5BYm91dE1hcHMgPSAhMSxcbiAgICAgIHVzZXJQcm92aWRlZEtleUVzY2FwZVJlZ2V4ID0gL1xcLysvZyxcbiAgICAgIHJlcG9ydEdsb2JhbEVycm9yID1cbiAgICAgICAgXCJmdW5jdGlvblwiID09PSB0eXBlb2YgcmVwb3J0RXJyb3JcbiAgICAgICAgICA/IHJlcG9ydEVycm9yXG4gICAgICAgICAgOiBmdW5jdGlvbiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgIFwib2JqZWN0XCIgPT09IHR5cGVvZiB3aW5kb3cgJiZcbiAgICAgICAgICAgICAgICBcImZ1bmN0aW9uXCIgPT09IHR5cGVvZiB3aW5kb3cuRXJyb3JFdmVudFxuICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICB2YXIgZXZlbnQgPSBuZXcgd2luZG93LkVycm9yRXZlbnQoXCJlcnJvclwiLCB7XG4gICAgICAgICAgICAgICAgICBidWJibGVzOiAhMCxcbiAgICAgICAgICAgICAgICAgIGNhbmNlbGFibGU6ICEwLFxuICAgICAgICAgICAgICAgICAgbWVzc2FnZTpcbiAgICAgICAgICAgICAgICAgICAgXCJvYmplY3RcIiA9PT0gdHlwZW9mIGVycm9yICYmXG4gICAgICAgICAgICAgICAgICAgIG51bGwgIT09IGVycm9yICYmXG4gICAgICAgICAgICAgICAgICAgIFwic3RyaW5nXCIgPT09IHR5cGVvZiBlcnJvci5tZXNzYWdlXG4gICAgICAgICAgICAgICAgICAgICAgPyBTdHJpbmcoZXJyb3IubWVzc2FnZSlcbiAgICAgICAgICAgICAgICAgICAgICA6IFN0cmluZyhlcnJvciksXG4gICAgICAgICAgICAgICAgICBlcnJvcjogZXJyb3JcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBpZiAoIXdpbmRvdy5kaXNwYXRjaEV2ZW50KGV2ZW50KSkgcmV0dXJuO1xuICAgICAgICAgICAgICB9IGVsc2UgaWYgKFxuICAgICAgICAgICAgICAgIFwib2JqZWN0XCIgPT09IHR5cGVvZiBwcm9jZXNzICYmXG4gICAgICAgICAgICAgICAgXCJmdW5jdGlvblwiID09PSB0eXBlb2YgcHJvY2Vzcy5lbWl0XG4gICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgIHByb2Nlc3MuZW1pdChcInVuY2F1Z2h0RXhjZXB0aW9uXCIsIGVycm9yKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgICAgICB9LFxuICAgICAgZGlkV2FybkFib3V0TWVzc2FnZUNoYW5uZWwgPSAhMSxcbiAgICAgIGVucXVldWVUYXNrSW1wbCA9IG51bGwsXG4gICAgICBhY3RTY29wZURlcHRoID0gMCxcbiAgICAgIGRpZFdhcm5Ob0F3YWl0QWN0ID0gITEsXG4gICAgICBpc0ZsdXNoaW5nID0gITEsXG4gICAgICBxdWV1ZVNldmVyYWxNaWNyb3Rhc2tzID1cbiAgICAgICAgXCJmdW5jdGlvblwiID09PSB0eXBlb2YgcXVldWVNaWNyb3Rhc2tcbiAgICAgICAgICA/IGZ1bmN0aW9uIChjYWxsYmFjaykge1xuICAgICAgICAgICAgICBxdWV1ZU1pY3JvdGFzayhmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHF1ZXVlTWljcm90YXNrKGNhbGxiYWNrKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgOiBlbnF1ZXVlVGFzaztcbiAgICBkZXByZWNhdGVkQVBJcyA9IE9iamVjdC5mcmVlemUoe1xuICAgICAgX19wcm90b19fOiBudWxsLFxuICAgICAgYzogZnVuY3Rpb24gKHNpemUpIHtcbiAgICAgICAgcmV0dXJuIHJlc29sdmVEaXNwYXRjaGVyKCkudXNlTWVtb0NhY2hlKHNpemUpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHZhciBmbk5hbWUgPSB7XG4gICAgICBtYXA6IG1hcENoaWxkcmVuLFxuICAgICAgZm9yRWFjaDogZnVuY3Rpb24gKGNoaWxkcmVuLCBmb3JFYWNoRnVuYywgZm9yRWFjaENvbnRleHQpIHtcbiAgICAgICAgbWFwQ2hpbGRyZW4oXG4gICAgICAgICAgY2hpbGRyZW4sXG4gICAgICAgICAgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgZm9yRWFjaEZ1bmMuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIGZvckVhY2hDb250ZXh0XG4gICAgICAgICk7XG4gICAgICB9LFxuICAgICAgY291bnQ6IGZ1bmN0aW9uIChjaGlsZHJlbikge1xuICAgICAgICB2YXIgbiA9IDA7XG4gICAgICAgIG1hcENoaWxkcmVuKGNoaWxkcmVuLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgbisrO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIG47XG4gICAgICB9LFxuICAgICAgdG9BcnJheTogZnVuY3Rpb24gKGNoaWxkcmVuKSB7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgbWFwQ2hpbGRyZW4oY2hpbGRyZW4sIGZ1bmN0aW9uIChjaGlsZCkge1xuICAgICAgICAgICAgcmV0dXJuIGNoaWxkO1xuICAgICAgICAgIH0pIHx8IFtdXG4gICAgICAgICk7XG4gICAgICB9LFxuICAgICAgb25seTogZnVuY3Rpb24gKGNoaWxkcmVuKSB7XG4gICAgICAgIGlmICghaXNWYWxpZEVsZW1lbnQoY2hpbGRyZW4pKVxuICAgICAgICAgIHRocm93IEVycm9yKFxuICAgICAgICAgICAgXCJSZWFjdC5DaGlsZHJlbi5vbmx5IGV4cGVjdGVkIHRvIHJlY2VpdmUgYSBzaW5nbGUgUmVhY3QgZWxlbWVudCBjaGlsZC5cIlxuICAgICAgICAgICk7XG4gICAgICAgIHJldHVybiBjaGlsZHJlbjtcbiAgICAgIH1cbiAgICB9O1xuICAgIGV4cG9ydHMuQWN0aXZpdHkgPSBSRUFDVF9BQ1RJVklUWV9UWVBFO1xuICAgIGV4cG9ydHMuQ2hpbGRyZW4gPSBmbk5hbWU7XG4gICAgZXhwb3J0cy5Db21wb25lbnQgPSBDb21wb25lbnQ7XG4gICAgZXhwb3J0cy5GcmFnbWVudCA9IFJFQUNUX0ZSQUdNRU5UX1RZUEU7XG4gICAgZXhwb3J0cy5Qcm9maWxlciA9IFJFQUNUX1BST0ZJTEVSX1RZUEU7XG4gICAgZXhwb3J0cy5QdXJlQ29tcG9uZW50ID0gUHVyZUNvbXBvbmVudDtcbiAgICBleHBvcnRzLlN0cmljdE1vZGUgPSBSRUFDVF9TVFJJQ1RfTU9ERV9UWVBFO1xuICAgIGV4cG9ydHMuU3VzcGVuc2UgPSBSRUFDVF9TVVNQRU5TRV9UWVBFO1xuICAgIGV4cG9ydHMuX19DTElFTlRfSU5URVJOQUxTX0RPX05PVF9VU0VfT1JfV0FSTl9VU0VSU19USEVZX0NBTk5PVF9VUEdSQURFID1cbiAgICAgIFJlYWN0U2hhcmVkSW50ZXJuYWxzO1xuICAgIGV4cG9ydHMuX19DT01QSUxFUl9SVU5USU1FID0gZGVwcmVjYXRlZEFQSXM7XG4gICAgZXhwb3J0cy5hY3QgPSBmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgICAgIHZhciBwcmV2QWN0UXVldWUgPSBSZWFjdFNoYXJlZEludGVybmFscy5hY3RRdWV1ZSxcbiAgICAgICAgcHJldkFjdFNjb3BlRGVwdGggPSBhY3RTY29wZURlcHRoO1xuICAgICAgYWN0U2NvcGVEZXB0aCsrO1xuICAgICAgdmFyIHF1ZXVlID0gKFJlYWN0U2hhcmVkSW50ZXJuYWxzLmFjdFF1ZXVlID1cbiAgICAgICAgICBudWxsICE9PSBwcmV2QWN0UXVldWUgPyBwcmV2QWN0UXVldWUgOiBbXSksXG4gICAgICAgIGRpZEF3YWl0QWN0Q2FsbCA9ICExO1xuICAgICAgdHJ5IHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IGNhbGxiYWNrKCk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBSZWFjdFNoYXJlZEludGVybmFscy50aHJvd25FcnJvcnMucHVzaChlcnJvcik7XG4gICAgICB9XG4gICAgICBpZiAoMCA8IFJlYWN0U2hhcmVkSW50ZXJuYWxzLnRocm93bkVycm9ycy5sZW5ndGgpXG4gICAgICAgIHRocm93IChcbiAgICAgICAgICAocG9wQWN0U2NvcGUocHJldkFjdFF1ZXVlLCBwcmV2QWN0U2NvcGVEZXB0aCksXG4gICAgICAgICAgKGNhbGxiYWNrID0gYWdncmVnYXRlRXJyb3JzKFJlYWN0U2hhcmVkSW50ZXJuYWxzLnRocm93bkVycm9ycykpLFxuICAgICAgICAgIChSZWFjdFNoYXJlZEludGVybmFscy50aHJvd25FcnJvcnMubGVuZ3RoID0gMCksXG4gICAgICAgICAgY2FsbGJhY2spXG4gICAgICAgICk7XG4gICAgICBpZiAoXG4gICAgICAgIG51bGwgIT09IHJlc3VsdCAmJlxuICAgICAgICBcIm9iamVjdFwiID09PSB0eXBlb2YgcmVzdWx0ICYmXG4gICAgICAgIFwiZnVuY3Rpb25cIiA9PT0gdHlwZW9mIHJlc3VsdC50aGVuXG4gICAgICApIHtcbiAgICAgICAgdmFyIHRoZW5hYmxlID0gcmVzdWx0O1xuICAgICAgICBxdWV1ZVNldmVyYWxNaWNyb3Rhc2tzKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBkaWRBd2FpdEFjdENhbGwgfHxcbiAgICAgICAgICAgIGRpZFdhcm5Ob0F3YWl0QWN0IHx8XG4gICAgICAgICAgICAoKGRpZFdhcm5Ob0F3YWl0QWN0ID0gITApLFxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICAgICAgXCJZb3UgY2FsbGVkIGFjdChhc3luYyAoKSA9PiAuLi4pIHdpdGhvdXQgYXdhaXQuIFRoaXMgY291bGQgbGVhZCB0byB1bmV4cGVjdGVkIHRlc3RpbmcgYmVoYXZpb3VyLCBpbnRlcmxlYXZpbmcgbXVsdGlwbGUgYWN0IGNhbGxzIGFuZCBtaXhpbmcgdGhlaXIgc2NvcGVzLiBZb3Ugc2hvdWxkIC0gYXdhaXQgYWN0KGFzeW5jICgpID0+IC4uLik7XCJcbiAgICAgICAgICAgICkpO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB0aGVuOiBmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICBkaWRBd2FpdEFjdENhbGwgPSAhMDtcbiAgICAgICAgICAgIHRoZW5hYmxlLnRoZW4oXG4gICAgICAgICAgICAgIGZ1bmN0aW9uIChyZXR1cm5WYWx1ZSkge1xuICAgICAgICAgICAgICAgIHBvcEFjdFNjb3BlKHByZXZBY3RRdWV1ZSwgcHJldkFjdFNjb3BlRGVwdGgpO1xuICAgICAgICAgICAgICAgIGlmICgwID09PSBwcmV2QWN0U2NvcGVEZXB0aCkge1xuICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgZmx1c2hBY3RRdWV1ZShxdWV1ZSksXG4gICAgICAgICAgICAgICAgICAgICAgZW5xdWV1ZVRhc2soZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlY3Vyc2l2ZWx5Rmx1c2hBc3luY0FjdFdvcmsoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVyblZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICByZWplY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvciQwKSB7XG4gICAgICAgICAgICAgICAgICAgIFJlYWN0U2hhcmVkSW50ZXJuYWxzLnRocm93bkVycm9ycy5wdXNoKGVycm9yJDApO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgaWYgKDAgPCBSZWFjdFNoYXJlZEludGVybmFscy50aHJvd25FcnJvcnMubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBfdGhyb3duRXJyb3IgPSBhZ2dyZWdhdGVFcnJvcnMoXG4gICAgICAgICAgICAgICAgICAgICAgUmVhY3RTaGFyZWRJbnRlcm5hbHMudGhyb3duRXJyb3JzXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIFJlYWN0U2hhcmVkSW50ZXJuYWxzLnRocm93bkVycm9ycy5sZW5ndGggPSAwO1xuICAgICAgICAgICAgICAgICAgICByZWplY3QoX3Rocm93bkVycm9yKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2UgcmVzb2x2ZShyZXR1cm5WYWx1ZSk7XG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGZ1bmN0aW9uIChlcnJvcikge1xuICAgICAgICAgICAgICAgIHBvcEFjdFNjb3BlKHByZXZBY3RRdWV1ZSwgcHJldkFjdFNjb3BlRGVwdGgpO1xuICAgICAgICAgICAgICAgIDAgPCBSZWFjdFNoYXJlZEludGVybmFscy50aHJvd25FcnJvcnMubGVuZ3RoXG4gICAgICAgICAgICAgICAgICA/ICgoZXJyb3IgPSBhZ2dyZWdhdGVFcnJvcnMoXG4gICAgICAgICAgICAgICAgICAgICAgUmVhY3RTaGFyZWRJbnRlcm5hbHMudGhyb3duRXJyb3JzXG4gICAgICAgICAgICAgICAgICAgICkpLFxuICAgICAgICAgICAgICAgICAgICAoUmVhY3RTaGFyZWRJbnRlcm5hbHMudGhyb3duRXJyb3JzLmxlbmd0aCA9IDApLFxuICAgICAgICAgICAgICAgICAgICByZWplY3QoZXJyb3IpKVxuICAgICAgICAgICAgICAgICAgOiByZWplY3QoZXJyb3IpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHZhciByZXR1cm5WYWx1ZSRqc2NvbXAkMCA9IHJlc3VsdDtcbiAgICAgIHBvcEFjdFNjb3BlKHByZXZBY3RRdWV1ZSwgcHJldkFjdFNjb3BlRGVwdGgpO1xuICAgICAgMCA9PT0gcHJldkFjdFNjb3BlRGVwdGggJiZcbiAgICAgICAgKGZsdXNoQWN0UXVldWUocXVldWUpLFxuICAgICAgICAwICE9PSBxdWV1ZS5sZW5ndGggJiZcbiAgICAgICAgICBxdWV1ZVNldmVyYWxNaWNyb3Rhc2tzKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGRpZEF3YWl0QWN0Q2FsbCB8fFxuICAgICAgICAgICAgICBkaWRXYXJuTm9Bd2FpdEFjdCB8fFxuICAgICAgICAgICAgICAoKGRpZFdhcm5Ob0F3YWl0QWN0ID0gITApLFxuICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgICAgICAgIFwiQSBjb21wb25lbnQgc3VzcGVuZGVkIGluc2lkZSBhbiBgYWN0YCBzY29wZSwgYnV0IHRoZSBgYWN0YCBjYWxsIHdhcyBub3QgYXdhaXRlZC4gV2hlbiB0ZXN0aW5nIFJlYWN0IGNvbXBvbmVudHMgdGhhdCBkZXBlbmQgb24gYXN5bmNocm9ub3VzIGRhdGEsIHlvdSBtdXN0IGF3YWl0IHRoZSByZXN1bHQ6XFxuXFxuYXdhaXQgYWN0KCgpID0+IC4uLilcIlxuICAgICAgICAgICAgICApKTtcbiAgICAgICAgICB9KSxcbiAgICAgICAgKFJlYWN0U2hhcmVkSW50ZXJuYWxzLmFjdFF1ZXVlID0gbnVsbCkpO1xuICAgICAgaWYgKDAgPCBSZWFjdFNoYXJlZEludGVybmFscy50aHJvd25FcnJvcnMubGVuZ3RoKVxuICAgICAgICB0aHJvdyAoXG4gICAgICAgICAgKChjYWxsYmFjayA9IGFnZ3JlZ2F0ZUVycm9ycyhSZWFjdFNoYXJlZEludGVybmFscy50aHJvd25FcnJvcnMpKSxcbiAgICAgICAgICAoUmVhY3RTaGFyZWRJbnRlcm5hbHMudGhyb3duRXJyb3JzLmxlbmd0aCA9IDApLFxuICAgICAgICAgIGNhbGxiYWNrKVxuICAgICAgICApO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdGhlbjogZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgIGRpZEF3YWl0QWN0Q2FsbCA9ICEwO1xuICAgICAgICAgIDAgPT09IHByZXZBY3RTY29wZURlcHRoXG4gICAgICAgICAgICA/ICgoUmVhY3RTaGFyZWRJbnRlcm5hbHMuYWN0UXVldWUgPSBxdWV1ZSksXG4gICAgICAgICAgICAgIGVucXVldWVUYXNrKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVjdXJzaXZlbHlGbHVzaEFzeW5jQWN0V29yayhcbiAgICAgICAgICAgICAgICAgIHJldHVyblZhbHVlJGpzY29tcCQwLFxuICAgICAgICAgICAgICAgICAgcmVzb2x2ZSxcbiAgICAgICAgICAgICAgICAgIHJlamVjdFxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgOiByZXNvbHZlKHJldHVyblZhbHVlJGpzY29tcCQwKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9O1xuICAgIGV4cG9ydHMuY2FjaGUgPSBmdW5jdGlvbiAoZm4pIHtcbiAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBmbi5hcHBseShudWxsLCBhcmd1bWVudHMpO1xuICAgICAgfTtcbiAgICB9O1xuICAgIGV4cG9ydHMuY2FjaGVTaWduYWwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9O1xuICAgIGV4cG9ydHMuY2FwdHVyZU93bmVyU3RhY2sgPSBmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgZ2V0Q3VycmVudFN0YWNrID0gUmVhY3RTaGFyZWRJbnRlcm5hbHMuZ2V0Q3VycmVudFN0YWNrO1xuICAgICAgcmV0dXJuIG51bGwgPT09IGdldEN1cnJlbnRTdGFjayA/IG51bGwgOiBnZXRDdXJyZW50U3RhY2soKTtcbiAgICB9O1xuICAgIGV4cG9ydHMuY2xvbmVFbGVtZW50ID0gZnVuY3Rpb24gKGVsZW1lbnQsIGNvbmZpZywgY2hpbGRyZW4pIHtcbiAgICAgIGlmIChudWxsID09PSBlbGVtZW50IHx8IHZvaWQgMCA9PT0gZWxlbWVudClcbiAgICAgICAgdGhyb3cgRXJyb3IoXG4gICAgICAgICAgXCJUaGUgYXJndW1lbnQgbXVzdCBiZSBhIFJlYWN0IGVsZW1lbnQsIGJ1dCB5b3UgcGFzc2VkIFwiICtcbiAgICAgICAgICAgIGVsZW1lbnQgK1xuICAgICAgICAgICAgXCIuXCJcbiAgICAgICAgKTtcbiAgICAgIHZhciBwcm9wcyA9IGFzc2lnbih7fSwgZWxlbWVudC5wcm9wcyksXG4gICAgICAgIGtleSA9IGVsZW1lbnQua2V5LFxuICAgICAgICBvd25lciA9IGVsZW1lbnQuX293bmVyO1xuICAgICAgaWYgKG51bGwgIT0gY29uZmlnKSB7XG4gICAgICAgIHZhciBKU0NvbXBpbGVyX2lubGluZV9yZXN1bHQ7XG4gICAgICAgIGE6IHtcbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICBoYXNPd25Qcm9wZXJ0eS5jYWxsKGNvbmZpZywgXCJyZWZcIikgJiZcbiAgICAgICAgICAgIChKU0NvbXBpbGVyX2lubGluZV9yZXN1bHQgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKFxuICAgICAgICAgICAgICBjb25maWcsXG4gICAgICAgICAgICAgIFwicmVmXCJcbiAgICAgICAgICAgICkuZ2V0KSAmJlxuICAgICAgICAgICAgSlNDb21waWxlcl9pbmxpbmVfcmVzdWx0LmlzUmVhY3RXYXJuaW5nXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICBKU0NvbXBpbGVyX2lubGluZV9yZXN1bHQgPSAhMTtcbiAgICAgICAgICAgIGJyZWFrIGE7XG4gICAgICAgICAgfVxuICAgICAgICAgIEpTQ29tcGlsZXJfaW5saW5lX3Jlc3VsdCA9IHZvaWQgMCAhPT0gY29uZmlnLnJlZjtcbiAgICAgICAgfVxuICAgICAgICBKU0NvbXBpbGVyX2lubGluZV9yZXN1bHQgJiYgKG93bmVyID0gZ2V0T3duZXIoKSk7XG4gICAgICAgIGhhc1ZhbGlkS2V5KGNvbmZpZykgJiZcbiAgICAgICAgICAoY2hlY2tLZXlTdHJpbmdDb2VyY2lvbihjb25maWcua2V5KSwgKGtleSA9IFwiXCIgKyBjb25maWcua2V5KSk7XG4gICAgICAgIGZvciAocHJvcE5hbWUgaW4gY29uZmlnKVxuICAgICAgICAgICFoYXNPd25Qcm9wZXJ0eS5jYWxsKGNvbmZpZywgcHJvcE5hbWUpIHx8XG4gICAgICAgICAgICBcImtleVwiID09PSBwcm9wTmFtZSB8fFxuICAgICAgICAgICAgXCJfX3NlbGZcIiA9PT0gcHJvcE5hbWUgfHxcbiAgICAgICAgICAgIFwiX19zb3VyY2VcIiA9PT0gcHJvcE5hbWUgfHxcbiAgICAgICAgICAgIChcInJlZlwiID09PSBwcm9wTmFtZSAmJiB2b2lkIDAgPT09IGNvbmZpZy5yZWYpIHx8XG4gICAgICAgICAgICAocHJvcHNbcHJvcE5hbWVdID0gY29uZmlnW3Byb3BOYW1lXSk7XG4gICAgICB9XG4gICAgICB2YXIgcHJvcE5hbWUgPSBhcmd1bWVudHMubGVuZ3RoIC0gMjtcbiAgICAgIGlmICgxID09PSBwcm9wTmFtZSkgcHJvcHMuY2hpbGRyZW4gPSBjaGlsZHJlbjtcbiAgICAgIGVsc2UgaWYgKDEgPCBwcm9wTmFtZSkge1xuICAgICAgICBKU0NvbXBpbGVyX2lubGluZV9yZXN1bHQgPSBBcnJheShwcm9wTmFtZSk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcE5hbWU7IGkrKylcbiAgICAgICAgICBKU0NvbXBpbGVyX2lubGluZV9yZXN1bHRbaV0gPSBhcmd1bWVudHNbaSArIDJdO1xuICAgICAgICBwcm9wcy5jaGlsZHJlbiA9IEpTQ29tcGlsZXJfaW5saW5lX3Jlc3VsdDtcbiAgICAgIH1cbiAgICAgIHByb3BzID0gUmVhY3RFbGVtZW50KFxuICAgICAgICBlbGVtZW50LnR5cGUsXG4gICAgICAgIGtleSxcbiAgICAgICAgcHJvcHMsXG4gICAgICAgIG93bmVyLFxuICAgICAgICBlbGVtZW50Ll9kZWJ1Z1N0YWNrLFxuICAgICAgICBlbGVtZW50Ll9kZWJ1Z1Rhc2tcbiAgICAgICk7XG4gICAgICBmb3IgKGtleSA9IDI7IGtleSA8IGFyZ3VtZW50cy5sZW5ndGg7IGtleSsrKVxuICAgICAgICB2YWxpZGF0ZUNoaWxkS2V5cyhhcmd1bWVudHNba2V5XSk7XG4gICAgICByZXR1cm4gcHJvcHM7XG4gICAgfTtcbiAgICBleHBvcnRzLmNyZWF0ZUNvbnRleHQgPSBmdW5jdGlvbiAoZGVmYXVsdFZhbHVlKSB7XG4gICAgICBkZWZhdWx0VmFsdWUgPSB7XG4gICAgICAgICQkdHlwZW9mOiBSRUFDVF9DT05URVhUX1RZUEUsXG4gICAgICAgIF9jdXJyZW50VmFsdWU6IGRlZmF1bHRWYWx1ZSxcbiAgICAgICAgX2N1cnJlbnRWYWx1ZTI6IGRlZmF1bHRWYWx1ZSxcbiAgICAgICAgX3RocmVhZENvdW50OiAwLFxuICAgICAgICBQcm92aWRlcjogbnVsbCxcbiAgICAgICAgQ29uc3VtZXI6IG51bGxcbiAgICAgIH07XG4gICAgICBkZWZhdWx0VmFsdWUuUHJvdmlkZXIgPSBkZWZhdWx0VmFsdWU7XG4gICAgICBkZWZhdWx0VmFsdWUuQ29uc3VtZXIgPSB7XG4gICAgICAgICQkdHlwZW9mOiBSRUFDVF9DT05TVU1FUl9UWVBFLFxuICAgICAgICBfY29udGV4dDogZGVmYXVsdFZhbHVlXG4gICAgICB9O1xuICAgICAgZGVmYXVsdFZhbHVlLl9jdXJyZW50UmVuZGVyZXIgPSBudWxsO1xuICAgICAgZGVmYXVsdFZhbHVlLl9jdXJyZW50UmVuZGVyZXIyID0gbnVsbDtcbiAgICAgIHJldHVybiBkZWZhdWx0VmFsdWU7XG4gICAgfTtcbiAgICBleHBvcnRzLmNyZWF0ZUVsZW1lbnQgPSBmdW5jdGlvbiAodHlwZSwgY29uZmlnLCBjaGlsZHJlbikge1xuICAgICAgZm9yICh2YXIgaSA9IDI7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspXG4gICAgICAgIHZhbGlkYXRlQ2hpbGRLZXlzKGFyZ3VtZW50c1tpXSk7XG4gICAgICBpID0ge307XG4gICAgICB2YXIga2V5ID0gbnVsbDtcbiAgICAgIGlmIChudWxsICE9IGNvbmZpZylcbiAgICAgICAgZm9yIChwcm9wTmFtZSBpbiAoZGlkV2FybkFib3V0T2xkSlNYUnVudGltZSB8fFxuICAgICAgICAgICEoXCJfX3NlbGZcIiBpbiBjb25maWcpIHx8XG4gICAgICAgICAgXCJrZXlcIiBpbiBjb25maWcgfHxcbiAgICAgICAgICAoKGRpZFdhcm5BYm91dE9sZEpTWFJ1bnRpbWUgPSAhMCksXG4gICAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgICAgXCJZb3VyIGFwcCAob3Igb25lIG9mIGl0cyBkZXBlbmRlbmNpZXMpIGlzIHVzaW5nIGFuIG91dGRhdGVkIEpTWCB0cmFuc2Zvcm0uIFVwZGF0ZSB0byB0aGUgbW9kZXJuIEpTWCB0cmFuc2Zvcm0gZm9yIGZhc3RlciBwZXJmb3JtYW5jZTogaHR0cHM6Ly9yZWFjdC5kZXYvbGluay9uZXctanN4LXRyYW5zZm9ybVwiXG4gICAgICAgICAgKSksXG4gICAgICAgIGhhc1ZhbGlkS2V5KGNvbmZpZykgJiZcbiAgICAgICAgICAoY2hlY2tLZXlTdHJpbmdDb2VyY2lvbihjb25maWcua2V5KSwgKGtleSA9IFwiXCIgKyBjb25maWcua2V5KSksXG4gICAgICAgIGNvbmZpZykpXG4gICAgICAgICAgaGFzT3duUHJvcGVydHkuY2FsbChjb25maWcsIHByb3BOYW1lKSAmJlxuICAgICAgICAgICAgXCJrZXlcIiAhPT0gcHJvcE5hbWUgJiZcbiAgICAgICAgICAgIFwiX19zZWxmXCIgIT09IHByb3BOYW1lICYmXG4gICAgICAgICAgICBcIl9fc291cmNlXCIgIT09IHByb3BOYW1lICYmXG4gICAgICAgICAgICAoaVtwcm9wTmFtZV0gPSBjb25maWdbcHJvcE5hbWVdKTtcbiAgICAgIHZhciBjaGlsZHJlbkxlbmd0aCA9IGFyZ3VtZW50cy5sZW5ndGggLSAyO1xuICAgICAgaWYgKDEgPT09IGNoaWxkcmVuTGVuZ3RoKSBpLmNoaWxkcmVuID0gY2hpbGRyZW47XG4gICAgICBlbHNlIGlmICgxIDwgY2hpbGRyZW5MZW5ndGgpIHtcbiAgICAgICAgZm9yIChcbiAgICAgICAgICB2YXIgY2hpbGRBcnJheSA9IEFycmF5KGNoaWxkcmVuTGVuZ3RoKSwgX2kgPSAwO1xuICAgICAgICAgIF9pIDwgY2hpbGRyZW5MZW5ndGg7XG4gICAgICAgICAgX2krK1xuICAgICAgICApXG4gICAgICAgICAgY2hpbGRBcnJheVtfaV0gPSBhcmd1bWVudHNbX2kgKyAyXTtcbiAgICAgICAgT2JqZWN0LmZyZWV6ZSAmJiBPYmplY3QuZnJlZXplKGNoaWxkQXJyYXkpO1xuICAgICAgICBpLmNoaWxkcmVuID0gY2hpbGRBcnJheTtcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlICYmIHR5cGUuZGVmYXVsdFByb3BzKVxuICAgICAgICBmb3IgKHByb3BOYW1lIGluICgoY2hpbGRyZW5MZW5ndGggPSB0eXBlLmRlZmF1bHRQcm9wcyksIGNoaWxkcmVuTGVuZ3RoKSlcbiAgICAgICAgICB2b2lkIDAgPT09IGlbcHJvcE5hbWVdICYmIChpW3Byb3BOYW1lXSA9IGNoaWxkcmVuTGVuZ3RoW3Byb3BOYW1lXSk7XG4gICAgICBrZXkgJiZcbiAgICAgICAgZGVmaW5lS2V5UHJvcFdhcm5pbmdHZXR0ZXIoXG4gICAgICAgICAgaSxcbiAgICAgICAgICBcImZ1bmN0aW9uXCIgPT09IHR5cGVvZiB0eXBlXG4gICAgICAgICAgICA/IHR5cGUuZGlzcGxheU5hbWUgfHwgdHlwZS5uYW1lIHx8IFwiVW5rbm93blwiXG4gICAgICAgICAgICA6IHR5cGVcbiAgICAgICAgKTtcbiAgICAgIHZhciBwcm9wTmFtZSA9IDFlNCA+IFJlYWN0U2hhcmVkSW50ZXJuYWxzLnJlY2VudGx5Q3JlYXRlZE93bmVyU3RhY2tzKys7XG4gICAgICByZXR1cm4gUmVhY3RFbGVtZW50KFxuICAgICAgICB0eXBlLFxuICAgICAgICBrZXksXG4gICAgICAgIGksXG4gICAgICAgIGdldE93bmVyKCksXG4gICAgICAgIHByb3BOYW1lID8gRXJyb3IoXCJyZWFjdC1zdGFjay10b3AtZnJhbWVcIikgOiB1bmtub3duT3duZXJEZWJ1Z1N0YWNrLFxuICAgICAgICBwcm9wTmFtZSA/IGNyZWF0ZVRhc2soZ2V0VGFza05hbWUodHlwZSkpIDogdW5rbm93bk93bmVyRGVidWdUYXNrXG4gICAgICApO1xuICAgIH07XG4gICAgZXhwb3J0cy5jcmVhdGVSZWYgPSBmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgcmVmT2JqZWN0ID0geyBjdXJyZW50OiBudWxsIH07XG4gICAgICBPYmplY3Quc2VhbChyZWZPYmplY3QpO1xuICAgICAgcmV0dXJuIHJlZk9iamVjdDtcbiAgICB9O1xuICAgIGV4cG9ydHMuZm9yd2FyZFJlZiA9IGZ1bmN0aW9uIChyZW5kZXIpIHtcbiAgICAgIG51bGwgIT0gcmVuZGVyICYmIHJlbmRlci4kJHR5cGVvZiA9PT0gUkVBQ1RfTUVNT19UWVBFXG4gICAgICAgID8gY29uc29sZS5lcnJvcihcbiAgICAgICAgICAgIFwiZm9yd2FyZFJlZiByZXF1aXJlcyBhIHJlbmRlciBmdW5jdGlvbiBidXQgcmVjZWl2ZWQgYSBgbWVtb2AgY29tcG9uZW50LiBJbnN0ZWFkIG9mIGZvcndhcmRSZWYobWVtbyguLi4pKSwgdXNlIG1lbW8oZm9yd2FyZFJlZiguLi4pKS5cIlxuICAgICAgICAgIClcbiAgICAgICAgOiBcImZ1bmN0aW9uXCIgIT09IHR5cGVvZiByZW5kZXJcbiAgICAgICAgICA/IGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgICAgIFwiZm9yd2FyZFJlZiByZXF1aXJlcyBhIHJlbmRlciBmdW5jdGlvbiBidXQgd2FzIGdpdmVuICVzLlwiLFxuICAgICAgICAgICAgICBudWxsID09PSByZW5kZXIgPyBcIm51bGxcIiA6IHR5cGVvZiByZW5kZXJcbiAgICAgICAgICAgIClcbiAgICAgICAgICA6IDAgIT09IHJlbmRlci5sZW5ndGggJiZcbiAgICAgICAgICAgIDIgIT09IHJlbmRlci5sZW5ndGggJiZcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgICAgIFwiZm9yd2FyZFJlZiByZW5kZXIgZnVuY3Rpb25zIGFjY2VwdCBleGFjdGx5IHR3byBwYXJhbWV0ZXJzOiBwcm9wcyBhbmQgcmVmLiAlc1wiLFxuICAgICAgICAgICAgICAxID09PSByZW5kZXIubGVuZ3RoXG4gICAgICAgICAgICAgICAgPyBcIkRpZCB5b3UgZm9yZ2V0IHRvIHVzZSB0aGUgcmVmIHBhcmFtZXRlcj9cIlxuICAgICAgICAgICAgICAgIDogXCJBbnkgYWRkaXRpb25hbCBwYXJhbWV0ZXIgd2lsbCBiZSB1bmRlZmluZWQuXCJcbiAgICAgICAgICAgICk7XG4gICAgICBudWxsICE9IHJlbmRlciAmJlxuICAgICAgICBudWxsICE9IHJlbmRlci5kZWZhdWx0UHJvcHMgJiZcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcImZvcndhcmRSZWYgcmVuZGVyIGZ1bmN0aW9ucyBkbyBub3Qgc3VwcG9ydCBkZWZhdWx0UHJvcHMuIERpZCB5b3UgYWNjaWRlbnRhbGx5IHBhc3MgYSBSZWFjdCBjb21wb25lbnQ/XCJcbiAgICAgICAgKTtcbiAgICAgIHZhciBlbGVtZW50VHlwZSA9IHsgJCR0eXBlb2Y6IFJFQUNUX0ZPUldBUkRfUkVGX1RZUEUsIHJlbmRlcjogcmVuZGVyIH0sXG4gICAgICAgIG93bk5hbWU7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZWxlbWVudFR5cGUsIFwiZGlzcGxheU5hbWVcIiwge1xuICAgICAgICBlbnVtZXJhYmxlOiAhMSxcbiAgICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIG93bk5hbWU7XG4gICAgICAgIH0sXG4gICAgICAgIHNldDogZnVuY3Rpb24gKG5hbWUpIHtcbiAgICAgICAgICBvd25OYW1lID0gbmFtZTtcbiAgICAgICAgICByZW5kZXIubmFtZSB8fFxuICAgICAgICAgICAgcmVuZGVyLmRpc3BsYXlOYW1lIHx8XG4gICAgICAgICAgICAoT2JqZWN0LmRlZmluZVByb3BlcnR5KHJlbmRlciwgXCJuYW1lXCIsIHsgdmFsdWU6IG5hbWUgfSksXG4gICAgICAgICAgICAocmVuZGVyLmRpc3BsYXlOYW1lID0gbmFtZSkpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBlbGVtZW50VHlwZTtcbiAgICB9O1xuICAgIGV4cG9ydHMuaXNWYWxpZEVsZW1lbnQgPSBpc1ZhbGlkRWxlbWVudDtcbiAgICBleHBvcnRzLmxhenkgPSBmdW5jdGlvbiAoY3Rvcikge1xuICAgICAgY3RvciA9IHsgX3N0YXR1czogLTEsIF9yZXN1bHQ6IGN0b3IgfTtcbiAgICAgIHZhciBsYXp5VHlwZSA9IHtcbiAgICAgICAgICAkJHR5cGVvZjogUkVBQ1RfTEFaWV9UWVBFLFxuICAgICAgICAgIF9wYXlsb2FkOiBjdG9yLFxuICAgICAgICAgIF9pbml0OiBsYXp5SW5pdGlhbGl6ZXJcbiAgICAgICAgfSxcbiAgICAgICAgaW9JbmZvID0ge1xuICAgICAgICAgIG5hbWU6IFwibGF6eVwiLFxuICAgICAgICAgIHN0YXJ0OiAtMSxcbiAgICAgICAgICBlbmQ6IC0xLFxuICAgICAgICAgIHZhbHVlOiBudWxsLFxuICAgICAgICAgIG93bmVyOiBudWxsLFxuICAgICAgICAgIGRlYnVnU3RhY2s6IEVycm9yKFwicmVhY3Qtc3RhY2stdG9wLWZyYW1lXCIpLFxuICAgICAgICAgIGRlYnVnVGFzazogY29uc29sZS5jcmVhdGVUYXNrID8gY29uc29sZS5jcmVhdGVUYXNrKFwibGF6eSgpXCIpIDogbnVsbFxuICAgICAgICB9O1xuICAgICAgY3Rvci5faW9JbmZvID0gaW9JbmZvO1xuICAgICAgbGF6eVR5cGUuX2RlYnVnSW5mbyA9IFt7IGF3YWl0ZWQ6IGlvSW5mbyB9XTtcbiAgICAgIHJldHVybiBsYXp5VHlwZTtcbiAgICB9O1xuICAgIGV4cG9ydHMubWVtbyA9IGZ1bmN0aW9uICh0eXBlLCBjb21wYXJlKSB7XG4gICAgICBudWxsID09IHR5cGUgJiZcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIm1lbW86IFRoZSBmaXJzdCBhcmd1bWVudCBtdXN0IGJlIGEgY29tcG9uZW50LiBJbnN0ZWFkIHJlY2VpdmVkOiAlc1wiLFxuICAgICAgICAgIG51bGwgPT09IHR5cGUgPyBcIm51bGxcIiA6IHR5cGVvZiB0eXBlXG4gICAgICAgICk7XG4gICAgICBjb21wYXJlID0ge1xuICAgICAgICAkJHR5cGVvZjogUkVBQ1RfTUVNT19UWVBFLFxuICAgICAgICB0eXBlOiB0eXBlLFxuICAgICAgICBjb21wYXJlOiB2b2lkIDAgPT09IGNvbXBhcmUgPyBudWxsIDogY29tcGFyZVxuICAgICAgfTtcbiAgICAgIHZhciBvd25OYW1lO1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvbXBhcmUsIFwiZGlzcGxheU5hbWVcIiwge1xuICAgICAgICBlbnVtZXJhYmxlOiAhMSxcbiAgICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIG93bk5hbWU7XG4gICAgICAgIH0sXG4gICAgICAgIHNldDogZnVuY3Rpb24gKG5hbWUpIHtcbiAgICAgICAgICBvd25OYW1lID0gbmFtZTtcbiAgICAgICAgICB0eXBlLm5hbWUgfHxcbiAgICAgICAgICAgIHR5cGUuZGlzcGxheU5hbWUgfHxcbiAgICAgICAgICAgIChPYmplY3QuZGVmaW5lUHJvcGVydHkodHlwZSwgXCJuYW1lXCIsIHsgdmFsdWU6IG5hbWUgfSksXG4gICAgICAgICAgICAodHlwZS5kaXNwbGF5TmFtZSA9IG5hbWUpKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICByZXR1cm4gY29tcGFyZTtcbiAgICB9O1xuICAgIGV4cG9ydHMuc3RhcnRUcmFuc2l0aW9uID0gZnVuY3Rpb24gKHNjb3BlKSB7XG4gICAgICB2YXIgcHJldlRyYW5zaXRpb24gPSBSZWFjdFNoYXJlZEludGVybmFscy5ULFxuICAgICAgICBjdXJyZW50VHJhbnNpdGlvbiA9IHt9O1xuICAgICAgY3VycmVudFRyYW5zaXRpb24uX3VwZGF0ZWRGaWJlcnMgPSBuZXcgU2V0KCk7XG4gICAgICBSZWFjdFNoYXJlZEludGVybmFscy5UID0gY3VycmVudFRyYW5zaXRpb247XG4gICAgICB0cnkge1xuICAgICAgICB2YXIgcmV0dXJuVmFsdWUgPSBzY29wZSgpLFxuICAgICAgICAgIG9uU3RhcnRUcmFuc2l0aW9uRmluaXNoID0gUmVhY3RTaGFyZWRJbnRlcm5hbHMuUztcbiAgICAgICAgbnVsbCAhPT0gb25TdGFydFRyYW5zaXRpb25GaW5pc2ggJiZcbiAgICAgICAgICBvblN0YXJ0VHJhbnNpdGlvbkZpbmlzaChjdXJyZW50VHJhbnNpdGlvbiwgcmV0dXJuVmFsdWUpO1xuICAgICAgICBcIm9iamVjdFwiID09PSB0eXBlb2YgcmV0dXJuVmFsdWUgJiZcbiAgICAgICAgICBudWxsICE9PSByZXR1cm5WYWx1ZSAmJlxuICAgICAgICAgIFwiZnVuY3Rpb25cIiA9PT0gdHlwZW9mIHJldHVyblZhbHVlLnRoZW4gJiZcbiAgICAgICAgICAoUmVhY3RTaGFyZWRJbnRlcm5hbHMuYXN5bmNUcmFuc2l0aW9ucysrLFxuICAgICAgICAgIHJldHVyblZhbHVlLnRoZW4ocmVsZWFzZUFzeW5jVHJhbnNpdGlvbiwgcmVsZWFzZUFzeW5jVHJhbnNpdGlvbiksXG4gICAgICAgICAgcmV0dXJuVmFsdWUudGhlbihub29wLCByZXBvcnRHbG9iYWxFcnJvcikpO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmVwb3J0R2xvYmFsRXJyb3IoZXJyb3IpO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgbnVsbCA9PT0gcHJldlRyYW5zaXRpb24gJiZcbiAgICAgICAgICBjdXJyZW50VHJhbnNpdGlvbi5fdXBkYXRlZEZpYmVycyAmJlxuICAgICAgICAgICgoc2NvcGUgPSBjdXJyZW50VHJhbnNpdGlvbi5fdXBkYXRlZEZpYmVycy5zaXplKSxcbiAgICAgICAgICBjdXJyZW50VHJhbnNpdGlvbi5fdXBkYXRlZEZpYmVycy5jbGVhcigpLFxuICAgICAgICAgIDEwIDwgc2NvcGUgJiZcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAgICAgXCJEZXRlY3RlZCBhIGxhcmdlIG51bWJlciBvZiB1cGRhdGVzIGluc2lkZSBzdGFydFRyYW5zaXRpb24uIElmIHRoaXMgaXMgZHVlIHRvIGEgc3Vic2NyaXB0aW9uIHBsZWFzZSByZS13cml0ZSBpdCB0byB1c2UgUmVhY3QgcHJvdmlkZWQgaG9va3MuIE90aGVyd2lzZSBjb25jdXJyZW50IG1vZGUgZ3VhcmFudGVlcyBhcmUgb2ZmIHRoZSB0YWJsZS5cIlxuICAgICAgICAgICAgKSksXG4gICAgICAgICAgbnVsbCAhPT0gcHJldlRyYW5zaXRpb24gJiZcbiAgICAgICAgICAgIG51bGwgIT09IGN1cnJlbnRUcmFuc2l0aW9uLnR5cGVzICYmXG4gICAgICAgICAgICAobnVsbCAhPT0gcHJldlRyYW5zaXRpb24udHlwZXMgJiZcbiAgICAgICAgICAgICAgcHJldlRyYW5zaXRpb24udHlwZXMgIT09IGN1cnJlbnRUcmFuc2l0aW9uLnR5cGVzICYmXG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgICAgICAgXCJXZSBleHBlY3RlZCBpbm5lciBUcmFuc2l0aW9ucyB0byBoYXZlIHRyYW5zZmVycmVkIHRoZSBvdXRlciB0eXBlcyBzZXQgYW5kIHRoYXQgeW91IGNhbm5vdCBhZGQgdG8gdGhlIG91dGVyIFRyYW5zaXRpb24gd2hpbGUgaW5zaWRlIHRoZSBpbm5lci5UaGlzIGlzIGEgYnVnIGluIFJlYWN0LlwiXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICAocHJldlRyYW5zaXRpb24udHlwZXMgPSBjdXJyZW50VHJhbnNpdGlvbi50eXBlcykpLFxuICAgICAgICAgIChSZWFjdFNoYXJlZEludGVybmFscy5UID0gcHJldlRyYW5zaXRpb24pO1xuICAgICAgfVxuICAgIH07XG4gICAgZXhwb3J0cy51bnN0YWJsZV91c2VDYWNoZVJlZnJlc2ggPSBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gcmVzb2x2ZURpc3BhdGNoZXIoKS51c2VDYWNoZVJlZnJlc2goKTtcbiAgICB9O1xuICAgIGV4cG9ydHMudXNlID0gZnVuY3Rpb24gKHVzYWJsZSkge1xuICAgICAgcmV0dXJuIHJlc29sdmVEaXNwYXRjaGVyKCkudXNlKHVzYWJsZSk7XG4gICAgfTtcbiAgICBleHBvcnRzLnVzZUFjdGlvblN0YXRlID0gZnVuY3Rpb24gKGFjdGlvbiwgaW5pdGlhbFN0YXRlLCBwZXJtYWxpbmspIHtcbiAgICAgIHJldHVybiByZXNvbHZlRGlzcGF0Y2hlcigpLnVzZUFjdGlvblN0YXRlKFxuICAgICAgICBhY3Rpb24sXG4gICAgICAgIGluaXRpYWxTdGF0ZSxcbiAgICAgICAgcGVybWFsaW5rXG4gICAgICApO1xuICAgIH07XG4gICAgZXhwb3J0cy51c2VDYWxsYmFjayA9IGZ1bmN0aW9uIChjYWxsYmFjaywgZGVwcykge1xuICAgICAgcmV0dXJuIHJlc29sdmVEaXNwYXRjaGVyKCkudXNlQ2FsbGJhY2soY2FsbGJhY2ssIGRlcHMpO1xuICAgIH07XG4gICAgZXhwb3J0cy51c2VDb250ZXh0ID0gZnVuY3Rpb24gKENvbnRleHQpIHtcbiAgICAgIHZhciBkaXNwYXRjaGVyID0gcmVzb2x2ZURpc3BhdGNoZXIoKTtcbiAgICAgIENvbnRleHQuJCR0eXBlb2YgPT09IFJFQUNUX0NPTlNVTUVSX1RZUEUgJiZcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIkNhbGxpbmcgdXNlQ29udGV4dChDb250ZXh0LkNvbnN1bWVyKSBpcyBub3Qgc3VwcG9ydGVkIGFuZCB3aWxsIGNhdXNlIGJ1Z3MuIERpZCB5b3UgbWVhbiB0byBjYWxsIHVzZUNvbnRleHQoQ29udGV4dCkgaW5zdGVhZD9cIlxuICAgICAgICApO1xuICAgICAgcmV0dXJuIGRpc3BhdGNoZXIudXNlQ29udGV4dChDb250ZXh0KTtcbiAgICB9O1xuICAgIGV4cG9ydHMudXNlRGVidWdWYWx1ZSA9IGZ1bmN0aW9uICh2YWx1ZSwgZm9ybWF0dGVyRm4pIHtcbiAgICAgIHJldHVybiByZXNvbHZlRGlzcGF0Y2hlcigpLnVzZURlYnVnVmFsdWUodmFsdWUsIGZvcm1hdHRlckZuKTtcbiAgICB9O1xuICAgIGV4cG9ydHMudXNlRGVmZXJyZWRWYWx1ZSA9IGZ1bmN0aW9uICh2YWx1ZSwgaW5pdGlhbFZhbHVlKSB7XG4gICAgICByZXR1cm4gcmVzb2x2ZURpc3BhdGNoZXIoKS51c2VEZWZlcnJlZFZhbHVlKHZhbHVlLCBpbml0aWFsVmFsdWUpO1xuICAgIH07XG4gICAgZXhwb3J0cy51c2VFZmZlY3QgPSBmdW5jdGlvbiAoY3JlYXRlLCBkZXBzKSB7XG4gICAgICBudWxsID09IGNyZWF0ZSAmJlxuICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgXCJSZWFjdCBIb29rIHVzZUVmZmVjdCByZXF1aXJlcyBhbiBlZmZlY3QgY2FsbGJhY2suIERpZCB5b3UgZm9yZ2V0IHRvIHBhc3MgYSBjYWxsYmFjayB0byB0aGUgaG9vaz9cIlxuICAgICAgICApO1xuICAgICAgcmV0dXJuIHJlc29sdmVEaXNwYXRjaGVyKCkudXNlRWZmZWN0KGNyZWF0ZSwgZGVwcyk7XG4gICAgfTtcbiAgICBleHBvcnRzLnVzZUVmZmVjdEV2ZW50ID0gZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gICAgICByZXR1cm4gcmVzb2x2ZURpc3BhdGNoZXIoKS51c2VFZmZlY3RFdmVudChjYWxsYmFjayk7XG4gICAgfTtcbiAgICBleHBvcnRzLnVzZUlkID0gZnVuY3Rpb24gKCkge1xuICAgICAgcmV0dXJuIHJlc29sdmVEaXNwYXRjaGVyKCkudXNlSWQoKTtcbiAgICB9O1xuICAgIGV4cG9ydHMudXNlSW1wZXJhdGl2ZUhhbmRsZSA9IGZ1bmN0aW9uIChyZWYsIGNyZWF0ZSwgZGVwcykge1xuICAgICAgcmV0dXJuIHJlc29sdmVEaXNwYXRjaGVyKCkudXNlSW1wZXJhdGl2ZUhhbmRsZShyZWYsIGNyZWF0ZSwgZGVwcyk7XG4gICAgfTtcbiAgICBleHBvcnRzLnVzZUluc2VydGlvbkVmZmVjdCA9IGZ1bmN0aW9uIChjcmVhdGUsIGRlcHMpIHtcbiAgICAgIG51bGwgPT0gY3JlYXRlICYmXG4gICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICBcIlJlYWN0IEhvb2sgdXNlSW5zZXJ0aW9uRWZmZWN0IHJlcXVpcmVzIGFuIGVmZmVjdCBjYWxsYmFjay4gRGlkIHlvdSBmb3JnZXQgdG8gcGFzcyBhIGNhbGxiYWNrIHRvIHRoZSBob29rP1wiXG4gICAgICAgICk7XG4gICAgICByZXR1cm4gcmVzb2x2ZURpc3BhdGNoZXIoKS51c2VJbnNlcnRpb25FZmZlY3QoY3JlYXRlLCBkZXBzKTtcbiAgICB9O1xuICAgIGV4cG9ydHMudXNlTGF5b3V0RWZmZWN0ID0gZnVuY3Rpb24gKGNyZWF0ZSwgZGVwcykge1xuICAgICAgbnVsbCA9PSBjcmVhdGUgJiZcbiAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgIFwiUmVhY3QgSG9vayB1c2VMYXlvdXRFZmZlY3QgcmVxdWlyZXMgYW4gZWZmZWN0IGNhbGxiYWNrLiBEaWQgeW91IGZvcmdldCB0byBwYXNzIGEgY2FsbGJhY2sgdG8gdGhlIGhvb2s/XCJcbiAgICAgICAgKTtcbiAgICAgIHJldHVybiByZXNvbHZlRGlzcGF0Y2hlcigpLnVzZUxheW91dEVmZmVjdChjcmVhdGUsIGRlcHMpO1xuICAgIH07XG4gICAgZXhwb3J0cy51c2VNZW1vID0gZnVuY3Rpb24gKGNyZWF0ZSwgZGVwcykge1xuICAgICAgcmV0dXJuIHJlc29sdmVEaXNwYXRjaGVyKCkudXNlTWVtbyhjcmVhdGUsIGRlcHMpO1xuICAgIH07XG4gICAgZXhwb3J0cy51c2VPcHRpbWlzdGljID0gZnVuY3Rpb24gKHBhc3N0aHJvdWdoLCByZWR1Y2VyKSB7XG4gICAgICByZXR1cm4gcmVzb2x2ZURpc3BhdGNoZXIoKS51c2VPcHRpbWlzdGljKHBhc3N0aHJvdWdoLCByZWR1Y2VyKTtcbiAgICB9O1xuICAgIGV4cG9ydHMudXNlUmVkdWNlciA9IGZ1bmN0aW9uIChyZWR1Y2VyLCBpbml0aWFsQXJnLCBpbml0KSB7XG4gICAgICByZXR1cm4gcmVzb2x2ZURpc3BhdGNoZXIoKS51c2VSZWR1Y2VyKHJlZHVjZXIsIGluaXRpYWxBcmcsIGluaXQpO1xuICAgIH07XG4gICAgZXhwb3J0cy51c2VSZWYgPSBmdW5jdGlvbiAoaW5pdGlhbFZhbHVlKSB7XG4gICAgICByZXR1cm4gcmVzb2x2ZURpc3BhdGNoZXIoKS51c2VSZWYoaW5pdGlhbFZhbHVlKTtcbiAgICB9O1xuICAgIGV4cG9ydHMudXNlU3RhdGUgPSBmdW5jdGlvbiAoaW5pdGlhbFN0YXRlKSB7XG4gICAgICByZXR1cm4gcmVzb2x2ZURpc3BhdGNoZXIoKS51c2VTdGF0ZShpbml0aWFsU3RhdGUpO1xuICAgIH07XG4gICAgZXhwb3J0cy51c2VTeW5jRXh0ZXJuYWxTdG9yZSA9IGZ1bmN0aW9uIChcbiAgICAgIHN1YnNjcmliZSxcbiAgICAgIGdldFNuYXBzaG90LFxuICAgICAgZ2V0U2VydmVyU25hcHNob3RcbiAgICApIHtcbiAgICAgIHJldHVybiByZXNvbHZlRGlzcGF0Y2hlcigpLnVzZVN5bmNFeHRlcm5hbFN0b3JlKFxuICAgICAgICBzdWJzY3JpYmUsXG4gICAgICAgIGdldFNuYXBzaG90LFxuICAgICAgICBnZXRTZXJ2ZXJTbmFwc2hvdFxuICAgICAgKTtcbiAgICB9O1xuICAgIGV4cG9ydHMudXNlVHJhbnNpdGlvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIHJldHVybiByZXNvbHZlRGlzcGF0Y2hlcigpLnVzZVRyYW5zaXRpb24oKTtcbiAgICB9O1xuICAgIGV4cG9ydHMudmVyc2lvbiA9IFwiMTkuMi44XCI7XG4gICAgXCJ1bmRlZmluZWRcIiAhPT0gdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXyAmJlxuICAgICAgXCJmdW5jdGlvblwiID09PVxuICAgICAgICB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdG9wICYmXG4gICAgICBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0b3AoRXJyb3IoKSk7XG4gIH0pKCk7XG4iLCIndXNlIHN0cmljdCc7XG5cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9janMvcmVhY3QucHJvZHVjdGlvbi5qcycpO1xufSBlbHNlIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2Nqcy9yZWFjdC5kZXZlbG9wbWVudC5qcycpO1xufVxuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDFdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0NBV0EsQ0FDRyxXQUFZO0VBQ1gsU0FBUyx5QkFBeUIsWUFBWSxNQUFNO0dBQ2xELE9BQU8sZUFBZSxVQUFVLFdBQVcsWUFBWSxFQUNyRCxLQUFLLFdBQVk7SUFDZixRQUFRLEtBQ04sK0RBQ0EsS0FBSyxJQUNMLEtBQUssRUFDUDtHQUNGLEVBQ0YsQ0FBQztFQUNIO0VBQ0EsU0FBUyxjQUFjLGVBQWU7R0FDcEMsSUFBSSxTQUFTLGlCQUFpQixhQUFhLE9BQU8sZUFDaEQsT0FBTztHQUNULGdCQUNHLHlCQUF5QixjQUFjLDBCQUN4QyxjQUFjO0dBQ2hCLE9BQU8sZUFBZSxPQUFPLGdCQUFnQixnQkFBZ0I7RUFDL0Q7RUFDQSxTQUFTLFNBQVMsZ0JBQWdCLFlBQVk7R0FDNUMsa0JBQ0ksaUJBQWlCLGVBQWUsaUJBQy9CLGVBQWUsZUFBZSxlQUFlLFNBQ2hEO0dBQ0YsSUFBSSxhQUFhLGlCQUFpQixNQUFNO0dBQ3hDLHdDQUF3QyxnQkFDckMsUUFBUSxNQUNQLHlQQUNBLFlBQ0EsY0FDRixHQUNDLHdDQUF3QyxjQUFjLENBQUM7RUFDNUQ7RUFDQSxTQUFTLFVBQVUsT0FBTyxTQUFTLFNBQVM7R0FDMUMsS0FBSyxRQUFRO0dBQ2IsS0FBSyxVQUFVO0dBQ2YsS0FBSyxPQUFPO0dBQ1osS0FBSyxVQUFVLFdBQVc7RUFDNUI7RUFDQSxTQUFTLGlCQUFpQixDQUFDO0VBQzNCLFNBQVMsY0FBYyxPQUFPLFNBQVMsU0FBUztHQUM5QyxLQUFLLFFBQVE7R0FDYixLQUFLLFVBQVU7R0FDZixLQUFLLE9BQU87R0FDWixLQUFLLFVBQVUsV0FBVztFQUM1QjtFQUNBLFNBQVMsT0FBTyxDQUFDO0VBQ2pCLFNBQVMsbUJBQW1CLE9BQU87R0FDakMsT0FBTyxLQUFLO0VBQ2Q7RUFDQSxTQUFTLHVCQUF1QixPQUFPO0dBQ3JDLElBQUk7SUFDRixtQkFBbUIsS0FBSztJQUN4QixJQUFJLDJCQUEyQixDQUFDO0dBQ2xDLFNBQVMsR0FBRztJQUNWLDJCQUEyQixDQUFDO0dBQzlCO0dBQ0EsSUFBSSwwQkFBMEI7SUFDNUIsMkJBQTJCO0lBQzNCLElBQUksd0JBQXdCLHlCQUF5QjtJQUNyRCxJQUFJLG9DQUNELGVBQWUsT0FBTyxVQUNyQixPQUFPLGVBQ1AsTUFBTSxPQUFPLGdCQUNmLE1BQU0sWUFBWSxRQUNsQjtJQUNGLHNCQUFzQixLQUNwQiwwQkFDQSw0R0FDQSxpQ0FDRjtJQUNBLE9BQU8sbUJBQW1CLEtBQUs7R0FDakM7RUFDRjtFQUNBLFNBQVMseUJBQXlCLE1BQU07R0FDdEMsSUFBSSxRQUFRLE1BQU0sT0FBTztHQUN6QixJQUFJLGVBQWUsT0FBTyxNQUN4QixPQUFPLEtBQUssYUFBYSx5QkFDckIsT0FDQSxLQUFLLGVBQWUsS0FBSyxRQUFRO0dBQ3ZDLElBQUksYUFBYSxPQUFPLE1BQU0sT0FBTztHQUNyQyxRQUFRLE1BQVI7SUFDRSxLQUFLLHFCQUNILE9BQU87SUFDVCxLQUFLLHFCQUNILE9BQU87SUFDVCxLQUFLLHdCQUNILE9BQU87SUFDVCxLQUFLLHFCQUNILE9BQU87SUFDVCxLQUFLLDBCQUNILE9BQU87SUFDVCxLQUFLLHFCQUNILE9BQU87R0FDWDtHQUNBLElBQUksYUFBYSxPQUFPLE1BQ3RCLFFBQ0csYUFBYSxPQUFPLEtBQUssT0FDeEIsUUFBUSxNQUNOLG1IQUNGLEdBQ0YsS0FBSyxVQUxQO0lBT0UsS0FBSyxtQkFDSCxPQUFPO0lBQ1QsS0FBSyxvQkFDSCxPQUFPLEtBQUssZUFBZTtJQUM3QixLQUFLLHFCQUNILFFBQVEsS0FBSyxTQUFTLGVBQWUsYUFBYTtJQUNwRCxLQUFLO0tBQ0gsSUFBSSxZQUFZLEtBQUs7S0FDckIsT0FBTyxLQUFLO0tBQ1osU0FDSSxPQUFPLFVBQVUsZUFBZSxVQUFVLFFBQVEsSUFDbkQsT0FBTyxPQUFPLE9BQU8sZ0JBQWdCLE9BQU8sTUFBTTtLQUNyRCxPQUFPO0lBQ1QsS0FBSyxpQkFDSCxPQUNHLFlBQVksS0FBSyxlQUFlLE1BQ2pDLFNBQVMsWUFDTCxZQUNBLHlCQUF5QixLQUFLLElBQUksS0FBSztJQUUvQyxLQUFLO0tBQ0gsWUFBWSxLQUFLO0tBQ2pCLE9BQU8sS0FBSztLQUNaLElBQUk7TUFDRixPQUFPLHlCQUF5QixLQUFLLFNBQVMsQ0FBQztLQUNqRCxTQUFTLEdBQUcsQ0FBQztHQUNqQjtHQUNGLE9BQU87RUFDVDtFQUNBLFNBQVMsWUFBWSxNQUFNO0dBQ3pCLElBQUksU0FBUyxxQkFBcUIsT0FBTztHQUN6QyxJQUNFLGFBQWEsT0FBTyxRQUNwQixTQUFTLFFBQ1QsS0FBSyxhQUFhLGlCQUVsQixPQUFPO0dBQ1QsSUFBSTtJQUNGLElBQUksT0FBTyx5QkFBeUIsSUFBSTtJQUN4QyxPQUFPLE9BQU8sTUFBTSxPQUFPLE1BQU07R0FDbkMsU0FBUyxHQUFHO0lBQ1YsT0FBTztHQUNUO0VBQ0Y7RUFDQSxTQUFTLFdBQVc7R0FDbEIsSUFBSSxhQUFhLHFCQUFxQjtHQUN0QyxPQUFPLFNBQVMsYUFBYSxPQUFPLFdBQVcsU0FBUztFQUMxRDtFQUNBLFNBQVMsZUFBZTtHQUN0QixPQUFPLE1BQU0sdUJBQXVCO0VBQ3RDO0VBQ0EsU0FBUyxZQUFZLFFBQVE7R0FDM0IsSUFBSSxlQUFlLEtBQUssUUFBUSxLQUFLLEdBQUc7SUFDdEMsSUFBSSxTQUFTLE9BQU8seUJBQXlCLFFBQVEsS0FBSyxDQUFDLENBQUM7SUFDNUQsSUFBSSxVQUFVLE9BQU8sZ0JBQWdCLE9BQU8sQ0FBQztHQUMvQztHQUNBLE9BQU8sS0FBSyxNQUFNLE9BQU87RUFDM0I7RUFDQSxTQUFTLDJCQUEyQixPQUFPLGFBQWE7R0FDdEQsU0FBUyx3QkFBd0I7SUFDL0IsK0JBQ0ksNkJBQTZCLENBQUMsR0FDaEMsUUFBUSxNQUNOLDJPQUNBLFdBQ0Y7R0FDSjtHQUNBLHNCQUFzQixpQkFBaUIsQ0FBQztHQUN4QyxPQUFPLGVBQWUsT0FBTyxPQUFPO0lBQ2xDLEtBQUs7SUFDTCxjQUFjLENBQUM7R0FDakIsQ0FBQztFQUNIO0VBQ0EsU0FBUyx5Q0FBeUM7R0FDaEQsSUFBSSxnQkFBZ0IseUJBQXlCLEtBQUssSUFBSTtHQUN0RCx1QkFBdUIsbUJBQ25CLHVCQUF1QixpQkFBaUIsQ0FBQyxHQUMzQyxRQUFRLE1BQ04sNklBQ0Y7R0FDRixnQkFBZ0IsS0FBSyxNQUFNO0dBQzNCLE9BQU8sS0FBSyxNQUFNLGdCQUFnQixnQkFBZ0I7RUFDcEQ7RUFDQSxTQUFTLGFBQWEsTUFBTSxLQUFLLE9BQU8sT0FBTyxZQUFZLFdBQVc7R0FDcEUsSUFBSSxVQUFVLE1BQU07R0FDcEIsT0FBTztJQUNMLFVBQVU7SUFDSjtJQUNEO0lBQ0U7SUFDUCxRQUFRO0dBQ1Y7R0FDQSxVQUFVLEtBQUssTUFBTSxVQUFVLFVBQVUsUUFDckMsT0FBTyxlQUFlLE1BQU0sT0FBTztJQUNqQyxZQUFZLENBQUM7SUFDYixLQUFLO0dBQ1AsQ0FBQyxJQUNELE9BQU8sZUFBZSxNQUFNLE9BQU87SUFBRSxZQUFZLENBQUM7SUFBRyxPQUFPO0dBQUssQ0FBQztHQUN0RSxLQUFLLFNBQVMsQ0FBQztHQUNmLE9BQU8sZUFBZSxLQUFLLFFBQVEsYUFBYTtJQUM5QyxjQUFjLENBQUM7SUFDZixZQUFZLENBQUM7SUFDYixVQUFVLENBQUM7SUFDWCxPQUFPO0dBQ1QsQ0FBQztHQUNELE9BQU8sZUFBZSxNQUFNLGNBQWM7SUFDeEMsY0FBYyxDQUFDO0lBQ2YsWUFBWSxDQUFDO0lBQ2IsVUFBVSxDQUFDO0lBQ1gsT0FBTztHQUNULENBQUM7R0FDRCxPQUFPLGVBQWUsTUFBTSxlQUFlO0lBQ3pDLGNBQWMsQ0FBQztJQUNmLFlBQVksQ0FBQztJQUNiLFVBQVUsQ0FBQztJQUNYLE9BQU87R0FDVCxDQUFDO0dBQ0QsT0FBTyxlQUFlLE1BQU0sY0FBYztJQUN4QyxjQUFjLENBQUM7SUFDZixZQUFZLENBQUM7SUFDYixVQUFVLENBQUM7SUFDWCxPQUFPO0dBQ1QsQ0FBQztHQUNELE9BQU8sV0FBVyxPQUFPLE9BQU8sS0FBSyxLQUFLLEdBQUcsT0FBTyxPQUFPLElBQUk7R0FDL0QsT0FBTztFQUNUO0VBQ0EsU0FBUyxtQkFBbUIsWUFBWSxRQUFRO0dBQzlDLFNBQVMsYUFDUCxXQUFXLE1BQ1gsUUFDQSxXQUFXLE9BQ1gsV0FBVyxRQUNYLFdBQVcsYUFDWCxXQUFXLFVBQ2I7R0FDQSxXQUFXLFdBQ1IsT0FBTyxPQUFPLFlBQVksV0FBVyxPQUFPO0dBQy9DLE9BQU87RUFDVDtFQUNBLFNBQVMsa0JBQWtCLE1BQU07R0FDL0IsZUFBZSxJQUFJLElBQ2YsS0FBSyxXQUFXLEtBQUssT0FBTyxZQUFZLEtBQ3hDLGFBQWEsT0FBTyxRQUNwQixTQUFTLFFBQ1QsS0FBSyxhQUFhLG9CQUNqQixnQkFBZ0IsS0FBSyxTQUFTLFNBQzNCLGVBQWUsS0FBSyxTQUFTLEtBQUssS0FDbEMsS0FBSyxTQUFTLE1BQU0sV0FDbkIsS0FBSyxTQUFTLE1BQU0sT0FBTyxZQUFZLEtBQ3hDLEtBQUssV0FBVyxLQUFLLE9BQU8sWUFBWTtFQUNsRDtFQUNBLFNBQVMsZUFBZSxRQUFRO0dBQzlCLE9BQ0UsYUFBYSxPQUFPLFVBQ3BCLFNBQVMsVUFDVCxPQUFPLGFBQWE7RUFFeEI7RUFDQSxTQUFTLE9BQU8sS0FBSztHQUNuQixJQUFJLGdCQUFnQjtJQUFFLEtBQUs7SUFBTSxLQUFLO0dBQUs7R0FDM0MsT0FDRSxNQUNBLElBQUksUUFBUSxTQUFTLFNBQVUsT0FBTztJQUNwQyxPQUFPLGNBQWM7R0FDdkIsQ0FBQztFQUVMO0VBQ0EsU0FBUyxjQUFjLFNBQVMsT0FBTztHQUNyQyxPQUFPLGFBQWEsT0FBTyxXQUN6QixTQUFTLFdBQ1QsUUFBUSxRQUFRLE9BQ2IsdUJBQXVCLFFBQVEsR0FBRyxHQUFHLE9BQU8sS0FBSyxRQUFRLEdBQUcsS0FDN0QsTUFBTSxTQUFTLEVBQUU7RUFDdkI7RUFDQSxTQUFTLGdCQUFnQixVQUFVO0dBQ2pDLFFBQVEsU0FBUyxRQUFqQjtJQUNFLEtBQUssYUFDSCxPQUFPLFNBQVM7SUFDbEIsS0FBSyxZQUNILE1BQU0sU0FBUztJQUNqQixTQUNFLFFBQ0csYUFBYSxPQUFPLFNBQVMsU0FDMUIsU0FBUyxLQUFLLE1BQU0sSUFBSSxLQUN0QixTQUFTLFNBQVMsV0FDcEIsU0FBUyxLQUNQLFNBQVUsZ0JBQWdCO0tBQ3hCLGNBQWMsU0FBUyxXQUNuQixTQUFTLFNBQVMsYUFDbkIsU0FBUyxRQUFRO0lBQ3RCLEdBQ0EsU0FBVSxPQUFPO0tBQ2YsY0FBYyxTQUFTLFdBQ25CLFNBQVMsU0FBUyxZQUNuQixTQUFTLFNBQVM7SUFDdkIsQ0FDRixJQUNKLFNBQVMsUUFoQlg7S0FrQkUsS0FBSyxhQUNILE9BQU8sU0FBUztLQUNsQixLQUFLLFlBQ0gsTUFBTSxTQUFTO0lBQ25CO0dBQ0o7R0FDQSxNQUFNO0VBQ1I7RUFDQSxTQUFTLGFBQWEsVUFBVSxPQUFPLGVBQWUsV0FBVyxVQUFVO0dBQ3pFLElBQUksT0FBTyxPQUFPO0dBQ2xCLElBQUksZ0JBQWdCLFFBQVEsY0FBYyxNQUFNLFdBQVc7R0FDM0QsSUFBSSxpQkFBaUIsQ0FBQztHQUN0QixJQUFJLFNBQVMsVUFBVSxpQkFBaUIsQ0FBQztRQUV2QyxRQUFRLE1BQVI7SUFDRSxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7S0FDSCxpQkFBaUIsQ0FBQztLQUNsQjtJQUNGLEtBQUssVUFDSCxRQUFRLFNBQVMsVUFBakI7S0FDRSxLQUFLO0tBQ0wsS0FBSztNQUNILGlCQUFpQixDQUFDO01BQ2xCO0tBQ0YsS0FBSyxpQkFDSCxPQUNHLGlCQUFpQixTQUFTLE9BQzNCLGFBQ0UsZUFBZSxTQUFTLFFBQVEsR0FDaEMsT0FDQSxlQUNBLFdBQ0EsUUFDRjtJQUVOO0dBQ0o7R0FDRixJQUFJLGdCQUFnQjtJQUNsQixpQkFBaUI7SUFDakIsV0FBVyxTQUFTLGNBQWM7SUFDbEMsSUFBSSxXQUNGLE9BQU8sWUFBWSxNQUFNLGNBQWMsZ0JBQWdCLENBQUMsSUFBSTtJQUM5RCxZQUFZLFFBQVEsS0FDZCxnQkFBZ0IsSUFDbEIsUUFBUSxhQUNMLGdCQUNDLFNBQVMsUUFBUSw0QkFBNEIsS0FBSyxJQUFJLE1BQzFELGFBQWEsVUFBVSxPQUFPLGVBQWUsSUFBSSxTQUFVLEdBQUc7S0FDNUQsT0FBTztJQUNULENBQUMsS0FDRCxRQUFRLGFBQ1AsZUFBZSxRQUFRLE1BQ3JCLFFBQVEsU0FBUyxRQUNkLGtCQUFrQixlQUFlLFFBQVEsU0FBUyxPQUNsRCx1QkFBdUIsU0FBUyxHQUFHLElBQ3RDLGdCQUFnQixtQkFDZixVQUNBLGlCQUNHLFFBQVEsU0FBUyxPQUNqQixrQkFBa0IsZUFBZSxRQUFRLFNBQVMsTUFDL0MsTUFDQyxLQUFLLFNBQVMsSUFBQSxDQUFLLFFBQ2xCLDRCQUNBLEtBQ0YsSUFBSSxPQUNSLFFBQ0osR0FDQSxPQUFPLGFBQ0wsUUFBUSxrQkFDUixlQUFlLGNBQWMsS0FDN0IsUUFBUSxlQUFlLE9BQ3ZCLGVBQWUsVUFDZixDQUFDLGVBQWUsT0FBTyxjQUN0QixjQUFjLE9BQU8sWUFBWSxJQUNuQyxXQUFXLGdCQUNkLE1BQU0sS0FBSyxRQUFRO0lBQ3ZCLE9BQU87R0FDVDtHQUNBLGlCQUFpQjtHQUNqQixXQUFXLE9BQU8sWUFBWSxNQUFNLFlBQVk7R0FDaEQsSUFBSSxZQUFZLFFBQVEsR0FDdEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUNuQyxZQUFhLFNBQVMsSUFDbkIsT0FBTyxXQUFXLGNBQWMsV0FBVyxDQUFDLEdBQzVDLGtCQUFrQixhQUNqQixXQUNBLE9BQ0EsZUFDQSxNQUNBLFFBQ0Y7UUFDRCxJQUFNLElBQUksY0FBYyxRQUFRLEdBQUksZUFBZSxPQUFPLEdBQzdELEtBQ0UsTUFBTSxTQUFTLFlBQ1osb0JBQ0MsUUFBUSxLQUNOLHVGQUNGLEdBQ0QsbUJBQW1CLENBQUMsSUFDckIsV0FBVyxFQUFFLEtBQUssUUFBUSxHQUMxQixJQUFJLEdBQ04sRUFBRSxZQUFZLFNBQVMsS0FBSyxFQUFBLENBQUcsT0FHL0IsWUFBYSxVQUFVLE9BQ3BCLE9BQU8sV0FBVyxjQUFjLFdBQVcsR0FBRyxHQUM5QyxrQkFBa0IsYUFDakIsV0FDQSxPQUNBLGVBQ0EsTUFDQSxRQUNGO1FBQ0QsSUFBSSxhQUFhLE1BQU07SUFDMUIsSUFBSSxlQUFlLE9BQU8sU0FBUyxNQUNqQyxPQUFPLGFBQ0wsZ0JBQWdCLFFBQVEsR0FDeEIsT0FDQSxlQUNBLFdBQ0EsUUFDRjtJQUNGLFFBQVEsT0FBTyxRQUFRO0lBQ3ZCLE1BQU0sTUFDSixxREFDRyxzQkFBc0IsUUFDbkIsdUJBQXVCLE9BQU8sS0FBSyxRQUFRLENBQUMsQ0FBQyxLQUFLLElBQUksSUFBSSxNQUMxRCxTQUNKLDJFQUNKO0dBQ0Y7R0FDQSxPQUFPO0VBQ1Q7RUFDQSxTQUFTLFlBQVksVUFBVSxNQUFNLFNBQVM7R0FDNUMsSUFBSSxRQUFRLFVBQVUsT0FBTztHQUM3QixJQUFJLFNBQVMsQ0FBQyxHQUNaLFFBQVE7R0FDVixhQUFhLFVBQVUsUUFBUSxJQUFJLElBQUksU0FBVSxPQUFPO0lBQ3RELE9BQU8sS0FBSyxLQUFLLFNBQVMsT0FBTyxPQUFPO0dBQzFDLENBQUM7R0FDRCxPQUFPO0VBQ1Q7RUFDQSxTQUFTLGdCQUFnQixTQUFTO0dBQ2hDLElBQUksT0FBTyxRQUFRLFNBQVM7SUFDMUIsSUFBSSxTQUFTLFFBQVE7SUFDckIsUUFBUSxXQUFXLE9BQU8sUUFBUSxPQUFPLE1BQU0sWUFBWSxJQUFJO0lBQy9ELFNBQVMsUUFBUTtJQUNqQixJQUFJLFdBQVcsT0FBTztJQUN0QixTQUFTLEtBQ1AsU0FBVSxjQUFjO0tBQ3RCLElBQUksTUFBTSxRQUFRLFdBQVcsT0FBTyxRQUFRLFNBQVM7TUFDbkQsUUFBUSxVQUFVO01BQ2xCLFFBQVEsVUFBVTtNQUNsQixJQUFJLFVBQVUsUUFBUTtNQUN0QixRQUFRLFlBQVksUUFBUSxNQUFNLFlBQVksSUFBSTtNQUNsRCxLQUFLLE1BQU0sU0FBUyxXQUNoQixTQUFTLFNBQVMsYUFDbkIsU0FBUyxRQUFRO0tBQ3RCO0lBQ0YsR0FDQSxTQUFVLE9BQU87S0FDZixJQUFJLE1BQU0sUUFBUSxXQUFXLE9BQU8sUUFBUSxTQUFTO01BQ25ELFFBQVEsVUFBVTtNQUNsQixRQUFRLFVBQVU7TUFDbEIsSUFBSSxXQUFXLFFBQVE7TUFDdkIsUUFBUSxhQUFhLFNBQVMsTUFBTSxZQUFZLElBQUk7TUFDcEQsS0FBSyxNQUFNLFNBQVMsV0FDaEIsU0FBUyxTQUFTLFlBQWMsU0FBUyxTQUFTO0tBQ3hEO0lBQ0YsQ0FDRjtJQUNBLFNBQVMsUUFBUTtJQUNqQixJQUFJLFFBQVEsUUFBUTtLQUNsQixPQUFPLFFBQVE7S0FDZixJQUFJLGNBQWMsU0FBUztLQUMzQixhQUFhLE9BQU8sZ0JBQWdCLE9BQU8sT0FBTztJQUNwRDtJQUNBLE9BQU8sUUFBUSxZQUNYLFFBQVEsVUFBVSxHQUFLLFFBQVEsVUFBVTtHQUMvQztHQUNBLElBQUksTUFBTSxRQUFRLFNBQ2hCLE9BQ0csU0FBUyxRQUFRLFNBQ2xCLEtBQUssTUFBTSxVQUNULFFBQVEsTUFDTixxT0FDQSxNQUNGLEdBQ0YsYUFBYSxVQUNYLFFBQVEsTUFDTix5S0FDQSxNQUNGLEdBQ0YsT0FBTztHQUVYLE1BQU0sUUFBUTtFQUNoQjtFQUNBLFNBQVMsb0JBQW9CO0dBQzNCLElBQUksYUFBYSxxQkFBcUI7R0FDdEMsU0FBUyxjQUNQLFFBQVEsTUFDTiwrYUFDRjtHQUNGLE9BQU87RUFDVDtFQUNBLFNBQVMseUJBQXlCO0dBQ2hDLHFCQUFxQjtFQUN2QjtFQUNBLFNBQVMsWUFBWSxNQUFNO0dBQ3pCLElBQUksU0FBUyxpQkFDWCxJQUFJO0lBQ0YsSUFBSSxpQkFBaUIsWUFBWSxLQUFLLE9BQU8sRUFBQSxDQUFHLE1BQU0sR0FBRyxDQUFDO0lBQzFELG1CQUFtQixVQUFVLE9BQU8sZUFBQSxDQUFnQixLQUNsRCxRQUNBLFFBQ0YsQ0FBQyxDQUFDO0dBQ0osU0FBUyxNQUFNO0lBQ2Isa0JBQWtCLFNBQVUsVUFBVTtLQUNwQyxDQUFDLE1BQU0sK0JBQ0gsNkJBQTZCLENBQUMsR0FDaEMsZ0JBQWdCLE9BQU8sa0JBQ3JCLFFBQVEsTUFDTiwwTkFDRjtLQUNKLElBQUksVUFBVSxJQUFJLGVBQWU7S0FDakMsUUFBUSxNQUFNLFlBQVk7S0FDMUIsUUFBUSxNQUFNLFlBQVksS0FBSyxDQUFDO0lBQ2xDO0dBQ0Y7R0FDRixPQUFPLGdCQUFnQixJQUFJO0VBQzdCO0VBQ0EsU0FBUyxnQkFBZ0IsUUFBUTtHQUMvQixPQUFPLElBQUksT0FBTyxVQUFVLGVBQWUsT0FBTyxpQkFDOUMsSUFBSSxlQUFlLE1BQU0sSUFDekIsT0FBTztFQUNiO0VBQ0EsU0FBUyxZQUFZLGNBQWMsbUJBQW1CO0dBQ3BELHNCQUFzQixnQkFBZ0IsS0FDcEMsUUFBUSxNQUNOLGtJQUNGO0dBQ0YsZ0JBQWdCO0VBQ2xCO0VBQ0EsU0FBUyw2QkFBNkIsYUFBYSxTQUFTLFFBQVE7R0FDbEUsSUFBSSxRQUFRLHFCQUFxQjtHQUNqQyxJQUFJLFNBQVMsT0FDWCxJQUFJLE1BQU0sTUFBTSxRQUNkLElBQUk7SUFDRixjQUFjLEtBQUs7SUFDbkIsWUFBWSxXQUFZO0tBQ3RCLE9BQU8sNkJBQTZCLGFBQWEsU0FBUyxNQUFNO0lBQ2xFLENBQUM7SUFDRDtHQUNGLFNBQVMsT0FBTztJQUNkLHFCQUFxQixhQUFhLEtBQUssS0FBSztHQUM5QztRQUNHLHFCQUFxQixXQUFXO0dBQ3ZDLElBQUkscUJBQXFCLGFBQWEsVUFDaEMsUUFBUSxnQkFBZ0IscUJBQXFCLFlBQVksR0FDMUQscUJBQXFCLGFBQWEsU0FBUyxHQUM1QyxPQUFPLEtBQUssS0FDWixRQUFRLFdBQVc7RUFDekI7RUFDQSxTQUFTLGNBQWMsT0FBTztHQUM1QixJQUFJLENBQUMsWUFBWTtJQUNmLGFBQWEsQ0FBQztJQUNkLElBQUksSUFBSTtJQUNSLElBQUk7S0FDRixPQUFPLElBQUksTUFBTSxRQUFRLEtBQUs7TUFDNUIsSUFBSSxXQUFXLE1BQU07TUFDckIsR0FBRztPQUNELHFCQUFxQixnQkFBZ0IsQ0FBQztPQUN0QyxJQUFJLGVBQWUsU0FBUyxDQUFDLENBQUM7T0FDOUIsSUFBSSxTQUFTLGNBQWM7UUFDekIsSUFBSSxxQkFBcUIsZUFBZTtTQUN0QyxNQUFNLEtBQUs7U0FDWCxNQUFNLE9BQU8sR0FBRyxDQUFDO1NBQ2pCO1FBQ0Y7UUFDQSxXQUFXO09BQ2IsT0FBTztNQUNULFNBQVM7S0FDWDtLQUNBLE1BQU0sU0FBUztJQUNqQixTQUFTLE9BQU87S0FDZCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxxQkFBcUIsYUFBYSxLQUFLLEtBQUs7SUFDdEUsVUFBVTtLQUNSLGFBQWEsQ0FBQztJQUNoQjtHQUNGO0VBQ0Y7RUFDQSxnQkFBZ0IsT0FBTyxrQ0FDckIsZUFDRSxPQUFPLCtCQUErQiwrQkFDeEMsK0JBQStCLDRCQUE0QixNQUFNLENBQUM7RUFDcEUsSUFBSSxxQkFBcUIsT0FBTyxJQUFJLDRCQUE0QixHQUM5RCxvQkFBb0IsT0FBTyxJQUFJLGNBQWMsR0FDN0Msc0JBQXNCLE9BQU8sSUFBSSxnQkFBZ0IsR0FDakQseUJBQXlCLE9BQU8sSUFBSSxtQkFBbUIsR0FDdkQsc0JBQXNCLE9BQU8sSUFBSSxnQkFBZ0IsR0FDakQsc0JBQXNCLE9BQU8sSUFBSSxnQkFBZ0IsR0FDakQscUJBQXFCLE9BQU8sSUFBSSxlQUFlLEdBQy9DLHlCQUF5QixPQUFPLElBQUksbUJBQW1CLEdBQ3ZELHNCQUFzQixPQUFPLElBQUksZ0JBQWdCLEdBQ2pELDJCQUEyQixPQUFPLElBQUkscUJBQXFCLEdBQzNELGtCQUFrQixPQUFPLElBQUksWUFBWSxHQUN6QyxrQkFBa0IsT0FBTyxJQUFJLFlBQVksR0FDekMsc0JBQXNCLE9BQU8sSUFBSSxnQkFBZ0IsR0FDakQsd0JBQXdCLE9BQU8sVUFDL0IsMENBQTBDLENBQUMsR0FDM0MsdUJBQXVCO0dBQ3JCLFdBQVcsV0FBWTtJQUNyQixPQUFPLENBQUM7R0FDVjtHQUNBLG9CQUFvQixTQUFVLGdCQUFnQjtJQUM1QyxTQUFTLGdCQUFnQixhQUFhO0dBQ3hDO0dBQ0EscUJBQXFCLFNBQVUsZ0JBQWdCO0lBQzdDLFNBQVMsZ0JBQWdCLGNBQWM7R0FDekM7R0FDQSxpQkFBaUIsU0FBVSxnQkFBZ0I7SUFDekMsU0FBUyxnQkFBZ0IsVUFBVTtHQUNyQztFQUNGLEdBQ0EsU0FBUyxPQUFPLFFBQ2hCLGNBQWMsQ0FBQztFQUNqQixPQUFPLE9BQU8sV0FBVztFQUN6QixVQUFVLFVBQVUsbUJBQW1CLENBQUM7RUFDeEMsVUFBVSxVQUFVLFdBQVcsU0FBVSxjQUFjLFVBQVU7R0FDL0QsSUFDRSxhQUFhLE9BQU8sZ0JBQ3BCLGVBQWUsT0FBTyxnQkFDdEIsUUFBUSxjQUVSLE1BQU0sTUFDSix3R0FDRjtHQUNGLEtBQUssUUFBUSxnQkFBZ0IsTUFBTSxjQUFjLFVBQVUsVUFBVTtFQUN2RTtFQUNBLFVBQVUsVUFBVSxjQUFjLFNBQVUsVUFBVTtHQUNwRCxLQUFLLFFBQVEsbUJBQW1CLE1BQU0sVUFBVSxhQUFhO0VBQy9EO0VBQ0EsSUFBSSxpQkFBaUI7R0FDbkIsV0FBVyxDQUNULGFBQ0Esb0hBQ0Y7R0FDQSxjQUFjLENBQ1osZ0JBQ0EsaUdBQ0Y7RUFDRjtFQUNBLEtBQUssVUFBVSxnQkFDYixlQUFlLGVBQWUsTUFBTSxLQUNsQyx5QkFBeUIsUUFBUSxlQUFlLE9BQU87RUFDM0QsZUFBZSxZQUFZLFVBQVU7RUFDckMsaUJBQWlCLGNBQWMsWUFBWSxJQUFJLGVBQWU7RUFDOUQsZUFBZSxjQUFjO0VBQzdCLE9BQU8sZ0JBQWdCLFVBQVUsU0FBUztFQUMxQyxlQUFlLHVCQUF1QixDQUFDO0VBQ3ZDLElBQUksY0FBYyxNQUFNLFNBQ3RCLHlCQUF5QixPQUFPLElBQUksd0JBQXdCLEdBQzVELHVCQUF1QjtHQUNyQixHQUFHO0dBQ0gsR0FBRztHQUNILEdBQUc7R0FDSCxHQUFHO0dBQ0gsVUFBVTtHQUNWLGtCQUFrQjtHQUNsQixrQkFBa0IsQ0FBQztHQUNuQix5QkFBeUIsQ0FBQztHQUMxQixlQUFlLENBQUM7R0FDaEIsY0FBYyxDQUFDO0dBQ2YsaUJBQWlCO0dBQ2pCLDRCQUE0QjtFQUM5QixHQUNBLGlCQUFpQixPQUFPLFVBQVUsZ0JBQ2xDLGFBQWEsUUFBUSxhQUNqQixRQUFRLGFBQ1IsV0FBWTtHQUNWLE9BQU87RUFDVDtFQUNOLGlCQUFpQixFQUNmLDBCQUEwQixTQUFVLG1CQUFtQjtHQUNyRCxPQUFPLGtCQUFrQjtFQUMzQixFQUNGO0VBQ0EsSUFBSSw0QkFBNEI7RUFDaEMsSUFBSSx5QkFBeUIsQ0FBQztFQUM5QixJQUFJLHlCQUF5QixlQUFlLHlCQUF5QixLQUNuRSxnQkFDQSxZQUNGLENBQUMsQ0FBQztFQUNGLElBQUksd0JBQXdCLFdBQVcsWUFBWSxZQUFZLENBQUM7RUFDaEUsSUFBSSxtQkFBbUIsQ0FBQyxHQUN0Qiw2QkFBNkIsUUFDN0Isb0JBQ0UsZUFBZSxPQUFPLGNBQ2xCLGNBQ0EsU0FBVSxPQUFPO0dBQ2YsSUFDRSxhQUFhLE9BQU8sVUFDcEIsZUFBZSxPQUFPLE9BQU8sWUFDN0I7SUFDQSxJQUFJLFFBQVEsSUFBSSxPQUFPLFdBQVcsU0FBUztLQUN6QyxTQUFTLENBQUM7S0FDVixZQUFZLENBQUM7S0FDYixTQUNFLGFBQWEsT0FBTyxTQUNwQixTQUFTLFNBQ1QsYUFBYSxPQUFPLE1BQU0sVUFDdEIsT0FBTyxNQUFNLE9BQU8sSUFDcEIsT0FBTyxLQUFLO0tBQ1g7SUFDVCxDQUFDO0lBQ0QsSUFBSSxDQUFDLE9BQU8sY0FBYyxLQUFLLEdBQUc7R0FDcEMsT0FBTyxJQUNMLGFBQWEsT0FBTyxXQUNwQixlQUFlLE9BQU8sUUFBUSxNQUM5QjtJQUNBLFFBQVEsS0FBSyxxQkFBcUIsS0FBSztJQUN2QztHQUNGO0dBQ0EsUUFBUSxNQUFNLEtBQUs7RUFDckIsR0FDTiw2QkFBNkIsQ0FBQyxHQUM5QixrQkFBa0IsTUFDbEIsZ0JBQWdCLEdBQ2hCLG9CQUFvQixDQUFDLEdBQ3JCLGFBQWEsQ0FBQyxHQUNkLHlCQUNFLGVBQWUsT0FBTyxpQkFDbEIsU0FBVSxVQUFVO0dBQ2xCLGVBQWUsV0FBWTtJQUN6QixPQUFPLGVBQWUsUUFBUTtHQUNoQyxDQUFDO0VBQ0gsSUFDQTtFQUNSLGlCQUFpQixPQUFPLE9BQU87R0FDN0IsV0FBVztHQUNYLEdBQUcsU0FBVSxNQUFNO0lBQ2pCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxhQUFhLElBQUk7R0FDOUM7RUFDRixDQUFDO0VBQ0QsSUFBSSxTQUFTO0dBQ1gsS0FBSztHQUNMLFNBQVMsU0FBVSxVQUFVLGFBQWEsZ0JBQWdCO0lBQ3hELFlBQ0UsVUFDQSxXQUFZO0tBQ1YsWUFBWSxNQUFNLE1BQU0sU0FBUztJQUNuQyxHQUNBLGNBQ0Y7R0FDRjtHQUNBLE9BQU8sU0FBVSxVQUFVO0lBQ3pCLElBQUksSUFBSTtJQUNSLFlBQVksVUFBVSxXQUFZO0tBQ2hDO0lBQ0YsQ0FBQztJQUNELE9BQU87R0FDVDtHQUNBLFNBQVMsU0FBVSxVQUFVO0lBQzNCLE9BQ0UsWUFBWSxVQUFVLFNBQVUsT0FBTztLQUNyQyxPQUFPO0lBQ1QsQ0FBQyxLQUFLLENBQUM7R0FFWDtHQUNBLE1BQU0sU0FBVSxVQUFVO0lBQ3hCLElBQUksQ0FBQyxlQUFlLFFBQVEsR0FDMUIsTUFBTSxNQUNKLHVFQUNGO0lBQ0YsT0FBTztHQUNUO0VBQ0Y7RUFDQSxRQUFRLFdBQVc7RUFDbkIsUUFBUSxXQUFXO0VBQ25CLFFBQVEsWUFBWTtFQUNwQixRQUFRLFdBQVc7RUFDbkIsUUFBUSxXQUFXO0VBQ25CLFFBQVEsZ0JBQWdCO0VBQ3hCLFFBQVEsYUFBYTtFQUNyQixRQUFRLFdBQVc7RUFDbkIsUUFBUSxrRUFDTjtFQUNGLFFBQVEscUJBQXFCO0VBQzdCLFFBQVEsTUFBTSxTQUFVLFVBQVU7R0FDaEMsSUFBSSxlQUFlLHFCQUFxQixVQUN0QyxvQkFBb0I7R0FDdEI7R0FDQSxJQUFJLFFBQVMscUJBQXFCLFdBQzlCLFNBQVMsZUFBZSxlQUFlLENBQUMsR0FDMUMsa0JBQWtCLENBQUM7R0FDckIsSUFBSTtJQUNGLElBQUksU0FBUyxTQUFTO0dBQ3hCLFNBQVMsT0FBTztJQUNkLHFCQUFxQixhQUFhLEtBQUssS0FBSztHQUM5QztHQUNBLElBQUksSUFBSSxxQkFBcUIsYUFBYSxRQUN4QyxNQUNHLFlBQVksY0FBYyxpQkFBaUIsR0FDM0MsV0FBVyxnQkFBZ0IscUJBQXFCLFlBQVksR0FDNUQscUJBQXFCLGFBQWEsU0FBUyxHQUM1QztHQUVKLElBQ0UsU0FBUyxVQUNULGFBQWEsT0FBTyxVQUNwQixlQUFlLE9BQU8sT0FBTyxNQUM3QjtJQUNBLElBQUksV0FBVztJQUNmLHVCQUF1QixXQUFZO0tBQ2pDLG1CQUNFLHNCQUNFLG9CQUFvQixDQUFDLEdBQ3ZCLFFBQVEsTUFDTixtTUFDRjtJQUNKLENBQUM7SUFDRCxPQUFPLEVBQ0wsTUFBTSxTQUFVLFNBQVMsUUFBUTtLQUMvQixrQkFBa0IsQ0FBQztLQUNuQixTQUFTLEtBQ1AsU0FBVSxhQUFhO01BQ3JCLFlBQVksY0FBYyxpQkFBaUI7TUFDM0MsSUFBSSxNQUFNLG1CQUFtQjtPQUMzQixJQUFJO1FBQ0YsY0FBYyxLQUFLLEdBQ2pCLFlBQVksV0FBWTtTQUN0QixPQUFPLDZCQUNMLGFBQ0EsU0FDQSxNQUNGO1FBQ0YsQ0FBQztPQUNMLFNBQVMsU0FBUztRQUNoQixxQkFBcUIsYUFBYSxLQUFLLE9BQU87T0FDaEQ7T0FDQSxJQUFJLElBQUkscUJBQXFCLGFBQWEsUUFBUTtRQUNoRCxJQUFJLGVBQWUsZ0JBQ2pCLHFCQUFxQixZQUN2QjtRQUNBLHFCQUFxQixhQUFhLFNBQVM7UUFDM0MsT0FBTyxZQUFZO09BQ3JCO01BQ0YsT0FBTyxRQUFRLFdBQVc7S0FDNUIsR0FDQSxTQUFVLE9BQU87TUFDZixZQUFZLGNBQWMsaUJBQWlCO01BQzNDLElBQUkscUJBQXFCLGFBQWEsVUFDaEMsUUFBUSxnQkFDUixxQkFBcUIsWUFDdkIsR0FDQyxxQkFBcUIsYUFBYSxTQUFTLEdBQzVDLE9BQU8sS0FBSyxLQUNaLE9BQU8sS0FBSztLQUNsQixDQUNGO0lBQ0YsRUFDRjtHQUNGO0dBQ0EsSUFBSSx1QkFBdUI7R0FDM0IsWUFBWSxjQUFjLGlCQUFpQjtHQUMzQyxNQUFNLHNCQUNILGNBQWMsS0FBSyxHQUNwQixNQUFNLE1BQU0sVUFDVix1QkFBdUIsV0FBWTtJQUNqQyxtQkFDRSxzQkFDRSxvQkFBb0IsQ0FBQyxHQUN2QixRQUFRLE1BQ04scU1BQ0Y7R0FDSixDQUFDLEdBQ0YscUJBQXFCLFdBQVc7R0FDbkMsSUFBSSxJQUFJLHFCQUFxQixhQUFhLFFBQ3hDLE1BQ0ksV0FBVyxnQkFBZ0IscUJBQXFCLFlBQVksR0FDN0QscUJBQXFCLGFBQWEsU0FBUyxHQUM1QztHQUVKLE9BQU8sRUFDTCxNQUFNLFNBQVUsU0FBUyxRQUFRO0lBQy9CLGtCQUFrQixDQUFDO0lBQ25CLE1BQU0scUJBQ0EscUJBQXFCLFdBQVcsT0FDbEMsWUFBWSxXQUFZO0tBQ3RCLE9BQU8sNkJBQ0wsc0JBQ0EsU0FDQSxNQUNGO0lBQ0YsQ0FBQyxLQUNELFFBQVEsb0JBQW9CO0dBQ2xDLEVBQ0Y7RUFDRjtFQUNBLFFBQVEsUUFBUSxTQUFVLElBQUk7R0FDNUIsT0FBTyxXQUFZO0lBQ2pCLE9BQU8sR0FBRyxNQUFNLE1BQU0sU0FBUztHQUNqQztFQUNGO0VBQ0EsUUFBUSxjQUFjLFdBQVk7R0FDaEMsT0FBTztFQUNUO0VBQ0EsUUFBUSxvQkFBb0IsV0FBWTtHQUN0QyxJQUFJLGtCQUFrQixxQkFBcUI7R0FDM0MsT0FBTyxTQUFTLGtCQUFrQixPQUFPLGdCQUFnQjtFQUMzRDtFQUNBLFFBQVEsZUFBZSxTQUFVLFNBQVMsUUFBUSxVQUFVO0dBQzFELElBQUksU0FBUyxXQUFXLEtBQUssTUFBTSxTQUNqQyxNQUFNLE1BQ0osMERBQ0UsVUFDQSxHQUNKO0dBQ0YsSUFBSSxRQUFRLE9BQU8sQ0FBQyxHQUFHLFFBQVEsS0FBSyxHQUNsQyxNQUFNLFFBQVEsS0FDZCxRQUFRLFFBQVE7R0FDbEIsSUFBSSxRQUFRLFFBQVE7SUFDbEIsSUFBSTtJQUNKLEdBQUc7S0FDRCxJQUNFLGVBQWUsS0FBSyxRQUFRLEtBQUssTUFDaEMsMkJBQTJCLE9BQU8seUJBQ2pDLFFBQ0EsS0FDRixDQUFDLENBQUMsUUFDRix5QkFBeUIsZ0JBQ3pCO01BQ0EsMkJBQTJCLENBQUM7TUFDNUIsTUFBTTtLQUNSO0tBQ0EsMkJBQTJCLEtBQUssTUFBTSxPQUFPO0lBQy9DO0lBQ0EsNkJBQTZCLFFBQVEsU0FBUztJQUM5QyxZQUFZLE1BQU0sTUFDZix1QkFBdUIsT0FBTyxHQUFHLEdBQUksTUFBTSxLQUFLLE9BQU87SUFDMUQsS0FBSyxZQUFZLFFBQ2YsQ0FBQyxlQUFlLEtBQUssUUFBUSxRQUFRLEtBQ25DLFVBQVUsWUFDVixhQUFhLFlBQ2IsZUFBZSxZQUNkLFVBQVUsWUFBWSxLQUFLLE1BQU0sT0FBTyxRQUN4QyxNQUFNLFlBQVksT0FBTztHQUNoQztHQUNBLElBQUksV0FBVyxVQUFVLFNBQVM7R0FDbEMsSUFBSSxNQUFNLFVBQVUsTUFBTSxXQUFXO1FBQ2hDLElBQUksSUFBSSxVQUFVO0lBQ3JCLDJCQUEyQixNQUFNLFFBQVE7SUFDekMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsS0FDNUIseUJBQXlCLEtBQUssVUFBVSxJQUFJO0lBQzlDLE1BQU0sV0FBVztHQUNuQjtHQUNBLFFBQVEsYUFDTixRQUFRLE1BQ1IsS0FDQSxPQUNBLE9BQ0EsUUFBUSxhQUNSLFFBQVEsVUFDVjtHQUNBLEtBQUssTUFBTSxHQUFHLE1BQU0sVUFBVSxRQUFRLE9BQ3BDLGtCQUFrQixVQUFVLElBQUk7R0FDbEMsT0FBTztFQUNUO0VBQ0EsUUFBUSxnQkFBZ0IsU0FBVSxjQUFjO0dBQzlDLGVBQWU7SUFDYixVQUFVO0lBQ1YsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsVUFBVTtJQUNWLFVBQVU7R0FDWjtHQUNBLGFBQWEsV0FBVztHQUN4QixhQUFhLFdBQVc7SUFDdEIsVUFBVTtJQUNWLFVBQVU7R0FDWjtHQUNBLGFBQWEsbUJBQW1CO0dBQ2hDLGFBQWEsb0JBQW9CO0dBQ2pDLE9BQU87RUFDVDtFQUNBLFFBQVEsZ0JBQWdCLFNBQVUsTUFBTSxRQUFRLFVBQVU7R0FDeEQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUNwQyxrQkFBa0IsVUFBVSxFQUFFO0dBQ2hDLElBQUksQ0FBQztHQUNMLElBQUksTUFBTTtHQUNWLElBQUksUUFBUSxRQUNWLEtBQUssWUFBYSw2QkFDaEIsRUFBRSxZQUFZLFdBQ2QsU0FBUyxXQUNQLDRCQUE0QixDQUFDLEdBQy9CLFFBQVEsS0FDTiwrS0FDRixJQUNGLFlBQVksTUFBTSxNQUNmLHVCQUF1QixPQUFPLEdBQUcsR0FBSSxNQUFNLEtBQUssT0FBTyxNQUMxRCxRQUNFLGVBQWUsS0FBSyxRQUFRLFFBQVEsS0FDbEMsVUFBVSxZQUNWLGFBQWEsWUFDYixlQUFlLGFBQ2QsRUFBRSxZQUFZLE9BQU87R0FDNUIsSUFBSSxpQkFBaUIsVUFBVSxTQUFTO0dBQ3hDLElBQUksTUFBTSxnQkFBZ0IsRUFBRSxXQUFXO1FBQ2xDLElBQUksSUFBSSxnQkFBZ0I7SUFDM0IsS0FDRSxJQUFJLGFBQWEsTUFBTSxjQUFjLEdBQUcsS0FBSyxHQUM3QyxLQUFLLGdCQUNMLE1BRUEsV0FBVyxNQUFNLFVBQVUsS0FBSztJQUNsQyxPQUFPLFVBQVUsT0FBTyxPQUFPLFVBQVU7SUFDekMsRUFBRSxXQUFXO0dBQ2Y7R0FDQSxJQUFJLFFBQVEsS0FBSyxjQUNmLEtBQUssWUFBYyxpQkFBaUIsS0FBSyxjQUFlLGdCQUN0RCxLQUFLLE1BQU0sRUFBRSxjQUFjLEVBQUUsWUFBWSxlQUFlO0dBQzVELE9BQ0UsMkJBQ0UsR0FDQSxlQUFlLE9BQU8sT0FDbEIsS0FBSyxlQUFlLEtBQUssUUFBUSxZQUNqQyxJQUNOO0dBQ0YsSUFBSSxXQUFXLE1BQU0scUJBQXFCO0dBQzFDLE9BQU8sYUFDTCxNQUNBLEtBQ0EsR0FDQSxTQUFTLEdBQ1QsV0FBVyxNQUFNLHVCQUF1QixJQUFJLHdCQUM1QyxXQUFXLFdBQVcsWUFBWSxJQUFJLENBQUMsSUFBSSxxQkFDN0M7RUFDRjtFQUNBLFFBQVEsWUFBWSxXQUFZO0dBQzlCLElBQUksWUFBWSxFQUFFLFNBQVMsS0FBSztHQUNoQyxPQUFPLEtBQUssU0FBUztHQUNyQixPQUFPO0VBQ1Q7RUFDQSxRQUFRLGFBQWEsU0FBVSxRQUFRO0dBQ3JDLFFBQVEsVUFBVSxPQUFPLGFBQWEsa0JBQ2xDLFFBQVEsTUFDTixxSUFDRixJQUNBLGVBQWUsT0FBTyxTQUNwQixRQUFRLE1BQ04sMkRBQ0EsU0FBUyxTQUFTLFNBQVMsT0FBTyxNQUNwQyxJQUNBLE1BQU0sT0FBTyxVQUNiLE1BQU0sT0FBTyxVQUNiLFFBQVEsTUFDTixnRkFDQSxNQUFNLE9BQU8sU0FDVCw2Q0FDQSw2Q0FDTjtHQUNOLFFBQVEsVUFDTixRQUFRLE9BQU8sZ0JBQ2YsUUFBUSxNQUNOLHVHQUNGO0dBQ0YsSUFBSSxjQUFjO0lBQUUsVUFBVTtJQUFnQztHQUFPLEdBQ25FO0dBQ0YsT0FBTyxlQUFlLGFBQWEsZUFBZTtJQUNoRCxZQUFZLENBQUM7SUFDYixjQUFjLENBQUM7SUFDZixLQUFLLFdBQVk7S0FDZixPQUFPO0lBQ1Q7SUFDQSxLQUFLLFNBQVUsTUFBTTtLQUNuQixVQUFVO0tBQ1YsT0FBTyxRQUNMLE9BQU8sZ0JBQ04sT0FBTyxlQUFlLFFBQVEsUUFBUSxFQUFFLE9BQU8sS0FBSyxDQUFDLEdBQ3JELE9BQU8sY0FBYztJQUMxQjtHQUNGLENBQUM7R0FDRCxPQUFPO0VBQ1Q7RUFDQSxRQUFRLGlCQUFpQjtFQUN6QixRQUFRLE9BQU8sU0FBVSxNQUFNO0dBQzdCLE9BQU87SUFBRSxTQUFTO0lBQUksU0FBUztHQUFLO0dBQ3BDLElBQUksV0FBVztJQUNYLFVBQVU7SUFDVixVQUFVO0lBQ1YsT0FBTztHQUNULEdBQ0EsU0FBUztJQUNQLE1BQU07SUFDTixPQUFPO0lBQ1AsS0FBSztJQUNMLE9BQU87SUFDUCxPQUFPO0lBQ1AsWUFBWSxNQUFNLHVCQUF1QjtJQUN6QyxXQUFXLFFBQVEsYUFBYSxRQUFRLFdBQVcsUUFBUSxJQUFJO0dBQ2pFO0dBQ0YsS0FBSyxVQUFVO0dBQ2YsU0FBUyxhQUFhLENBQUMsRUFBRSxTQUFTLE9BQU8sQ0FBQztHQUMxQyxPQUFPO0VBQ1Q7RUFDQSxRQUFRLE9BQU8sU0FBVSxNQUFNLFNBQVM7R0FDdEMsUUFDRSxRQUFRLE1BQ04sc0VBQ0EsU0FBUyxPQUFPLFNBQVMsT0FBTyxJQUNsQztHQUNGLFVBQVU7SUFDUixVQUFVO0lBQ0o7SUFDTixTQUFTLEtBQUssTUFBTSxVQUFVLE9BQU87R0FDdkM7R0FDQSxJQUFJO0dBQ0osT0FBTyxlQUFlLFNBQVMsZUFBZTtJQUM1QyxZQUFZLENBQUM7SUFDYixjQUFjLENBQUM7SUFDZixLQUFLLFdBQVk7S0FDZixPQUFPO0lBQ1Q7SUFDQSxLQUFLLFNBQVUsTUFBTTtLQUNuQixVQUFVO0tBQ1YsS0FBSyxRQUNILEtBQUssZ0JBQ0osT0FBTyxlQUFlLE1BQU0sUUFBUSxFQUFFLE9BQU8sS0FBSyxDQUFDLEdBQ25ELEtBQUssY0FBYztJQUN4QjtHQUNGLENBQUM7R0FDRCxPQUFPO0VBQ1Q7RUFDQSxRQUFRLGtCQUFrQixTQUFVLE9BQU87R0FDekMsSUFBSSxpQkFBaUIscUJBQXFCLEdBQ3hDLG9CQUFvQixDQUFDO0dBQ3ZCLGtCQUFrQixpQ0FBaUIsSUFBSSxJQUFJO0dBQzNDLHFCQUFxQixJQUFJO0dBQ3pCLElBQUk7SUFDRixJQUFJLGNBQWMsTUFBTSxHQUN0QiwwQkFBMEIscUJBQXFCO0lBQ2pELFNBQVMsMkJBQ1Asd0JBQXdCLG1CQUFtQixXQUFXO0lBQ3hELGFBQWEsT0FBTyxlQUNsQixTQUFTLGVBQ1QsZUFBZSxPQUFPLFlBQVksU0FDakMscUJBQXFCLG9CQUN0QixZQUFZLEtBQUssd0JBQXdCLHNCQUFzQixHQUMvRCxZQUFZLEtBQUssTUFBTSxpQkFBaUI7R0FDNUMsU0FBUyxPQUFPO0lBQ2Qsa0JBQWtCLEtBQUs7R0FDekIsVUFBVTtJQUNSLFNBQVMsa0JBQ1Asa0JBQWtCLG1CQUNoQixRQUFRLGtCQUFrQixlQUFlLE1BQzNDLGtCQUFrQixlQUFlLE1BQU0sR0FDdkMsS0FBSyxTQUNILFFBQVEsS0FDTixxTUFDRixJQUNGLFNBQVMsa0JBQ1AsU0FBUyxrQkFBa0IsVUFDMUIsU0FBUyxlQUFlLFNBQ3ZCLGVBQWUsVUFBVSxrQkFBa0IsU0FDM0MsUUFBUSxNQUNOLHNLQUNGLEdBQ0QsZUFBZSxRQUFRLGtCQUFrQixRQUMzQyxxQkFBcUIsSUFBSTtHQUM5QjtFQUNGO0VBQ0EsUUFBUSwyQkFBMkIsV0FBWTtHQUM3QyxPQUFPLGtCQUFrQixDQUFDLENBQUMsZ0JBQWdCO0VBQzdDO0VBQ0EsUUFBUSxNQUFNLFNBQVUsUUFBUTtHQUM5QixPQUFPLGtCQUFrQixDQUFDLENBQUMsSUFBSSxNQUFNO0VBQ3ZDO0VBQ0EsUUFBUSxpQkFBaUIsU0FBVSxRQUFRLGNBQWMsV0FBVztHQUNsRSxPQUFPLGtCQUFrQixDQUFDLENBQUMsZUFDekIsUUFDQSxjQUNBLFNBQ0Y7RUFDRjtFQUNBLFFBQVEsY0FBYyxTQUFVLFVBQVUsTUFBTTtHQUM5QyxPQUFPLGtCQUFrQixDQUFDLENBQUMsWUFBWSxVQUFVLElBQUk7RUFDdkQ7RUFDQSxRQUFRLGFBQWEsU0FBVSxTQUFTO0dBQ3RDLElBQUksYUFBYSxrQkFBa0I7R0FDbkMsUUFBUSxhQUFhLHVCQUNuQixRQUFRLE1BQ04sOEhBQ0Y7R0FDRixPQUFPLFdBQVcsV0FBVyxPQUFPO0VBQ3RDO0VBQ0EsUUFBUSxnQkFBZ0IsU0FBVSxPQUFPLGFBQWE7R0FDcEQsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLGNBQWMsT0FBTyxXQUFXO0VBQzdEO0VBQ0EsUUFBUSxtQkFBbUIsU0FBVSxPQUFPLGNBQWM7R0FDeEQsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLGlCQUFpQixPQUFPLFlBQVk7RUFDakU7RUFDQSxRQUFRLFlBQVksU0FBVSxRQUFRLE1BQU07R0FDMUMsVUFDRSxRQUFRLEtBQ04sa0dBQ0Y7R0FDRixPQUFPLGtCQUFrQixDQUFDLENBQUMsVUFBVSxRQUFRLElBQUk7RUFDbkQ7RUFDQSxRQUFRLGlCQUFpQixTQUFVLFVBQVU7R0FDM0MsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLGVBQWUsUUFBUTtFQUNwRDtFQUNBLFFBQVEsUUFBUSxXQUFZO0dBQzFCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxNQUFNO0VBQ25DO0VBQ0EsUUFBUSxzQkFBc0IsU0FBVSxLQUFLLFFBQVEsTUFBTTtHQUN6RCxPQUFPLGtCQUFrQixDQUFDLENBQUMsb0JBQW9CLEtBQUssUUFBUSxJQUFJO0VBQ2xFO0VBQ0EsUUFBUSxxQkFBcUIsU0FBVSxRQUFRLE1BQU07R0FDbkQsVUFDRSxRQUFRLEtBQ04sMkdBQ0Y7R0FDRixPQUFPLGtCQUFrQixDQUFDLENBQUMsbUJBQW1CLFFBQVEsSUFBSTtFQUM1RDtFQUNBLFFBQVEsa0JBQWtCLFNBQVUsUUFBUSxNQUFNO0dBQ2hELFVBQ0UsUUFBUSxLQUNOLHdHQUNGO0dBQ0YsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLGdCQUFnQixRQUFRLElBQUk7RUFDekQ7RUFDQSxRQUFRLFVBQVUsU0FBVSxRQUFRLE1BQU07R0FDeEMsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFFBQVEsUUFBUSxJQUFJO0VBQ2pEO0VBQ0EsUUFBUSxnQkFBZ0IsU0FBVSxhQUFhLFNBQVM7R0FDdEQsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLGNBQWMsYUFBYSxPQUFPO0VBQy9EO0VBQ0EsUUFBUSxhQUFhLFNBQVUsU0FBUyxZQUFZLE1BQU07R0FDeEQsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFdBQVcsU0FBUyxZQUFZLElBQUk7RUFDakU7RUFDQSxRQUFRLFNBQVMsU0FBVSxjQUFjO0dBQ3ZDLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxPQUFPLFlBQVk7RUFDaEQ7RUFDQSxRQUFRLFdBQVcsU0FBVSxjQUFjO0dBQ3pDLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxTQUFTLFlBQVk7RUFDbEQ7RUFDQSxRQUFRLHVCQUF1QixTQUM3QixXQUNBLGFBQ0EsbUJBQ0E7R0FDQSxPQUFPLGtCQUFrQixDQUFDLENBQUMscUJBQ3pCLFdBQ0EsYUFDQSxpQkFDRjtFQUNGO0VBQ0EsUUFBUSxnQkFBZ0IsV0FBWTtHQUNsQyxPQUFPLGtCQUFrQixDQUFDLENBQUMsY0FBYztFQUMzQztFQUNBLFFBQVEsVUFBVTtFQUNsQixnQkFBZ0IsT0FBTyxrQ0FDckIsZUFDRSxPQUFPLCtCQUErQiw4QkFDeEMsK0JBQStCLDJCQUEyQixNQUFNLENBQUM7Q0FDckUsRUFBQSxDQUFHOzs7OztDQzl2Q0gsT0FBTyxVQUFBLDBCQUFBIn0=