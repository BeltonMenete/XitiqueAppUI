import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/business/RegisterCollectorModal.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03f72e91";
import { X, Phone, Mail, User, CheckCircle2, Camera } from "/node_modules/.vite/deps/lucide-react.js?v=03f72e91";
import { Modal, ModalFooter } from "/src/components/ui/Modal.tsx";
import { Button } from "/src/components/ui/Button.tsx";
var _jsxFileName = "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/RegisterCollectorModal.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03f72e91";
var _s = $RefreshSig$();
export function RegisterCollectorModal({ isOpen, onClose, onSubmit }) {
	_s();
	const [formData, setFormData] = useState({
		name: "",
		phone: "",
		email: "",
		observations: "",
		isActive: true
	});
	const [showToast, setShowToast] = useState(false);
	const handleSubmit = (e) => {
		e.preventDefault();
		onSubmit(formData);
		setShowToast(true);
		setTimeout(() => {
			setShowToast(false);
			onClose();
		}, 3e3);
	};
	const handleCancel = () => {
		setFormData({
			name: "",
			phone: "",
			email: "",
			observations: "",
			isActive: true
		});
		onClose();
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Modal, {
		isOpen,
		onClose: handleCancel,
		title: "Registar Cobrador",
		"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:54:7",
		children: [/* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			className: "space-4",
			"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:55:9",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col items-center justify-center mb-4",
					"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:57:11",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-24 h-24 rounded-full bg-slate-100 flex items-center justify-center border-2 border-dashed border-slate-300 cursor-pointer hover:border-emerald-500 transition-colors relative overflow-hidden group",
						"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:58:13",
						children: /* @__PURE__ */ _jsxDEV(Camera, {
							className: "text-slate-400 text-3xl group-hover:text-emerald-500 transition-colors",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:59:15"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-sm text-slate-500 mt-2",
						"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:61:13",
						children: "Adicionar Foto"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:65:11",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "name",
						className: "block text-sm font-medium text-slate-700 mb-1",
						"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:66:13",
						children: ["Nome completo ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-red-500",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:67:29",
							children: "*"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "relative",
						"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:69:13",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:70:15",
							children: /* @__PURE__ */ _jsxDEV(User, {
								className: "text-slate-400",
								size: 18,
								"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:71:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							id: "name",
							type: "text",
							placeholder: "Ex: João Silva",
							required: true,
							value: formData.name,
							onChange: (e) => setFormData({
								...formData,
								name: e.target.value
							}),
							className: "block w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:73:15"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:86:11",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "phone",
						className: "block text-sm font-medium text-slate-700 mb-1",
						"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:87:13",
						children: ["Telefone ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-red-500",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:88:24",
							children: "*"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 24
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 87,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex border border-slate-200 rounded-lg overflow-hidden focus-within:ring-2 focus-within:ring-emerald-500/20 focus-within:border-emerald-500 transition-colors bg-white",
						"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:90:13",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-100 px-3 py-2 flex items-center border-r border-slate-200",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:91:15",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono text-slate-500",
								"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:92:17",
								children: "+258"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "relative flex-1",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:94:15",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",
								"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:95:17",
								children: /* @__PURE__ */ _jsxDEV(Phone, {
									className: "text-slate-400",
									size: 18,
									"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:96:19"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 96,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								id: "phone",
								type: "tel",
								placeholder: "8X XXX XXXX",
								required: true,
								value: formData.phone,
								onChange: (e) => setFormData({
									...formData,
									phone: e.target.value
								}),
								className: "block w-full pl-10 pr-3 py-2 bg-transparent border-none focus:ring-0 font-mono text-slate-900 placeholder:text-slate-400 outline-none",
								"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:98:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:112:11",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "email",
						className: "block text-sm font-medium text-slate-700 mb-1",
						"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:113:13",
						children: ["Email ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:114:21",
							children: "(Opcional)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 21
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "relative",
						"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:116:13",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:117:15",
							children: /* @__PURE__ */ _jsxDEV(Mail, {
								className: "text-slate-400",
								size: 18,
								"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:118:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 118,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							id: "email",
							type: "email",
							placeholder: "exemplo@email.com",
							value: formData.email,
							onChange: (e) => setFormData({
								...formData,
								email: e.target.value
							}),
							className: "block w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:120:15"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:132:11",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "observations",
						className: "block text-sm font-medium text-slate-700 mb-1",
						"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:133:13",
						children: ["Observações ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:134:27",
							children: "(Opcional)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 27
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("textarea", {
						id: "observations",
						placeholder: "Trabalha região X...",
						rows: 2,
						value: formData.observations,
						onChange: (e) => setFormData({
							...formData,
							observations: e.target.value
						}),
						className: "block w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 resize-none",
						"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:136:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pt-2 border-t border-slate-200",
					"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:147:11",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:148:13",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-sm font-medium text-slate-900",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:149:15",
							children: "Status do Cobrador"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:150:15",
							children: "Define se o cobrador pode aceder à App"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 150,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("label", {
						className: "relative inline-flex items-center cursor-pointer",
						"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:152:13",
						children: [
							/* @__PURE__ */ _jsxDEV("input", {
								type: "checkbox",
								checked: formData.isActive,
								onChange: (e) => setFormData({
									...formData,
									isActive: e.target.checked
								}),
								className: "sr-only peer",
								"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:153:15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600",
								"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:159:15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 159,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "ml-3 text-xs font-medium text-slate-600 peer-checked:text-emerald-600",
								"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:160:15",
								children: "Ativo"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 147,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV(ModalFooter, {
			"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:167:9",
			children: [/* @__PURE__ */ _jsxDEV(Button, {
				variant: "outline",
				onClick: handleCancel,
				"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:168:11",
				children: "Cancelar"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 168,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV(Button, {
				type: "submit",
				onClick: handleSubmit,
				leftIcon: /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 16 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 171,
					columnNumber: 66
				}, this),
				"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:171:11",
				children: "Salvar"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 171,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 167,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 54,
		columnNumber: 7
	}, this), showToast && /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed bottom-6 right-6 bg-white border-l-4 border-emerald-500 shadow-lg rounded-lg p-4 transform transition-all duration-300 z-50 flex items-start gap-4 max-w-sm",
		"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:179:9",
		children: [
			/* @__PURE__ */ _jsxDEV(CheckCircle2, {
				className: "text-emerald-500 fill mt-0.5",
				size: 20,
				"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:180:11"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 180,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1",
				"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:181:11",
				children: [/* @__PURE__ */ _jsxDEV("h4", {
					className: "text-sm font-medium text-slate-900",
					"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:182:13",
					children: "Cobrador criado com sucesso"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 182,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500 mt-1",
					"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:183:13",
					children: [
						"Um SMS foi enviado para o telefone com o PIN de acesso: ",
						/* @__PURE__ */ _jsxDEV("span", {
							className: "font-mono font-bold text-slate-900",
							"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:184:71",
							children: "1234"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 184,
							columnNumber: 71
						}, this),
						"."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 183,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 181,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: () => setShowToast(false),
				className: "text-slate-400 hover:text-slate-600 transition-colors",
				"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:187:11",
				children: /* @__PURE__ */ _jsxDEV(X, {
					size: 16,
					"data-tsd-source": "/src/components/business/RegisterCollectorModal.tsx:192:13"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 192,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 187,
				columnNumber: 11
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 179,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 53,
		columnNumber: 5
	}, this);
}
_s(RegisterCollectorModal, "I2+gWWpMUNxsvQLDNxMK0sHA11U=");
_c = RegisterCollectorModal;
var _c;
$RefreshReg$(_c, "RegisterCollectorModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/business/RegisterCollectorModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/RegisterCollectorModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/RegisterCollectorModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/zelto/OneDrive/Documentos/GitHub/XitiqueAppUI/src/components/business/RegisterCollectorModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFnQkE7O0NBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0E7Q0FFQTtDQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7R0FDQTtHQUNBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0E7RUFDQTtDQUNBO0NBRUEsT0FDQSxnREFDQTtFQUFBO0VBQUE7RUFBQTtFQUFBO1lBQUEsQ0FDQTtHQUFBO0dBQUE7R0FBQTthQUFBO0lBRUE7S0FBQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO01BQUE7Z0JBQ0E7T0FBQTtPQUFBO01BQXlHOzs7OztLQUN6Rzs7OztlQUNBO01BQUE7TUFBQTtnQkFBeUQ7S0FBQTs7OzthQUN6RDs7Ozs7O0lBR0E7S0FBQTtlQUFBLENBQ0E7TUFBQTtNQUFBO01BQUE7Z0JBQUEsQ0FBMkYsa0JBQzNGO09BQUE7T0FBQTtpQkFBMEQ7TUFBQTs7OztjQUMxRDs7Ozs7ZUFDQTtNQUFBO01BQUE7Z0JBQUEsQ0FDQTtPQUFBO09BQUE7aUJBQ0E7UUFBQTtRQUFBO1FBQUE7T0FBMkQ7Ozs7O01BQzNEOzs7O2dCQUNBO09BQ0E7T0FDQTtPQUNBO09BQ0E7T0FDQTtPQUNBO1FBQUE7UUFBQTtPQUFBO09BQ0E7T0FDQTtNQUFjOzs7O2NBQ2Q7Ozs7O2FBQ0E7Ozs7OztJQUdBO0tBQUE7ZUFBQSxDQUNBO01BQUE7TUFBQTtNQUFBO2dCQUFBLENBQTRGLGFBQzVGO09BQUE7T0FBQTtpQkFBcUQ7TUFBQTs7OztjQUNyRDs7Ozs7ZUFDQTtNQUFBO01BQUE7Z0JBQUEsQ0FDQTtPQUFBO09BQUE7aUJBQ0E7UUFBQTtRQUFBO2tCQUEwRDtPQUFBOzs7OztNQUMxRDs7OztnQkFDQTtPQUFBO09BQUE7aUJBQUEsQ0FDQTtRQUFBO1FBQUE7a0JBQ0E7U0FBQTtTQUFBO1NBQUE7UUFBOEQ7Ozs7O09BQzlEOzs7O2lCQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1NBQUE7U0FBQTtRQUFBO1FBQ0E7UUFDQTtPQUFnQjs7OztlQUNoQjs7Ozs7Y0FDQTs7Ozs7YUFDQTs7Ozs7O0lBR0E7S0FBQTtlQUFBLENBQ0E7TUFBQTtNQUFBO01BQUE7Z0JBQUEsQ0FBNEYsVUFDNUY7T0FBQTtPQUFBO2lCQUFvRDtNQUFBOzs7O2NBQ3BEOzs7OztlQUNBO01BQUE7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtpQkFDQTtRQUFBO1FBQUE7UUFBQTtPQUEyRDs7Ozs7TUFDM0Q7Ozs7Z0JBQ0E7T0FDQTtPQUNBO09BQ0E7T0FDQTtPQUNBO1FBQUE7UUFBQTtPQUFBO09BQ0E7T0FDQTtNQUFjOzs7O2NBQ2Q7Ozs7O2FBQ0E7Ozs7OztJQUdBO0tBQUE7ZUFBQSxDQUNBO01BQUE7TUFBQTtNQUFBO2dCQUFBLENBQW1HLGdCQUNuRztPQUFBO09BQUE7aUJBQTBEO01BQUE7Ozs7Y0FDMUQ7Ozs7O2VBQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO09BQUE7T0FBQTtNQUFBO01BQ0E7TUFDQTtLQUFZOzs7O2FBQ1o7Ozs7OztJQUdBO0tBQUE7S0FBQTtlQUFBLENBQ0E7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtpQkFBa0U7TUFBQTs7OztnQkFDbEU7T0FBQTtPQUFBO2lCQUFtRDtNQUFBOzs7O2NBQ25EOzs7OztlQUNBO01BQUE7TUFBQTtnQkFBQTtPQUNBO1FBQ0E7UUFDQTtRQUNBO1NBQUE7U0FBQTtRQUFBO1FBQ0E7UUFDQTtPQUFjOzs7OztPQUNkO1FBQUE7UUFBQTtPQUFpWDs7Ozs7T0FDalg7UUFBQTtRQUFBO2tCQUFxRztPQUVyRzs7Ozs7TUFDQTs7Ozs7YUFDQTs7Ozs7O0dBQ0E7Ozs7O1lBRUE7R0FBQTthQUFBLENBQ0E7SUFBQTtJQUFBO0lBQUE7Y0FBMEQ7R0FFMUQ7Ozs7YUFDQTtJQUFBO0lBQUE7SUFBQTs7Ozs7SUFBQTtjQUE0RjtHQUU1Rjs7OztXQUNBOzs7OztVQUNBOzs7OztXQUdBLGFBQ0E7RUFBQTtFQUFBO1lBQUE7R0FDQTtJQUFBO0lBQUE7SUFBQTtHQUEyRTs7Ozs7R0FDM0U7SUFBQTtJQUFBO2NBQUEsQ0FDQTtLQUFBO0tBQUE7ZUFBOEQ7SUFBQTs7OztjQUM5RDtLQUFBO0tBQUE7ZUFBQTtNQUFzRDtNQUN0RDtPQUFBO09BQUE7aUJBQTBIO01BQUE7Ozs7O01BQUE7S0FDMUg7Ozs7O1lBQ0E7Ozs7OztHQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7Y0FDQTtLQUFBO0tBQUE7SUFBeUI7Ozs7O0dBQ3pCOzs7OztFQUNBOzs7OztTQUVBOzs7OztBQUVBIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZWdpc3RlckNvbGxlY3Rvck1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFgsIFBob25lLCBNYWlsLCBVc2VyLCBDaGVja0NpcmNsZTIsIENhbWVyYSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBNb2RhbCwgTW9kYWxGb290ZXIgfSBmcm9tICcjL2NvbXBvbmVudHMvdWkvTW9kYWwnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnIy9jb21wb25lbnRzL3VpL0J1dHRvbic7XG5cbmludGVyZmFjZSBSZWdpc3RlckNvbGxlY3Rvck1vZGFsUHJvcHMge1xuICBpc09wZW46IGJvb2xlYW47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIG9uU3VibWl0OiAoZGF0YTogQ29sbGVjdG9yRGF0YSkgPT4gdm9pZDtcbn1cblxuaW50ZXJmYWNlIENvbGxlY3RvckRhdGEge1xuICBuYW1lOiBzdHJpbmc7XG4gIHBob25lOiBzdHJpbmc7XG4gIGVtYWlsPzogc3RyaW5nO1xuICBvYnNlcnZhdGlvbnM/OiBzdHJpbmc7XG4gIGlzQWN0aXZlOiBib29sZWFuO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gUmVnaXN0ZXJDb2xsZWN0b3JNb2RhbCh7IGlzT3Blbiwgb25DbG9zZSwgb25TdWJtaXQgfTogUmVnaXN0ZXJDb2xsZWN0b3JNb2RhbFByb3BzKSB7XG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGU8Q29sbGVjdG9yRGF0YT4oe1xuICAgIG5hbWU6ICcnLFxuICAgIHBob25lOiAnJyxcbiAgICBlbWFpbDogJycsXG4gICAgb2JzZXJ2YXRpb25zOiAnJyxcbiAgICBpc0FjdGl2ZTogdHJ1ZSxcbiAgfSk7XG5cbiAgY29uc3QgW3Nob3dUb2FzdCwgc2V0U2hvd1RvYXN0XSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIG9uU3VibWl0KGZvcm1EYXRhKTtcbiAgICBzZXRTaG93VG9hc3QodHJ1ZSk7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXRTaG93VG9hc3QoZmFsc2UpO1xuICAgICAgb25DbG9zZSgpO1xuICAgIH0sIDMwMDApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNhbmNlbCA9ICgpID0+IHtcbiAgICBzZXRGb3JtRGF0YSh7XG4gICAgICBuYW1lOiAnJyxcbiAgICAgIHBob25lOiAnJyxcbiAgICAgIGVtYWlsOiAnJyxcbiAgICAgIG9ic2VydmF0aW9uczogJycsXG4gICAgICBpc0FjdGl2ZTogdHJ1ZSxcbiAgICB9KTtcbiAgICBvbkNsb3NlKCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPE1vZGFsIGlzT3Blbj17aXNPcGVufSBvbkNsb3NlPXtoYW5kbGVDYW5jZWx9IHRpdGxlPVwiUmVnaXN0YXIgQ29icmFkb3JcIj5cbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UtNFwiPlxuICAgICAgICAgIHsvKiBQaG90byBVcGxvYWQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMjQgaC0yNCByb3VuZGVkLWZ1bGwgYmctc2xhdGUtMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTMwMCBjdXJzb3ItcG9pbnRlciBob3Zlcjpib3JkZXItZW1lcmFsZC01MDAgdHJhbnNpdGlvbi1jb2xvcnMgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIGdyb3VwXCI+XG4gICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC0zeGwgZ3JvdXAtaG92ZXI6dGV4dC1lbWVyYWxkLTUwMCB0cmFuc2l0aW9uLWNvbG9yc1wiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS01MDAgbXQtMlwiPkFkaWNpb25hciBGb3RvPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIE5hbWUgSW5wdXQgKi99XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibmFtZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICBOb21lIGNvbXBsZXRvIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcGwtMyBmbGV4IGl0ZW1zLWNlbnRlciBwb2ludGVyLWV2ZW50cy1ub25lXCI+XG4gICAgICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIiBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXg6IEpvw6NvIFNpbHZhXCJcbiAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5uYW1lfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgbmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHBsLTEwIHByLTMgcHktMiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUGhvbmUgSW5wdXQgKi99XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGhvbmVcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgVGVsZWZvbmUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBvdmVyZmxvdy1oaWRkZW4gZm9jdXMtd2l0aGluOnJpbmctMiBmb2N1cy13aXRoaW46cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1cy13aXRoaW46Ym9yZGVyLWVtZXJhbGQtNTAwIHRyYW5zaXRpb24tY29sb3JzIGJnLXdoaXRlXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtMTAwIHB4LTMgcHktMiBmbGV4IGl0ZW1zLWNlbnRlciBib3JkZXItciBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtc2xhdGUtNTAwXCI+KzI1ODwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgbGVmdC0wIHBsLTMgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgICAgICAgPFBob25lIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCIgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICBpZD1cInBob25lXCJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCI4WCBYWFggWFhYWFwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBob25lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBwaG9uZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcGwtMTAgcHItMyBweS0yIGJnLXRyYW5zcGFyZW50IGJvcmRlci1ub25lIGZvY3VzOnJpbmctMCBmb250LW1vbm8gdGV4dC1zbGF0ZS05MDAgcGxhY2Vob2xkZXI6dGV4dC1zbGF0ZS00MDAgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEVtYWlsIElucHV0ICovfVxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImVtYWlsXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgICAgICAgIEVtYWlsIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+KE9wY2lvbmFsKTwvc3Bhbj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBwbC0zIGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cbiAgICAgICAgICAgICAgICA8TWFpbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgaWQ9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImV4ZW1wbG9AZW1haWwuY29tXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1haWx9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBlbWFpbDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHBsLTEwIHByLTMgcHktMiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogT2JzZXJ2YXRpb25zICovfVxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm9ic2VydmF0aW9uc1wiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICBPYnNlcnZhw6fDtWVzIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+KE9wY2lvbmFsKTwvc3Bhbj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgaWQ9XCJvYnNlcnZhdGlvbnNcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlRyYWJhbGhhIHJlZ2nDo28gWC4uLlwiXG4gICAgICAgICAgICAgIHJvd3M9ezJ9XG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5vYnNlcnZhdGlvbnN9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgb2JzZXJ2YXRpb25zOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDAgcmVzaXplLW5vbmVcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBTdGF0dXMgVG9nZ2xlICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTkwMFwiPlN0YXR1cyBkbyBDb2JyYWRvcjwvc3Bhbj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPkRlZmluZSBzZSBvIGNvYnJhZG9yIHBvZGUgYWNlZGVyIMOgIEFwcDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInJlbGF0aXZlIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmlzQWN0aXZlfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgaXNBY3RpdmU6IGUudGFyZ2V0LmNoZWNrZWQgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1zbGF0ZS0zMDAgcGVlci1mb2N1czpvdXRsaW5lLW5vbmUgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLXNsYXRlLTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwIHBlZXItY2hlY2tlZDp0ZXh0LWVtZXJhbGQtNjAwXCI+XG4gICAgICAgICAgICAgICAgQXRpdm9cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgIDxNb2RhbEZvb3Rlcj5cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17aGFuZGxlQ2FuY2VsfT5cbiAgICAgICAgICAgIENhbmNlbGFyXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgb25DbGljaz17aGFuZGxlU3VibWl0fSBsZWZ0SWNvbj17PENoZWNrQ2lyY2xlMiBzaXplPXsxNn0gLz59PlxuICAgICAgICAgICAgU2FsdmFyXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDwvTW9kYWxGb290ZXI+XG4gICAgICA8L01vZGFsPlxuXG4gICAgICB7LyogVG9hc3QgTm90aWZpY2F0aW9uICovfVxuICAgICAge3Nob3dUb2FzdCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgYm90dG9tLTYgcmlnaHQtNiBiZy13aGl0ZSBib3JkZXItbC00IGJvcmRlci1lbWVyYWxkLTUwMCBzaGFkb3ctbGcgcm91bmRlZC1sZyBwLTQgdHJhbnNmb3JtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCB6LTUwIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTQgbWF4LXctc21cIj5cbiAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC01MDAgZmlsbCBtdC0wLjVcIiBzaXplPXsyMH0gLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS05MDBcIj5Db2JyYWRvciBjcmlhZG8gY29tIHN1Y2Vzc288L2g0PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtdC0xXCI+XG4gICAgICAgICAgICAgIFVtIFNNUyBmb2kgZW52aWFkbyBwYXJhIG8gdGVsZWZvbmUgY29tIG8gUElOIGRlIGFjZXNzbzogPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPjEyMzQ8L3NwYW4+LlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1RvYXN0KGZhbHNlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8WCBzaXplPXsxNn0gLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy96ZWx0by9PbmVEcml2ZS9Eb2N1bWVudG9zL0dpdEh1Yi9YaXRpcXVlQXBwVUkvc3JjL2NvbXBvbmVudHMvYnVzaW5lc3MvUmVnaXN0ZXJDb2xsZWN0b3JNb2RhbC50c3gifQ==